# 1. Issues

> **Latest status:** see [11-seventh-round-react-bindings-and-client-root.md](11-seventh-round-react-bindings-and-client-root.md) and [10-sixth-round-retest-library-4187-lines.md](10-sixth-round-retest-library-4187-lines.md).

> **Status after the library update:** this file describes the library as it was when written. See [08-fourth-round-retest-after-library-update.md](08-fourth-round-retest-after-library-update.md) for what is fixed, what is still present, and what changed.

Each item says how sure I am: **Confirmed** (reproduced in the running app) or **From the code**
(read, reasoned, not run).

---

## 1.1 Snapshot merge updates other components during render — Confirmed

**Symptom.** In the browser console, after client-side navigation (Store lab → Venues):

```
Cannot update a component (`Controls`) while rendering a different component (`VenuesView`).
```

**Where.** `useInstance` (≈ lines 825–844) calls `fromServer(mine.snapshot)` (line 835) while a component
is rendering. For a later page's snapshot, `fromServer` (≈ 781–794) goes to `seedOf(base)(serverData)`,
which runs `seed()` → `apply(...)` and `notify(entryChannel(k))` (≈ 3171–3197). Notifying fires the
`useSyncExternalStore` subscribers of other mounted components (here `Controls`, which reads `sports`)
synchronously, in the middle of another component's render.

**When.** Only on client-side navigation to a page whose `<Root>` carries new server data while a
component that reads the same keys is still mounted. The first load (hydration) did not warn.

**Impact.** A dev-mode React warning; behaviour was correct in every test. It could matter under
concurrent rendering, where a render may be thrown away after the store was already changed.

**Suggestion.** Don't merge during render. Options: merge in `ClientRoot`'s effect only (the
`__mergeSnapshot` export already exists for that), and have `useInstance` read the snapshot without
applying it; or schedule the `notify` calls in a microtask / `queueMicrotask`.

---

## 1.2 `./react-bindings` is missing and its contract is implicit — Confirmed

**Symptom.** `createStore.ts` does not compile on its own: it imports
`createContext, createElement, useCallback, useContext, useEffect, useRef, useSyncExternalStore, RSC, cache, ClientRoot`
from `./react-bindings` (lines 1–14), and no such file is in `.store`.

**What I had to infer** (see `05-integration-guide.md`):
- `RSC` must be true only in the Server Component build.
- `cache` must be React's `cache` in Server Components.
- `ClientRoot` must be a `'use client'` component taking `{ name, snapshot, children }`, built on the
  internal exports `__SnapshotContext` and `__mergeSnapshot`, whose shape (`Record<storeName, { snapshot, scope? }>`)
  is only visible by reading `useInstance`.

**Suggestion.** Ship a reference `react-bindings.ts` and `client-root.tsx` next to the library, or document
the contract at the top of `createStore.ts`.

---

## 1.3 `createContext` is called unconditionally, even in Server Components — Confirmed

Line 20 is careful: `RSC ? null : createContext(...)`. But `withScopes` calls
`const Ctx = createContext<Inst | null>(null)` (line 705) with no guard, and `createStore()` runs `withScopes`
in every environment. In React's `react-server` build `createContext` does not exist, so a bindings file that
just re-exports React's `createContext` gives `undefined` and the store throws on import in a Server
Component.

**Workaround used.** `react-bindings.ts` supplies a stand-in context object when `React.createContext` is
missing. It is never rendered there.

**Suggestion.** Guard line 705 the same way as line 20, or create `Ctx` lazily.

---

## 1.4 Reload while an optimistic save is in flight rolls the change back — Confirmed (behaviour), cause inferred

**Repro.** Log in → favourite a venue (a `keyActions` toggle with `save`) → reload the page immediately
(before the ~250 ms request returns). After the reload `favorites` is `[]` instead of `[id]`.

**Why (inferred).** The browser aborts the in-flight `fetch` on navigation; the save promise rejects; the
store treats that like any failed save and rolls back, and persistence writes the rolled-back value during
`pagehide`. I did not check whether the server had already applied the request, so I can't say whether
local and server state ended up different.

**Impact.** A user who saves and then leaves the page quickly can lose a change that may have succeeded on
the server.

**Suggestion.** Distinguish "the page is going away" from a real failure (e.g. don't roll back or persist
when `document.visibilityState === 'hidden'`/`pagehide` fired), or document the behaviour.
Waiting for the save to finish (it takes one request) made my test pass, so it only affects very fast
navigations.

---

## 1.5 A default `ssr: true` snapshot overwrites persisted state — From the code

**Where.** `snapshot()` (≈ 3782–3825) includes **every** state key unless `ssr: { keys }` or
`ssr: { exclude }` is set. In the browser `hydrate()` → `seed()` writes those values with
`apply(fresh, 'hydrate', ...)` (≈ 3183–3190), and sets `initialValues[k]` too.

**Consequence.** With `persist` and plain `ssr: true`, the server's snapshot carries the server's *initial*
values (`city: 'Bengaluru'`, `token: null`, `favorites: []`), and hydration would replace what the browser
had just loaded from localStorage — a logged-in user appears logged out on every full page load.

**What I did.** I never ran the default; I set `ssr: { keys: [...] }` to public server data only
(`store/ssr.ts`), which avoids it. This is from reading the code.

**Suggestion.** Make `persist`ed keys (and `syncTabs`-only/secret keys) excluded from snapshots by default,
or have `seed()` skip keys the browser already restored from storage. At minimum, document it next to
`ssr`.

---

## 1.6 `query()` without `initial` starts as `[]` for any return type — From the code

Line 1112: `values[key] = 'initial' in q.options ? q.options.initial : [];`

The type of the key is the query's result type `T` (or `R` with `select`), but before the first response
its value is `[]`. For a query that returns an object, e.g. `query(() => fetchUser())` with `T = User`, the
first render sees `[]` typed as `User`: `user.name` is `undefined`, and `user.items.map` would throw.
The doc comment on `QueryOptions.initial` says "default: []", so it is intended, but the typing doesn't
reflect it.

I did not hit this because my only no-params query (`sports`) returns an array.

**Suggestion.** Type the value as `T | undefined` unless `initial` is given, or make `initial` required for
non-array results.

---

## 1.7 `shared: true` logs a warning on the server even where it's harmless — Confirmed

`makeBase` (≈ line 596–604) warns on every server evaluation. With `shared: typeof window !== 'undefined'`
the warning goes away, which is what I used. It showed up once per build worker (`next build`) and on
each dev-server module evaluation.

**Suggestion.** Warn once, or skip the warning when `ssr: true` is set (that case is already guarded).

---

## 1.8 Small code smells (low priority)

- Line 649 `void base;` — `serverComponentStore` takes `base` and doesn't use it.
- `keyOf.tooLarge` (line 963) is assigned to a hoisted function declaration before the function appears
  in the file; it works, but reads like a mistake.
- `hydrate()` declares `const unknown: string[]` (≈ line 763), a local named like the TypeScript type.
  Legal, but confusing next to `as unknown as ...` casts a few lines away.
