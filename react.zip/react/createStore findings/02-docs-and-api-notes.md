# 2. Docs, messages and API ergonomics

> **Latest status:** see [11-seventh-round-react-bindings-and-client-root.md](11-seventh-round-react-bindings-and-client-root.md) and [10-sixth-round-retest-library-4187-lines.md](10-sixth-round-retest-library-4187-lines.md).

> **Status after the library update:** this file describes the library as it was when written. See [08-fourth-round-retest-after-library-update.md](08-fourth-round-retest-after-library-update.md) for what is fixed, what is still present, and what changed.

## 2.1 Error messages that name an option which doesn't exist — Confirmed (read)

`snapshot()` throws, at line 3795 and 3806, text ending in:

> `... or leave it out with ssr: { serialize: [...] }.`

`StoreOptions.ssr` (line 426) accepts `{ keys, exclude, version }`. There is no `serialize`. Someone
following the message will get a type error. Suggest `ssr: { exclude: [...] }` (or `keys`).

The doc comment on `snapshot()` (line ≈ 3778) also says "`ssr.serialize`'s keys".

## 2.2 Doc comments attached to the wrong declaration

- Lines 191–194 ("Why `value` wouldn't come back unchanged from JSON.stringify + JSON.parse…") sit above
  `const MAX_SNAPSHOT_DEPTH`; the function they describe, `notJsonSafe`, is at line 200.
- Lines 259–263 ("A snapshot as text that's safe inside an HTML `<script>` tag…") sit above `dataTagId`
  (line 265); the function they describe, `serializeSnapshot`, is at line 268.

In an editor, hovering `serializeSnapshot` shows no docs, and hovering `dataTagId` shows the wrong ones.

Also in `ScopeApi` (≈ 667–674), two JSDoc blocks are stacked on `hydrate`; the first one is the old
description and the second the new one, so only the second is used.

## 2.3 Computed keys and `useGlobalState` return shapes

`useGlobalState('someComputed')` returns a tuple `[value, undefined, Status]`, the same shape as for any key.
The selector form `useGlobalState((s) => ...)` returns the bare value. I wrote
`const total = app.useGlobalState('total')` four times and used it as a number; TypeScript caught every
one (the tuple isn't assignable to `number`), but it's an easy slip. A doc line next to `computed` would
help ("read with `const [x] = useGlobalState('x')`").

## 2.4 Queries without params need a dummy first argument

The fetch signature is `(params, signal)`, so a no-params query that wants the abort signal has to be
written `query((_: undefined, signal: AbortSignal) => api.sports(signal))`. Without the dummy the signal
arrives as `params`. Related: the "waiting for params" warning (`checkWaiting`) relies on `fn.length`, so a
wrapper or default parameter can change its behaviour.

## 2.5 Typing extracted pieces

Splitting the store into files (state / queries / computed / key-actions / actions) worked, with these notes:

- **`computed` layers outside the `createStore` call lose contextual typing.** `get` must be annotated
  (`StateReader<Values<typeof state & typeof queries>>`). Layer 2 needs the layer-1 result types, but
  `LayerValues` and `AddedValues` are **not exported**; I rebuilt the same mapped type locally. Exporting
  `LayerValues` would remove the copy.
- **`keyActions` extracted into plain objects work** as long as the action arguments are annotated
  (`(current: Selection, venueId: number, date: string) => ...`). `NoExtraKeys` still catches a wrong key.
- **`actions` in separate files** work with a hand-written structural interface (`ActionContext`
  with `token()`, `favorites()`, `batch()`, `emit()`, `fetchQuery()`): the library's
  `StoreApi & ApiSetters` is assignable to it. No casts were needed.
- Strict mode (`strict: true`, TypeScript 5.9) compiled the whole library without errors.
  TypeScript 7.0.2 was not tried.

## 2.6 Things that read well

- Error messages for misuse are specific and say what to do (e.g. "enabled is an option of the hook",
  "`<Root>` needs a scope here", the `queries` option migration message).
- The file's map comment at the top, and the comments explaining *why* (hot reload, per-request stores).
