# 3. What worked (and how it was checked)

Two kinds of check: **self-tests** (16 checks in `/lab`, each on a throwaway store, run in the browser)
and **end-to-end** (13 flows in a real browser against the running app). All passed in the final run.

## Self-tests (`apps/web/src/features/lab/selftest.ts`)

| Check | Result |
| --- | --- |
| `setState` / `getState` / updater function | pass |
| computed values, two layers (layer 2 follows layer 1) | pass |
| `subscribe` reports `key:source` (`a:local`) and stops after unsubscribe | pass |
| `batch` writes persisted state **once** (measured: 1 storage write) | pass |
| `persist` saves, a new store with the same name loads it, `exclude` keeps a key out | pass |
| history `undo` / `undo` / `redo` | pass |
| `keyActions` | pass |
| key action with `save`: success keeps the change, failure **rolls back** | pass |
| `setState(key, value, serverCall)` failing → rolls back | pass |
| `query` params: same params fetched once; `force` refetches; new params fetch | pass |
| `query` retry then success (3 calls) | pass |
| params keyed by value: `{a,b}` and `{b,a}` share an entry | pass |
| typed events: `on` / `emit` / unsubscribe | pass |
| `createScope` is isolated from its store | pass |
| `snapshot` + `serializeSnapshot` leave no raw `<`, `>`, `&` and round-trip | pass |
| `reset()` | pass |

## End-to-end flows

- **Paged query** (`venues`): first page 6 cards, "Load more" → 12, count text from `total`.
- **Per-params cache**: sport filter, city change, going back — each filter is its own entry.
- **`persist`**: city survives reload; no hydration warnings even when the saved city differs from the
  server's default (needs the `useMounted` gating described in `05-integration-guide.md`).
- **`actions` + `batch`** (`login`, `logout`), `me` keyed by token, `waitFor` (slots wait for venue,
  bookings wait for `me`), `enabled`/params `undefined` = waiting.
- **Optimistic entry setters** with server call: book, cancel, join/leave, host a game — shown immediately
  and reconciled by `refetchAfterMutation`.
- **`keyActions` with `save`**: favourite toggle applied at once, `onSaveSuccess` toast on success.
  With the server forced to 503: change appears, then disappears, `onSaveError` toast shows, header
  count returns to its previous value (measured: ♥ 1 → ♥ 2 → ♥ 1).
- **`history`** on the `selection` key: undo/redo change the total and the picked slots.
- **Typed events**: `emit('toast')` / `on('toast')` drive all toasts; `useHistory` drives the buttons.
- **Selectors**: `useGlobalState((s) => ...)` re-renders only when the selected value changes.

## SSR (`ssr: true`, Next.js 16.4 App Router)

- Raw server HTML contains 6 venue cards, the sport chips, and the venue page heading (checked with `curl`).
- `await app.fetchQuery(...)` in a Server Component + `<app.Root>` delivers that data to the browser; no
  duplicate fetch on first load.
- Browser store fills once from the snapshot; a later page's snapshot only adds server data.
- Hydration was clean in every flow (no mismatch warnings) with the gating described in the guide.
- `next build` passes; data pages are dynamic, `/bookings` and `/lab` stay static and still work through
  the layout's empty `<app.Root>`.
- Using the app's store on the server outside a `Root` throws a clear message (by design).

## Backend-independent behaviour worth noting

- A query whose `fetch` rejects on the server (backend down) can be swallowed with
  `Promise.allSettled`; the page renders and the browser loads the data itself. (The path was written but
  I did not run it with the backend actually down.)
