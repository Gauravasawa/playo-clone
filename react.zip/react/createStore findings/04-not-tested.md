# 4. Not tested

> **Latest status:** see [11-seventh-round-react-bindings-and-client-root.md](11-seventh-round-react-bindings-and-client-root.md) and [10-sixth-round-retest-library-4187-lines.md](10-sixth-round-retest-library-4187-lines.md).

> **Status after the library update:** this file describes the library as it was when written. See [08-fourth-round-retest-after-library-update.md](08-fourth-round-retest-after-library-update.md) for what is fixed, what is still present, and what changed.

After two rounds, these are the options and behaviours in `createStore.ts` that no test or screen of the
app exercised. "No problems found" does **not** apply to them.

(Round 1 listed `syncTabs` broadcast, `offline`, `validate`, `devtools`, `logger`, `persist.migrate`/`debounce`,
async adapters, `pages.max`, `gcTime`, `abort`, `hydrate()`/`toScript()`, `ssr.version` and Server Action / Route
Handler scopes as untested. They are now covered; see `06-second-round-social-build.md`.)

## Status after round 3

Covered in round 3 (see `07-third-round-phase3.md`): state sync between real tabs, DevTools `subscribe` (fake extension), `offline.maxSize`,
`persist: 'session'`, several `whenOnline` tasks, refresh on focus/online, `onSaveStart`, nested `<Root scope>`, a scope with computed /
key actions / history on the server, custom `retryDelay`, concurrency (6 cases), a benchmark, TypeScript 7.0.2 and WebKit.

Also covered afterwards (07, addendum): 3–5 tabs and simultaneous writes (including 4 real tabs), `store.set.<key>(value)`, `getState()` with
no key, the hot-reload behaviour of a shared store, 100,000-item state and 20,000 cache entries, and the root cause of the stale paged query.

Still not covered:

| Feature | Notes |
| --- | --- |
| A **real** Redux DevTools extension | A fake object with the same contract was used. |
| **Firefox** | Could not be launched on this machine (`firefox.exe` blocked, "Permission denied"). Chromium (Edge) and WebKit pass. |
| 5+ real tabs | 4 real tabs and 5 same-page stores were tested. |
| Real hot reload with Next Fast Refresh | Simulated by calling `createStore` again with the same name; Fast Refresh itself was not driven. |
