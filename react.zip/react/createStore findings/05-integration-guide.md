# 5. Integration guide (what a consumer must supply)

What I had to build around `createStore.ts` to use it in Next.js 16 (App Router). All of it lives in
`apps/web/src/lib/store/` and `apps/web/src/store/`.

## 5.1 `react-bindings.ts`

```ts
import * as React from 'react';
import { ClientRoot as ClientRootComponent } from './client-root';

const R = React as unknown as Record<string, unknown>;
export const RSC: boolean = typeof R.useState !== 'function';          // true only in Server Components
export const createContext = (R.createContext ?? fakeContext) as typeof React.createContext; // see issue 1.3
export const createElement = React.createElement;
export const useCallback = R.useCallback as typeof React.useCallback;  // ...and useContext, useEffect,
export const useRef = R.useRef as typeof React.useRef;                 //    useRef, useSyncExternalStore
export const cache = R.cache as ((fn) => fn) | undefined;             // React.cache, Server Components only
export const ClientRoot = ClientRootComponent as unknown;
```

Why a namespace import: in the Server Component build of React, `useState`, `createContext`, etc. are not
exported. Named imports of them fail the build; a namespace import just yields `undefined`, and `RSC` is
derived from that. One file then works in all three places (Server Components, Client Components
rendered on the server, browser).

## 5.2 `client-root.tsx` (`'use client'`)

```tsx
export function ClientRoot({ name, snapshot, children }) {
  const Context = __SnapshotContext!;
  const parent = useContext(Context);
  const value = useMemo(() => ({ ...parent, [name]: { snapshot } }), [parent, name, snapshot]);
  useEffect(() => { __mergeSnapshot(name, snapshot); }, [name, snapshot]);
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
```

- The value must be **memoised**: on the server, `useInstance` stores the request's scope on that object
  (`mine.scope ??= createScope(...)`), so a new object per render would build a new store per render.
- Spread the parent so nested Roots (layout + page) both work; the inner one wins for the same store name.
- `__SnapshotContext` and `__mergeSnapshot` are exported from `createStore.ts` with a double underscore;
  they are the only coupling, and they are internals (see issue 1.2).
- `client-root.tsx` imports `createStore.ts`, which imports `react-bindings.ts`, which imports
  `client-root.tsx`. It's a cycle, harmless because nothing is used at module-evaluation time.

## 5.3 Store options for SSR

```ts
createStore(state, {
  name: 'playo',               // required for <Root> in Server Components
  ssr: { keys: ['sports', 'venues', 'venue', 'games'], version: 1 }, // public server data only (issue 1.5)
  shared: typeof window !== 'undefined',                             // browser only (issue 1.7)
  persist, syncTabs, history, ...
});
```

## 5.4 Rules that followed from how the library works

1. **`store/index.ts` has no `'use client'`.** Server Components import the same module and get the
   per-request store; Client Components get the browser/SSR one. They are separate module instances.
2. **Prefetch, then `<app.Root>`, in the page.** `Root` takes its snapshot when it renders, so data
   fetched after it is not included. The layout's `Root` renders first and therefore is empty — fine for
   the header, which only needs a store to exist.
3. **Pages that fetch from a live backend are `dynamic = 'force-dynamic'`**, otherwise `next build`
   tries to call the API.
4. **Absolute backend URL on the server.** A relative `/api/...` has no origin during server rendering.
5. **First client render must equal the server render.** The server doesn't have the visitor's persisted
   state, so UI that depends on it uses the server's defaults until `useMounted()` is true:
   `filter = mounted ? realFilter : DEFAULT_FILTER`. Using `enabled: mounted` instead (what I had before SSR)
   also works but leaves a loading state in the first paint.
6. **Anything depending on the visitor's clock** (e.g. "today" in the day picker) has the same problem
   and is rendered after mount.
7. **Per-user data (token-keyed queries) stays in the browser.** The server never sees the token, so
   `me` and `bookings` are not in `ssr.keys`.
8. **Calling `app.something()` outside a `Root` during server rendering throws** (by design). Handlers
   and effects are fine because they only run in the browser; module-level code must only create
   closures, not call the store (my `bindStore({ getToken: () => app.getState('token') })` is safe).
9. **Key-action `save` callbacks and `onSaveError` are defined before the store exists**, so they reach it
   through a tiny bridge module that is filled in right after `createStore` returns.
