# 6. Second round: what building profiles, chat, notifications, payments and the remaining store options showed

> **Latest status:** see [11-seventh-round-react-bindings-and-client-root.md](11-seventh-round-react-bindings-and-client-root.md) and [10-sixth-round-retest-library-4187-lines.md](10-sixth-round-retest-library-4187-lines.md).

> **Status after the library update:** this file describes the library as it was when written. See [08-fourth-round-retest-after-library-update.md](08-fourth-round-retest-after-library-update.md) for what is fixed, what is still present, and what changed.

The first round (files 01–05) came from a small booking app. This round added a WebSocket, a
second store on IndexedDB, a Pages Router page, a Server Action and Route Handler, and used the
options that had been left untested. **The library was not changed.**

Evidence for the claims below: a 61-check backend test, 39 browser steps (two real users plus demo
players; in `next dev` with StrictMode and in `next build && next start`), 30 in-browser self-tests,
and a handful of focused probes. Line numbers are for `createStore.ts` as before (3874 lines).

---

## A. New issues

### A.1 Every change rewrites the saved state, even changes to keys that aren't saved — Confirmed

**Where.** `applyNow` (≈ line 2049) calls `persistChanges(keys)` with the changed keys; `persistChanges`
(≈ 2091–2100) calls `saveState()` without checking whether any of `keys` is in `persistedKeys`.
`saveNow` then writes **all** persisted keys.

**How I hit it.** The Lab writes an "old" saved state into localStorage and reloads. About half the time
the old value was gone: the page had just connected its WebSocket, which set the (non-persisted) `socket`
key, which scheduled a debounced save; on `pagehide` the pending save was flushed, overwriting what I had
written with the in-memory state.

**Why it matters more than that test.**
- In the chat store (IndexedDB) the non-persisted keys `typing`, `activeChat` and `hasMore` change all the time.
  Each change re-serialises and rewrites the whole `messages` blob (up to 100 messages × every chat).
- With `debounce`, those unrelated changes keep re-arming the timer (see A.2).
- It makes the saved copy depend on timing of unrelated state.

**Suggestion.** In `persistChanges`, return early unless `keys.some((k) => persistedKeySet.has(k))`.

### A.2 `persist.debounce` + `pagehide` does not save with an async adapter, and unrelated changes postpone the write — Confirmed

**Probe.** Type in the chat box (a `drafts` change on the IndexedDB store, `debounce: 300`), wait N ms, reload,
and see whether the draft is back:

| wait before reload | draft restored |
| --- | --- |
| 700 ms (3 runs) | yes |
| 350 ms | yes |
| 100 ms (2 runs) | **no** (the previous draft came back) |

The doc says the debounced write is "flushed when the page is hidden". `flushSave` does call the adapter, but
an IndexedDB `put` is asynchronous and the page is gone before it commits. With `localStorage` the flush is
synchronous and works.

Separately, in the full end-to-end run a 700 ms wait failed once: `saveState()` does
`clearTimeout(saveTimer); saveTimer = setTimeout(...)` on **every** change, so a typing or presence event
for another key pushes the write back again (A.1). I raised that test's wait to 1.5 s.

**Suggestion.** Fix A.1 so unrelated changes don't re-arm the timer. For async adapters, document that a quick
reload can lose the last `debounce` ms, or write immediately on `pagehide` using `navigator.sendBeacon`-style
synchronous storage where available.

### A.3 A rejected saved value falls back to the *initial* value, which can log the user out — Confirmed

`validate` returning false on a value from storage means "the key keeps what it had". When loading synchronous
storage the key hasn't been touched yet, so what it "had" is the **initial** value. I saved
`token: "definitely-not-a-token"` and `city: "Atlantis"`: both were rejected with a warning (good), the
city became the default, and the token became `null` — the person was logged out.

That's reasonable (an invalid token shouldn't be used), but the warning says "it keeps its current value",
which suggests the previous saved value survives. Wording suggestion: "falls back to its initial value".

### A.4 `invalidate()` is not reflected in the offline copy, so a reload can show stale "fresh" data — Confirmed behaviour, cause from the code

With `offline: true`, entries are saved to localStorage with their `updatedAt`. `invalidate()` sets
`updatedAt: 0` in memory (≈ 2914) but doesn't call `saveCache()`. After a **full page reload** the entry is
restored with its old `updatedAt`; if that is within `staleTime` it counts as fresh and isn't refetched.

How it showed: a venue's "can I review?" answer (`canReview`) was cached; after the booking was marked
attended the form stayed hidden on the next page load. The Lab's "Mark attended" now uses
`fetchQuery(..., true)` (which does save), not `invalidate`.

**Suggestion.** Call `saveCache()` at the end of `invalidate()` (or store `updatedAt: 0` in the copy).

### A.5 The offline copy keeps per-user data on the device and nothing clears it on logout — Confirmed (and the fix is `reset()`)

`offline: true` writes query results (`me`, `bookings`, `chats`, `wallet`, …) to `localStorage` under
`<name>:queries` and `<name>:inline`. Changing `token` doesn't clear them. `reset()` does (it calls
`saveCache()`/`saveInline()`), and my `signOut()` uses it: the end-to-end test confirms that after logout no
bookings remain in the offline copy and the IndexedDB chat messages are gone (the chat store's `reset()`).
Worth a sentence in the `offline` docs, since the default behaviour leaves a previous user's data readable.

### A.6 `createScope(initial)` takes `Partial<RawValues<S>>` but really accepts a snapshot — Confirmed (types)

On the Pages Router path I pass what `scope.snapshot()` returned (it has `$version` and `$queries`) back into
`createScope(snapshot)` on the server render. It works (`seed()` handles those keys), but the parameter type
doesn't allow it, so I needed `as never`. `Snapshot<S>` is already exported; `createScope(initial?: Partial<RawValues<S>> | Snapshot<S>)`
would match what the code does.

### A.7 The snapshot-merge-during-render warning is still there — Confirmed (same as 1.1)

Seen again in development, and **more often than first thought**. It appears on client-side navigation to any page
whose `<Root>` carries server data while a component that reads the same key is still mounted:
`Controls` → `VenuesView` (Lab → Home), `SportChips` → `GamesView` (Home → Play), and on opening a venue.
(An earlier version of this note said it didn't happen on `/games` or `/venues/[id]`; that was wrong, it was only
missed because those tests used full page loads.) Full loads never trigger it.

In `next dev` it also makes Next's red **"1 Issue"** badge appear in the corner of the page, which looks like
something is broken to anyone using the app. It is a development-only React warning and I saw no wrong behaviour.
There is no app-side way to avoid it: the notification that causes it happens inside the library while the first
hook of the new page renders.

### A.8 `offline: true` makes the first browser render differ from the server's HTML — Confirmed

**Symptom.** After visiting the home page, opening `/tournaments`, `/coaches` or `/leaderboard` threw
"Hydration failed because the server rendered HTML didn't match the client" (React then discards the server HTML
and re-renders; in Next dev the red error overlay appears, which looks like "the page didn't load").

**Cause.** With `offline` on, query results saved in `localStorage` (`<name>:inline` / `:queries`) are loaded
into the store **while it is created in the browser**, before React hydrates. Those pages show the sport chips, which
come from the `sports` query. The server had not fetched it for these pages, so it rendered "loading sports…"; the
browser's first render already had the saved chips. (Pages that prefetch the same data, like the home page, match.)

The same hazard exists for **any** query the server didn't load but the browser has saved: I found two more
(venue slots and venue reviews) by reasoning, and gated them.

**Fix used in the app.** Prefetch on the server everything a page's first render shows, and show anything the
server didn't fetch only after `useMounted()`. A scan of 15 routes twice (second pass with the offline copy filled,
visitor's city and sport not the defaults) is clean in `next dev` and in the production build.

**Suggestion.** Document it next to `offline`, or give an option to defer loading the offline copy until after
hydration (e.g. apply it in an effect), since the library already knows when it is hydrating (`hydratedEntries`).

---

## B. What worked, newly confirmed

Everything here was exercised by a test that passed in dev (StrictMode on) and against the production build,
unless stated.

| Feature | How it was checked |
| --- | --- |
| **`offline` + `whenOnline`** | Browser set offline: a chat message shows "sending…" and is delivered when the network returns; a `keyActions` toggle with `save` is applied locally and the save runs after reconnect (toast "Saved favorites.toggle"). |
| **Async `StorageAdapter` (IndexedDB)** | Chat store loads after mount; drafts restored after reload (when waited ≥ 350 ms); `reset()` empties it on logout. |
| **`persist.migrate` + `version`** | A v1 saved state loads with its values (`city`, `sport`) and is rewritten as v2 with the new key (`recentSearches: []`). Also self-tested: no `migrate` → old data dropped with a warning. |
| **`persist.debounce`** | Self-test: a burst of 5 changes → 0 writes during it, 1 write after the pause, last value saved. |
| **`validate`** | Invalid city/token/favorites in saved state were rejected, each with a console warning, and the app kept running. Also self-tested. |
| **`syncTabs` `broadcast` events** | A second tab of the same user: marking notifications read in one tab cleared the badge in the other (`emit('notifications-read', …, { broadcast: true })`). |
| **`devtools`** | With a fake `__REDUX_DEVTOOLS_EXTENSION__` the store connected as `playo` and reported actions (e.g. `city`). A real extension was not used. |
| **`logger`** | With `NEXT_PUBLIC_STORE_LOGGER=1` the console shows `[playo] <change> …` lines. |
| **`pages.max`** | Notifications (pages of 10, `max: 3`): after loading 4 pages the list holds at most 30 rows. |
| **`gcTime`** | Self-test: an entry nobody shows is dropped after its `gcTime`, so the next `fetchQuery` fetches again. |
| **`abort`** | Self-test: `store.abort('name')` aborts the fetch function's signal. The player search also aborts the previous text on every keystroke. |
| **`ssr.version`** | Self-test: `hydrate()` with another version warns and leaves state alone; same version applies. |
| **`hydrate()` / `toScript()` / `createScope` on the Pages Router** | `/p/[username]`: the server HTML contains the profile and the data tag (`<script type="application/json" id="createstore:playo">`); a private profile arrives restricted in the HTML; the browser hydrates with no warnings. |
| **Server Action** | A friend request is sent by a Server Action which then loads the fresh list with `createScope().fetchQuery(...)`; the browser puts the result into its store with `setQueryData`. |
| **Route Handler** | `/share/<username>` builds a share card through `createScope()`. |
| **SSR with the backend down** | The page renders (HTTP 200, no venue cards in the HTML); the browser shows "Couldn't load venues"; after the backend is back, "Try again" loads them. |
| **Second store** | `chatStore` (non-SSR, IndexedDB) next to `app` (SSR, localStorage): independent, both persisted, both reset on sign-out. |
| **`destroy`, `onChange`, `history.keys`, `createScope` not persisting, `emit` broadcast without `syncTabs` warning** | Self-tests. |
| **Structural typing of `actions`** | `chatActions(s)` accepts the store's `api` for a hand-written interface with **no cast** (I had assumed it would need one). |

Real-time behaviour built on top of the store (WebSocket handlers calling `setQueryData`, `invalidate`,
`fetchQuery(..., true)` and key actions) was stable: typing indicators, read receipts, unread badges and presence
all worked between two real browsers.

---

## C. Integration notes added this round

1. **Don't read the store from modules a Server Action imports.** My API client had a reader
   `() => app.getState('simulateFailure')`. In a Server Action `app` is the Server Component proxy and
   `getState()` throws ("used outside a Server Component render"). The error message is clear and tells you to use
   a scope. Fix: register such readers only when `typeof window !== 'undefined'`.
2. **A dev server can keep an old Server Action bundle** after such an edit (the error trace pointed at the old
   line numbers until I restarted `next dev`). That's Next, not the library.
3. **Pages Router data tag:** `hydrate()` removes the tag element (`el.remove()`) during render, so the server's
   `<script>` must be rendered where React won't compare it:
   `<div suppressHydrationWarning dangerouslySetInnerHTML={{ __html: scope.toScript() }} />`.
   `useState(() => typeof window === 'undefined' ? app.createScope(snapshot) : app.hydrate())` creates the scope
   once per render pass (StrictMode's double render is handled by `hydrate()` itself).
   `next/navigation`'s `useRouter` and `usePathname` work inside Pages Router components.
4. **High-churn UI state belongs in a store without `persist`** (or see A.1): typing indicators, presence and
   "which chat is open" changed far more often than anything saved.
5. **Presence-style maps:** a key action that returns the same object when nothing changed
   (`current[id] === online ? current : {...}`) avoids notifying subscribers on repeated events.
6. **A custom `StorageAdapter` must tolerate the server**: the store calls `getItem` on the server too, so the
   IndexedDB adapter returns `null` when `indexedDB` is undefined.
7. **`reset()` also resets the saved preferences** (city, sport): it's "back to a fresh store", which is what a
   sign-out wants but not what a "clear cache" button wants.
8. **Next 16 blocks its dev scripts for any host except `localhost`** (not a library issue, but it looks like one).
   Opened as `http://127.0.0.1:3000`, a LAN IP or the machine name, the server-rendered HTML shows, React never
   hydrates, buttons do nothing, and every query that loads in the browser stays on "loading". The dev log says
   "Blocked cross-origin request to Next.js dev resource /_next/hmr". Fix: `allowedDevOrigins` in `next.config.ts`
   (done in the app: `127.0.0.1`, the machine name and its LAN addresses, plus `DEV_ORIGINS`). A store-heavy app
   makes this look like "the store doesn't load", because server-rendered data is the only thing that appears.
9. **Test client-side navigation, not just `page.goto`.** My first two scans used full page loads and were clean.
   Clicking links found the render-time warning on more pages (A.7) and a header menu that stayed open after
   navigation. Anything rendered in a layout (header, toasts, socket provider) lives across navigations, so
   state that should reset per page (an open `<details>`, a modal) needs an effect on the path.
10. **Cross-check with the host the user really uses.** The same suite passes on `localhost` and, after the config
    fix, on `127.0.0.1`; it would have kept passing on `localhost` forever while the user's setup was broken.

## D. App bugs found in this round (not library issues, recorded so they aren't mistaken for them)

| Symptom | Cause | Fix |
| --- | --- | --- |
| `/tournaments`, `/coaches`, `/leaderboard` threw a hydration error and showed the Next error overlay | the offline copy made the browser's first render differ from the server HTML (A.8) | prefetch on the server what the first render shows; show the rest only after mount |
| Venue slots/reviews could mismatch the same way | same cause | gated until mounted |
| A reviewed venue's form stayed hidden after "Mark attended" | `invalidate()` isn't saved to the offline copy (A.4) | the demo tool forces a refetch |
| User menu stayed open after choosing a link | the header persists across pages and `<details>` keeps its `open` state | close it when the path changes |
| Server Action failed with a 500 | the API client's failure-switch reader called `app.getState()`, which throws outside a render | register those readers only in the browser |
