# 7. Third round: money, games v2, coaching, events, owner, help, safety (Phase 3)

> **Latest status:** see [11-seventh-round-react-bindings-and-client-root.md](11-seventh-round-react-bindings-and-client-root.md) and [10-sixth-round-retest-library-4187-lines.md](10-sixth-round-retest-library-4187-lines.md).

> **Status after the library update:** this file describes the library as it was when written. See [08-fourth-round-retest-after-library-update.md](08-fourth-round-retest-after-library-update.md) for what is fixed, what is still present, and what changed.

The library was **not changed**. This round added about 40 screens and 25 query/state keys, then exercised the features that
rounds 1–2 listed as untested (see `04-not-tested.md`). Raw working notes from each part of the build are in the `_fork-*.md` files;
this file is the cleaned-up result.

How it was tested: 7 browser journeys (`g1`–`g7`, about 110 steps, production build), 14 store-feature checks (`store-phase3.mts`,
dev build) in **Edge and WebKit**, 43 in-browser self-tests, a 36-route scan, and a TypeScript 7.0.2 type-check.
Firefox could not be tested: `firefox.exe` fails to start on this machine with `spawn UNKNOWN` / "Permission denied" (the same with a
copy under `C:\pw-browsers`), so that is an environment limit, not a result.

## A. New issues and surprises

### A.1 A query without params starts as `[]`, even when it returns an object  *(confirmed, caused a page crash)*
`policy: query((_: undefined, signal) => api.policy(signal))` read as `useGlobalState('policy')` is `[]` until its first response (the
documented default of `initial`). `[]` is truthy, so `policy?.giftCard.min` threw while rendering and the whole page showed "This page
couldn't load". Queries **with** params give `undefined` first, so the two kinds disagree. This is the same thing as 01 · 1.6, now seen
as an actual crash. Workaround: `initial: null as unknown as Policy`. Suggestion: default `initial` to `undefined` unless the query is
declared as returning an array, or type the first tuple element honestly as `T | undefined`.

### A.2 A restored paged query is not refetched after a full reload  *(confirmed, not root-caused)*
`/notifications` → `/games` (client-side) → two notifications arrive over the WebSocket (handler calls `app.invalidate('notifications')`
while nothing observes the query) → reload `/notifications`: the **old** list shows and no request is made for 12 s, although the saved
copy is older than `staleTime`. Chats, games, bookings refreshed fine in the same journeys. Candidates: the offline restore keeps
`updatedAt`; `invalidate` of an entry nobody observes may be forgotten when the page unloads (06 · A.4 is the same family).
Workaround: the page calls `app.invalidate('notifications')` on mount. Repro: `dbg4.mts` in the e2e folder.

### A.3 `offline` saves parameterless queries under `:inline`, queries with params under `:queries`
`writeOffline('inline', …)` vs `writeOffline('queries', …)`. A store key such as `big: query(async (_: undefined) => …)` is *inline* because
it has no params. Not documented; it matters when you want to look at, clear or size-check the offline copy (my first self-test looked in
the wrong key and failed).

### A.4 `persist` and `offline` storage keys
Saved state is `<name>:state` (with `$version`), the offline copy `<name>:inline` / `<name>:queries`. Only visible by reading the source.

### A.5 Smaller points
- `onSaveStart` is called for every key-action save, **before** the request; with `offline` on, a save queued by `whenOnline` keeps the
  count above zero until the connection returns, which made a correct "Saving when you are back online…" indicator trivial.
- `subscribe(listener)` takes one argument: it hears **every** change (no key filter), unlike `useGlobalState`. With 500 subscribers a
  `setState` costs about 4.4 µs (vs 1.3 µs with none) — see the benchmark.
- History state (`canUndo`) is only exposed through a hook, not as a store property, so the benchmark can't ask "can I still undo?" and
  calls `undo()` a fixed number of times.
- `createScope()` copies `history` (a scope has its own undo stack), and its computed values and key actions work: the `/quote` Route
  Handler uses all three.
- A `createStore` call without `shared` in a module imported by both server and client files is fine; `shared: typeof window !== 'undefined'`
  worked for the new `prefs` store as well.

### A.6 Ergonomics noted while building
- Params that contain the token (`{ city, sport, token }`) split the cache per user; it works and is what you want for private data, but
  logging in/out leaves one cache entry per token until `gcTime`.
- Filters kept in `useState` and passed as query params must be memoised, or every render creates a new object (it is keyed by value, so
  it is *correct*, but easy to misread as a refetch loop).
- A persisted `sort: 'distance'` that depends on a non-persisted `location` needs a fallback in the view. (A persisted value that depends on
  an unpersisted one is a pattern the library could warn about.)
- The same query holding public and "mine" data (`canReview`, `mine`) under `{ id, token }` makes the page flash its loading state once
  after login (new params = new entry). Two queries would avoid it.

## B. What worked (new this round)

| Feature | How it was checked | Result |
| --- | --- | --- |
| **`syncTabs` state keys between real tabs** | two pages in one browser context: city (twice), favourites count, log out | all followed within 5 s (Edge, WebKit) |
| **`validate` on tab sync** | a hand-posted `BroadcastChannel` message with `city: 12345` | refused, city unchanged |
| `emit(..., { broadcast: true })`, 2 tabs | Lab button | toast in the other tab |
| **Redux DevTools time travel** | fake extension: record every `send`, then call the subscribed callback with `JUMP_TO_STATE` | store jumped back to the chosen state; malformed JSON ignored without a crash |
| **Nested `<Root scope={createScope()}>`** | owner price preview | writes/reads stay in the scope; `app.getState('selection')` of the real store stayed at 0 slots (asserted) |
| **Scope on the server** | `GET /quote` Route Handler: `createScope`, `fetchQuery` venue + slots, key actions, computed `quote`, `history.undo` | same payable as the API's own quote (₹1545) and as the browser; `undo()` restored the quote |
| `onSaveStart` / `onSaveSuccess` / `onSaveError` | self-test (order) + a slow favourites save in the browser | `start save ok / start save err`; header shows "Saving…" then clears |
| **`persist: 'session'`** | `prefs` store: reload keeps it, a new tab starts clean, `localStorage` untouched | works (key `playo-prefs:state` in sessionStorage) |
| **`offline.maxSize`** | self-test with limit 1000 | copy not saved **and the older copy is removed**; one warning |
| **Several `whenOnline` tasks** | self-test (3 tasks, the 2nd throws) + browser (3 favourites offline) | nothing runs offline; on `online` they run in order; a failing task rejects only its own promise; all 3 favourites reached the server |
| **Custom `retryDelay`** | self-test + the `wallet` query behind a route that returns 503 three times | asked with attempts 1, 2; gaps 320 / 606 / 1210 ms (target 300 / 600 / 1200) |
| **Refresh on focus / `online`** | wallet page, `window` `focus` and `online` events | stale (>10 s) → one request each; fresh → none |
| **Concurrency** | 6 self-tests | 10 `fetchQuery` for one key = 1 request; 4 params run in parallel; `invalidate` mid-request → a second request and the newer answer wins; 200 `setState` calls land in order; two failing saves at once roll back to the original; `abort()` ends a retry loop |
| `persist.migrate` (v1 → v3) | Lab writes a v1 state, reload | upgraded |
| Production build + dev (StrictMode) | all journeys | no console errors, no 4xx/5xx except the intentional ones |
| **TypeScript 7.0.2** | `tsc --noEmit --incremental false` in `apps/web` (827 files, 192k lines) and `apps/api` | **0 errors**; 0.46 s vs 4.8 s on 5.9.3; a deliberately wrong `getState('city')` assignment is still caught, so the inference of state/query types survives |
| **WebKit** | `store-phase3.mts` | 14/14 (including offline queue and `BroadcastChannel`) |

Not verified: a **real** Redux DevTools extension (a fake object with the same contract was used), **Firefox** (cannot launch here),
more than two tabs, the exact conflict rule when two tabs write one key at the same moment.

## C. Benchmark (Lab → "Performance benchmark", production-like numbers vary by machine; dev build, Edge)

| Case | Ops | Total | per op |
| --- | --- | --- | --- |
| `setState` on a number, no listeners | 20,000 | 25 ms | 1.3 µs |
| `setState` with 500 subscribers | 5,000 | 22 ms | 4.4 µs |
| `setState` + 2-layer computed read | 5,000 | 11 ms | 2.2 µs |
| `batch` of 1,000 `setState` calls | 200 batches | 153 ms | 0.76 µs per call |
| key action on a 1,000-item list | 2,000 | 14 ms | 6.9 µs |
| `fetchQuery`, cache hit | 20,000 | 8 ms | 0.4 µs |
| `fetchQuery`, 2,000 different params | 2,000 | 13 ms | 6.7 µs |
| `history`: 1,000 changes (limit 50) + undo | 1,000 | 3.4 ms | 3.4 µs |
| `snapshot()` + `JSON.stringify` with 5,000 cached entries | 20 | 155 ms | 7.8 ms each |

Nothing here looks slow. The only number worth knowing is the snapshot: a page that serialises thousands of cached entries for SSR pays
a few milliseconds per render.

## D. App bugs found by the journeys (all fixed; full table in `_fork-G-e2e.md`)

Gift-card tab crash (A.1), stale notifications after reload (A.2), ticket page crash from an effect returning a non-function (React 19 calls
it as cleanup), non-admins fetching the admin list, invite modal vs server rule mismatch, blog search ignoring tags, gallery rendered twice,
`/games?with=` ignored, missing wording for the new notification types.

Design points to remember (kept on purpose): the login rate limit is per phone number; a host is credited every paid join, including
no-shows; football venues list two rentals both called "Ball".

## E. Process notes (not the library)

- Long shell heredocs with quotes in JSX broke twice and wrote nothing; the Write/Edit tools are reliable.
- `next start` must be restarted after every `next build` (it keeps the old build id in memory); `pkill` does not exist in Git Bash here.
- `firefox.exe` could not be started on this Windows machine; WebKit and Chromium (Edge) could.
- Test data accumulates in a shared database: journeys that look up "the newest event/venue" can pick up another run's data. Start from a
  fresh database (`rm apps/api/playo.db*`) for deterministic runs.

---

# Addendum: the gaps from `04-not-tested.md`, now tested (18 more self-tests, 1 more browser step)

Self-tests: **61 pass** (Edge and WebKit). Browser: 4 real tabs, 15 rounds, in Edge and WebKit.

## F. Root cause of 07 · A.2 (stale paged query after a reload)  *(found by reading the code, confirmed by two self-tests)*

Two things add up:
1. **`staleTime` is accepted for paged queries but never read.** `PAGED_OPTIONS` allows it and the type documents it, but
   `fetchInfinite` returns the cached data whenever `status === 'success'`, however old it is (`createStore.ts` ~L2856,
   `if (mode === 'first' && data && entry.status === 'success' && !force) return …`). The comment above says "loaded pages aren't
   refreshed on focus or when stale", so this is intended for *scroll stability*, but then `staleTime` on a paged query does nothing.
   Self-test: two `fetchQuery` calls 60 ms apart with `staleTime: 10` make **one** request.
2. **`invalidate()` of an entry nobody shows isn't remembered across a reload** (06 · A.4): the offline copy is restored as "success".
   Self-test: paged query + `offline: true`, destroy, create the store again, ask again: **no request**.

Result: a paged list (my notifications) never refreshes by itself after a reload. Fix options for the library: honour `staleTime` for
the first page when the entry is *restored* (or on mount), or at least reject `staleTime` for paged queries with a clear message.
The app's workaround (invalidate on mount) is the right one until then.

## G. Several tabs  *(confirmed working; one quirk)*

| Check | Result |
| --- | --- |
| 5 tabs, one writes | all follow |
| a change hopping tab 0 → 4 → 1 | everyone follows each hop |
| 5 tabs write the same key **in the same tick**, 30 random orders | **always converge** to one value |
| later write beats earlier write | yes: a tab that saw a newer change wins over its own older one |
| simultaneous writes to **different** keys | all kept (merged per key) |
| **4 real browser tabs** pick different cities at the same instant, 15 rounds | converge every round; the saved `localStorage` value matches the screen (Edge and WebKit) |
| bad value posted on the channel (with a valid stamp) | refused in every tab by `validate` |
| `emit({ broadcast })` with 4 tabs | received once by each other tab, not echoed to the sender |

Quirks:
- **Same-tick ties are broken by tab id, and the id is random per tab**: in the single-page test the *same* store won all 30 rounds
  (the one with the biggest id), in real tabs different tabs won. So "last writer wins" is true only when the writes are in different
  ticks; in the same tick the winner is arbitrary but consistent.
- **Whole-value, not merge:** two tabs appending to one list at the same time keep only one of the two additions (`[from-0]`).
  Expected for last-writer-wins, but worth knowing for arrays and objects; use separate keys, or keep append-only data
  (like chat messages) in a store that doesn't sync.
- Round 3's first "bad value from another tab" browser test posted a message **without** a stamp, which the library silently ignores
  (correct), so it passed for the wrong reason. The rewritten test sends `{ type:'state', stamp:[n,'id'], values:{…} }` and still passes.

## H. The unused forms  *(work)*

- `store.set.<key>(value)`, `store.set.<key>(updater)`, and `store.set.<key>(value, serverCall)` (rolls back when the call fails, keeps on success).
- `getState()` with no key returns every value **including computed ones**, as a copy of that moment: a later change doesn't alter an earlier
  result, and mutating the returned object doesn't change the store.

## I. Hot reload of the file that creates a `shared` store  *(a footgun, by design)*

`shared: true` keeps one instance under `Symbol.for('createStore:<name>')` and **ignores the definition of every later call**.
Self-test: re-running `createStore({ a, b }, { shared: true, computed: [...] })` after `createStore({ a }, …)` returns the *same instance*
with state kept, and the new key `b` and the new computed value are **not there**. So during development, editing `state.ts`,
`computed.ts`, `key-actions/` or `queries.ts` and letting Fast Refresh swap the module gives you the old store with the old
definition until you reload the page.
After `destroy()` a new call builds a fresh working store (checked), so a dev hot-reload hook that calls `destroy()` first is a way out.
Suggestion: in development, compare a hash of the definition (keys + option names) and warn "the store's definition changed, reload".
Not driven with real Fast Refresh: simulated by calling `createStore` again with the same name.

## J. Large state

All numbers: Edge, dev build, one run (WebKit within about 2x).

| Case | Result |
| --- | --- |
| `setState('items', 100,000 objects)` | ~0 ms (stored by reference) |
| a computed value over 100,000 items | first read 1–2 ms; **not re-run** by 50 unrelated writes |
| key action appending to the 100,000-item list, 20× | 6 ms (25 ms WebKit): each copies the array, still cheap |
| `getState('items')` 1,000× / `getState()` 100× | 0.1 ms / 1.5 ms |
| `snapshot()` + `JSON.stringify` of the list | 47–62 ms, 4.5 MB (what SSR would pay per request if that key were in the snapshot) |
| persist: 100,000 numbers, 21 quick changes, `debounce: 50` | **1 write** (0.59 MB), loaded back in 3–5 ms |
| 20,000 cached query entries | fetch 141–301 ms; 20,000 cache hits 16–21 ms; after `gcTime` the snapshot shrinks from 1.7 MB to ~0 |

Nothing slow or leaking. The one cost to watch is the snapshot of very large lists on the server.

## K. Still not covered

A real Redux DevTools extension (fake extension only), Firefox (cannot launch here), 5+ real browser tabs (4 tested), and real Next
Fast Refresh (simulated).
