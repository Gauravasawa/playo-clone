# 8. Fourth round: everything re-tested against the updated `createStore.ts`

> **Latest status:** see [11-seventh-round-react-bindings-and-client-root.md](11-seventh-round-react-bindings-and-client-root.md) and [10-sixth-round-retest-library-4187-lines.md](10-sixth-round-retest-library-4187-lines.md).

The library file was updated (now 3,991 lines; `c:\react\.store\createStore.ts` and the app's copy are identical). It was **not edited by me**.
Every finding in 01, 02, 06 and 07 (and the `_fork-*` notes) was re-checked: by reading the new source, and wherever behaviour was claimed by
running a test (Bun scripts that import the library, the Lab self-tests, and Playwright in Edge against a dev server). Then the whole app was
run again to see what still works. The detailed per-item tables are in the scratchpad files `retest-R1.md`, `retest-R2.md`, `retest-R3.md`
(summarised below).

## 1. Scoreboard

| Finding | Old status | Now |
| --- | --- | --- |
| 01 · 1.1 / 06 · A.7 snapshot merge notifies components **during render** (React warning, Next "1 Issue" badge) | confirmed | **mostly fixed**: hook subscribers are held until a microtask. **Still warns** for `store.subscribe()` / `onChange` / `logger` listeners (see 3.1) |
| 01 · 1.2 `./react-bindings` missing, contract undocumented | confirmed | **still present** (no contract text, no reference file in `.store/`) |
| 01 · 1.3 `createContext` called in Server Components | confirmed | **fixed** (guarded; tested with a bindings file that has no `createContext`) |
| 01 · 1.4 reload during an in-flight optimistic save rolls the change back | confirmed | **fixed** (`leavingPage` flag on `pagehide`; reload 0/30/80 ms after the click kept the change, localStorage and server agreed) |
| 01 · 1.5 default `ssr: true` snapshot overwrites persisted state | from the code | **fixed** (persisted keys the server didn't change are left out; `ssr: { keys }` still sends a key regardless) |
| 01 · 1.6 / 07 · A.1 `query()` without `initial` starts as `[]` (crashed the gift-card page) | confirmed | **fixed**: starts as `undefined`, typed `T \| undefined` (the app needed 10 small `?? []` fixes, and the `initial: null` workaround was removed) |
| 01 · 1.7 `shared: true` warns on every server evaluation | confirmed | **fixed** (once per store, and not at all when `ssr` is set) |
| 01 · 1.8 code smells | low | **fixed** (unused parameter and variable gone; the one remaining assignment is commented) |
| 02 · 2.1 errors name `ssr.serialize` (doesn't exist) | confirmed | **fixed** (say `ssr: { exclude }`; a leftover `serialize` throws a clear "now ssr.keys" message) |
| 02 · 2.2 doc comments on the wrong declaration | — | **fixed** |
| 02 · 2.3 computed values are read as `const [x] = …` (undocumented) | — | **still present** |
| 02 · 2.4 no-params queries get a dummy first argument | — | **still present** (docs only) |
| 02 · 2.5 typing extracted pieces | — | **improved** (`LayerValues`, `AddedValues` exported) |
| 06 · A.1 every change rewrites saved state, even unsaved keys | confirmed | **fixed** (10 changes to an unsaved key: 0 writes, was 10) |
| 06 · A.2a unrelated changes re-arm `debounce` | confirmed | **fixed** |
| 06 · A.2b `debounce` + `pagehide` loses the last write with an **async** adapter (IndexedDB) | confirmed | **still present**, now a race: reload 700/350 ms after the change kept it, 100 ms kept it 1 of 3 times, 30 ms lost it every time (see 3.2) |
| 06 · A.3 rejected saved value falls back to the **initial** value, text said "keeps its current value" | confirmed | **wording fixed**; behaviour unchanged (a bad saved token still logs the user out) |
| 06 · A.4 / 07 · A.2 `invalidate()` not reflected in the offline copy; stale restored data | confirmed | **fixed** (`invalidate` saves the offline copy) |
| 07 · A.2 / F paged query: `staleTime` ignored; restored list never refetched | confirmed | **fixed** (a stale paged list refetches from page 1 when asked for; fresh ones stay). App workaround (invalidate on mount) removed and the reload repro now issues the request |
| 06 · A.5 offline copy keeps per-user data after logout | confirmed | **unchanged by design** (`reset()` clears it; the `offline` option comment still doesn't say so) |
| 06 · A.6 `createScope(initial)` rejects a snapshot (types) | confirmed | **fixed** (accepts `Partial<RawValues> \| Snapshot`) |
| 06 · A.8 `offline: true` → hydration mismatch | confirmed | **fixed** (a query the server didn't load reports "loading" in the browser's server snapshot); a page with no prefetch visited twice, plus `/tournaments`, `/coaches`, `/leaderboard`: no hydration error |
| 06 · C.1 `app.getState()` in a Server Action / Route Handler throws | note | **unchanged** (message is clear and names `createScope()`) |
| 06 · C.3 Pages Router data tag + `hydrate()` | worked | **still works** |
| 06 · C.6 custom storage adapter's `getItem` is called on the server | note | **unchanged** |
| 06 · C.7 `reset()` also resets saved preferences | note | **unchanged** |
| 07 · A.3 offline keys `:inline` (no params) / `:queries` (with params) undocumented | note | **still present** |
| 07 · G same-tick tab ties decided by tab id (not write order) | quirk | **still present** (40 rounds, always agreed, but only 2 of 5 stores ever won) |
| 07 · G whole-value last-writer-wins (two list appends keep one) | quirk | **still present** (expected) |
| 07 · I shared store ignores a changed definition on hot reload | footgun | **changed**: still returns the old instance, but now **warns once** ("the store's definition changed… reload the page"); an identical definition doesn't warn; `destroy()` now also frees the shared slot |
| 07 · stamps are a logical counter, not the wall clock | — | **confirmed** (a store whose clock was an hour behind still lost to a later write) |

Summary: **16 fixed or improved**, **2 partly** (1.1 and the A.2b race), **9 unchanged** (mostly docs, by-design behaviour, or inherent).

## 2. What worked, re-run on the new library (all green)

| What | Result |
| --- | --- |
| Type-check: TypeScript **5.9.3** and **7.0.2**, web and API | 0 errors (after the app adapted to `T \| undefined`) |
| `next build` (production) | passes, 36 routes |
| 61 in-browser self-tests (Edge **and** WebKit) | 61/61, including the three that were rewritten to assert the **new** paged-query behaviour |
| 15 store-feature browser checks (Edge **and** WebKit): quote through a server scope, saving indicator, session prefs, 2-tab and 4-real-tab sync, `validate` on a stamped bad message, DevTools `JUMP_TO_STATE`, focus/online refresh, `retryDelay` gaps, three offline saves | 15/15 and 15/15 |
| 7 feature journeys, ~110 steps (money, venues, games, social/safety, coaching/events, owner/help, notifications, chat) | all pass on a fresh database |
| 36-route scan (two passes) | no console errors, no 4xx/5xx |
| Pages Router public profile, Server Action, Route Handler with `createScope`, nested `<Root scope>` (owner price preview) | all still work |

The previous "worked" lists (03, 06 · B, 07 · B and J) were all covered by the above; nothing regressed.

## 3. Open problems (new or still present)

### 3.1 `subscribe()` / `onChange` / `logger` listeners are still called during render
`useInstance` now merges the server snapshot with `withHeldNotify`, which delays **hook** notifications to a microtask. But `apply` still calls
`emitChangeEvents` directly (~L2108), so a component that listens with `store.subscribe(listener)` and calls `setState` in it (the Lab's change
feed) still triggers "Cannot update a component (ChangeFeed) while rendering a different component (…)" once, when navigating from `/lab` to
another page that merges server data. Navigating from Home through 9 pages gave no warning. Suggestion: hold `emitChangeEvents` the same way.

### 3.2 Async adapter + `pagehide`: still a race
`flushSave` calls the adapter's `setItem` on `pagehide` and doesn't (can't) wait for IndexedDB to commit. With a real IndexedDB, a reload
30 ms after a change lost the draft 2 of 2 times, 100 ms kept it 1 of 3, 350 ms and 700 ms kept it. Not fixable by the library alone;
it deserves a sentence in the docs ("with an async adapter the last change within the debounce window may be lost on reload") or a
sync fallback (a small `localStorage` write-ahead).

### 3.3 New behaviour worth knowing
- `snapshot()` now **throws** (clear message) if a state key in the snapshot is `undefined`. Because param-less queries now start as
  `undefined` and server snapshots are made after the data is loaded, the app is fine, but a store with an `undefined` key in `ssr.keys`
  that rendered before will fail now.
- A stale paged list shown in exactly one place now **starts over from page 1** when asked for again, replacing the loaded pages. For a list
  the user had scrolled through (with `max` pages loaded) this resets it after a reload. Not tested with a real scrolled list.
- Because `useGlobalState('someQuery')` now honestly returns `undefined` first, every consumer needs `?? []` or a loading branch. The
  app needed 10 such fixes; TypeScript found all of them (a good sign for the new typing).

### 3.4 Docs still missing
2.3 (computed values are read like `const [x]`), 2.4 (the dummy first argument of param-less queries), 1.2 (the `react-bindings` contract), 07 · A.3 (offline storage key names) and 06 · A.5 (`offline` keeps data after logout until `reset()`).

## 4. App changes made because of the update

- 10 `useGlobalState('sports')` call sites: `const sports = sportsData ?? []`.
- Removed the `initial: null as unknown as Policy` workaround on the `policy` query (gift-card page still loads).
- Removed the "invalidate notifications on mount" workaround (the reload repro now issues the request by itself).
- Rewrote 3 self-tests that documented the old behaviour so they now **assert** the new one.
- The earlier workarounds for the render-time warning (prefetching public pages) and for hydration mismatch were left in place: they are harmless and
  also good practice for SEO.

## 5. Still not covered
A real Redux DevTools extension (fake extension only), Firefox (`firefox.exe` can't be started on this machine), 5+ real tabs, real Next Fast
Refresh (the shared-store re-evaluation was simulated), and a scrolled paged list after a reload (3.3).
