# 9. Fifth round: everything re-tested against the library updated again (4,104 lines)

`c:\react\.store\createStore.ts` grew from 3,991 to **4,104 lines** (the app's copy is identical). It was **not edited by me**. Every row of the
round-4 scoreboard (`08-…`) was re-checked by reading the new source and by running the tests again (Bun scripts that import the library,
61 Lab self-tests, Playwright in Edge, and for the key items real IndexedDB and real navigation). Detail per item:
scratchpad `retest-R4.md`. Then the whole app was run again.

## 1. Scoreboard (status now → was in round 4)

| Finding | Now | Was |
| --- | --- | --- |
| 1.1 / A.7 notifications during render: hook subscribers | **fixed** | mostly fixed |
| **1.1 rest: `subscribe()` / `onChange` / `logger` listeners called during render** | **fixed** — change events are now queued with the held notifications (`heldEvents`, ~L1409) and delivered after the render. `/lab` → Venues, Play, Events, Coaching, Tournaments, Leaderboard, Help, logged in and out: **0** "Cannot update a component" messages (old: 1 each for Venues and Play) | still present |
| **06 · A.2b async adapter (IndexedDB) loses the last write on reload** | **fixed** — new *rescue copy*: on `pagehide`/hidden, while an async write isn't committed, the same text is written to `localStorage` under `<persistKey>:rescue`; the next load uses whichever copy is newer and deletes the rescue key. Real IndexedDB, reload 0 / 10 / 30 / 100 / 400 ms after the change: **60 of 60 kept** (old library: 30 ms lost every time, 100 ms lost 2 of 3). No `:rescue` key is left behind; a stale rescue doesn't beat a newer committed value | still present (race) |
| 07 · A.3 offline key names undocumented | **fixed (docs)** — the `offline` option comment now names `<name>:inline` (no params) and `<name>:queries` (with params and paged) | still present |
| 06 · A.5 offline copy keeps per-user data until `reset()` | **fixed (docs)** — the comment says "call `reset()` on sign-out" (behaviour unchanged) | unchanged |
| 1.2 `react-bindings` contract undocumented | **still present** (the file still only imports it; `.store/` still holds only `createStore.ts`) | still present |
| 2.3 computed values are read like `const [x] = …` | **still present** (docs only) | still present |
| 2.4 no-params queries get a dummy first argument | **still present** (docs only: `fetch(undefined, signal)`) | still present |
| 07 · G same-tick tab ties decided by tab id | **still present** (by design; 30 rounds, always converged, one store always won; real tabs: different winners) | still present |
| 07 · G whole-value last-writer-wins (list appends keep one) | **still present** (by design) | still present |
| 06 · C.1 / C.6 / C.7 (`getState()` in Route Handlers throws with a clear message; adapter `getItem` runs on the server; `reset()` resets saved preferences) | **unchanged** | unchanged |
| 07 · I shared store, definition changed on hot reload | **kept**: same instance, one warning (`#12`), `destroy()` frees the slot | warns once |
| everything else fixed in round 4 (1.3–1.8, 2.1, 2.2, 2.5, A.1, A.2a, A.3 wording, A.4, A.6, A.8, paged `staleTime`, `[]` initial) | **still fixed** | fixed |

Totals: **20 fixed or improved**, **8 open** (3 docs: 1.2, 2.3, 2.4; 2 by design: tie-break, last-writer-wins; 3 unchanged notes: C.1, C.6, C.7), **1 new problem** (below).

## 2. New in the library (read + tested)

| New | Result |
| --- | --- |
| `query({ whenAborted: 'loading' \| 'idle' })`, `IdleStatus` / `PagedIdleStatus`, a fifth status `'idle'` | **works.** A first load cancelled with `abort()`: default → `state: ready`, no data (the old confusing answer to the FAQ-abort question in `_fork-F-notes.md`); `'loading'` → `state: loading, fetching: false`; `'idle'` → `state: idle, loading: false`. A bad value throws "whenAborted is 'loading' or 'idle'…" |
| Rescue copy for async `persist` on `pagehide` | works (see above) |
| Held change events for `subscribe` / `onChange` / `logger` | works (see above) |
| Dev warning when a shared store's definition changes | works |
| `snapshot()` throws on an `undefined` state key | confirmed (L~4033, message says use `null` or `ssr: { exclude }`); a loaded param-less query serialises fine |
| Offline / `reset()` documentation | present |

## 3. New problem: a stale, visible paged list is reset to page 1 on window focus

`fetchInfinite` (~L3054) treats "the entry is stale and shown by at most one component" as "start over from page 1". That "at most one"
includes the one component showing the list, and the focus/online refresh calls `fetchQuery` for every on-screen entry. So someone who
loaded more pages and then comes back to the tab after `staleTime` loses everything below page 1.

- Throwaway page (`staleTime: 1000`, 4 pages loaded, wait 1.3 s, `focus`): pages `1,2,3,4` → `1`. A fresh list is untouched.
- **In the real app:** Venues, "Load more" (6 → 12 cards), wait 31 s (default `staleTime` 30 s), window `focus`: **12 → 6 cards**. The notifications
  list (`staleTime` 5 s, `max: 3`) is exposed too.
- The library's own comment above it (~L3030) says the opposite: "Loaded pages aren't refreshed on focus or when stale; `refetch()` starts over,
  which keeps the scroll position stable."
- Suggested fix: apply "start over" only when the entry is **restored or first shown** (not on focus/online refreshes), or skip paged entries in
  `refreshVisible`. App-level workaround until then: a large `staleTime` on paged queries.

(Round 4 flagged this as a risk; the real-app repro now confirms it.)

## 4. What still works (re-run on the new library, all green)

| What | Result |
| --- | --- |
| TypeScript 5.9.3 and 7.0.2, web + API | 0 errors |
| `next build` (production, 36 routes) | passes |
| 61 Lab self-tests (Edge and WebKit) | 61/61 |
| 15 store-feature browser checks (Edge and WebKit): server-scope quote, "Saving…", session prefs, 2 + 4 real-tab sync, `validate` on a stamped bad message, DevTools `JUMP_TO_STATE`, focus/online refresh, `retryDelay` gaps, offline queue | 15/15 and 15/15 |
| 7 feature journeys, ~110 steps, fresh database | all pass. One step ("RSVP going → counts update") failed twice on a populated database because the test waited a fixed 1 s for the refetch; it passes on a fresh run and in a standalone repro (the count updates ~0.3–0.5 s after the click). The test now waits for the text instead |
| 36-route scan, two passes | no console errors, no 4xx/5xx |
| Pages Router data tag, Server Action, Route Handler scope, nested `<Root scope>`, hydration with the offline copy on `/tournaments`, `/coaches`, `/leaderboard` | still work |

## 5. Still not covered

A real Redux DevTools extension (a fake one was used), Firefox (`firefox.exe` can't be started on this machine), 5+ real tabs, real Next Fast Refresh,
and the scrolled-list reset above in a real long list beyond the 6 → 12 cards case.
