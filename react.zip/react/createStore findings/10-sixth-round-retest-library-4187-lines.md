# 10. Sixth round: everything re-tested against the library updated again (4,187 lines)

`c:\react\.store\createStore.ts` is now **4,187 lines** (was 4,104; the app's copy is identical). I did not edit it. The new file was diffed against
the saved 4,104-line copy (111 changed lines), every row of the round-5 scoreboard (`09-…`) was re-run, and the whole app was run again.
Per-item evidence: scratchpad `retest-R5.md`. **No regressions and no new library problems were found.**

## 1. What changed in the library (the whole diff)

1. Paged lists that are on screen are no longer refreshed by window focus / `online` (`inFocusRefresh`, `shownAgain`).
2. New option **`pages.refresh: 'first' | 'loaded'`** (validated: a wrong value throws a clear message).
3. Docs: the `react-bindings` contract (file header), "computed values are read like `const [total] = useGlobalState('total')`", and the placeholder
   argument of no-params queries (`query((_: undefined, signal) => …)`).
4. `hydrate()` hardening: only the **last** `<script type="application/json">` with the data-tag id is read; other elements with that id are ignored with a warning.
5. Rescue copy hardening: used only if it is valid saved state **and strictly newer**.

## 2. Scoreboard

| Finding | Round 5 | Now |
| --- | --- | --- |
| **09 · NEW-1: a stale, visible paged list resets to page 1 on window focus** | new problem | **FIXED.** Page with `staleTime: 1000`, 4 pages, wait 1.3 s, `focus`: `1,2,3,4` stays `1,2,3,4` (was `1`). Real Venues page: Load more 6 → 12 cards, 31 s, focus: **12 → 12** (was 12 → 6); `focus` and `online` make 0 requests |
| notifications list, same exposure | exposed | **fixed for focus** (30 items stay 30). One *app-side* cause remains: a late WebSocket notification calls `invalidate('notifications')`, which means "start over". The app now sets `refresh: 'loaded'` on `notifications` and `venues`, so a refresh keeps the loaded length |
| 1.2 `react-bindings` contract | still present | **fixed (docs)** — the header lists every export it must provide (`createContext`, `createElement`, hooks, `RSC`, `cache`, `ClientRoot` with `__SnapshotContext` / `__mergeSnapshot`). **Caveat:** it says "the package ships it", but `c:\react\.store\` still contains only `createStore.ts`, so the file itself is still not there to copy |
| 2.3 computed values read as `const [x]` | still present | **fixed (docs)** |
| 2.4 dummy first argument of no-params queries | still present | **fixed (docs)** — behaviour unchanged (`fetch(undefined, signal)`) |
| 1.1 render-time notifications (hooks and `subscribe`/`onChange`/`logger`) | fixed | **still fixed** (0 warnings: `/lab` → 8 pages, Home → 9 pages) |
| 06 · A.2b async adapter + `pagehide` | fixed | **still fixed** — real IndexedDB, reload at 0 / 10 / 30 / 100 / 400 ms: 60/60 kept |
| 1.3–1.8, 2.1, 2.2, 2.5, 06 · A.1–A.6, A.8, 07 · A.1–A.3, F | fixed | **still fixed** |
| 07 · G same-tick tab ties decided by tab id | by design | **still present** (5 stores × 30 rounds: always agree, one store wins; 4 real tabs: agree, winners vary) |
| 07 · G whole-value last-writer-wins (two list appends keep one) | by design | **still present** |
| 07 · I shared store, changed definition on hot reload | warns once | **unchanged** (same instance, one warning, fresh store after `destroy()`) |
| 06 · C.1 / C.6 / C.7 | unchanged | **unchanged** |
| `snapshot()` throws on an `undefined` key | confirmed | **still true** |

Totals: **23 fixed or improved**, **7 open** (2 by design: tie-break and last-writer-wins; 3 unchanged notes: C.1, C.6, C.7; 1 kept hot-reload warning; 1 caveat: `react-bindings` isn't in `.store/`), **0 new problems**.

## 3. New in the library, tested

| New | Result |
| --- | --- |
| **`pages.refresh: 'loaded'`** | **works.** Refetches as many pages as were loaded, in order, and swaps them in at once, so the list never shrinks while refreshing. A server list that got shorter (5 → 3 items) ends at `1,2,3` and stops asking where it ends; with `max: 3` and pages 4,5,6 loaded it refetches 4,5,6 (keeps the window); `refresh: 'first'` + `refetch()` still starts over. A stale list shown again: default `'first'` → `1,2,3,4` becomes `1`; `'loaded'` → all four kept, requests `p1 p2 p3 p4` in order |
| `pages.refresh` validation | works: `'everything'` and `5` throw "pages.refresh is 'first' … or 'loaded' …"; the unknown-option message lists `first, next, max, refresh` |
| `hydrate()` data-tag hardening | **works.** A fake `<div>` and a fake `text/plain` script with the same id in front of the real tag: the store read the real value (`a = 5`), one warning "hydrate() found N other element(s) with the data tag's id… ignored them" |
| Rescue-copy hardening | **works.** Garbage, JSON without `state` (even with a huge `$saved`), an equal timestamp and an older copy are ignored; a strictly newer valid copy is used and written back; the rescue key is always removed |
| `whenAborted` on paged queries | works (default → `ready`, `'loading'` → `loading`, `'idle'` → `idle`) |

## 4. App changes made because of the update
- `venues` and `notifications` paged queries now use `refresh: 'loaded'`. With it the real Venues page keeps 12 cards after a 31 s wait plus focus.

## 5. What still works (all green on the new library)

| What | Result |
| --- | --- |
| TypeScript 5.9.3 and 7.0.2, web and API | 0 errors |
| `next build` (production) | passes |
| 61 Lab self-tests (Edge **and** WebKit) | 61/61 |
| 15 store-feature browser checks (Edge **and** WebKit) | 15/15 and 15/15 |
| 7 feature journeys, ~110 steps, **fresh database** | g1 21/21 · g2 18/18 · g3 13/13 · g4 12/12 · g5 12/12 · g6 7/7 · g7 7/7 |
| 36-route scan | clean |
| 100,000-item state, 20,000 cache entries, 5-tab sync, DevTools time travel, offline queue, `retryDelay` | unchanged |

(g4/g5 fail on a long-lived database with the same three signatures as before: leftover events/bookings from earlier runs, not the library.)

## 6. Still not covered
A real Redux DevTools extension (a fake one was used), Firefox (`firefox.exe` can't be started on this machine), 5+ real tabs, real Next Fast Refresh.
