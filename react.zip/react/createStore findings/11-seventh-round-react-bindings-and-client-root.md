# 11. Seventh round: new `react-bindings.ts` and `client-root.tsx` (with the 4,187-line `createStore.ts`)

You changed the React glue next to the library: `apps/web/src/lib/store/react-bindings.ts` and `client-root.tsx` (the library file itself is the
same 4,187 lines as in round 6). I did not edit any of them. Per-check evidence: scratchpad `retest-R6.md`.

**Result: nothing regressed; one latent fragility; one improvement.**

## 1. What changed in the glue (inferred from the old files in `05-integration-guide.md`)

- `react-bindings.ts` no longer substitutes a fake `createContext` when React has none (Server Components). The library now guards that itself
  (`RSC ? null : createContext(...)`, createStore.ts ~L20 and ~L803), so the workaround isn't needed. This is the final form of finding 01 · 1.3.
- `ClientRoot` is exported as `unknown` and imported from `./client-root`; `client-root.tsx` is a `'use client'` file that merges the server
  snapshot in a **`useLayoutEffect`** (so a new page's components subscribe after the merge instead of fetching first), which is what the
  library header (L41-61) now prescribes.
- The import cycle `createStore → react-bindings → client-root → createStore` existed before and still exists.

## 2. What was tested (dev and production builds, Edge; the store suites also in WebKit)

| Check | Result |
| --- | --- |
| `next build` (production) | passes, **no** circular-dependency or `'use client'` warnings |
| Server HTML has the data on `/`, `/venues/3`, `/games`, `/tournaments`, `/coaches`, `/events`, `/help`, `/blog`, `/policy`, `/p/aarav_k`, `/leaderboard` | yes, all 22 probes (11 routes × dev and prod) |
| Hydration and console: first load of 11 routes and client navigation through 7 header links, logged out and in, dev and prod | **0** errors or warnings (4 runs) |
| Pages Router `/p/aarav_k` (data tag + `hydrate()`), Route Handlers `/share/aarav_k` and `/quote` (₹1545, `undo` check true) | work in dev and prod |
| `/lab` → Venues and `/lab` → Play ("Cannot update a component while rendering") | 0 warnings, dev and prod |
| 61 Lab self-tests; 15 store-feature browser checks (DevTools time travel, 4-tab sync, offline queue, focus/online refresh, `retryDelay`, server-scope quote…) | 61/61 and 15/15 in Edge **and** WebKit |
| `tsc` 5.9.3 and 7.0.2, web + API | 0 errors |
| 7 feature journeys on a fresh database, 36-route scan | 21/21 · 18/18 · 13/13 · 12/12 · 12/12 · 7/7 · 7/7, scan clean |

## 3. The fragility (not reachable in the app today)

**Load order matters now.** If a module imports `react-bindings.ts` *before* `createStore.ts`, it throws
`ReferenceError: Cannot access 'RSC' before initialization` at createStore.ts:20: `react-bindings` starts evaluating, pulls in `client-root`,
which pulls in `createStore`, which reads `RSC` (not yet defined) at module top level.
- The app is safe because every file imports `createStore` first (and `store/index.ts` is the only entry), so `createStore` is evaluated first and
  finishes before `react-bindings` runs. A new file that imports `react-bindings` directly, or a bundler that reorders imports, would break it.
- The previous version avoided this because `createStore` didn't read anything from `react-bindings` at module-evaluation time.
- Suggested fixes (yours to choose): read `RSC` lazily inside a function; or have `react-bindings.ts` not import `client-root` (let `createStore.ts`
  import `ClientRoot` itself); or break the cycle by putting `__SnapshotContext` / `__mergeSnapshot` in a third module.

**Second, smaller point:** `client-root.tsx` can't be loaded under a React stub that has no hooks (its named imports `useContext`, `useLayoutEffect`,
`useMemo` fail). In Next this is a `'use client'` boundary that is not evaluated in the Server Component graph, so SSR is unaffected (server HTML checked above).

## 4. Status of the earlier open items (unchanged by this round)

Still open: tab-id tie-break and whole-value last-writer-wins (by design), C.1 / C.6 / C.7 (unchanged notes), the hot-reload warning for a changed
shared-store definition (kept). Docs for `react-bindings` are now in the library header, and the file now lives in the app, next to `createStore.ts`
(it is still not in `c:\react\.store\`).

## 5. Still not covered
A real Redux DevTools extension (a fake one was used), Firefox (`firefox.exe` can't be started on this machine), 5+ real tabs, real Next Fast Refresh.
