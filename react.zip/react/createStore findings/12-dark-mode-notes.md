# 12. Dark mode: what it showed about the store (and what was tested)

The theme is a normal store key, so it is also a small test of the library's persistence and sync. No library problem was found. The library was not changed.

## How the store is used
- `theme: 'light' | 'dark' | 'system'` is in `persist.keys` (persist **version 4**, `migrate` adds `theme: 'system'` for older saves) and in `syncTabs.keys`, and `validate` accepts only those three values.
- **Pre-paint script vs store:** a page must not flash white, so an inline `<head>` script reads the store's own saved entry (`localStorage['playo:state']` → `state.theme`) before React exists. That couples the script to the persist key and shape (`<name>:state`, `{ $version, state }`), which the library documents only in its source (see 07 · A.4, now documented in the `offline` comment for the offline keys; the `persist` key is still source-only).
- **`app.hydrated`** is the right gate for "the saved choice is loaded": until it resolves, `useGlobalState('theme')` is the default (`'system'`), and painting from it would undo what the head script did. `ThemeProvider` waits for it.
- **Tab sync** moves the *preference*; each tab paints its own `<html>` (`ThemeProvider`), so the 3D animation only plays in the tab where you click.
- **Version bump:** adding a persisted key meant bumping `persist.version` and extending `migrate`; the existing "save an old v1 state" Lab scenario upgraded through the whole chain to version 4 (the journey test expects 4 now).

## Tested (Edge, and WebKit where noted)
| What | Result |
| --- | --- |
| Theme tests (11): system light/dark, no flash at first paint (`DOMContentLoaded` already `dark`, body `rgb(9,17,14)`), click flips + saves + removes the transition class, reload and new tab, menu (Light/Dark/System, live OS changes, Escape, click outside), another tab changes it, reduced motion (no transition class, no spin), hero scene follows the pointer and changes sun ↔ moon, map tiles darkened without rebuilding the map, Pages Router page, no console errors on 6 pages | 11/11 in Edge and in WebKit, on the dev server and on the production build |
| Contrast audit of every text element on 31 pages × 2 themes | light: 2 → 0 failures after fixes; dark: 0. (Emoji are ignored; symbols such as ★ need 3:1) |
| Interactive states: hover on 11 controls, keyboard focus on 28 elements per theme, selects and their options, placeholders and typed text, the login form, menus, toasts, disabled and pressed buttons, loading skeletons | focus ring on everything (after a fix for the hero search box); form-field edges 3:1; the only remaining "failure" is a *disabled* button's label (exempt from WCAG, kept ≥ 3:1) |
| Whole app on the new styles | `tsc` 5.9.3 and 7.0.2: 0 errors; 61 self-tests; 15 store checks (Edge and WebKit); 7 journeys on a fresh database; route scan in light **and** dark |

## Second audit: dialogs and phone widths
| What | Result |
| --- | --- |
| 16 dialogs (login, checkout, day pass, cancel, reschedule, join a priced game, invite, end game, report, coach session / enrol / enquiry, host a meet-up, marathon registration, support ticket, new chat) in both themes | text contrast clean in all of them. Every one **failed** two keyboard checks at first: Escape did not close it and Tab left it. Fixed once in a shared `useDialog` hook (focus the first field, trap Tab, Escape, restore focus, lock page scroll; radio groups count as one stop), used by `Modal` and the login form |
| 45 page states × 3 viewports (390, 360, 768) × 2 themes, logged in and out (270 loads) | sideways scrolling on the venue page, leaderboard, chat and the logged-in header; about 45 controls under 24 px; user/More menus that stayed open; the theme menu opening off screen: all fixed. Now 0 overflow, 0 clipped, 0 contrast failures, 0 targets under 24 px (14 name links are exactly 24 px: advisory) |
| the test itself | Playwright's mobile mode lets the layout grow to fit wide content, which hid the sideways scrolling in the first run; later runs use a plain viewport with touch |

## Third audit: tooltips, markup and the price editor
| What | Result |
| --- | --- |
| Markup audit (`html-audit.mts`), 31 routes, logged in and out | the first run found symbol-only buttons, badges and dots with no name or tooltip, cut-off text with no way to read it, disabled buttons with no reason, two `<h1>` on `/learning` and none on `/owner` when logged out, truncated chat titles. All fixed; the last run: **CLEAN, no findings** |
| Tooltips (`tooltips.mts`): hover, keyboard focus, touch long-press and tap; both themes; reduced motion | 65 / 65 |
| Price editor (`editor-link.mts`) | 12 / 12: preview row → field focused and selected; hover and focus highlight each other; keyboard |
| Test flakiness found on the way (not app bugs) | a fixed 400 ms wait for 4 real tabs to agree was too short in WebKit (convergence took up to ~460 ms: the test now waits until they agree, up to 3 s); reading the saved value right after convergence raced the 250 ms save debounce; the `retryDelay` test only saw requests when the offline copy had not been saved yet |
| Dev-server pitfall (third time) | after many edits `next dev` stopped rendering the new tooltip layer until it was restarted with a fresh dist directory |

## No `dangerouslySetInnerHTML`
- The theme script is now a static file instead of an inline script. The public profile page no longer uses the library's data tag (`scope.toScript()` written into the page, read by `hydrate()`), which needs `dangerouslySetInnerHTML`: it passes the snapshot in the Next page props and calls `hydrate(snapshot)`, which the library supports. So the app no longer exercises `toScript()` / the no-argument `hydrate()`; the library's own self-test of `serializeSnapshot` still covers the escaping, and earlier rounds covered the data tag in a browser (06 · C.3, 09).
- The library itself now warns when other elements share the data tag's id ("If the page shows user-written HTML, that's where they came from") and reads only the last `<script type="application/json">`: the data tag is a place where user-written HTML can interfere, which is one more reason to prefer the props route.
- `xss.mts`: hostile name, bio, game title, chat message and ticket subject on 10 pages, two users, both themes: 40 visits, nothing executed, nothing became markup, the server HTML had no raw payload.

## Things found while doing it (app, not library)
- CARTO's dark map tiles now answer "API KEY REQUIRED"; the dark map uses the OpenStreetMap tiles with a CSS filter instead.
- White text on the brand green (`#00b259`) was only 2.9:1; the brand green was darkened to `#007f3b` (5.2:1). The faint `text-ink/20…50` steps (down to 1.5:1) were raised.
- The header ran out of room with one more button, so Tournaments and Leaderboard moved under **More ▾** on wide screens (they stay in the scrolling row on phones).
- The login form was not a `role="dialog"`; it is now. The venue page showed two Share buttons (one removed) and the gallery twice earlier.
- Dev-server pitfall: after editing a file that is server-rendered, a stale dev compile gave a one-off hydration "attribute mismatch" console error; restarting `next dev` cleared it (not reproducible in a production build).

## Not tested
Firefox (cannot launch here), real phones and screen readers, forced-colors / high-contrast mode, printing.
