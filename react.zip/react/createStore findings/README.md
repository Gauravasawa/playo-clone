# createStore findings

Notes from building a Playo-style app (Bun API + Next.js 16.4 / React 19.3) on top of
`c:\react\.store\createStore.ts`. **The library was not changed.** Everything here is something I
saw, tried, or read in the code.

Line numbers refer to `createStore.ts` as it was when this was written (3874 lines).

| File | What's in it |
| --- | --- |
| [01-issues.md](01-issues.md) | Round 1: bugs and footguns, with where, how I hit them, and a suggested fix |
| [02-docs-and-api-notes.md](02-docs-and-api-notes.md) | Wrong or misplaced comments and error messages, API ergonomics, typing notes |
| [03-what-worked.md](03-what-worked.md) | Round 1: what I exercised and confirmed working |
| [04-not-tested.md](04-not-tested.md) | What is **still** untested after both rounds |
| [05-integration-guide.md](05-integration-guide.md) | What a consumer has to supply to use the library in Next.js |
| [12-dark-mode-notes.md](12-dark-mode-notes.md) | Dark mode built on the store (persist v4, syncTabs, validate, `hydrated`): how it was tested (theme e2e, contrast audit, interactive states) and what it found in the app |
| [11-seventh-round-react-bindings-and-client-root.md](11-seventh-round-react-bindings-and-client-root.md) | **Round 7 (latest): the new `react-bindings.ts` + `client-root.tsx` tested: build, SSR, hydration, Route Handlers, Pages Router all fine; one latent fragility: the import cycle makes load order matter** |
| [10-sixth-round-retest-library-4187-lines.md](10-sixth-round-retest-library-4187-lines.md) | **Round 6 (latest): re-test against the library updated again (4,187 lines): the stale-paged-list-on-focus problem is fixed, new `pages.refresh`, hydrate/rescue hardening, docs; 23 fixed/improved, 7 open, 0 new problems** |
| [09-fifth-round-retest-library-4104-lines.md](09-fifth-round-retest-library-4104-lines.md) | **Round 5 (latest): re-test against the library updated again (4,104 lines): 20 fixed/improved, 8 open, 1 new problem (stale paged list resets to page 1 on focus); new `whenAborted`, rescue copy, held change events** |
| [08-fourth-round-retest-after-library-update.md](08-fourth-round-retest-after-library-update.md) | **Round 4 (latest): every finding re-tested against the updated library; scoreboard (fixed / still present), what still works, new open problems** |
| [07-third-round-phase3.md](07-third-round-phase3.md) | Round 3: tab sync between real tabs, DevTools time travel, nested Root, scope on the server, saving indicator, session store, offline size limit and queue, retryDelay, focus/online refresh, concurrency, benchmark, TypeScript 7.0.2, WebKit; new issues (A.1 `[]` crash, A.2 stale reload) |
| [06-second-round-social-build.md](06-second-round-social-build.md) | Round 2: new issues, new things confirmed, new integration notes (WebSocket, IndexedDB store, Pages Router, Server Actions, offline, validate…) |

> **Read 11 and 10 first (then 09, 08).** Files 01–07 describe the library *as it was*. After the library was updated three times, 23 of the findings are fixed or improved
> (e.g. render-time warning for hooks, rewriting saved state, reload during a save, `[]` initial value, stale paged queries, offline `invalidate`,
> hydration mismatch, error messages), and 7 remain (2 by design, 3 unchanged notes, the hot-reload warning, and `react-bindings` not being in `.store/`); no open new problems. Each old section is still accurate history; 08 has its current status.

## Short version (as of round 3; see 08 for today)

- **Works:** params and paged queries (with `max`), optimistic setters and `keyActions` with rollback, computed
  layers, history, persist (with `version`, `migrate`, `debounce`, async IndexedDB adapter), `offline` + `whenOnline`,
  `validate`, `devtools`, `logger`, events with `broadcast`, `gcTime`, `abort`, `createScope`, and full SSR on
  Next.js: Server Components, the Pages Router data-tag path (`toScript` / `hydrate`), a Server Action and a Route Handler.
  30 in-browser self-tests, a 61-check backend test and 39 browser steps (dev with StrictMode, and production) passed.
- **Needs attention (confirmed):**
  1. **Every change rewrites the saved state**, even for keys that aren't saved (`persistChanges`), and unrelated
     changes keep re-arming `debounce` (06 · A.1, A.2).
  2. `debounce` + `pagehide` **loses the last write with an async adapter** (06 · A.2).
  3. Snapshot merging calls `setState` on other components **during render** (React warning) (01 · 1.1, 06 · A.7).
  4. `./react-bindings` is not in `.store` and its contract is undocumented; `createContext` is called unconditionally
     even in Server Components (01 · 1.2, 1.3).
  5. Error messages point to an option that doesn't exist (`ssr: { serialize }`) (02 · 2.1).
  6. `invalidate()` isn't saved to the offline copy, so a reload can serve stale "fresh" data (06 · A.4).
  7. A rejected saved value falls back to the **initial** value (a bad saved token logs the user out), but the warning
     says it "keeps its current value" (06 · A.3).
  8. **`offline: true` restores saved query data before hydration**, so any page that shows data the server didn't
     fetch throws a hydration error (06 · A.8). The render-time warning (3) is also more widespread than first
     recorded: it shows Next's "1 Issue" badge on client navigation to Play and to a venue (06 · A.7).
- **Needs attention (from reading the code, not reproduced):** a default `ssr: true` snapshot carries every state key
  and would overwrite persisted state on hydrate (01 · 1.5); `query()` without `initial` starts as `[]` for any return
  type (01 · 1.6); `createScope(initial)` is typed narrower than what it accepts (06 · A.6).
- **Behaviour to be aware of:** reloading while an optimistic save is in flight rolls the change back (01 · 1.4); the
  offline copy keeps per-user data on the device until `reset()` (06 · A.5).
- **Not the library, but easy to blame it on:** Next 16 blocks its dev scripts for any host except `localhost`, which
  makes a store-driven app look like it never loads (06 · C.8).
- **Round 3 (07):** tab sync, DevTools time travel, nested `<Root>`, a scope on the server (computed + key actions + history), `onSaveStart`, `persist: 'session'`, `offline.maxSize`, several `whenOnline` tasks, `retryDelay`, focus/online refresh and concurrency all behave as documented; TypeScript 7.0.2 (0 errors, 10x faster) and WebKit pass. New: a param-less query starts as `[]` and crashed a page (07 · A.1); a restored paged query isn't refetched after a reload (07 · A.2).
- **Gaps closed afterwards (07 addendum):** 3-5 tabs and same-tick writes always converge (the same-tick winner is arbitrary; lists are last-writer-wins, not merged); `set.<key>(value)` and `getState()` work; a **shared store ignores a changed definition on hot reload** (07 · I); 100,000-item state is fast; the stale paged query is explained: **`staleTime` is accepted but ignored for paged queries**, and `invalidate` of an unobserved entry is not persisted (07 · F).
- **Not tested:** a real Redux DevTools extension, Firefox (could not be launched here), 5+ real tabs, real Fast Refresh (see 04).

## Environment

Bun 1.3.14 · Next.js 16.4.2 (Turbopack) · React 19.3.1 · TypeScript 5.9 · Edge (Chromium) driven by
`playwright-core` on Node 24. App: `c:\react\playo-clone`.
