# Fork A (money UI) notes — append-only

- Computed `quote` (layer 3) reads `checkout`, `pricing` and `selection`; the checkout writes `pricing` from an effect (venue rentals, Plus, Karma, whether the pass covers the slots). Works, but it means a computed value depends on state that is only filled once a component mounts: not testable without opening the modal.
- `app.getState('quote')` used inside the book handler to read a computed value outside React — untested in a browser yet.
- Optimistic `setBookings(updater, save)`: the save function's return value is ignored, so the cancel result (refund amount) is captured via a closure variable.
