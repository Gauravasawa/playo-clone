# Fork B (venues UI) notes
- `useGlobalState('mapVenues', filter, { enabled: view === 'map' })` worked as a lazy query: nothing is fetched until the map tab is opened.
- The `sort` state key now holds 'distance'; if it is restored from persist while `location` (not persisted) is null the view falls back to 'rating' itself. A persisted value that depends on a non-persisted one is easy to get wrong.
- Filters that are not shared across pages (amenities, max price, km) are local useState in the view and become the query param object; every distinct object is its own cache entry (works, but keep the params memoised or each render re-keys).
