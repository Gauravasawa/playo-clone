# Fork C notes (games UI v2)

- Games lists are keyed by { city, sport, token }, so logging in/out gives a separate cache entry per token (the private-game-aware list); invalidate("games") refreshes all of them. No library problem, but worth knowing: params that include a token fragment the cache.
- Optimistic setGames was dropped for join/leave: joins now involve payments, approval holds and server-side rules (level, capacity), so the UI calls the API and invalidates games/myGames/game/gameByCode/wallet/karma instead.
