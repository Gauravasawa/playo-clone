# Fork D notes (social/safety UI)

- Nothing library-specific found while building these screens. `blocks`, `adminReports` use `refetchAfterMutation`, but block/unblock go through plain api calls, so I invalidate by name (blocks, player, friends, suggested, chats...) after each one.
- Browser push is gated on the persisted `pushEnabled` key plus the browser permission, read with app.getState inside the realtime handlers.
