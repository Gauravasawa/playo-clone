# Fork E notes (coaching + events UI)

Observations while building; not yet merged into the numbered findings files.

1. **Public detail pages (`/coaches/[id]`, `/events/[id]`)**: the same query holds both public data and "mine" data (`canReview`, `mine`), keyed by `{ id, token }`. Server prefetch uses `token: null`; the client switches to the real token only after mount (`mounted ? token : null`) so the first client render matches the server HTML. After login the param changes, so the entry is a new one and the list shows its loading state once. A separate "mine" query would avoid that flash.
2. **`app.useGlobalState('learning', token ?? undefined, { enabled })`**: `enabled` is the clean way to skip a login-only query; no `waitFor` needed.
3. **`refetchAfterMutation: true` on `coach` / `event` / `events` / `coachSlots`** plus explicit `app.invalidate(...)` after each booking. Both are needed: the first only fires for key-action saves, and these actions are plain API calls.
4. **Slot picker in a modal** keys `coachSlots` by `{ id, date }`, so flipping between days re-uses cached days instantly (staleTime 5 s).
5. Heredoc writes of TSX with `'`/backticks in the shell broke (unterminated quote); the Write tool is the reliable path.
