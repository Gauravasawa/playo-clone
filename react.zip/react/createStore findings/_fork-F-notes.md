# Fork F notes (owner dashboard + help) — append-only

Status: written from reading `createStore.ts` and type-checking only. No browser run was done by this fork (no dev server allowed), so everything below marked "expected" still needs an e2e check.

## Nested `<Root>` with its own scope (owner price preview)
Where: `features/owner/PricePreview.tsx`. `const [scope] = useState(() => app.createScope({ pricing: {...} }))`, then `<app.Root scope={scope}>` inside the page that already sits under the layout's Root.
- Source says (createStore.ts ~L717): `createScope` builds a fresh store from the same definition with `shared:false, persist:false, syncTabs:false, offline:false, devtools:false`. So the preview scope is never saved, never synced to other tabs and never shows up in Redux DevTools. Good for a "what if" sandbox; also means key actions / computed (`quote`, `slotCount`) do work in the scope, since they come from the same definition.
- `Root` nested in the browser with a scope that is not `base` gives no warning; warns only (once) if nested during SERVER rendering, or if `scope === base`. The owner dashboard returns `null` until mounted and the Pricing tab only renders after data loads, so it never renders on the server.
- Hooks inside the nested Root resolve to the nearest Root's scope; `app.getState(...)` always reads the app's own store (the preview shows this in `data-testid="preview-global-check"`: slots/extras of the real store stay untouched while the owner types).
- Expected, not verified: typing a price calls `setSelection(...)` in the scope only; the real `selection` stays as it was.
- Note: `selection` has `history` configured (undo/redo) on the app store; in a scope the history option is copied (`...options`), so the scope has its own undo stack too — untested.
- API shape detail: `createScope(initial)` takes `Partial<RawValues<S>>`; seeding a non-persisted key (`pricing`) worked type-wise.

## FAQ search + `app.abort('faq')`
`HelpView` debounces the text (300 ms) and calls `app.abort('faq')` on every keystroke (effect on the raw text). Question for the e2e: what does a query entry look like after its in-flight request is aborted — error state, or silently idle? The view keeps the last good answers in a ref so a flash of error can't empty the list; `data-testid="faq-meta"` carries `data-cancelled` (count of aborts).

## Other
- Public pages (/help, /blog, /blog/[slug], /policy) prefetch on the server (`ssr.keys` already has faq/articles/article/policy) to avoid the offline-cache hydration mismatch found in round 2 (A.8). Article uses `DEFAULT_CITY` on the server and the visitor's city after mount.
- `useSearchParams()` returns `ReadonlyURLSearchParams | null` in this Next version's types, so `/help/tickets` wraps the view in `<Suspense>`.
- Tooling: a long multi-heredoc Bash command with `'` inside JSX text failed to parse ("unexpected EOF") and ran nothing — use the Write tool for files.
