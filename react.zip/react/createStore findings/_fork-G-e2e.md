# Fork G: browser journeys for every Phase 3 feature (what broke, what it taught)

Scripts: `…/scratchpad/e2e/g1-money.mts`, `g2-venues-games.mts`, `g3-social-safety.mts`, `g4-learning-events.mts`,
`g5-owner-help.mts`, `g6-notifs-policy.mts` (+ shared `glib.mts`). Node + Playwright-core + Edge, two or three signed-in users per journey,
production build on :3000, API on :4000.

## createStore observations

### G.1 A query without params starts as `[]`, even when it returns an object
`policy: query((_: undefined, signal) => api.policy(signal))` read with `useGlobalState('policy')` is `[]` until the first response
(the library default for `initial` is `[]`). `[]` is truthy and has no `giftCard`, so `policy?.giftCard.min` threw during the first
render and took the whole page down ("This page couldn't load"). Queries *with* params give `undefined` before the first response, so
the two kinds behave differently.
Workaround: `initial: null as unknown as Policy` on object-returning queries without params. Worth a type-level fix: `initial` could
default to `undefined` for non-array results, or the hook's first element could be typed `T | undefined` honestly.
Repro: open `/wallet?tab=gift` in a fresh browser (nothing cached).

### G.2 A restored paged query is not refetched after a full reload
Open `/notifications`, go to `/games` (client-side), let the WebSocket deliver two new notifications (the handler calls
`app.invalidate('notifications')` while nothing observes the query), then reload `/notifications`. The list shows the *old* data and no
request to `/api/notifications` is ever made (checked with a response listener for 12 s), although the saved copy is older than
`staleTime: 5_000`. Other (non-paged) lists such as chats and games refreshed fine in the same journeys.
Workaround: `NotificationsView` calls `app.invalidate('notifications')` once on mount.
Not root-caused in the library; the offline-cache restore (`updatedAt` kept) and `invalidate` of an unobserved query are the two
places to look. Repro script: `dbg4.mts` in the e2e folder.

### G.3 Effects that return a value crash only when the value is a non-function (React, but the store makes it easy)
`useEffect(() => end.current?.scrollIntoView(...), [count])` threw `i is not a function` when the dependency changed (React 19 calls the
returned value as the cleanup). Same pattern for `useEffect(() => setState(...))`. Not a library bug, but `app.subscribe(...)` is the
one legitimate "return the unsubscribe" case, which makes the expression-bodied form look idiomatic. All effects now use braces.

### G.4 Nested `<Root>` preview worked as designed
`app.Root scope={app.createScope(...)}` around the owner price preview: `useGlobalState('selection'|'checkout'|'pricing'|'quote'|'slotCount')`
inside it read and wrote the scope, while `app.getState('selection')` (read from a plain interval next to it) kept reporting the app's own
store: 0 slots before, during and after editing prices (asserted through `data-slots` on `preview-global-check`).

### G.5 `abort('faq')` while typing
Typing "refund" with a 60 ms delay (300 ms debounce) results in `faq-meta data-cancelled=6` on the search page: requests were aborted
and the UI kept the last good answers. No errors in the console.

## App bugs found by the journeys (all fixed)

| # | Where | What | Fix |
| - | ----- | ---- | --- |
| 1 | `store/queries.ts` policy | G.1: gift-card tab crashed on first render | `initial: null` |
| 2 | `features/notifications/NotificationsView.tsx` | G.2: stale list after reload | invalidate on mount |
| 3 | `features/help/TicketThreadView.tsx` | G.3: page crashed when the agent's reply arrived | braces around the effect |
| 4 | `features/safety/AdminReportsView.tsx` | non-admins fetched `/api/admin/reports` and got a 403 in the console before `me` loaded | params only when `me.isAdmin` |
| 5 | `apps/api/src/services/games.ts` `inviteToGame` | the invite modal lists *friends and people you've played with*, the server only accepted friends (403) | accept players you've played with too |
| 6 | `apps/api/src/routes/help.ts` | blog search ignored tags/sport (searching "football" found nothing) | match tags and sport too |
| 7 | `features/booking/VenueDetailView.tsx` | gallery rendered twice (here and in `VenueInfo`) | removed one |
| 8 | `features/games/GamesView.tsx` | `/games?with=username` ("Join a game together") was ignored | banner + filter by player |
| 9 | `realtime/handlers.ts` etc. | new notification types had no wording | `describe.ts` for all of them |

## Notes that are not bugs but worth knowing

- Login rate limit is per phone number (a brute-force guard for the OTP), not per IP: 11 logins to the same number in a minute give 429,
  logins to different numbers don't. The spec said "per IP when logged out"; this is stricter for OTP guessing and was kept.
- Football venues offer two rentals both labelled "Ball" (football ₹60/h and basketball ₹50/h): the checkout lists equipment for every sport
  of the venue. Cosmetic.
- A host is credited the price of every *paid* join when a game ends, including players marked absent (they paid; no refund for no-shows).
- Test pitfalls: slot buttons and their inner "taken" label share a `slot-` testid prefix (`button[data-testid^=slot-]`); Leaflet marker icons
  are 0×0 boxes so `visible` waits fail (use `attached` and a dispatched click); headless Edge has `navigator.share`, so the Share button
  opens the share sheet unless the test removes it; `window.confirm()` (block player) needs a dialog handler.
