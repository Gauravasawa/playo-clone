# createStore documentation page

| File | What it is |
| --- | --- |
| `createStore documentation.html` | the improved page (open it in a browser; it is one self-contained file) |
| `createStore documentation (original).html` | the page as you gave it (copied from `Microsoft Teams Chat Files`); the original in OneDrive was not touched |
| `build-docs.js` | `node build-docs.js` rebuilds the improved page from the original: the changes are in this one readable script, not hand-edited into 380 KB of HTML |
| `check-docs-against-library.js` | compares the page with `.store/createStore.ts`: documented names that don't exist, library options the page doesn't mention |

## What changed in the page
- **The left list follows the page.** Scrolling, clicking or tabbing into the text, selecting text (a field in a table, a heading), a link, the search and a `#section` in the address all mark the matching section on the left, and the current section opens a short list of its sub-headings with the current one marked. Before, the left list was driven only by an IntersectionObserver band: opening `#persist` marked the section *before* it (`named-queries`), and clicking a paragraph in `#persist` while `#sync-tabs` was on screen marked `cancel-retry`.
- **Tooltips on hover and keyboard focus** (and tap / long-press on touch): the icon buttons (menu, theme, search, copy), and 84 API names (288 places in the running text, e.g. `persist`, `staleTime`, `keys`) explain themselves, with the text taken from the API reference tables at load time, so nothing is typed twice. Existing `title` attributes became the same tooltip, so the slow native one doesn't show twice.
- Small fixes: `scope="col"` on all table headers (127), code blocks scroll with the keyboard (`tabindex="0"`).

## Not changed
All the text, the search index, the live demo, the theme switch and the copy buttons.
Documented by the checker but missing from the page: the `whenAborted` query option; the rescue copy written when the page is hidden (async storage); that the offline copy keeps per-user data until `reset()`; the `react-bindings` file.

Tests: `tests/e2e/docs-page.mts` (16 checks; run it with `FILE="file:///C:/react/docs/createStore%20documentation.html"`).
