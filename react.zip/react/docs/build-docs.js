// Builds "createStore documentation.html" from the original page (docs/createStore documentation (original).html):
//   * the left list follows the page: scrolling, clicking or selecting text in the page, a link, the search or a #hash all select the matching
//     section (and its sub-heading) on the left; the current section opens a short list of its sub-headings
//   * tooltips on hover and keyboard focus: icon buttons, copy buttons, and every API name in running text (taken from the API reference tables)
//   * small markup fixes: scope on table headers, keyboard-scrollable code blocks
// Run: node build-docs.js
const fs = require('fs');
const path = require('path');
const dir = __dirname;
const src = path.join(dir, 'createStore documentation (original).html');
const out = path.join(dir, 'createStore documentation.html');
let html = fs.readFileSync(src, 'utf8');
const before = html;

function replaceOnce(from, to, label) {
  if (!html.includes(from)) throw new Error('not found: ' + label);
  html = html.replace(from, () => to);
}

/* ---------- CSS ---------- */
const CSS = `
/* ---------- Added: sub-headings under the current section, tooltips ---------- */
.sidebar ul.sub { margin: 2px 0 8px 14px; padding: 0 0 0 8px; border-left: 2px solid var(--line); }
.sidebar ul.sub[hidden] { display: none; }
.sidebar ul.sub a { font-size: 13.5px; padding: 3px 8px; color: var(--ink-2); }
.sidebar ul.sub a[aria-current] { color: var(--ink); background: var(--accent-soft); font-weight: 700; }
.sidebar a[aria-expanded="true"]::after { content: ""; }
.has-tip { cursor: help; text-decoration: underline dotted var(--ink-3); text-decoration-thickness: 1px; text-underline-offset: 3px; }
.tip {
  position: fixed; z-index: 200; left: 0; top: 0; max-width: min(340px, calc(100vw - 16px)); padding: 7px 10px; border-radius: 8px;
  background: var(--ink); color: var(--bg); font: 500 13px/1.45 var(--font-body); box-shadow: 0 6px 22px rgba(0, 0, 0, .28);
  pointer-events: none; opacity: 0; transition: opacity .12s ease; overflow-wrap: anywhere;
}
.tip.show { opacity: 1; }
.tip b { font-family: var(--font-mono); font-weight: 500; }
@media (prefers-reduced-motion: reduce) { .tip { transition: none; } }
@media print { .tip { display: none; } }
`;
replaceOnce('</style>', CSS + '</style>', 'style end');

/* ---------- Markup ---------- */
// the controls get a title (also works with no JavaScript); the script turns every title into the styled tooltip
replaceOnce('aria-label="Open navigation" aria-controls="sidebar"', 'aria-label="Open navigation" title="Show or hide the navigation" aria-controls="sidebar"', 'menu');
replaceOnce('<a class="brand" href="#top" aria-label="createStore home">', '<a class="brand" href="#top" aria-label="createStore home" title="Back to the top">', 'brand');
replaceOnce('<button class="search-btn" type="button" aria-label="Search the docs"', '<button class="search-btn" type="button" aria-label="Search the docs" title="Search the docs (press / or Ctrl+K)"', 'search');
replaceOnce('aria-label="Switch between light and dark mode">', 'aria-label="Switch between light and dark mode" title="Switch between light and dark mode">', 'theme');
replaceOnce('type="button" aria-label="Hide navigation">', 'type="button" aria-label="Hide navigation" title="Hide the navigation">', 'close nav');
html = html.split('<button class="copy" type="button">Copy</button>').join('<button class="copy" type="button" title="Copy this code to the clipboard">Copy</button>');
html = html.split('<button class="small-copy" type="button"').join('<button class="small-copy" type="button" title="Copy to the clipboard"');
html = html.split('<th>').join('<th scope="col">');
html = html.split('<pre><code').join('<pre tabindex="0"><code');

/* ---------- Script: the current section ---------- */
const NAV_START = '  /* ---------- Current section in the navigation ---------- */';
const NAV_END = '  /* ---------- The live demo';
const a = html.indexOf(NAV_START);
const b = html.indexOf(NAV_END);
if (a < 0 || b < 0 || b < a) throw new Error('nav block not found');

const NAV = `  /* ---------- Current section in the navigation ---------- */
  // The left list follows where you are. Scrolling, clicking or tabbing into the page, selecting text, a link, the search or a #hash in the address
  // all mark the section on the left, and open a short list of that section's sub-headings with the current one marked.
  var links = {}; $$('[data-nav]').forEach(function (a) { links[a.getAttribute('data-nav')] = a; });
  var subLinks = {};
  var sections = $$('.doc-section');
  sections.forEach(function (sec) {
    var a = links[sec.id]; if (!a) return;
    var heads = $$('h3[id]', sec); if (!heads.length) return;
    var ul = document.createElement('ul'); ul.className = 'sub'; ul.hidden = true; ul.id = 'sub-' + sec.id;
    heads.forEach(function (h) {
      var li = document.createElement('li'), sa = document.createElement('a');
      sa.href = '#' + h.id; sa.setAttribute('data-sub', h.id); sa.textContent = h.textContent.replace(/^#\\s*/, '').trim();
      li.appendChild(sa); ul.appendChild(li); subLinks[h.id] = sa;
    });
    a.parentNode.appendChild(ul);
    a.setAttribute('aria-controls', ul.id);
  });
  var current = null, currentSub = null, picked = false, pickY = 0, jumping = null, jumpUntil = 0, idleTimer = 0;
  // keep the marked entry inside the visible part of the left list
  function keepVisible(a) {
    if (!a || !sidebar.offsetParent && !sidebar.classList.contains('open')) return;
    var s = sidebar.getBoundingClientRect(), r = a.getBoundingClientRect();
    if (r.top < s.top + 70 || r.bottom > s.bottom - 70) sidebar.scrollTop += r.top - s.top - s.height / 3;
  }
  function clearCurrent() {
    if (current && links[current]) { links[current].removeAttribute('aria-current'); links[current].removeAttribute('aria-expanded'); var u = $('#sub-' + current); if (u) u.hidden = true; }
    if (currentSub && subLinks[currentSub]) subLinks[currentSub].removeAttribute('aria-current');
    current = null; currentSub = null;
  }
  function setCurrent(id, subId) {
    if (!links[id]) return;
    if (id !== current) {
      clearCurrent();
      links[id].setAttribute('aria-current', 'true');
      var ul = $('#sub-' + id); if (ul) { ul.hidden = false; links[id].setAttribute('aria-expanded', 'true'); }
      current = id;
    }
    var want = subId && subLinks[subId] ? subId : null;
    if (want !== currentSub) {
      if (currentSub && subLinks[currentSub]) subLinks[currentSub].removeAttribute('aria-current');
      if (want) subLinks[want].setAttribute('aria-current', 'location');
      currentSub = want;
    }
    keepVisible(want ? subLinks[want] : links[id]);
  }
  // From the position on the page: the last section (and sub-heading) that has reached the reading line under the top bar
  function fromScroll() {
    var y = $('.topbar').offsetHeight + 24, sec = null, i;
    for (i = 0; i < sections.length; i++) { if (sections[i].getBoundingClientRect().top <= y) sec = sections[i]; else break; }
    if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) sec = sections[sections.length - 1];
    if (!sec) { clearCurrent(); return; }
    var sub = null; $$('h3[id]', sec).forEach(function (h) { if (h.getBoundingClientRect().top <= y) sub = h.id; });
    setCurrent(sec.id, sub);
  }
  // From something you picked: a click, a tab stop, selected text or a link target. It stays marked until you scroll away from where you picked it.
  function fromElement(el) {
    var sec = el && el.closest ? el.closest('.doc-section') : null; if (!sec) return;
    var sub = null, h3 = el.closest('h3[id]');
    if (h3) sub = h3.id;
    else if (!el.closest('h2')) { var top = el.getBoundingClientRect().top; $$('h3[id]', sec).forEach(function (h) { if (h.getBoundingClientRect().top <= top + 1) sub = h.id; }); }
    picked = true; pickY = window.scrollY;
    setCurrent(sec.id, sub);
  }
  // A link, the search, a #hash: the page scrolls (smoothly) to the target, so wait until it has arrived instead of following the sections it passes
  function startJump(el) { jumping = el; jumpUntil = Date.now() + 2500; fromElement(el); }
  function endJump() {
    var el = jumping; jumping = null; if (!el) return;
    var top = el.getBoundingClientRect().top, atBottom = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4;
    if (Math.abs(top - ($('.topbar').offsetHeight + 16)) < 90 || atBottom) fromElement(el); else fromScroll();
  }
  var scrollTick = false;
  window.addEventListener('scroll', function () {
    if (jumping && Date.now() > jumpUntil) endJump();
    if (!scrollTick) {
      scrollTick = true;
      requestAnimationFrame(function () {
        scrollTick = false;
        if (jumping) return;
        if (picked && Math.abs(window.scrollY - pickY) < 140) return;
        picked = false; fromScroll();
      });
    }
    clearTimeout(idleTimer); idleTimer = setTimeout(function () { if (jumping) endJump(); }, 180);
  }, { passive: true });
  window.addEventListener('resize', function () { picked = false; fromScroll(); });
  var mainEl = $('main');
  mainEl.addEventListener('click', function (e) { fromElement(e.target); });
  mainEl.addEventListener('focusin', function (e) { fromElement(e.target); });
  var selTimer = 0;
  document.addEventListener('selectionchange', function () {
    clearTimeout(selTimer);
    selTimer = setTimeout(function () {
      var sel = window.getSelection(); if (!sel || sel.isCollapsed || !sel.anchorNode) return;
      var n = sel.anchorNode; fromElement(n.nodeType === 1 ? n : n.parentElement);
    }, 120);
  });
  function fromHash() {
    var id = ''; try { id = decodeURIComponent(location.hash.slice(1)); } catch (e) {}
    var el = id && document.getElementById(id);
    if (el && el.closest('.doc-section')) startJump(el); else { picked = false; fromScroll(); }
  }
  window.addEventListener('hashchange', fromHash);
  sidebar.addEventListener('click', function (e) {
    var a = e.target.closest('a[data-nav], a[data-sub]'); if (!a) return;
    var id = a.getAttribute('data-nav') || a.getAttribute('data-sub'), el = document.getElementById(id); if (el) startJump(el);
  });
  if (location.hash) fromHash(); else fromScroll();

`;
html = html.slice(0, a) + NAV + html.slice(b);

/* ---------- Script: tooltips ---------- */
const TIPJS = `
  /* ---------- Tooltips ---------- */
  // Hover or keyboard focus shows a short explanation. The text comes from the title / data-tip attributes (a title is turned into this tooltip, so the browser's
  // slow native one does not show twice) and, for API names in running text (persist, staleTime, keys ...), from the API reference tables: there is no
  // separate list to keep in step. Touch: tap or press and hold.
  $$('[title]').forEach(function (el) { el.setAttribute('data-tip', el.getAttribute('title')); el.removeAttribute('title'); });
  var gloss = Object.create(null);
  function glossName(text) {
    return text.trim().replace(/^store\\./, '').replace(/^['"]|['"]$/g, '').replace(/\\(.*$/s, '').replace(/\\?$/, '').trim();
  }
  $$('#api table').forEach(function (table) {
    var heads = $$('thead th', table).map(function (th) { return th.textContent.trim(); });
    var typeIdx = heads.findIndex(function (h) { return /^type$/i.test(h); });
    var descIdx = heads.findIndex(function (h) { return /what it does|meaning|describes|what it.s for|notes/i.test(h); });
    $$('tbody tr', table).forEach(function (tr) {
      var cells = $$('td', tr), code = cells[0] && $('code', cells[0]); if (!code) return;
      var name = glossName(code.textContent); if (!name || name.length > 40 || /\\s/.test(name)) return;
      var desc = descIdx >= 0 && cells[descIdx] ? cells[descIdx].textContent : '';
      if (!desc) { var see = $('a', tr); if (see) desc = 'See \\u201c' + see.textContent + '\\u201d'; }
      desc = desc.replace(/\\s+/g, ' ').trim();
      if (!desc) return;
      var type = typeIdx >= 0 && cells[typeIdx] ? cells[typeIdx].textContent.replace(/\\s+/g, ' ').trim() : '';
      if (!gloss[name]) gloss[name] = { type: type.length <= 48 ? type : '', desc: desc.length > 170 ? desc.slice(0, 167) + '\\u2026' : desc };
    });
  });
  var glossed = 0;
  $$('.doc-section p code, .doc-section li code, .doc-section td code, .callout code').forEach(function (c) {
    if (c.closest('pre') || c.hasAttribute('data-tip')) return;
    if (c.closest('#api table') && c.closest('td') === c.closest('tr').firstElementChild) return;   // the definition itself
    var g = gloss[glossName(c.textContent)]; if (!g) return;
    c.className += (c.className ? ' ' : '') + 'has-tip';
    c.setAttribute('data-tip', glossName(c.textContent) + (g.type ? ' \\u00b7 ' + g.type : '') + ' \\u2014 ' + g.desc); glossed++;
  });
  var tipEl = document.createElement('div'); tipEl.className = 'tip'; tipEl.id = 'doc-tip'; tipEl.setAttribute('role', 'tooltip'); document.body.appendChild(tipEl);
  var tipFor = null, tipTimer = 0, tipHide = 0;
  function tipTarget(el) {
    for (var e = el, d = 0; e && e !== document.body && d < 6; e = e.parentElement, d++) {
      if (e.getAttribute && e.getAttribute('data-tip')) return { el: e, text: e.getAttribute('data-tip') };
      if (e.classList && e.classList.contains('icon-btn') && e.getAttribute('aria-label')) return { el: e, text: e.getAttribute('aria-label') };   // follows the live label (Show/Hide navigation)
    }
    return null;
  }
  function showTip(t) {
    clearTimeout(tipHide); tipEl.textContent = t.text; tipEl.classList.remove('show');
    var r = t.el.getBoundingClientRect(), w = tipEl.offsetWidth, h = tipEl.offsetHeight, m = 8;
    var left = Math.min(Math.max(m, r.left + r.width / 2 - w / 2), window.innerWidth - w - m);
    var top = r.top - h - 8; if (top < m) top = Math.min(r.bottom + 8, window.innerHeight - h - m);
    tipEl.style.left = left + 'px'; tipEl.style.top = top + 'px';
    tipEl.classList.add('show'); tipFor = t.el; t.el.setAttribute('aria-describedby', 'doc-tip');
  }
  function hideTip() {
    clearTimeout(tipTimer); clearTimeout(tipHide); tipEl.classList.remove('show');
    if (tipFor) { tipFor.removeAttribute('aria-describedby'); tipFor = null; }
  }
  document.addEventListener('pointerover', function (e) {
    if (e.pointerType && e.pointerType !== 'mouse') return;
    var t = tipTarget(e.target); if (!t) { hideTip(); return; }
    if (t.el === tipFor) return;
    hideTip(); tipTimer = setTimeout(function () { showTip(t); }, 220);
  });
  document.addEventListener('pointerout', function (e) {
    if (e.pointerType && e.pointerType !== 'mouse') return;
    var t = tipTarget(e.target); if (t && (!e.relatedTarget || !t.el.contains(e.relatedTarget))) hideTip();
  });
  document.addEventListener('focusin', function (e) {
    var t = tipTarget(e.target); if (!t) { hideTip(); return; }
    var kb = false; try { kb = e.target.matches(':focus-visible'); } catch (x) { kb = true; }
    if (kb) { hideTip(); tipTimer = setTimeout(function () { showTip(t); }, 80); }
  });
  document.addEventListener('focusout', hideTip);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') hideTip(); });
  window.addEventListener('scroll', hideTip, { passive: true, capture: true });
  document.addEventListener('pointerdown', function (e) {
    if (e.pointerType === 'mouse') { hideTip(); return; }
    var t = tipTarget(e.target); if (!t) { hideTip(); return; }
    clearTimeout(tipTimer);
    var show = function () { showTip(t); tipHide = setTimeout(hideTip, 2600); };
    if (e.target.closest('button, a')) tipTimer = setTimeout(show, 450); else show();   // a tap on a term shows at once; a long press on a button after 0.45 s
  });
  ['pointerup', 'pointercancel'].forEach(function (n) { document.addEventListener(n, function (e) { if (e.pointerType !== 'mouse') clearTimeout(tipTimer); }); });
  window.__docTips = { glossary: Object.keys(gloss).length, terms: glossed };
`;
const END = '\n})();\n</script>';
const endAt = html.lastIndexOf(END);
if (endAt < 0) throw new Error('script end not found');
html = html.slice(0, endAt) + TIPJS + html.slice(endAt);

if (html === before) throw new Error('nothing changed');
fs.writeFileSync(out, html);
console.log('written', out, (html.length / 1024).toFixed(0) + ' KB (was ' + (before.length / 1024).toFixed(0) + ' KB)');
