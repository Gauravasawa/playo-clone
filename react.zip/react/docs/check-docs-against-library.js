// Compares the documentation with the library source: documented names that no longer exist, library options the docs never mention.
// Run: node check-docs-against-library.js
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, 'createStore documentation (original).html'), 'utf8');
const lib = fs.readFileSync(path.join(__dirname, '..', '.store', 'createStore.ts'), 'utf8');
const text = html
  .replace(/<script[\s\S]*?<\/script>/g, '')
  .replace(/<[^>]+>/g, ' ')
  .replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
const has = (src, word) => new RegExp('\\b' + word.replace(/\$/g, '\\$') + '\\b').test(src);

// 1. names in the first column of the API tables that the library source does not contain
const names = new Set();
for (const m of html.matchAll(/<tr><td><code>([^<]+)<\/code><\/td>/g)) {
  const n = m[1].replace(/&#x27;/g, "'").replace(/\([\s\S]*$/, '').replace(/\?$/, '').replace(/^store\./, '').trim();
  if (/^[A-Za-z_][\w.]*$/.test(n)) names.add(n);
}
const missing = [...names].filter((n) => !has(lib, n.split('.').pop()));
console.log(`documented names: ${names.size}; not found in the library source: ${missing.join(', ') || 'none'}`);

// 2. members of the library's option interfaces that the docs never mention
function members(iface) {
  const start = lib.search(new RegExp('interface ' + iface + '\\b'));
  if (start < 0) return [];
  const body = lib.slice(lib.indexOf('{', start), lib.indexOf('\n}', start));
  return [...body.matchAll(/^\s{2}(?:readonly )?(\w+)\??[:(<]/gm)].map((x) => x[1]);
}
for (const iface of ['QueryOptions', 'PagesOptions', 'PersistOptions', 'StoreOptions']) {
  const mem = members(iface);
  const undocumented = mem.filter((n) => !has(text, n));
  console.log(`${iface}: ${mem.length} members; not mentioned anywhere in the docs: ${undocumented.join(', ') || 'none'}`);
}

// 3. behaviours found while testing the library
const topics = [
  ['pages.refresh ("loaded")', /refresh/i], ['query whenAborted', /whenAborted/], ['offline.maxSize', /maxSize/], ['onSaveStart', /onSaveStart/],
  ['the async-storage rescue copy on page hide', /rescue/i], ['offline copy keeps per-user data until reset()', /reset\(\)[^.]*offline|offline[^.]*reset\(\)|sign[- ]out/i],
  ['offline storage key names (:inline / :queries)', /:inline|:queries/], ['the react-bindings file', /react-bindings/], ['hydrate(snapshot)', /hydrate\(/], ['toScript() data tag', /toScript/],
  ['same-tick tab conflicts decided by tab id', /tab id|tabId|same tick|same time/i], ['last writer wins when two tabs add to one list', /last writer|last write|overwrit/i],
  ['snapshot() throws on an undefined key', /undefined[^.]*snapshot|snapshot[^.]*undefined/i],
];
for (const [label, re] of topics) console.log(`${re.test(text) ? 'mentioned    ' : 'NOT mentioned'}  ${label}`);
