# Playo clone — a test bed for `createStore`

A Playo-style sports app: book venues, join and host games, find players you've played with, add
friends, follow, chat (1:1, groups, game chats), get live notifications, pay with a wallet, review
venues and players, climb the leaderboard, join tournaments and ask coaches. Its global state is
`createStore` from `c:\react\.store\createStore.ts`, and every store option is used somewhere real.

Bun is the package manager and the backend; Next.js (App Router, plus one Pages Router route) is the frontend.

```
bun install
bun run dev          # API on :4000 (REST + WebSocket), web on :3000 → http://localhost:3000
bun run build        # production build of the web app (then: bun run --filter web start)
```

Log in with **any 10 digit phone, OTP `1234`**. The first login of a number creates the account.

`apps/web` copies `.store/createStore.ts` into `src/lib/store/` before `dev` and `build`
(`bun run sync-store`), so your library file stays the only copy you edit.

## Troubleshooting

- **Buttons do nothing, and messages / notifications / profiles stay on "loading"** while some pages still show
  content: you opened the dev site from a host other than `localhost` (e.g. `http://127.0.0.1:3000` or your IP).
  Next 16 blocks its dev scripts for other hosts, so the page never becomes interactive. `next.config.ts` now allows
  `127.0.0.1`, this machine's name and its LAN addresses (**restart `bun run dev` after pulling this change**); add
  others with `DEV_ORIGINS="my-host,192.168.0.20"`. The dev server log says "Blocked cross-origin request".
- **A red "1 Issue" badge in the corner of the dev site** after moving to a page that carries server data: it's React's
  "Cannot update a component while rendering a different component", raised by the library's snapshot merge (see
  `c:\react\createStore findings`, 01 · 1.1). Nothing is broken; it doesn't appear in a production build.
- Stale saved data from an older version of the app can be cleared with the browser's "Clear site data".

## What a new account gets (demo data, on purpose)

₹1000 in the wallet and **two finished games** with demo players, so there are people you've
"played with" straight away. Demo players (`aarav_k`, `diya_s`, `kabir_r` (private), `meera_p`,
`ishita_j` (private, never accepts friends), …) behave like people:

| You do | They do |
| --- | --- |
| first login | Aarav sends a friend request after ~4 s, Diya follows you after ~7 s |
| friend request | accept after ~2.5 s, say hello in a new chat (Ishita declines) |
| follow a private player | approve after ~3 s |
| message them | "type", read your message, answer |
| host a game | two of them join after a few seconds |
| join a game they host | they end it ~10 s later with a winner |

To test the human-to-human side, open a second browser profile (or a private window) and log in with
another number. **Friend and follow requests only go to players you've shared a finished game with**
(the server enforces it; the buttons say so). Easiest way to get that with a second person: one hosts a
game, the other joins, the host presses **End game**.

## Structure

```
apps/
  api/src/                      Bun backend
    index.ts                    boot: migrate, seed, Bun.serve (HTTP + WebSocket)
    config.ts                   port, latency, db path, demo OTP
    routes/                     auth, players, social, chats, bookings, games, community (wallet,
                                reviews, leaderboard, tournaments, coaches), catalog (+ index.ts wiring)
    middleware/                 latency, simulate-failure switch, authenticate / requireUser
    repositories/               all SQL: users, social, chats, bookings, games, money, reviews
    services/                   people (profile, relationship, badges), notify, chat, games, bots, onboarding
    realtime/                   hub (who is connected) and ws (upgrade + "typing")
    db/ data/ lib/              schema+seed, static data (venues, bots, tournaments, coaches), http + Router
  web/src/                      Next.js frontend
    app/                        routes only: each page.tsx renders one feature view (some prefetch on the server)
      actions/                  Server Actions
      share/[username]/         a Route Handler
    pages/p/[username].tsx      the one Pages Router page (public profile; see "Server vs browser")
    features/                   one folder per product area, each with an index.ts
      venues  booking  bookings  games  auth  friends  profile  chat  notifications  wallet  community  lab
    components/{layout,ui}/     Shell, Header, Toasts · Avatar, Modal, Tabs, Skeleton…
    realtime/                   WebSocket client, event handlers that write into the stores, provider
    store/                      THE global store, split by concern (below)
      chat/                     a second store: messages, drafts, receipts (IndexedDB)
    lib/{api,hooks,store}/      typed API client · hooks · createStore.ts (synced copy) + bindings
    config/                     cities, nav, constants
```

### The stores, split

| File | Holds |
| --- | --- |
| `store/state.ts` | plain state keys and their initial values (incl. `presence`, `socket`, the Lab switches) |
| `store/queries.ts` | every `query(...)`: catalog, community, a player, and the signed-in user's data (keyed by token) |
| `store/computed.ts` | computed layers (layer 2 reads layer 1) |
| `store/key-actions/` | per-key actions, one file per key: `favorites` (with `save`), `selection`, `recentSearches`, `presence` |
| `store/actions/` | multi-key operations (`auth.ts`), typed by `ActionContext` |
| `store/persistence.ts` | what is persisted (`version 2`, `migrate`, `debounce`), synced between tabs, and has history |
| `store/validate.ts` | the `validate` function for saved state, the offline copy and other tabs |
| `store/ssr.ts` | what the server sends to the browser |
| `store/bridge.ts` | lets `save` callbacks reach the store before it exists |
| `store/session.ts` | `signOut()`: logs out and wipes both stores, the offline cache and IndexedDB |
| `store/app.store.ts` | wires the parts into `createStore(...)` |
| `store/chat/*` | the chat store (own state, key actions, actions, IndexedDB adapter) |

Adding a feature: state/query in `state.ts`/`queries.ts`, actions in `key-actions/` or `actions/`,
a folder under `features/`, a thin `app/<route>/page.tsx`.

## Server vs browser (`ssr: true`)

The store runs in three places, and the library behaves differently in each:

| Where | What `app` is | How you use it |
| --- | --- | --- |
| **Server Component** (`app/**/page.tsx`, `layout.tsx`) | a fresh store **per request** | `await app.fetchQuery(...)`, then render `<app.Root>`. Hooks throw here. |
| **Client Component, rendered on the server** | a per-request scope built from the snapshot | hooks work, but only under a `<Root>` |
| **Browser** | the one app store (persist, syncTabs, history, devtools) | everything; filled once from the server snapshot |
| **Server Action / Route Handler** | no request store | make a scope: `const scope = app.createScope()`, then `scope.fetchQuery(...)` |
| **Pages Router page** (`pages/p/[username].tsx`) | scope + data tag | server: `createScope` + `scope.toScript()`; browser: `app.hydrate()` with no argument finds the tag |

Request flow for `/` (the first row): `page.tsx` runs `prefetch(app.fetchQuery(...))`, `<app.Root>` serialises
the request's store into `ClientRoot`, client components render from it (the HTML already has the venues),
and the browser fills its store once. Later client-side navigations only **add** server data.

Rules this app follows because of that:

- **Only public data is in the snapshot** (`store/ssr.ts`). City, token and favourites are loaded from
  localStorage, and a snapshot would overwrite them with the server's initial values.
- **First client render = server render.** Until `useMounted()` is true the views use the default filter the server used.
- **Per-user queries (`me`, `bookings`, `chats`…) load in the browser** — they need the token.
- Pages that fetch are `force-dynamic`. The layout has an empty `<app.Root>` so the header works on the server.
- `lib/api/client.ts` uses an absolute backend URL on the server; the Lab's failure switches are registered **only in the browser**
  (`app.getState()` throws in a Server Action).
- `/p/[username]` is on the Pages Router on purpose: it's how the data-tag path (`toScript()` + `hydrate()`) is used.

## Real time

One WebSocket per logged-in browser (`ws://localhost:4000/ws?token=…`; the browser connects straight to
the backend because Next's rewrites can't proxy WebSockets). The server pushes notifications, messages,
typing, read receipts, presence, and "refresh X" hints; handlers in `realtime/handlers.ts` write them into
the stores (`setQueryData`, `invalidate`, `fetchQuery(..., true)`, key actions). The client sends only
"typing"; everything else is HTTP so it can be retried.

## Which createStore feature is exercised where

| Feature | Where |
| --- | --- |
| Plain keys, selectors | everywhere; `Inspector` (selector) |
| `query()` with params, per-params cache | `venue`, `slots`, `games`, `player`, `me`, `chats`, … |
| Paged `query({ pages })`, `max` | `venues`, `coaches` (Load more); `notifications` keeps the latest **3** pages |
| `waitFor`, `enabled`, `Status.state` | slots wait for the venue; bookings wait for `me` |
| Optimistic entry setters + rollback | book, cancel, join/leave, host, end game, profile, wallet top-up, tournament, reviews, friends |
| `refetchAfterMutation` | bookings, games, friends, tournaments, reviews |
| `keyActions` (+ `save` with rollback) | `favorites.toggle`, `selection.*`, `recentSearches`, `presence`, chat `messages`/`drafts`/`reads`/`typing` |
| `computed` (2 layers), `history` | `loggedIn`…`canBook`; undo/redo of slot picking |
| `events` + `broadcast` | toasts; `notifications-read` reaches every tab |
| `actions` + `batch` | `login`, `logout`, chat `send`/`retry`/`loadHistory`/`markSeen` |
| `persist` (`version`, `migrate`, `debounce`) | app store v2 (added `recentSearches`); Lab can write a v1 state and reload |
| `persist` with an **async** `StorageAdapter` | chat store on IndexedDB (`store/chat/idb.ts`) |
| `syncTabs` | `city, sport, token, favorites, recentSearches`; chat `drafts` |
| `offline` + `whenOnline` | pages keep working offline; favourites and chat messages queue and go out when back online |
| `validate` | saved state, offline copy, other tabs (`store/validate.ts`); Lab can write bad values |
| `devtools`, `logger` | `devtools` in development (Redux DevTools); `NEXT_PUBLIC_STORE_LOGGER=1` for the console log |
| `gcTime`, `abort` | `player`/`searchPlayers` entries expire; the player search aborts the previous text |
| `ssr` (`keys`, `version`), `Root`, `createScope`, `snapshot`, `toScript`, `hydrate` | see "Server vs browser" |
| `onSaveStart` / `onSaveSuccess` / `onSaveError` | header "Saving…" indicator (`pendingSaves` count; says "when you are back online" if queued) |
| `persist: 'session'` | a second store (`store/prefs.store.ts`): "Hide amounts" in the user menu lasts for the tab |
| `offline: { maxSize }` | app store keeps 1,000,000 characters at most; self-tested with a tiny limit |
| Several `whenOnline` tasks | three favourites toggled offline all land, in order, when back online |
| `retryDelay` as a function | `wallet` query (300 / 600 / 1200 ms, capped at 3 s) |
| Refresh on focus / `online` | asserted on the wallet page (stale data refetches, fresh data doesn't) |
| Nested `<Root scope={createScope()}>` | owner price preview (`features/owner/PricePreview.tsx`) never touches the real store |
| `createScope` + computed + key actions + `history` on the server | `GET /quote` Route Handler prices a booking exactly like the checkout and the API |
| Redux DevTools time travel | `JUMP_TO_STATE` from a fake extension changes the real store (e2e) |
| `reset`, `destroy`, `onChange`, `subscribe`, `fetchQuery`, `invalidate`, `setQueryData` | `signOut`, `/lab`, realtime handlers, self-tests |

## Dark mode

A ball in the navbar (☀️ football / 🌙 moon, with a ▾ menu for **Light / Dark / System**). The choice is a store key (`theme`): saved with `persist` (version 4,
`migrate` adds it), shared between tabs with `syncTabs`, checked by `validate`. `System` follows the operating system live.

| Piece | Where |
| --- | --- |
| No flash: an inline script in `<head>` sets `data-theme` before the first paint (reads the same `playo:state` entry the store saves). Also in `pages/_document.tsx` for the Pages Router page | `components/theme/ThemeScript.tsx` |
| Keeps `<html>` in step with the store (after the saved choice loaded, other tabs, OS changes) | `components/theme/ThemeProvider.tsx` |
| The 3D ball, the menu, the hop/spin animation | `components/theme/ThemeToggle.tsx`, `app/theme.css` |
| The switch animation: the new theme grows out of the ball as a circle while the old page tilts away in 3D (View Transitions API); instant when the browser has none or `prefers-reduced-motion` is set | `lib/theme.ts` |
| Home hero: a CSS 3D pitch and ball that tilt with the pointer; sun by day, moon, stars and floodlights at night | `components/theme/HeroScene.tsx` |
| Dark map: OpenStreetMap tiles darkened with a CSS filter (CARTO's dark tiles now need an API key) | `app/theme.css`, `features/venues/VenueMap.tsx` |
| Palette (deep green-black, brand green accents) and every re-coloured utility | `app/theme.css` |

Contrast was audited with a script that checks every text element on 31 pages in both themes (WCAG: 4.5:1 for text, 3:1 for large text and symbols and for the edge of
form fields). Light mode needed fixes too: the brand green was darkened (`#00b259` → `#007f3b`, white text on it was 2.9:1) and the faint `text-ink/20…50` steps were raised.
Dialogs (`components/ui/useDialog.ts`) take focus, keep Tab inside, close on Escape and give focus back. Phone widths (390, 360, 768) were audited for overflow, clipping and tap targets. The browser tests are in `tests/e2e/` (see its README).
The header shows a **More ▾** menu (Tournaments, Leaderboard) so the extra button fits.

## No raw HTML

The app never writes strings into the page as HTML: no `dangerouslySetInnerHTML`, no `innerHTML`.
- The no-flash theme script is a file (`public/theme-init.js`), so a strict `Content-Security-Policy: script-src 'self'` could allow it.
- The public profile page (`pages/p/[username].tsx`) passes the store snapshot in the page props (Next escapes them) and fills the store with `app.hydrate(snapshot)`. The library's other route, `scope.toScript()` + `hydrate()`, needs `dangerouslySetInnerHTML`, so it is not used here.
- The venue map builds its pins and popups with DOM calls and `textContent`.
- `tests/e2e/xss.mts` puts hostile text in every place a user can type and checks that none of it runs.

## Tooltips, and editors that point at each other

- One tooltip system for the whole app (`components/ui/Tooltip.tsx`, a `TooltipLayer` mounted in the Shell): hover (after 250 ms), keyboard focus, and press-and-hold on touch. It uses a `data-tip="…"` attribute, a normal `title="…"` (shown as the same styled tooltip, not the slow native one), the accessible name of symbol-only controls (♥ 🔔 💬 × ▾ ★), and the full text of anything cut off with an ellipsis. It also works on disabled buttons, selects and inputs, stays inside the screen, closes on Escape, and is readable in both themes.
- The owner **price editor** (`/owner/<venue>` → Pricing) links the form and its preview: clicking a row in the preview focuses and selects the matching field on the left (a normal hour → *Price per hour*, a peak hour → *Peak extra*), hovering or focusing a field lights up the preview rows it changes, and the rows are keyboard buttons with a tooltip.
- `tests/e2e/html-audit.mts` fails when an icon, badge, cut-off text or disabled button has no name or tooltip, or a page has no `<h1>`, `lang` or `<title>`.

## The Lab (`/lab`)

Live state, change feed, **61 self-tests**, a performance benchmark of the library (each on a throwaway store), and buttons for
situations that are hard to reach by hand: fail every write, decline UPI/card payments, make 40 notifications,
mark a booking attended (unlocks its venue review), call the Route Handler, save an old (v1) or invalid
state and reload. To try **offline**, switch the network off in the browser's DevTools.

## Tests that were run

- Backend: 61 checks over HTTP and WebSocket (rules, bots, chat, payments, reviews, leaderboard…).
- Browser (Edge via Playwright, two real users + the demo players): 39 end-to-end steps, passing in
  development (React StrictMode on) **and** against the production build; plus devtools, logger, and
  "backend down while rendering" checks.
- The library's 61 self-tests pass inside the browser (Edge and WebKit), including 4-tab sync, big state and hot-reload behaviour.
- Phase 3 (money, venues, games v2, social/safety, coaching/events, owner, help): 7 journeys, ~110 browser steps (`g1`–`g7`), plus 14 store-feature checks (tab sync, DevTools time travel, saving indicator, session prefs, offline queue, focus/online refresh, retryDelay, server quote) in Edge and WebKit. Firefox could not be launched on the machine used (`firefox.exe` blocked: "Permission denied").
- TypeScript 7.0.2 type-checks the web and API projects with no errors (0.46 s vs 4.8 s on 5.9.3).

See `c:\react\createStore findings\` for what building this showed about the library.

After the library was updated, every earlier finding was re-tested (`createStore findings/08-…`): 23 fixed or improved, 7 still open (by design or unchanged notes), 0 new problems after the third update (10-…); all 61 self-tests, 15 store-feature checks (Edge + WebKit), 7 journeys and the route scan pass on the new version.

The library glue (`src/lib/store/react-bindings.ts`, `client-root.tsx`) was re-tested after you changed it (findings `11-…`): builds, SSR, hydration and all suites pass; note the import cycle makes load order matter (import `createStore` before `react-bindings`).
