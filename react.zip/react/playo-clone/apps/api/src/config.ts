export const config = {
  port: Number(process.env.PORT ?? 4000),
  /** Artificial delay on every request, so loading states are visible in the UI */
  latencyMs: Number(process.env.LATENCY_MS ?? 250),
  dbPath: process.env.DB_PATH ?? `${import.meta.dir}/../playo.db`,
  /** The OTP every login accepts (this is a demo: there's no SMS provider) */
  demoOtp: '1234',
};
