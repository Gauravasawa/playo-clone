/** The demo players. They respond like people would: accept requests, reply in chat, end games. */
export interface BotSpec {
  phone: string; name: string; username: string; city: string; emoji: string; color: string; isPrivate: boolean; bio: string;
  sports: [string, 'Beginner' | 'Intermediate' | 'Advanced'][];
  /** When they usually play (used by "Players for you") */
  plays: { days: ('weekday' | 'weekend')[]; times: ('morning' | 'evening')[] };
  /** Always says no to friend requests, so the "declined" path can be seen */
  declinesFriends?: boolean;
  plus?: boolean;
}

type Plays = BotSpec['plays'];
const wk: Plays = { days: ['weekday'], times: ['evening'] };
const we: Plays = { days: ['weekend'], times: ['morning'] };
const all: Plays = { days: ['weekday', 'weekend'], times: ['morning', 'evening'] };

export const BOTS: BotSpec[] = [
  { phone: '9000000001', name: 'Aarav Kumar', username: 'aarav_k', city: 'Bengaluru', emoji: '🏸', color: '#2563eb', isPrivate: false, bio: 'Badminton every morning. Doubles partner wanted!', sports: [['badminton', 'Advanced'], ['tennis', 'Intermediate']], plays: { days: ['weekday', 'weekend'], times: ['morning'] }, plus: true },
  { phone: '9000000002', name: 'Diya Shah', username: 'diya_s', city: 'Bengaluru', emoji: '⚽', color: '#db2777', isPrivate: false, bio: 'Weekend football. Striker.', sports: [['football', 'Intermediate']], plays: { days: ['weekend'], times: ['morning', 'evening'] } },
  { phone: '9000000003', name: 'Kabir Rao', username: 'kabir_r', city: 'Bengaluru', emoji: '🏏', color: '#ea580c', isPrivate: true, bio: 'Cricket, nets and chai.', sports: [['cricket', 'Advanced']], plays: we },
  { phone: '9000000004', name: 'Meera Pillai', username: 'meera_p', city: 'Bengaluru', emoji: '🎾', color: '#7c3aed', isPrivate: false, bio: 'Tennis coach on weekends.', sports: [['tennis', 'Advanced'], ['pickleball', 'Intermediate'], ['padel', 'Beginner']], plays: all },
  { phone: '9000000005', name: 'Rohan Mehta', username: 'rohan_m', city: 'Bengaluru', emoji: '🏀', color: '#0891b2', isPrivate: false, bio: 'Hoops after work.', sports: [['basketball', 'Intermediate']], plays: wk },
  { phone: '9000000006', name: 'Ishita Jain', username: 'ishita_j', city: 'Bengaluru', emoji: '🏊', color: '#16a34a', isPrivate: true, bio: 'Swimmer. Not accepting everyone 🙂', sports: [['swimming', 'Advanced']], plays: { days: ['weekday'], times: ['morning'] }, declinesFriends: true },
  { phone: '9000000007', name: 'Vikram Nair', username: 'vikram_n', city: 'Mumbai', emoji: '🏓', color: '#ca8a04', isPrivate: false, bio: 'Table tennis league regular.', sports: [['tabletennis', 'Advanced'], ['badminton', 'Beginner']], plays: wk },
  { phone: '9000000008', name: 'Ananya Gupta', username: 'ananya_g', city: 'Bengaluru', emoji: '🥒', color: '#be185d', isPrivate: false, bio: 'Pickleball convert.', sports: [['pickleball', 'Beginner'], ['badminton', 'Intermediate']], plays: { days: ['weekday', 'weekend'], times: ['evening'] } },
  { phone: '9000000009', name: 'Arjun Thakur', username: 'arjun_t', city: 'Bengaluru', emoji: '⚽', color: '#4338ca', isPrivate: false, bio: 'Goalkeeper. Cricket on Sundays.', sports: [['football', 'Advanced'], ['cricket', 'Intermediate'], ['padel', 'Intermediate']], plays: we },
  { phone: '9000000010', name: 'Sneha Bhat', username: 'sneha_b', city: 'Bengaluru', emoji: '🏸', color: '#0d9488', isPrivate: false, bio: 'Badminton and coffee.', sports: [['badminton', 'Intermediate']], plays: wk },
  { phone: '9000000011', name: 'Karan Verma', username: 'karan_v', city: 'Delhi', emoji: '🏀', color: '#b91c1c', isPrivate: false, bio: 'Streetball.', sports: [['basketball', 'Advanced']], plays: all },
  { phone: '9000000012', name: 'Priya Desai', username: 'priya_d', city: 'Bengaluru', emoji: '🎾', color: '#9333ea', isPrivate: false, bio: 'Learning tennis, loving it.', sports: [['tennis', 'Beginner']], plays: we },
  // one host per newer city, so every city has games to join
  { phone: '9000000013', name: 'Karthik Raj', username: 'karthik_r', city: 'Chennai', emoji: '🏏', color: '#0369a1', isPrivate: false, bio: 'Chennai cricket regular.', sports: [['cricket', 'Intermediate'], ['badminton', 'Intermediate']], plays: all },
  { phone: '9000000014', name: 'Sourav Dutta', username: 'sourav_d', city: 'Kolkata', emoji: '⚽', color: '#15803d', isPrivate: false, bio: 'Football is life.', sports: [['football', 'Advanced']], plays: wk },
  { phone: '9000000015', name: 'Hetal Patel', username: 'hetal_p', city: 'Ahmedabad', emoji: '🏸', color: '#a21caf', isPrivate: false, bio: 'Badminton doubles.', sports: [['badminton', 'Intermediate']], plays: we },
  { phone: '9000000016', name: 'Rajveer Singh', username: 'rajveer_s', city: 'Jaipur', emoji: '🎾', color: '#c2410c', isPrivate: false, bio: 'Tennis in the evenings.', sports: [['tennis', 'Advanced'], ['padel', 'Intermediate']], plays: wk },
  { phone: '9000000017', name: 'Omar Khalid', username: 'omar_k', city: 'Dubai', emoji: '🎾', color: '#0f766e', isPrivate: false, bio: 'Padel every weekend in Dubai.', sports: [['padel', 'Advanced'], ['tennis', 'Intermediate']], plays: we, plus: true },
  { phone: '9000000018', name: 'Yousef Ali', username: 'yousef_a', city: 'Doha', emoji: '⚽', color: '#7e22ce', isPrivate: false, bio: 'Five-a-side in Doha.', sports: [['football', 'Intermediate'], ['padel', 'Beginner']], plays: wk },
  { phone: '9000000019', name: 'Chloe Evans', username: 'chloe_e', city: 'Sydney', emoji: '🏊', color: '#0284c7', isPrivate: false, bio: 'Open water and pool laps.', sports: [['swimming', 'Advanced'], ['tennis', 'Beginner']], plays: all },
  { phone: '9000000020', name: 'Oliver Smith', username: 'oliver_s', city: 'London', emoji: '🏏', color: '#be123c', isPrivate: false, bio: 'Sunday league cricketer.', sports: [['cricket', 'Intermediate'], ['padel', 'Beginner']], plays: we },
];

/** The admin account: sees /admin/reports. Logs in like anyone (demo OTP). */
export const ADMIN = { phone: '9000000000', name: 'Playo Admin', username: 'admin', emoji: '🛡️', color: '#111827' };
