import { CITIES, CITY_INFO } from './currency';
import { SPORTS } from './sports';

function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 2 ** 32);
}

/** Prices abroad are higher: everything priced in rupees is scaled for non-Indian cities */
export const priceTier = (city: string) => (CITY_INFO[city]?.currency === 'INR' ? 1 : 8);

const COACH_FIRST = ['Suresh', 'Anita', 'Manoj', 'Pooja', 'Rahul', 'Neha', 'Imran', 'Divya', 'Sanjay', 'Kavya'];
const COACH_LAST = ['Iyer', 'Nair', 'Shetty', 'Kulkarni', 'Reddy', 'Khan', 'Gupta', 'Menon'];
const CERTS: Record<string, string[]> = {
  badminton: ['BAI Level 1 Coach', 'BAI Level 2 Coach'], football: ['AFC C Licence', 'FIFA Grassroots Certificate'], cricket: ['BCCI Level 1', 'NCA Coaching Certificate'],
  tennis: ['ITF Level 1', 'PTR Certified'], basketball: ['FIBA Level 1 Coach'], swimming: ['ASA Level 2 Teacher', 'Red Cross Lifeguard'],
  tabletennis: ['ITTF Level 1 Coach'], pickleball: ['PPR Certified Instructor'], padel: ['FIP Padel Instructor'],
};
const SPECIALTIES = ['Beginner basics', 'Footwork', 'Match tactics', 'Fitness and conditioning', 'Kids (6–12)', 'Advanced drills', 'Doubles play', 'Technique correction'];

export interface Batch { id: number; programId: number; days: string; time: string; startsOn: string; seats: number }
export interface Program { id: number; coachId: number; title: string; sport: string; level: string; sessions: number; weeks: number; priceInr: number; description: string; batches: Batch[] }
export interface Coach {
  id: number; name: string; sport: string; city: string; area: string; experienceYears: number; pricePerSession: number; rating: number; bio: string;
  certifications: string[]; specialties: string[]; languages: string[];
}

export const COACHES: Coach[] = (() => {
  const out: Coach[] = [];
  let id = 1;
  for (const city of CITIES) {
    for (let i = 0; i < 8; i++) {
      const r = rng(id * 7727);
      const sport = SPORTS[Math.floor(r() * SPORTS.length)];
      const years = 2 + Math.floor(r() * 18);
      const certs = CERTS[sport.id] ?? [];
      out.push({
        id, name: `Coach ${COACH_FIRST[Math.floor(r() * COACH_FIRST.length)]} ${COACH_LAST[Math.floor(r() * COACH_LAST.length)]}`,
        sport: sport.id, city, area: ['Central', 'North', 'South', 'East', 'West'][Math.floor(r() * 5)],
        experienceYears: years, pricePerSession: (300 + Math.floor(r() * 12) * 100) * priceTier(city),
        rating: Math.round((3.8 + r() * 1.2) * 10) / 10,
        bio: `${years} years coaching ${sport.name.toLowerCase()} for beginners and club players. Small batches, video feedback.`,
        certifications: certs.slice(0, 1 + Math.floor(r() * certs.length)),
        specialties: SPECIALTIES.filter(() => r() > 0.65).slice(0, 3).concat(SPECIALTIES[0]).filter((v, k, a) => a.indexOf(v) === k),
        languages: ['English', ...(r() > 0.5 ? ['Hindi'] : []), ...(r() > 0.8 ? ['Tamil'] : [])],
      });
      id++;
    }
  }
  return out;
})();

const BATCH_PATTERNS: [days: string, time: string][] = [['Mon, Wed, Fri', '06:30'], ['Tue, Thu', '18:00'], ['Sat, Sun', '08:00']];
const nextMonday = (weeksAhead: number) => {
  const d = new Date();
  d.setDate(d.getDate() + ((8 - d.getDay()) % 7 || 7) + weeksAhead * 7);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export const PROGRAMS: Program[] = COACHES.flatMap((c) =>
  [
    { title: 'Beginner foundations', level: 'Beginner', sessions: 8, weeks: 4, text: 'Grip, stance and basic strokes, with games at the end of each session.' },
    { title: 'Match play and tactics', level: 'Intermediate', sessions: 12, weeks: 6, text: 'Shot selection, positioning and playing under pressure.' },
  ].map((p, k) => {
    const id = c.id * 10 + k;
    const r = rng(id * 31);
    return {
      id, coachId: c.id, title: `${p.title} (${p.sessions} sessions)`, sport: c.sport, level: p.level, sessions: p.sessions, weeks: p.weeks,
      priceInr: Math.round((c.pricePerSession * p.sessions * 0.85) / 50) * 50, description: p.text,
      batches: BATCH_PATTERNS.map(([days, time], j) => ({ id: id * 10 + j, programId: id, days, time, startsOn: nextMonday(1 + j + k), seats: 8 + Math.floor(r() * 7) })),
    };
  })
);

export const findCoach = (id: number) => COACHES.find((c) => c.id === id);
export const findProgram = (id: number) => PROGRAMS.find((p) => p.id === id);
export const findBatch = (id: number) => PROGRAMS.flatMap((p) => p.batches).find((b) => b.id === id);

/** A coach's free hours for a trial session on a date (stable per coach and date); 07:00–20:00 */
export function coachHours(coachId: number, date: string): string[] {
  let h = coachId * 131;
  for (const ch of date) h = (Math.imul(h, 31) + ch.charCodeAt(0)) >>> 0;
  const r = rng(h);
  const hours: string[] = [];
  for (let hour = 7; hour <= 20; hour++) if (r() > 0.35) hours.push(`${String(hour).padStart(2, '0')}:00`);
  return hours;
}
