export type CurrencyCode = 'INR' | 'AED' | 'QAR' | 'AUD' | 'GBP';

/**
 * Fixed demo exchange rates: how many rupees one unit of each currency is worth. Everything the server
 * stores and charges is in rupees; other currencies are only for showing prices in a city.
 * (Mirrored in apps/web/src/config/cities.ts: change both.)
 */
export const CURRENCIES: Record<CurrencyCode, { symbol: string; inr: number; name: string }> = {
  INR: { symbol: '₹', inr: 1, name: 'Indian rupee' },
  AED: { symbol: 'AED ', inr: 22.5, name: 'UAE dirham' },
  QAR: { symbol: 'QAR ', inr: 23, name: 'Qatari riyal' },
  AUD: { symbol: 'A$', inr: 55, name: 'Australian dollar' },
  GBP: { symbol: '£', inr: 105, name: 'Pound sterling' },
};

export interface CityInfo { currency: CurrencyCode; lat: number; lng: number; country: string }

/** The cities, with their currency and centre (used for distances when the browser gives no location) */
export const CITY_INFO: Record<string, CityInfo> = {
  Bengaluru: { currency: 'INR', lat: 12.9716, lng: 77.5946, country: 'India' },
  Mumbai: { currency: 'INR', lat: 19.076, lng: 72.8777, country: 'India' },
  Delhi: { currency: 'INR', lat: 28.6139, lng: 77.209, country: 'India' },
  Hyderabad: { currency: 'INR', lat: 17.385, lng: 78.4867, country: 'India' },
  Pune: { currency: 'INR', lat: 18.5204, lng: 73.8567, country: 'India' },
  Chennai: { currency: 'INR', lat: 13.0827, lng: 80.2707, country: 'India' },
  Kolkata: { currency: 'INR', lat: 22.5726, lng: 88.3639, country: 'India' },
  Ahmedabad: { currency: 'INR', lat: 23.0225, lng: 72.5714, country: 'India' },
  Jaipur: { currency: 'INR', lat: 26.9124, lng: 75.7873, country: 'India' },
  Dubai: { currency: 'AED', lat: 25.2048, lng: 55.2708, country: 'UAE' },
  Doha: { currency: 'QAR', lat: 25.2854, lng: 51.531, country: 'Qatar' },
  Sydney: { currency: 'AUD', lat: -33.8688, lng: 151.2093, country: 'Australia' },
  London: { currency: 'GBP', lat: 51.5072, lng: -0.1276, country: 'UK' },
};

export const CITIES = Object.keys(CITY_INFO);

export const toLocal = (inr: number, currency: CurrencyCode) => Math.round(inr / CURRENCIES[currency].inr);
export const toInr = (local: number, currency: CurrencyCode) => Math.round(local * CURRENCIES[currency].inr);

/** Straight-line distance in kilometres */
export function distanceKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const rad = (d: number) => (d * Math.PI) / 180;
  const h = Math.sin(rad(b.lat - a.lat) / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(rad(b.lng - a.lng) / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
}
