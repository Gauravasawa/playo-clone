import { CITIES } from './currency';
import { priceTier } from './coaching';

export type EventType = 'marathon' | 'trek' | 'meetup';

export interface EventCategory { id: string; label: string; feeInr: number }
export interface SportEvent {
  id: number; type: EventType; title: string; city: string; startsAt: string; place: string; description: string;
  /** Rupees to take part (marathon: see categories) */
  feeInr: number; capacity: number; hostName: string; hostId: number | null;
  categories?: EventCategory[]; difficulty?: 'Easy' | 'Moderate' | 'Hard'; itinerary?: string[]; sport?: string;
}

function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 2 ** 32);
}

const daysAhead = (n: number, hour: number) => {
  const d = new Date(Date.now() + n * 86_400_000);
  d.setHours(hour, 0, 0, 0);
  return d.toISOString();
};

const PLACES: Record<string, string[]> = {
  Bengaluru: ['Cubbon Park', 'Lalbagh', 'Nandi Hills'], Mumbai: ['Marine Drive', 'Sanjay Gandhi National Park', 'Bandra Fort'], Delhi: ['Lodhi Garden', 'Nehru Park', 'Sunder Nursery'],
  Hyderabad: ['Hussain Sagar', 'KBR Park', 'Gandipet'], Pune: ['Sinhagad Fort', 'Pashan Lake', 'Bund Garden'], Chennai: ['Marina Beach', 'Elliot\'s Beach', 'Guindy Park'],
  Kolkata: ['Maidan', 'Rabindra Sarobar', 'Eco Park'], Ahmedabad: ['Sabarmati Riverfront', 'Kankaria Lake', 'Law Garden'], Jaipur: ['Central Park', 'Nahargarh Fort', 'Jal Mahal'],
  Dubai: ['Jumeirah Beach', 'Al Qudra Lakes', 'Creek Park'], Doha: ['Corniche', 'Aspire Park', 'The Pearl'], Sydney: ['Bondi to Coogee', 'Centennial Park', 'Manly Beach'], London: ['Hyde Park', 'Richmond Park', 'Thames Path'],
};

const base: Omit<SportEvent, 'id'>[] = [];
for (const city of CITIES) {
  const t = priceTier(city);
  const places = PLACES[city] ?? ['City park'];
  const r = rng(city.length * 97 + city.charCodeAt(0));
  base.push({
    type: 'marathon', title: `${city} Run for Fun`, city, startsAt: daysAhead(25 + Math.floor(r() * 40), 6), place: `Start: ${places[0]}`,
    description: 'A friendly city run with a medal, timing chip and breakfast for everyone who finishes.',
    feeInr: 0, capacity: 400, hostName: 'Playo Events', hostId: null,
    categories: [{ id: '5k', label: '5K fun run', feeInr: 400 * t }, { id: '10k', label: '10K', feeInr: 700 * t }, { id: '21k', label: 'Half marathon (21K)', feeInr: 1100 * t }],
  });
  base.push({
    type: 'marathon', title: `${city} Night Run`, city, startsAt: daysAhead(50 + Math.floor(r() * 30), 20), place: `Start: ${places[1]}`,
    description: 'Run under the lights on a closed route, with music at every kilometre.',
    feeInr: 0, capacity: 250, hostName: 'Playo Events', hostId: null,
    categories: [{ id: '5k', label: '5K', feeInr: 500 * t }, { id: '10k', label: '10K', feeInr: 800 * t }],
  });
  base.push({
    type: 'trek', title: `${places[2]} sunrise trek`, city, startsAt: daysAhead(10 + Math.floor(r() * 20), 5), place: `Meet at ${places[2]} main gate, 5:00 AM`,
    description: 'A guided group walk to catch the sunrise, with a trek leader and a first-aid kit.',
    feeInr: (600 + Math.floor(r() * 5) * 100) * t, capacity: 12 + Math.floor(r() * 3) * 6, hostName: 'Playo Outdoors', hostId: null,
    difficulty: (['Easy', 'Moderate', 'Hard'] as const)[Math.floor(r() * 3)],
    itinerary: ['5:00  Meet and safety briefing', '5:30  Start the climb', '7:00  Sunrise and breakfast at the top', '9:00  Walk back down', '10:30  Back at the gate'],
  });
  base.push({
    type: 'trek', title: `${city} weekend trail day`, city, startsAt: daysAhead(30 + Math.floor(r() * 20), 7), place: `Meet at ${places[1]}, 7:00 AM`,
    description: 'A full day out on the trails with lunch included. Bring water and good shoes.',
    feeInr: (1200 + Math.floor(r() * 5) * 100) * t, capacity: 16 + Math.floor(r() * 3) * 4, hostName: 'Playo Outdoors', hostId: null,
    difficulty: 'Moderate', itinerary: ['7:00  Meet', '7:30  Drive to the trailhead', '8:30  Trail walk (about 10 km)', '13:00  Lunch', '16:00  Back in the city'],
  });
}

/** Meet-ups and workshops hosted by the demo players are created with the seed (they need a host id) */
export const STATIC_EVENTS: SportEvent[] = base.map((e, i) => ({ ...e, id: i + 1 }));
