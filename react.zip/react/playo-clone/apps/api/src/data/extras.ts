import { CITIES, SPORTS } from './sports';
import { priceTier } from './coaching';

/* ---------- Coupons ---------- */

export interface Coupon { code: string; label: string; minAmount: number; flat?: number; percent?: number; maxDiscount?: number }

export const COUPONS: Coupon[] = [
  { code: 'WELCOME100', label: '₹100 off bookings above ₹300', minAmount: 300, flat: 100 },
  { code: 'PLAY20', label: '20% off, up to ₹200', minAmount: 200, percent: 20, maxDiscount: 200 },
  { code: 'WEEKEND50', label: '₹50 off any booking', minAmount: 100, flat: 50 },
];

export function discountFor(code: string | null | undefined, amount: number): { coupon: Coupon; discount: number } | { error: string } | null {
  if (!code) return null;
  const coupon = COUPONS.find((c) => c.code === code.trim().toUpperCase());
  if (!coupon) return { error: 'Invalid coupon code' };
  if (amount < coupon.minAmount) return { error: `Add ₹${coupon.minAmount - amount} more to use ${coupon.code}` };
  const raw = coupon.flat ?? Math.floor((amount * (coupon.percent ?? 0)) / 100);
  return { coupon, discount: Math.min(raw, coupon.maxDiscount ?? raw, amount) };
}

/* ---------- Tournaments and coaches (deterministic, like the venues) ---------- */

function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 2 ** 32);
}

export interface Tournament {
  id: number; name: string; sport: string; city: string; startsAt: string; fee: number; prize: number; capacity: number; format: string;
}

const FORMATS = ['Knockout', 'League', 'Round robin', 'Doubles knockout'];
const T_NAMES = ['Monsoon Cup', 'City Open', 'Weekend Smash', 'Champions Trophy', 'Corporate League', 'Sunrise Series'];

export const TOURNAMENTS: Tournament[] = (() => {
  const out: Tournament[] = [];
  let id = 1;
  for (const city of CITIES) {
    for (let i = 0; i < 4; i++) {
      const r = rng(id * 104729);
      const sport = SPORTS[Math.floor(r() * SPORTS.length)];
      const when = new Date(Date.now() + (3 + Math.floor(r() * 40)) * 24 * 3600 * 1000);
      when.setHours(7 + Math.floor(r() * 3), 0, 0, 0);
      out.push({
        id, name: `${city} ${sport.name} ${T_NAMES[Math.floor(r() * T_NAMES.length)]}`, sport: sport.id, city,
        startsAt: when.toISOString(), fee: (200 + Math.floor(r() * 10) * 100) * priceTier(city), prize: (5000 + Math.floor(r() * 20) * 1000) * priceTier(city),
        capacity: 8 + Math.floor(r() * 4) * 8, format: FORMATS[Math.floor(r() * FORMATS.length)],
      });
      id++;
    }
  }
  return out;
})();

