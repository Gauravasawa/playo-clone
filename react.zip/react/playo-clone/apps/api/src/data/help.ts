export type FaqCategory = 'Booking' | 'Payments' | 'Games' | 'Account' | 'Plus & Karma';
export interface Faq { id: number; category: FaqCategory; question: string; answer: string }

const f = (category: FaqCategory, question: string, answer: string): Omit<Faq, 'id'> => ({ category, question, answer });

const RAW_FAQS: Omit<Faq, 'id'>[] = [
  f('Booking', 'How do I book a venue?', 'Open Venues, pick a venue, choose a day and one or more hourly slots, then press Book now. At checkout choose how to pay and confirm.'),
  f('Booking', 'Can I rent equipment?', 'Yes. At checkout, tick the rackets, balls or other gear the venue offers. They are charged per hour of your booking.'),
  f('Booking', 'Can I cancel a booking?', 'Yes, from My bookings. You get 100% back if you cancel at least 24 hours before the first slot, 50% from 24 to 2 hours before, and nothing in the last 2 hours. Plus members get a full refund up to 2 hours before. See the Cancellation policy page for the exact rules.'),
  f('Booking', 'Can I move a booking to another time?', 'Yes, until 2 hours before it starts, to free slots at the same venue. If the new slots cost more you pay the difference from your wallet; if they cost less, the difference goes back to your wallet.'),
  f('Booking', 'Why can I not pick some hours?', 'Hours that have already started, hours someone else booked, and hours the venue has closed are greyed out.'),
  f('Booking', 'What are day passes and monthly memberships?', 'A day pass covers any number of hours at one venue on a day you choose. A monthly membership gives you a number of hours at a venue to use before the end of the month, at a lower price than booking by the hour. Choose "book with pass" at checkout.'),
  f('Payments', 'How can I pay?', 'From your wallet, or with UPI or a card. Payments in this demo app go to a mock gateway: nothing real is charged.'),
  f('Payments', 'What is the convenience fee?', 'A small fee (3% of what you pay for slots and rentals, at least ₹10 and at most ₹100) for booking online. Playo Plus members do not pay it, and it is not charged when a pass covers your booking.'),
  f('Payments', 'How do coupons work?', 'Enter a code at checkout and press Apply. WELCOME100 takes ₹100 off bookings above ₹300, PLAY20 takes 20% off up to ₹200, and WEEKEND50 takes ₹50 off any booking.'),
  f('Payments', 'Where does my refund go?', 'Refunds always go to your wallet, whichever way you paid, and are available straight away.'),
  f('Payments', 'What if my payment is declined?', 'Nothing is booked and you are not charged. Try another method, or top up your wallet and pay from there.'),
  f('Payments', 'Can I buy a gift card?', 'Yes, from Wallet. Choose an amount, optionally pick a friend to send it to, and pay. You get a code like PLAYO-AB12-CD34. Whoever enters it on the Wallet page gets the amount in their wallet. Codes can be used once and expire after a year.'),
  f('Games', 'How do I host a game?', 'Open Play and press Host a game. Choose the sport, venue and time. You can make it open or approval-only, public or private, set a minimum skill level, and charge a price per player.'),
  f('Games', 'What is an approval game?', 'People who want to join send a request and you decide. If the game costs money, their payment is held and goes back to them if you decline.'),
  f('Games', 'What is a private game?', 'It is hidden from the Play list. People join with an invite link or because you or another player invited them.'),
  f('Games', 'What happens when I leave a paid game?', 'If you leave at least 3 hours before it starts you get your money back. Later than that, you do not.'),
  f('Games', 'Why can I not join a game?', 'The game may be full, already started, private, or need a higher skill level than the one on your profile. The message tells you which.'),
  f('Games', 'Why do I need to play with someone before sending a friend request?', 'Friend and follow requests go to players you have shared a finished game with. It keeps requests between people who actually know each other.'),
  f('Games', 'What does the host marking attendance do?', 'When a game ends the host marks who showed up. Only players who attended get the game in their stats, Karma and leaderboard points, and as someone they have played with.'),
  f('Account', 'How do I log in?', 'Enter your phone number and the one-time password. In this demo app the password is always 1234.'),
  f('Account', 'Can I make my profile private?', 'Yes, on your profile page. People you have played with then need your approval to follow you, and only friends and followers see your sports, stats and badges.'),
  f('Account', 'How do I block someone?', 'Open their profile and choose Block. They can no longer find you, message you or send requests, and their direct chats with you are hidden.'),
  f('Account', 'How do I report something?', 'Use Report on a profile, a message, a game or a review, and choose a reason. Our team looks at every report.'),
  f('Account', 'What is a referral code?', 'Everyone has one on the Referrals page. A friend who signs up with it gets ₹100, and you get ₹100 and Karma points after their first booking.'),
  f('Plus & Karma', 'What is Playo Plus?', 'A membership with 2x Karma, no convenience fee, free cancellation up to 2 hours before a booking, a badge on your profile and priority in Players for you. It costs ₹149 a month or ₹1,199 a year.'),
  f('Plus & Karma', 'How do I cancel Plus?', 'On the Plus page. It stays active until the end of the period you already paid for.'),
  f('Plus & Karma', 'How do I earn Karma?', 'You earn 1 point for every ₹10 you pay, 20 points for each finished game you attend, 10 for a review, and 5 for your first login of the day. Plus members earn double.'),
  f('Plus & Karma', 'How do I use Karma?', 'At checkout, switch on Use Karma. 10 points are worth ₹1, up to 20% of what you pay.'),
];
export const FAQS: Faq[] = RAW_FAQS.map((q, i) => ({ id: i + 1, ...q }));

export interface Article {
  slug: string; title: string; summary: string; tags: string[]; sport: string | null; readMinutes: number; publishedAt: string; body: string[];
}

export const ARTICLES: Article[] = [
  {
    slug: 'badminton-footwork-basics', title: 'Badminton footwork: the five steps that matter', sport: 'badminton', tags: ['badminton', 'technique'], readMinutes: 4, publishedAt: '2026-08-02',
    summary: 'Most of your speed on court comes from how you move, not how you swing.',
    body: ['Good badminton starts below the waist. If you reach every shuttle early and balanced, the strokes look after themselves.', 'Start from a ready position at the centre: knees soft, weight on the balls of your feet, racket up. After every shot, return here. It sounds boring, and it is what separates club players from beginners.', 'Learn five movements: the split step before your opponent hits, the chasse step to the sides, the lunge to the front corners, the cross step to the back, and the recovery push-off. Practise them slowly without a shuttle before adding speed.', 'Ten minutes of shadow footwork before a game is worth more than an hour of hitting. Book a court early in the day and make it part of your warm-up.'],
  },
  {
    slug: 'first-football-match-checklist', title: 'Your first five-a-side: a checklist', sport: 'football', tags: ['football', 'beginners'], readMinutes: 3, publishedAt: '2026-08-14',
    summary: 'What to bring, how to join a game, and how not to be the person everyone waits for.',
    body: ['Join a game marked Beginner or Intermediate on the Play page, and read the host\'s note about the level. Most five-a-side games welcome newcomers who say hello.', 'Bring turf shoes or trainers with good grip, shin guards, a bottle of water and a dark and a light shirt so teams can be told apart.', 'Arrive ten minutes early to warm up. Pass, move, and talk: calling for the ball helps more than running hard.', 'After the game, check the box to rate the people you played with. It helps you find them next time.'],
  },
  {
    slug: 'choosing-a-tennis-racket', title: 'How to choose your first tennis racket', sport: 'tennis', tags: ['tennis', 'equipment'], readMinutes: 5, publishedAt: '2026-08-21',
    summary: 'Weight, head size and grip, in plain words.',
    body: ['Do not buy the same racket your favourite player uses. Their frames are heavy and stiff, made for people who hit hard every day.', 'A beginner does best with a head size around 100 square inches and a weight between 260 and 285 grams. A bigger head forgives mis-hits; a lighter frame is easier on the arm.', 'Grip size matters more than people think. Hold the racket like a handshake: you should fit a finger between your fingertips and palm. Too big a grip is tiring, too small causes blisters.', 'Before buying, rent one from the venue for a session. Our venues list rackets you can add at checkout.'],
  },
  {
    slug: 'padel-for-beginners', title: 'Padel in ten minutes: how the game works', sport: 'padel', tags: ['padel', 'beginners'], readMinutes: 4, publishedAt: '2026-09-01',
    summary: 'A small court, a bouncy wall, and a game you can enjoy in your first hour.',
    body: ['Padel is played in doubles on a court about a third the size of a tennis court, with glass and mesh walls you are allowed to use. Scoring is the same as tennis.', 'The serve is underhand, bounced once, and hit below the waist. After the serve the ball may bounce on the walls before you return it, which makes rallies long and fun.', 'Hold the racket firmly but do not grip it tight. A short, compact swing is better than a big one: the walls give you time.', 'Padel is easy to start, so it is a favourite for mixed-level groups. Look for Padel in the sports list and join a game with a Beginner level.'],
  },
  {
    slug: 'swim-faster-with-less-effort', title: 'Swim faster with less effort', sport: 'swimming', tags: ['swimming', 'technique'], readMinutes: 4, publishedAt: '2026-09-09',
    summary: 'Three habits that save energy and make laps feel easy.',
    body: ['Most swimmers fight the water by lifting their head. Look at the bottom of the pool, slightly forward, so your hips stay high.', 'Rotate your body with each stroke instead of paddling flat. The rotation gives your arm more reach and your lungs easy access to air.', 'Breathe out steadily under water so each breath in is quick. Holding your breath makes you tense and tired.', 'A monthly membership at a pool is the cheapest way to swim regularly. Check the passes on the venue page.'],
  },
  {
    slug: 'how-to-run-your-first-10k', title: 'Run your first 10K in eight weeks', sport: null, tags: ['running', 'events'], readMinutes: 6, publishedAt: '2026-09-18',
    summary: 'A plain plan for people who can already jog for 20 minutes.',
    body: ['Run three days a week and rest between them. Two short, easy runs and one longer one is enough.', 'Add about 10% to your long run each week, and take an easy week every fourth week. If you cannot chat while running, slow down.', 'In the last two weeks, cut back and sleep well. On race day, start slower than you think you should.', 'Register for a 10K on the Events page a few weeks ahead: having a date and a bib number does wonders for motivation.'],
  },
  {
    slug: 'warm-up-routine-for-any-sport', title: 'A seven-minute warm-up for any sport', sport: null, tags: ['fitness', 'injury-prevention'], readMinutes: 3, publishedAt: '2026-09-25',
    summary: 'Warm muscles are happy muscles. Here is a routine that needs no equipment.',
    body: ['Start with two minutes of easy jogging or skipping to raise your heart rate.', 'Then move your joints through their range: arm circles, hip circles, leg swings front-to-back and side-to-side, ten each.', 'Finish with sport-specific movements at half speed: a few easy serves, passes or strokes.', 'Skip long static stretches before playing. Save those for after, when your muscles are warm.'],
  },
  {
    slug: 'making-friends-through-sport', title: 'How to find your regular playing group', sport: null, tags: ['community', 'games'], readMinutes: 3, publishedAt: '2026-10-03',
    summary: 'The easiest way to play more is to know people who play.',
    body: ['Join two or three open games at the same venue and the same time. Familiar faces build up quickly.', 'After a game, send a friend request to the people you enjoyed playing with. You can only ask players you have shared a game with, which keeps requests friendly.', 'Make a group chat for your regulars and host a game now and then, even a small one. People remember the one who organises.', 'The Players for you page shows people with a similar level and schedule to yours: a good place to start.'],
  },
];

export const TICKET_TOPICS = ['Booking', 'Payment', 'Refund', 'Game', 'Account', 'Other'] as const;
