export { CITIES } from './currency';

export interface Sport { id: string; name: string; emoji: string }

export const SPORTS: Sport[] = [
  { id: 'badminton', name: 'Badminton', emoji: '🏸' },
  { id: 'football', name: 'Football', emoji: '⚽' },
  { id: 'cricket', name: 'Cricket', emoji: '🏏' },
  { id: 'tennis', name: 'Tennis', emoji: '🎾' },
  { id: 'basketball', name: 'Basketball', emoji: '🏀' },
  { id: 'swimming', name: 'Swimming', emoji: '🏊' },
  { id: 'tabletennis', name: 'Table Tennis', emoji: '🏓' },
  { id: 'pickleball', name: 'Pickleball', emoji: '🥒' },
  { id: 'padel', name: 'Padel', emoji: '🎾' },
];
