import { CITIES, CITY_INFO, CURRENCIES, toInr, type CurrencyCode } from './currency';
import { SPORTS } from './sports';

export interface Equipment { id: string; name: string; priceInr: number }

export interface Venue {
  id: number; name: string; city: string; area: string; sports: string[];
  /** Rupees per hour: what is charged */
  pricePerHour: number;
  /** Extra rupees per hour in the evening peak (18:00–21:00) */
  peakExtra: number;
  currency: CurrencyCode;
  /** The same price per hour in the city's own currency, for showing */
  pricePerHourLocal: number;
  rating: number; reviews: number; image: string; images: string[];
  amenities: string[]; address: string; description: string;
  lat: number; lng: number;
  equipment: Equipment[];
}

const AREAS: Record<string, string[]> = {
  Bengaluru: ['Indiranagar', 'Koramangala', 'HSR Layout', 'Whitefield', 'Jayanagar'],
  Mumbai: ['Andheri', 'Bandra', 'Powai', 'Juhu', 'Thane'],
  Delhi: ['Saket', 'Dwarka', 'Rohini', 'Hauz Khas', 'Noida'],
  Hyderabad: ['Gachibowli', 'Madhapur', 'Banjara Hills', 'Kondapur', 'Jubilee Hills'],
  Pune: ['Kothrud', 'Baner', 'Hinjewadi', 'Viman Nagar', 'Aundh'],
  Chennai: ['Adyar', 'Anna Nagar', 'T Nagar', 'Velachery', 'OMR'],
  Kolkata: ['Salt Lake', 'New Town', 'Ballygunge', 'Behala', 'Dum Dum'],
  Ahmedabad: ['Navrangpura', 'Satellite', 'Bopal', 'Maninagar', 'Prahlad Nagar'],
  Jaipur: ['Malviya Nagar', 'Vaishali Nagar', 'C Scheme', 'Mansarovar', 'Jagatpura'],
  Dubai: ['Dubai Marina', 'Al Quoz', 'Jumeirah', 'Deira', 'Business Bay'],
  Doha: ['West Bay', 'The Pearl', 'Lusail', 'Al Sadd', 'Aspire Zone'],
  Sydney: ['Bondi', 'Parramatta', 'Surry Hills', 'Manly', 'Newtown'],
  London: ['Camden', 'Shoreditch', 'Wimbledon', 'Hackney', 'Greenwich'],
};
const PREFIX = ['Ace', 'Smash', 'Victory', 'Champion', 'Playzone', 'Arena', 'Striker', 'Hoops', 'Kick Off', 'Net Hub'];
const SUFFIX = ['Sports Complex', 'Turf', 'Arena', 'Courts', 'Club', 'Academy'];
const AMENITIES = ['Parking', 'Washroom', 'Changing room', 'Floodlights', 'Drinking water', 'Cafe', 'Equipment rental', 'First aid'];
export const ALL_AMENITIES = AMENITIES;
const SPORT_IDS = SPORTS.map((s) => s.id);

/** What a venue can rent out, per sport (rupees per hour at an Indian venue; foreign venues cost more) */
const EQUIPMENT: Record<string, [name: string, inr: number][]> = {
  badminton: [['Racket', 50], ['Shuttlecocks (3)', 40]],
  football: [['Ball', 60], ['Bibs (set)', 30]],
  cricket: [['Bat', 80], ['Ball', 50]],
  tennis: [['Racket', 80], ['Balls (3)', 40]],
  basketball: [['Ball', 50]],
  swimming: [['Goggles', 30], ['Swim cap', 20]],
  tabletennis: [['Bat', 30], ['Balls (3)', 20]],
  pickleball: [['Paddle', 60], ['Balls (3)', 30]],
  padel: [['Racket', 120], ['Balls (3)', 40]],
};

/** Price per hour in the city's own currency, tidy numbers */
const LOCAL_PRICE: Record<CurrencyCode, [min: number, step: number, count: number]> = {
  INR: [200, 50, 16], AED: [40, 5, 16], QAR: [40, 5, 16], AUD: [25, 3, 16], GBP: [12, 2, 16],
};

/** Deterministic pseudo-random, so the same venue is the same on every restart */
function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 2 ** 32);
}

export const STATIC_VENUES: Venue[] = (() => {
  const out: Venue[] = [];
  let id = 1;
  for (const city of CITIES) {
    const info = CITY_INFO[city];
    for (let i = 0; i < 12; i++) {
      const r = rng(id * 7919);
      const area = AREAS[city][i % 5];
      const nSports = 1 + Math.floor(r() * 3);
      const first = Math.floor(r() * SPORT_IDS.length);
      const sports = [...new Set(Array.from({ length: nSports }, (_, j) => SPORT_IDS[(first + j * 3) % SPORT_IDS.length]))];
      const name = `${PREFIX[Math.floor(r() * PREFIX.length)]} ${SUFFIX[Math.floor(r() * SUFFIX.length)]}`;
      const [min, step, count] = LOCAL_PRICE[info.currency];
      const local = min + Math.floor(r() * count) * step;
      const priceInr = Math.round(toInr(local, info.currency) / 10) * 10;
      const tier = info.currency === 'INR' ? 1 : 8; // rentals cost more abroad
      out.push({
        id, name, city, area, sports,
        pricePerHour: priceInr,
        peakExtra: Math.max(100, Math.round((priceInr * 0.15) / 10) * 10),
        currency: info.currency,
        pricePerHourLocal: local,
        rating: Math.round((3.6 + r() * 1.4) * 10) / 10,
        reviews: 10 + Math.floor(r() * 400),
        image: `https://picsum.photos/seed/playo-${id}/640/360`,
        images: Array.from({ length: 5 }, (_, k) => `https://picsum.photos/seed/playo-${id}-${k}/960/540`),
        amenities: AMENITIES.filter(() => r() > 0.45),
        address: `${10 + Math.floor(r() * 90)}, ${area} Main Road, ${city}`,
        description: `${name} in ${area} is a popular ${sports.join(' & ')} venue with well-maintained surfaces, open from 6 AM to 11 PM.`,
        lat: Math.round((info.lat + (r() - 0.5) * 0.12) * 10000) / 10000,
        lng: Math.round((info.lng + (r() - 0.5) * 0.12) * 10000) / 10000,
        equipment: sports.flatMap((s) => (EQUIPMENT[s] ?? []).map(([n, p]) => ({ id: `${s}:${n}`, name: n, priceInr: p * tier }))),
      });
      id++;
    }
  }
  return out;
})();

/** Is this hour already taken by someone else? Stable per venue + date + hour */
export function takenByOthers(venueId: number, date: string, hour: number): boolean {
  let h = venueId * 31 + hour * 17;
  for (const ch of date) h = (Math.imul(h, 31) + ch.charCodeAt(0)) >>> 0;
  return rng(h)() < 0.3;
}

export const isPeakHour = (hour: number) => hour >= 18 && hour < 21;
export const hourOf = (slot: string) => Number(slot.slice(0, 2));
export const slotLabel = (hour: number) => `${String(hour).padStart(2, '0')}:00`;
export const slotPrice = (venue: Pick<Venue, 'pricePerHour' | 'peakExtra'>, hour: number) => venue.pricePerHour + (isPeakHour(hour) ? venue.peakExtra : 0);
/** When a slot on a date starts (the server's clock and time zone: a demo simplification) */
export const slotStart = (date: string, time: string) => new Date(`${date}T${time}:00`);
export const currencySymbol = (c: CurrencyCode) => CURRENCIES[c].symbol;
