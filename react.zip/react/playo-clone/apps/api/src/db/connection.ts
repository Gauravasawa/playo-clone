import { Database } from 'bun:sqlite';
import { config } from '../config';

export const db = new Database(config.dbPath, { create: true });
db.run('PRAGMA journal_mode = WAL');
db.run('PRAGMA foreign_keys = ON');
