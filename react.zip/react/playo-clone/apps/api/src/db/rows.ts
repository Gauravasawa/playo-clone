/** The shape of each table's rows, as bun:sqlite returns them */
export interface UserRow {
  id: number; phone: string; name: string; username: string; bio: string; city: string;
  avatar_emoji: string; avatar_color: string; is_private: number; wallet: number;
  favorites: string; is_bot: number; created_at: number;
  plays: string; referral_code: string; referred_by: number | null; referral_rewarded: number; is_admin: number; last_login_day: string | null;
}
export interface BookingRow {
  id: number; user_id: number; venue_id: number; sport: string; date: string; slots: string; total: number;
  discount: number; paid: number; method: string; coupon: string | null; status: 'confirmed' | 'attended'; created_at: number;
  extras: string; extras_inr: number; slots_inr: number; pass_id: number | null; pass_covered: number;
  fee: number; karma_used: number; karma_discount: number; starts_at: number;
}
export interface GameRow {
  id: number; host_id: number; host_name: string; title: string; sport: string; city: string; venue_id: number;
  starts_at: string; capacity: number; level: string; status: 'open' | 'ended'; ended_at: number | null;
  join_mode: 'open' | 'approval'; visibility: 'public' | 'private'; invite_code: string | null; min_level: string | null;
  price_inr: number; paid_out: number;
}
export interface PlayerRow { user_id: number; name: string; won: number; attended: number | null; paid_inr: number; karma_used: number }
export interface GameRequestRow { id: number; game_id: number; user_id: number; status: 'pending' | 'approved' | 'declined'; paid_inr: number; karma_used: number; created_at: number }
export interface FriendshipRow { id: number; requester_id: number; addressee_id: number; status: 'pending' | 'accepted'; created_at: number }
export interface FollowRow { follower_id: number; followee_id: number; status: 'pending' | 'accepted'; created_at: number }
export interface NotificationRow { id: number; user_id: number; type: string; data: string; read: number; created_at: number }
export interface ChatRow { id: number; kind: 'direct' | 'group' | 'game'; title: string | null; game_id: number | null; created_by: number; created_at: number }
export interface MessageRow { id: number; chat_id: number; sender_id: number; body: string; image: string | null; created_at: number }
export interface WalletTxRow { id: number; user_id: number; amount: number; kind: string; note: string; created_at: number }
export interface KarmaTxRow { id: number; user_id: number; points: number; kind: string; note: string; ref: string | null; created_at: number }
export interface ReviewRow { id: number; kind: 'venue' | 'player' | 'coach'; target_id: number; author_id: number; rating: number; body: string; context_id: number; created_at: number }
export interface SubscriptionRow { id: number; user_id: number; plan: 'monthly' | 'yearly'; started_at: number; renews_at: number; cancelled_at: number | null; paid: number }
export interface PassRow { id: number; user_id: number; venue_id: number; kind: 'daily' | 'monthly'; valid_date: string | null; hours_total: number; hours_left: number; valid_until: number; paid: number; created_at: number }
export interface GiftCardRow { code: string; amount: number; buyer_id: number; recipient_id: number | null; message: string; created_at: number; expires_at: number; redeemed_by: number | null; redeemed_at: number | null }
export interface EnrolmentRow { id: number; user_id: number; program_id: number; batch_id: number; paid: number; karma_used: number; status: 'active' | 'cancelled' | 'completed'; created_at: number }
export interface CoachSessionRow { id: number; user_id: number; coach_id: number; date: string; time: string; price: number; paid: number; karma_used: number; status: 'confirmed' | 'attended' | 'cancelled'; starts_at: number; created_at: number }
export interface EventRegRow { id: number; event_id: number; user_id: number; category: string | null; bib: number | null; paid: number; status: 'going' | 'maybe' | 'cancelled'; created_at: number }
export interface TicketRow { id: number; user_id: number; topic: string; subject: string; booking_id: number | null; status: 'open' | 'answered' | 'closed'; created_at: number; updated_at: number }
export interface TicketMessageRow { id: number; ticket_id: number; sender: 'user' | 'agent'; body: string; created_at: number }
export interface ReportRow { id: number; reporter_id: number; kind: string; target_id: number; reason: string; details: string; status: 'open' | 'resolved' | 'dismissed'; created_at: number }
