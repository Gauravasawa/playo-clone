import { db } from './connection';

/** Bump when a table changes. This is a demo database: an older one is dropped and recreated. */
const SCHEMA_VERSION = 4;

const TABLES = [
  'users', 'sessions', 'user_sports', 'friendships', 'follows', 'notifications',
  'chats', 'chat_members', 'messages', 'bookings', 'wallet_tx', 'games', 'game_players',
  'game_requests', 'game_invites', 'game_rsvps', 'reviews', 'tournament_regs', 'coach_enquiries',
  'karma_tx', 'subscriptions', 'venue_passes', 'gift_cards',
  'program_enrolments', 'coach_sessions', 'event_regs', 'events_custom',
  'venue_owners', 'venue_overrides', 'blocked_slots', 'custom_venues', 'review_replies',
  'support_tickets', 'ticket_messages', 'blocks', 'reports',
];

export function migrate() {
  const current = (db.query('PRAGMA user_version').get() as { user_version: number }).user_version;
  if (current < SCHEMA_VERSION) {
    for (const t of TABLES) db.run(`DROP TABLE IF EXISTS ${t}`);
    db.run(`PRAGMA user_version = ${SCHEMA_VERSION}`);
  }

  /* ---------- People ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY, phone TEXT UNIQUE, name TEXT, username TEXT UNIQUE, bio TEXT DEFAULT '', city TEXT DEFAULT 'Bengaluru',
    avatar_emoji TEXT DEFAULT '🙂', avatar_color TEXT DEFAULT '#00b259', is_private INTEGER DEFAULT 0,
    wallet INTEGER DEFAULT 0, favorites TEXT DEFAULT '[]', is_bot INTEGER DEFAULT 0, created_at INTEGER,
    plays TEXT DEFAULT '{"days":[],"times":[]}', referral_code TEXT UNIQUE, referred_by INTEGER, referral_rewarded INTEGER DEFAULT 0,
    is_admin INTEGER DEFAULT 0, last_login_day TEXT)`);
  db.run(`CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS user_sports (user_id INTEGER, sport TEXT, level TEXT, PRIMARY KEY (user_id, sport))`);

  /* ---------- Social ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS friendships (id INTEGER PRIMARY KEY, requester_id INTEGER, addressee_id INTEGER, status TEXT, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS follows (follower_id INTEGER, followee_id INTEGER, status TEXT, created_at INTEGER, PRIMARY KEY (follower_id, followee_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY, user_id INTEGER, type TEXT, data TEXT, read INTEGER DEFAULT 0, created_at INTEGER)`);
  db.run(`CREATE INDEX IF NOT EXISTS notifications_user ON notifications (user_id, id)`);
  db.run(`CREATE TABLE IF NOT EXISTS blocks (blocker_id INTEGER, blocked_id INTEGER, created_at INTEGER, PRIMARY KEY (blocker_id, blocked_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY, reporter_id INTEGER, kind TEXT, target_id INTEGER, reason TEXT, details TEXT, status TEXT DEFAULT 'open', created_at INTEGER)`);

  /* ---------- Chat ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS chats (id INTEGER PRIMARY KEY, kind TEXT, title TEXT, game_id INTEGER, created_by INTEGER, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS chat_members (chat_id INTEGER, user_id INTEGER, last_read_id INTEGER DEFAULT 0, PRIMARY KEY (chat_id, user_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, chat_id INTEGER, sender_id INTEGER, body TEXT, image TEXT, created_at INTEGER)`);
  db.run(`CREATE INDEX IF NOT EXISTS messages_chat ON messages (chat_id, id)`);

  /* ---------- Money ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS wallet_tx (id INTEGER PRIMARY KEY, user_id INTEGER, amount INTEGER, kind TEXT, note TEXT, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS karma_tx (id INTEGER PRIMARY KEY, user_id INTEGER, points INTEGER, kind TEXT, note TEXT, ref TEXT, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS subscriptions (id INTEGER PRIMARY KEY, user_id INTEGER, plan TEXT, started_at INTEGER, renews_at INTEGER, cancelled_at INTEGER, paid INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS venue_passes (
    id INTEGER PRIMARY KEY, user_id INTEGER, venue_id INTEGER, kind TEXT, valid_date TEXT, hours_total INTEGER, hours_left INTEGER,
    valid_until INTEGER, paid INTEGER, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS gift_cards (
    code TEXT PRIMARY KEY, amount INTEGER, buyer_id INTEGER, recipient_id INTEGER, message TEXT, created_at INTEGER, expires_at INTEGER,
    redeemed_by INTEGER, redeemed_at INTEGER)`);

  /* ---------- Bookings ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY, user_id INTEGER, venue_id INTEGER, sport TEXT, date TEXT, slots TEXT, total INTEGER,
    discount INTEGER DEFAULT 0, paid INTEGER DEFAULT 0, method TEXT DEFAULT 'wallet', coupon TEXT,
    status TEXT DEFAULT 'confirmed', created_at INTEGER,
    extras TEXT DEFAULT '[]', extras_inr INTEGER DEFAULT 0, slots_inr INTEGER DEFAULT 0, pass_id INTEGER, pass_covered INTEGER DEFAULT 0,
    fee INTEGER DEFAULT 0, karma_used INTEGER DEFAULT 0, karma_discount INTEGER DEFAULT 0, starts_at INTEGER)`);

  /* ---------- Games ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS games (
    id INTEGER PRIMARY KEY, host_id INTEGER, host_name TEXT, title TEXT, sport TEXT, city TEXT, venue_id INTEGER,
    starts_at TEXT, capacity INTEGER, level TEXT, status TEXT DEFAULT 'open', ended_at INTEGER,
    join_mode TEXT DEFAULT 'open', visibility TEXT DEFAULT 'public', invite_code TEXT, min_level TEXT,
    price_inr INTEGER DEFAULT 0, paid_out INTEGER DEFAULT 0)`);
  db.run(`CREATE TABLE IF NOT EXISTS game_players (
    game_id INTEGER, user_id INTEGER, name TEXT, won INTEGER DEFAULT 0, attended INTEGER, paid_inr INTEGER DEFAULT 0, karma_used INTEGER DEFAULT 0,
    PRIMARY KEY (game_id, user_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS game_requests (
    id INTEGER PRIMARY KEY, game_id INTEGER, user_id INTEGER, status TEXT, paid_inr INTEGER DEFAULT 0, karma_used INTEGER DEFAULT 0,
    created_at INTEGER, UNIQUE (game_id, user_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS game_invites (game_id INTEGER, user_id INTEGER, invited_by INTEGER, created_at INTEGER, PRIMARY KEY (game_id, user_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS game_rsvps (game_id INTEGER, user_id INTEGER, answer TEXT, updated_at INTEGER, PRIMARY KEY (game_id, user_id))`);

  /* ---------- Reviews, tournaments, coaching, events ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY, kind TEXT, target_id INTEGER, author_id INTEGER, rating INTEGER, body TEXT, context_id INTEGER DEFAULT 0, created_at INTEGER,
    UNIQUE (kind, target_id, author_id, context_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS review_replies (review_id INTEGER PRIMARY KEY, owner_id INTEGER, body TEXT, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS tournament_regs (tournament_id INTEGER, user_id INTEGER, paid INTEGER, created_at INTEGER, PRIMARY KEY (tournament_id, user_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS coach_enquiries (id INTEGER PRIMARY KEY, coach_id INTEGER, user_id INTEGER, message TEXT, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS program_enrolments (
    id INTEGER PRIMARY KEY, user_id INTEGER, program_id INTEGER, batch_id INTEGER, paid INTEGER, karma_used INTEGER DEFAULT 0, status TEXT DEFAULT 'active', created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS coach_sessions (
    id INTEGER PRIMARY KEY, user_id INTEGER, coach_id INTEGER, date TEXT, time TEXT, price INTEGER, paid INTEGER DEFAULT 0, karma_used INTEGER DEFAULT 0,
    status TEXT DEFAULT 'confirmed', starts_at INTEGER, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS event_regs (
    id INTEGER PRIMARY KEY, event_id INTEGER, user_id INTEGER, category TEXT, bib INTEGER, paid INTEGER DEFAULT 0, status TEXT DEFAULT 'going',
    created_at INTEGER, UNIQUE (event_id, user_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS events_custom (id INTEGER PRIMARY KEY, host_id INTEGER, data TEXT, created_at INTEGER)`);

  /* ---------- Venue owners ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS venue_owners (venue_id INTEGER PRIMARY KEY, owner_id INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS venue_overrides (venue_id INTEGER PRIMARY KEY, price_inr INTEGER, peak_extra INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS blocked_slots (venue_id INTEGER, date TEXT, time TEXT, PRIMARY KEY (venue_id, date, time))`);
  db.run(`CREATE TABLE IF NOT EXISTS custom_venues (id INTEGER PRIMARY KEY, owner_id INTEGER, data TEXT)`);

  /* ---------- Help ---------- */
  db.run(`CREATE TABLE IF NOT EXISTS support_tickets (
    id INTEGER PRIMARY KEY, user_id INTEGER, topic TEXT, subject TEXT, booking_id INTEGER, status TEXT DEFAULT 'open', created_at INTEGER, updated_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS ticket_messages (id INTEGER PRIMARY KEY, ticket_id INTEGER, sender TEXT, body TEXT, created_at INTEGER)`);
}
