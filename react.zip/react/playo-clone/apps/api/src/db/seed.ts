import { ADMIN, BOTS } from '../data/bots';
import { SPORTS } from '../data/sports';
import type { Venue } from '../data/venues';
import { games } from '../repositories/games';
import { users } from '../repositories/users';
import { catalog } from '../services/catalog';
import { customEvents, eventRegs } from '../repositories/learning';
import { ensureGameChat } from '../services/chat';
import { db } from './connection';

const DAY = 24 * 3600 * 1000;
const sportName = (id: string) => SPORTS.find((s) => s.id === id)!.name;

/** A game with its players already in it (used for the demo data) */
export function createGameWith(opts: {
  host: { id: number; name: string }; others: { id: number; name: string }[]; venue: Venue; sport: string;
  startsAt: Date; status: 'open' | 'ended'; winners?: number[]; capacity?: number; level?: string; title?: string;
  joinMode?: 'open' | 'approval'; visibility?: 'public' | 'private'; minLevel?: string | null; priceInr?: number; inviteCode?: string | null;
}) {
  const game = games.create({
    hostId: opts.host.id, hostName: opts.host.name, title: opts.title ?? `${sportName(opts.sport)} at ${opts.venue.name}`,
    sport: opts.sport, city: opts.venue.city, venueId: opts.venue.id, startsAt: opts.startsAt.toISOString(),
    capacity: opts.capacity ?? 8, level: opts.level ?? 'Intermediate', status: opts.status,
    endedAt: opts.status === 'ended' ? opts.startsAt.getTime() + 2 * 3600 * 1000 : null,
    joinMode: opts.joinMode, visibility: opts.visibility, minLevel: opts.minLevel ?? null, priceInr: opts.priceInr ?? 0, inviteCode: opts.inviteCode ?? null,
  });
  for (const p of opts.others) games.join(game.id, p.id, p.name);
  for (const w of opts.winners ?? []) db.run('UPDATE game_players SET won = 1 WHERE game_id = ? AND user_id = ?', [game.id, w]);
  ensureGameChat(game);
  return game;
}

export const venueFor = (city: string, sport: string) => {
  const all = catalog.list();
  return all.find((v) => v.city === city && v.sports.includes(sport)) ?? all.find((v) => v.city === city)!;
};

/** The demo players, and games between them (open ones to join, ended ones for stats and the leaderboard) */
export function seed() {
  if (users.count() > 0) return;

  users.create({ phone: ADMIN.phone, name: ADMIN.name, username: ADMIN.username, emoji: ADMIN.emoji, color: ADMIN.color, isAdmin: true, isBot: true, wallet: 0 });

  for (const b of BOTS) {
    const u = users.create({ phone: b.phone, name: b.name, username: b.username, city: b.city, emoji: b.emoji, color: b.color, isPrivate: b.isPrivate, bio: b.bio, isBot: true, wallet: 5000, plays: b.plays });
    users.setSports(u.id, b.sports.map(([sport, level]) => ({ sport, level })));
    if (b.plus) db.run('INSERT INTO subscriptions (user_id, plan, started_at, renews_at, paid) VALUES (?,?,?,?,?)', [u.id, 'yearly', Date.now(), Date.now() + 365 * DAY, 0]);
  }
  const bots = users.bots();
  const specOf = (username: string) => BOTS.find((b) => b.username === username)!;

  // Ended games between the demo players, preferring people from the same city
  let n = 0;
  for (const host of bots) {
    for (const [sport] of specOf(host.username).sports) {
      const sameSport = bots.filter((b) => b.id !== host.id && specOf(b.username).sports.some(([s]) => s === sport));
      const local = sameSport.filter((b) => b.city === host.city);
      const pool = local.length >= 2 ? local : sameSport.length ? sameSport : bots.filter((b) => b.id !== host.id);
      const others = pool.slice(0, 3);
      const winner = [host, ...others][n % (others.length + 1)];
      createGameWith({
        host, others, venue: venueFor(host.city, sport), sport, status: 'ended', winners: [winner.id],
        startsAt: new Date(Date.now() - (3 + (n % 20)) * DAY),
      });
      n++;
    }
  }

  // Open games hosted by demo players in every city; a mix of rules so the host controls can be seen
  const cities = [...new Set(bots.map((b) => b.city))];
  for (const [ci, city] of cities.entries()) {
    const hosts = bots.filter((b) => b.city === city);
    hosts.slice(0, 4).forEach((host, i) => {
      const sport = specOf(host.username).sports[0][0];
      const others = hosts.filter((b) => b.id !== host.id).slice(i, i + 1 + (i % 2));
      const when = new Date(Date.now() + ((i + ci) % 5 + 2) * DAY);
      when.setHours(6 + ((i * 3 + ci) % 14), 0, 0, 0);
      const k = (i + ci) % 6;
      createGameWith({
        host, others, venue: venueFor(city, sport), sport, startsAt: when, status: 'open', capacity: 4 + ((i + ci) % 6),
        level: ['Beginner', 'Intermediate', 'Advanced'][i % 3],
        joinMode: k === 1 ? 'approval' : 'open',
        priceInr: k === 2 ? 150 : 0,
        minLevel: k === 3 ? 'Intermediate' : null,
        title: k === 4 ? `${sportName(sport)} social (everyone welcome)` : undefined,
      });
    });
  }
  // Meet-ups and workshops hosted by the demo players (free or small fee), so the Events page isn't empty
  const meetupTitles = ['Sunday pickup games', 'Beginner clinic', 'Social doubles evening', 'Strategy workshop'];
  bots.forEach((b, i) => {
    const when = new Date(Date.now() + (3 + (i % 9)) * DAY);
    when.setHours(8 + (i % 10), 0, 0, 0);
    const id = customEvents.add(b.id, {
      title: `${meetupTitles[i % meetupTitles.length]} · ${b.name.split(' ')[0]}`, city: b.city, startsAt: when.toISOString(), place: `${b.city} community ground`,
      description: 'Friendly and open to all levels. Bring water and a smile.', feeInr: i % 3 === 0 ? 100 : 0, capacity: 16 + (i % 4) * 4, sport: specOf(b.username).sports[0][0], hostName: b.name,
    });
    eventRegs.upsert({ eventId: id, userId: b.id, category: null, bib: null, paid: 0, status: 'going' });
  });
}
