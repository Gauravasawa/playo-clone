import { config } from './config';
import { migrate } from './db/schema';
import { seed } from './db/seed';
import type { WsData } from './realtime/hub';
import { upgrade, websocket } from './realtime/ws';
import { router } from './routes';

migrate();
seed();

Bun.serve<WsData>({
  port: config.port,
  fetch(req, server) {
    if (new URL(req.url).pathname === '/ws') return upgrade(req, server);
    return router.handle(req);
  },
  websocket,
});
console.log(`Playo API on http://localhost:${config.port} (WebSocket at /ws)`);
