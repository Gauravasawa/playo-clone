export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export const json = (data: unknown, status = 200) => Response.json(data, { status });
export const errorResponse = (status: number, message: string, extra: { retryAfter?: number } = {}) =>
  Response.json({ error: message, ...extra }, { status, headers: extra.retryAfter ? { 'retry-after': String(extra.retryAfter) } : undefined });
export const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** The JSON body, or a 400 */
export async function readJson<T>(req: Request): Promise<Partial<T>> {
  try {
    return (await req.json()) as Partial<T>;
  } catch {
    throw new HttpError(400, 'Invalid JSON body');
  }
}
