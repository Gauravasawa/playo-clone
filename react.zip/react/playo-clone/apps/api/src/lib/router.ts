import type { UserRow } from '../db/rows';
import { HttpError, errorResponse } from './http';

export interface Ctx {
  req: Request;
  url: URL;
  /** Values of `:name` segments, as strings */
  params: Record<string, string>;
  user: UserRow | null;
}
export type Handler = (ctx: Ctx) => Response | Promise<Response>;
export type Middleware = (ctx: Ctx, next: () => Promise<Response>) => Promise<Response>;

interface Route { method: string; pattern: RegExp; names: string[]; handler: Handler }

/** A small router: `router.get('/api/venues/:id', handler)`, plus middleware that wraps every request */
export class Router {
  private routes: Route[] = [];
  private middleware: Middleware[] = [];

  use(mw: Middleware) {
    this.middleware.push(mw);
    return this;
  }

  private add(method: string, path: string, handler: Handler) {
    const names: string[] = [];
    const source = path.replace(/:(\w+)/g, (_, name) => (names.push(name), '([^/]+)'));
    this.routes.push({ method, pattern: new RegExp(`^${source}$`), names, handler });
    return this;
  }

  get = (path: string, h: Handler) => this.add('GET', path, h);
  post = (path: string, h: Handler) => this.add('POST', path, h);
  put = (path: string, h: Handler) => this.add('PUT', path, h);
  delete = (path: string, h: Handler) => this.add('DELETE', path, h);

  /** Mounts another router's routes (each file in routes/ exports one) */
  mount(other: Router) {
    this.routes.push(...other.routes);
    return this;
  }

  handle = async (req: Request): Promise<Response> => {
    const url = new URL(req.url);
    const ctx: Ctx = { req, url, params: {}, user: null };

    const dispatch = async (): Promise<Response> => {
      for (const r of this.routes) {
        if (r.method !== req.method) continue;
        const m = url.pathname.match(r.pattern);
        if (!m) continue;
        r.names.forEach((n, i) => (ctx.params[n] = m[i + 1]));
        return r.handler(ctx);
      }
      return errorResponse(404, 'Not found');
    };

    const run = this.middleware.reduceRight<() => Promise<Response>>(
      (next, mw) => () => mw(ctx, next),
      dispatch
    );
    try {
      return await run();
    } catch (e) {
      if (e instanceof HttpError) return errorResponse(e.status, e.message, { retryAfter: (e as { retryAfter?: number }).retryAfter });
      console.error(e);
      return errorResponse(500, e instanceof Error ? e.message : 'Server error');
    }
  };
}
