import { config } from '../config';
import { HttpError, delay } from '../lib/http';
import type { Ctx, Middleware } from '../lib/router';
import { users } from '../repositories/users';

/** Artificial latency, so the UI's loading states can be seen */
export const latency: Middleware = async (ctx, next) => {
  if (ctx.url.pathname !== '/api/health') await delay(config.latencyMs);
  return next();
};

/**
 * The UI's "simulate failures" switch: every write fails with 503, so optimistic updates
 * can be seen rolling back.
 */
export const simulateFailure: Middleware = async (ctx, next) => {
  if (ctx.req.method !== 'GET' && ctx.req.headers.get('x-simulate-failure') === '1') throw new HttpError(503, 'Simulated server failure');
  return next();
};

/** Looks the user up from `Authorization: Bearer <token>`; routes that need one call requireUser */
export const authenticate: Middleware = async (ctx, next) => {
  const token = ctx.req.headers.get('authorization')?.replace(/^Bearer /, '');
  ctx.user = token ? users.byToken(token) : null;
  return next();
};

/** The Lab's "decline UPI and card payments" switch, sent as a header by the browser */
export const wantsDecline = (ctx: Ctx) => ctx.req.headers.get('x-simulate-payment-failure') === '1';

export function requireUser(ctx: Ctx) {
  if (!ctx.user) throw new HttpError(401, 'Please log in');
  return ctx.user;
}
