import { HttpError } from '../lib/http';
import type { Middleware } from '../lib/router';

/** A request was refused because there were too many too quickly */
export class RateLimitError extends HttpError {
  constructor(public retryAfter: number) {
    super(429, `Too many requests. Please try again in ${retryAfter} second${retryAfter === 1 ? '' : 's'}.`);
  }
}

interface Rule { name: string; limit: number; windowMs: number; matches: (method: string, path: string) => boolean }

const scale = Number(process.env.RATE_LIMIT_SCALE ?? 1);
const RULES: Rule[] = [
  { name: 'login', limit: 10, windowMs: 60_000, matches: (m, p) => m === 'POST' && p === '/api/auth/login' },
  { name: 'messages', limit: 30, windowMs: 60_000, matches: (m, p) => m === 'POST' && /^\/api\/chats\/\d+\/messages$/.test(p) },
  { name: 'requests', limit: 20, windowMs: 60_000, matches: (m, p) => m === 'POST' && (p === '/api/friends/requests' || p === '/api/follows') },
  { name: 'tickets', limit: 5, windowMs: 60_000, matches: (m, p) => m === 'POST' && p === '/api/tickets' },
];

/** Timestamps of recent hits per rule and person */
const hits = new Map<string, number[]>();

/**
 * A sliding window per rule and per person (the logged-in user, or the phone number being logged into).
 * In memory, so it resets when the server restarts: enough to show how the UI copes with a 429.
 */
export const rateLimit: Middleware = async (ctx, next) => {
  const rule = RULES.find((r) => r.matches(ctx.req.method, ctx.url.pathname));
  if (!rule) return next();

  let who = ctx.user ? `u${ctx.user.id}` : '';
  if (!who && rule.name === 'login') {
    const phone = (await ctx.req.clone().json().catch(() => ({})) as { phone?: string }).phone;
    who = `p${phone ?? ctx.req.headers.get('x-forwarded-for') ?? 'anon'}`;
  }
  const key = `${rule.name}:${who || 'anon'}`;
  const now = Date.now();
  const limit = Math.max(1, Math.round(rule.limit * scale));
  const recent = (hits.get(key) ?? []).filter((t) => now - t < rule.windowMs);
  if (recent.length >= limit) {
    hits.set(key, recent);
    throw new RateLimitError(Math.max(1, Math.ceil((recent[0] + rule.windowMs - now) / 1000)));
  }
  recent.push(now);
  hits.set(key, recent);
  return next();
};
