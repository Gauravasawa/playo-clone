import type { ServerWebSocket } from 'bun';

export interface WsData { userId: number }

/** Every open WebSocket, by user (one user can have several tabs) */
const sockets = new Map<number, Set<ServerWebSocket<WsData>>>();

/** What the server pushes to browsers */
export type ServerEvent =
  | { type: 'notification'; notification: unknown }
  | { type: 'message'; message: unknown }
  | { type: 'typing'; chatId: number; userId: number }
  | { type: 'read'; chatId: number; userId: number; upTo: number }
  | { type: 'presence'; userId: number; online: boolean }
  | { type: 'chat'; chatId: number } // a chat was created or its members changed: reload the list
  | { type: 'refresh'; what: 'friends' | 'followRequests' | 'games' | 'wallet' | 'bookings' | 'player' | 'owner' | 'tickets' | 'learning' | 'events' | 'karma' }
  | { type: 'ticket'; ticketId: number } // a support agent answered
  | { type: 'hello'; userId: number };

export const hub = {
  add(ws: ServerWebSocket<WsData>) {
    const set = sockets.get(ws.data.userId) ?? new Set();
    set.add(ws);
    sockets.set(ws.data.userId, set);
    return set.size === 1; // first connection: the user just came online
  },
  remove(ws: ServerWebSocket<WsData>) {
    const set = sockets.get(ws.data.userId);
    set?.delete(ws);
    if (set && set.size === 0) {
      sockets.delete(ws.data.userId);
      return true; // last connection: the user went offline
    }
    return false;
  },
  hasSocket: (userId: number) => sockets.has(userId),
  sendTo(userId: number, event: ServerEvent) {
    const set = sockets.get(userId);
    if (!set) return;
    const text = JSON.stringify(event);
    for (const ws of set) ws.send(text);
  },
  sendToMany(userIds: Iterable<number>, event: ServerEvent) {
    for (const id of new Set(userIds)) hub.sendTo(id, event);
  },
};
