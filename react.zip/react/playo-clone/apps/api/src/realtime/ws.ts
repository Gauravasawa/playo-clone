import type { Server, WebSocketHandler } from 'bun';
import { chats } from '../repositories/chats';
import { friendships } from '../repositories/social';
import { users } from '../repositories/users';
import { hub, type WsData } from './hub';

/** Browsers connect with `/ws?token=<session token>` */
export function upgrade(req: Request, server: Server<WsData>): Response | undefined {
  const token = new URL(req.url).searchParams.get('token');
  const user = token ? users.byToken(token) : null;
  if (!user) return new Response('Unauthorized', { status: 401 });
  if (server.upgrade(req, { data: { userId: user.id } })) return undefined;
  return new Response('Expected a WebSocket', { status: 426 });
}

const tellFriends = (userId: number, online: boolean) =>
  hub.sendToMany(friendships.friendIds(userId), { type: 'presence', userId, online });

/** Messages browsers send: only "typing" (everything else goes over HTTP so it can be retried) */
export const websocket: WebSocketHandler<WsData> = {
  open(ws) {
    if (hub.add(ws)) tellFriends(ws.data.userId, true);
    ws.send(JSON.stringify({ type: 'hello', userId: ws.data.userId }));
  },
  message(ws, raw) {
    let msg: { type?: string; chatId?: number };
    try {
      msg = JSON.parse(String(raw));
    } catch {
      return;
    }
    if (msg.type === 'typing' && typeof msg.chatId === 'number' && chats.isMember(msg.chatId, ws.data.userId)) {
      hub.sendToMany(chats.memberIds(msg.chatId).filter((id) => id !== ws.data.userId), { type: 'typing', chatId: msg.chatId, userId: ws.data.userId });
    }
  },
  close(ws) {
    if (hub.remove(ws)) tellFriends(ws.data.userId, false);
  },
};
