import { db } from '../db/connection';
import type { BookingRow } from '../db/rows';

export interface NewBookingInput {
  userId: number; venueId: number; sport: string; date: string; slots: string[]; startsAt: number;
  slotsInr: number; extras: { id: string; name: string; hours: number; priceInr: number }[]; extrasInr: number;
  passId: number | null; passCovered: number; coupon: string | null; couponDiscount: number;
  karmaUsed: number; karmaDiscount: number; fee: number; paid: number; method: string;
}

export const bookings = {
  forUser: (userId: number) =>
    db.query('SELECT * FROM bookings WHERE user_id = ? ORDER BY date DESC, id DESC').all(userId) as BookingRow[],
  forVenue: (venueId: number) =>
    db.query('SELECT * FROM bookings WHERE venue_id = ? ORDER BY date DESC, id DESC').all(venueId) as BookingRow[],

  byId: (id: number) => db.query('SELECT * FROM bookings WHERE id = ?').get(id) as BookingRow | null,

  /** Slots already booked at a venue on a day, by anyone */
  takenSlots: (venueId: number, date: string, exceptBookingId = 0) =>
    (db.query('SELECT slots FROM bookings WHERE venue_id = ? AND date = ? AND id != ?').all(venueId, date, exceptBookingId) as Pick<BookingRow, 'slots'>[]).flatMap(
      (r) => JSON.parse(r.slots) as string[]
    ),

  create: (b: NewBookingInput) => {
    const res = db.run(
      `INSERT INTO bookings (user_id, venue_id, sport, date, slots, total, discount, paid, method, coupon, status, created_at,
         extras, extras_inr, slots_inr, pass_id, pass_covered, fee, karma_used, karma_discount, starts_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        b.userId, b.venueId, b.sport, b.date, JSON.stringify(b.slots), b.slotsInr + b.extrasInr, b.couponDiscount, b.paid, b.method, b.coupon, 'confirmed', Date.now(),
        JSON.stringify(b.extras), b.extrasInr, b.slotsInr, b.passId, b.passCovered, b.fee, b.karmaUsed, b.karmaDiscount, b.startsAt,
      ]
    );
    return bookings.byId(Number(res.lastInsertRowid))!;
  },

  /** A rescheduled booking: new date and slots, new slot price */
  move: (id: number, date: string, slots: string[], startsAt: number, slotsInr: number, extrasInr: number) =>
    db.run('UPDATE bookings SET date = ?, slots = ?, starts_at = ?, slots_inr = ?, total = ? WHERE id = ?', [date, JSON.stringify(slots), startsAt, slotsInr, slotsInr + extrasInr, id]),

  remove: (id: number) => db.run('DELETE FROM bookings WHERE id = ?', [id]).changes > 0,
  markAttended: (id: number) => db.run("UPDATE bookings SET status = 'attended' WHERE id = ?", [id]),
  hasAttended: (userId: number, venueId: number) =>
    !!db.query("SELECT 1 FROM bookings WHERE user_id = ? AND venue_id = ? AND status = 'attended'").get(userId, venueId),
  count: (userId: number) => (db.query('SELECT COUNT(*) AS n FROM bookings WHERE user_id = ?').get(userId) as { n: number }).n,
  revenueByDay: (venueId: number, sinceMs: number) =>
    db.query("SELECT date, SUM(paid) AS revenue, COUNT(*) AS bookings FROM bookings WHERE venue_id = ? AND created_at >= ? GROUP BY date ORDER BY date").all(venueId, sinceMs) as { date: string; revenue: number; bookings: number }[],
};
