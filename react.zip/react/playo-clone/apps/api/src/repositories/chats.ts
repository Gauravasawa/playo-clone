import { db } from '../db/connection';
import type { ChatRow, MessageRow } from '../db/rows';

export const chats = {
  byId: (id: number) => db.query('SELECT * FROM chats WHERE id = ?').get(id) as ChatRow | null,
  byGame: (gameId: number) => db.query("SELECT * FROM chats WHERE kind = 'game' AND game_id = ?").get(gameId) as ChatRow | null,

  create: (c: { kind: ChatRow['kind']; title?: string | null; gameId?: number | null; createdBy: number; memberIds: number[] }) => {
    const res = db.run('INSERT INTO chats (kind, title, game_id, created_by, created_at) VALUES (?,?,?,?,?)', [c.kind, c.title ?? null, c.gameId ?? null, c.createdBy, Date.now()]);
    const id = Number(res.lastInsertRowid);
    for (const m of new Set(c.memberIds)) db.run('INSERT OR IGNORE INTO chat_members (chat_id, user_id, last_read_id) VALUES (?,?,0)', [id, m]);
    return chats.byId(id)!;
  },

  /** The 1:1 chat between two people, if they have one */
  direct: (a: number, b: number) =>
    db.query(
      `SELECT c.* FROM chats c
       WHERE c.kind = 'direct'
         AND EXISTS (SELECT 1 FROM chat_members m WHERE m.chat_id = c.id AND m.user_id = ?)
         AND EXISTS (SELECT 1 FROM chat_members m WHERE m.chat_id = c.id AND m.user_id = ?)`
    ).get(a, b) as ChatRow | null,

  forUser: (userId: number) =>
    db.query('SELECT c.* FROM chats c JOIN chat_members m ON m.chat_id = c.id WHERE m.user_id = ?').all(userId) as ChatRow[],

  members: (chatId: number) => db.query('SELECT user_id, last_read_id FROM chat_members WHERE chat_id = ? ORDER BY user_id').all(chatId) as { user_id: number; last_read_id: number }[],
  memberIds: (chatId: number) => chats.members(chatId).map((m) => m.user_id),
  isMember: (chatId: number, userId: number) => !!db.query('SELECT 1 FROM chat_members WHERE chat_id = ? AND user_id = ?').get(chatId, userId),
  addMember: (chatId: number, userId: number) => db.run('INSERT OR IGNORE INTO chat_members (chat_id, user_id, last_read_id) VALUES (?,?,0)', [chatId, userId]),
  removeMember: (chatId: number, userId: number) => db.run('DELETE FROM chat_members WHERE chat_id = ? AND user_id = ?', [chatId, userId]),

  insertMessage: (chatId: number, senderId: number, body: string, image: string | null) => {
    const res = db.run('INSERT INTO messages (chat_id, sender_id, body, image, created_at) VALUES (?,?,?,?,?)', [chatId, senderId, body, image, Date.now()]);
    // what you send, you have read
    db.run('UPDATE chat_members SET last_read_id = ? WHERE chat_id = ? AND user_id = ?', [Number(res.lastInsertRowid), chatId, senderId]);
    return db.query('SELECT * FROM messages WHERE id = ?').get(Number(res.lastInsertRowid)) as MessageRow;
  },

  /** `limit` messages older than `before` (newest first in the query, returned oldest first) */
  messages: (chatId: number, before: number | null, limit: number) =>
    (db.query('SELECT * FROM messages WHERE chat_id = ? AND (? IS NULL OR id < ?) ORDER BY id DESC LIMIT ?').all(chatId, before, before, limit) as MessageRow[]).reverse(),

  lastMessage: (chatId: number) => db.query('SELECT * FROM messages WHERE chat_id = ? ORDER BY id DESC LIMIT 1').get(chatId) as MessageRow | null,

  unread: (chatId: number, userId: number) =>
    (db.query(
      `SELECT COUNT(*) AS n FROM messages WHERE chat_id = ? AND sender_id != ?
         AND id > COALESCE((SELECT last_read_id FROM chat_members WHERE chat_id = ? AND user_id = ?), 0)`
    ).get(chatId, userId, chatId, userId) as { n: number }).n,

  setRead: (chatId: number, userId: number, upTo: number) =>
    db.run('UPDATE chat_members SET last_read_id = MAX(last_read_id, ?) WHERE chat_id = ? AND user_id = ?', [upTo, chatId, userId]),
};
