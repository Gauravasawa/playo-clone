import { db } from '../db/connection';
import type { GameRequestRow, GameRow, PlayerRow } from '../db/rows';

export interface NewGameInput {
  hostId: number; hostName: string; title: string; sport: string; city: string; venueId: number;
  startsAt: string; capacity: number; level: string; status?: 'open' | 'ended'; endedAt?: number | null;
  joinMode?: 'open' | 'approval'; visibility?: 'public' | 'private'; minLevel?: string | null; priceInr?: number; inviteCode?: string | null;
}

/** Counts a player's game in their record, unless the host marked them absent */
const ATTENDED = '(p.attended IS NULL OR p.attended = 1)';

const code = () => Array.from({ length: 8 }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');

export const games = {
  all: () => db.query('SELECT * FROM games ORDER BY starts_at').all() as GameRow[],
  byId: (id: number) => db.query('SELECT * FROM games WHERE id = ?').get(id) as GameRow | null,
  byInviteCode: (c: string) => db.query('SELECT * FROM games WHERE invite_code = ?').get(c.trim().toUpperCase()) as GameRow | null,
  players: (gameId: number) => db.query('SELECT user_id, name, won, attended, paid_inr, karma_used FROM game_players WHERE game_id = ?').all(gameId) as PlayerRow[],
  playerCount: (gameId: number) => (db.query('SELECT COUNT(*) AS n FROM game_players WHERE game_id = ?').get(gameId) as { n: number }).n,
  isPlayer: (gameId: number, userId: number) => !!db.query('SELECT 1 FROM game_players WHERE game_id = ? AND user_id = ?').get(gameId, userId),
  count: () => (db.query('SELECT COUNT(*) AS n FROM games').get() as { n: number }).n,

  create: (g: NewGameInput) => {
    const visibility = g.visibility ?? 'public';
    const res = db.run(
      `INSERT INTO games (host_id, host_name, title, sport, city, venue_id, starts_at, capacity, level, status, ended_at, join_mode, visibility, invite_code, min_level, price_inr)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        g.hostId, g.hostName, g.title, g.sport, g.city, g.venueId, g.startsAt, g.capacity, g.level, g.status ?? 'open', g.endedAt ?? null,
        g.joinMode ?? 'open', visibility, g.inviteCode ?? (visibility === 'private' ? code() : null), g.minLevel ?? null, g.priceInr ?? 0,
      ]
    );
    const id = Number(res.lastInsertRowid);
    games.join(id, g.hostId, g.hostName);
    return games.byId(id)!;
  },

  join: (gameId: number, userId: number, name: string, paidInr = 0, karmaUsed = 0) =>
    db.run('INSERT OR IGNORE INTO game_players (game_id, user_id, name, won, paid_inr, karma_used) VALUES (?,?,?,0,?,?)', [gameId, userId, name, paidInr, karmaUsed]),
  leave: (gameId: number, userId: number) => db.run('DELETE FROM game_players WHERE game_id = ? AND user_id = ?', [gameId, userId]),

  end: (gameId: number, winnerIds: number[]) => {
    db.run("UPDATE games SET status = 'ended', ended_at = ? WHERE id = ?", [Date.now(), gameId]);
    for (const w of winnerIds) db.run('UPDATE game_players SET won = 1 WHERE game_id = ? AND user_id = ?', [gameId, w]);
  },
  /** Everyone listed attended; every other player did not */
  setAttendance: (gameId: number, attendedIds: number[]) => {
    db.run('UPDATE game_players SET attended = 0 WHERE game_id = ?', [gameId]);
    for (const id of attendedIds) db.run('UPDATE game_players SET attended = 1 WHERE game_id = ? AND user_id = ?', [gameId, id]);
  },
  markPaidOut: (gameId: number) => db.run('UPDATE games SET paid_out = 1 WHERE id = ?', [gameId]),

  /** Ended games two people were both in (and both attended) */
  sharedEnded: (a: number, b: number) =>
    db.query(
      `SELECT g.* FROM games g
       JOIN game_players p ON p.game_id = g.id AND p.user_id = ?
       JOIN game_players p2 ON p2.game_id = g.id AND p2.user_id = ?
       WHERE g.status = 'ended' AND ${ATTENDED} AND (p2.attended IS NULL OR p2.attended = 1) ORDER BY g.ended_at DESC`
    ).all(a, b) as GameRow[],

  /** People the user has played with: others in ended games, with how many and the latest */
  playedWith: (userId: number) =>
    db.query(
      `SELECT o.user_id AS other, COUNT(*) AS games, MAX(g.ended_at) AS last_at
       FROM game_players p
       JOIN game_players o ON o.game_id = p.game_id AND o.user_id != p.user_id AND (o.attended IS NULL OR o.attended = 1)
       JOIN games g ON g.id = p.game_id AND g.status = 'ended'
       WHERE p.user_id = ? AND ${ATTENDED} GROUP BY o.user_id ORDER BY last_at DESC`
    ).all(userId) as { other: number; games: number; last_at: number }[],

  hasPlayedWith: (a: number, b: number) => games.sharedEnded(a, b).length > 0,

  stats: (userId: number) =>
    db.query(
      `SELECT COUNT(*) AS played, COALESCE(SUM(p.won), 0) AS wins
       FROM game_players p JOIN games g ON g.id = p.game_id AND g.status = 'ended' WHERE p.user_id = ? AND ${ATTENDED}`
    ).get(userId) as { played: number; wins: number },

  leaderboard: (sport: string | null, city: string | null) =>
    db.query(
      `SELECT p.user_id AS id, COUNT(*) AS games, SUM(p.won) AS wins
       FROM game_players p JOIN games g ON g.id = p.game_id AND g.status = 'ended' JOIN users u ON u.id = p.user_id
       WHERE (? IS NULL OR g.sport = ?) AND (? IS NULL OR u.city = ?) AND u.is_admin = 0 AND ${ATTENDED}
       GROUP BY p.user_id ORDER BY (SUM(p.won) * 3 + COUNT(*)) DESC, games DESC LIMIT 50`
    ).all(sport, sport, city, city) as { id: number; games: number; wins: number }[],

  /* ---------- Join requests (approval games) ---------- */
  requestFor: (gameId: number, userId: number) => db.query('SELECT * FROM game_requests WHERE game_id = ? AND user_id = ?').get(gameId, userId) as GameRequestRow | null,
  requests: (gameId: number, status: GameRequestRow['status'] = 'pending') =>
    db.query('SELECT * FROM game_requests WHERE game_id = ? AND status = ? ORDER BY id').all(gameId, status) as GameRequestRow[],
  createRequest: (gameId: number, userId: number, paidInr: number, karmaUsed: number) => {
    db.run('INSERT OR REPLACE INTO game_requests (game_id, user_id, status, paid_inr, karma_used, created_at) VALUES (?,?,?,?,?,?)', [gameId, userId, 'pending', paidInr, karmaUsed, Date.now()]);
    return games.requestFor(gameId, userId)!;
  },
  setRequestStatus: (id: number, status: GameRequestRow['status']) => db.run('UPDATE game_requests SET status = ? WHERE id = ?', [status, id]),

  /* ---------- Invites and RSVP ---------- */
  invite: (gameId: number, userId: number, invitedBy: number) => db.run('INSERT OR IGNORE INTO game_invites (game_id, user_id, invited_by, created_at) VALUES (?,?,?,?)', [gameId, userId, invitedBy, Date.now()]),
  isInvited: (gameId: number, userId: number) => !!db.query('SELECT 1 FROM game_invites WHERE game_id = ? AND user_id = ?').get(gameId, userId),
  invitedTo: (userId: number) => (db.query('SELECT game_id FROM game_invites WHERE user_id = ?').all(userId) as { game_id: number }[]).map((r) => r.game_id),
  setRsvp: (gameId: number, userId: number, answer: string) =>
    db.run('INSERT INTO game_rsvps (game_id, user_id, answer, updated_at) VALUES (?,?,?,?) ON CONFLICT(game_id, user_id) DO UPDATE SET answer = excluded.answer, updated_at = excluded.updated_at', [gameId, userId, answer, Date.now()]),
  rsvps: (gameId: number) => db.query('SELECT user_id, answer FROM game_rsvps WHERE game_id = ?').all(gameId) as { user_id: number; answer: 'going' | 'maybe' | 'no' }[],
};
