import { db } from '../db/connection';
import type { CoachSessionRow, EnrolmentRow, EventRegRow } from '../db/rows';

export const enrolments = {
  byId: (id: number) => db.query('SELECT * FROM program_enrolments WHERE id = ?').get(id) as EnrolmentRow | null,
  forUser: (userId: number) => db.query('SELECT * FROM program_enrolments WHERE user_id = ? ORDER BY id DESC').all(userId) as EnrolmentRow[],
  activeIn: (userId: number, programId: number) =>
    db.query("SELECT * FROM program_enrolments WHERE user_id = ? AND program_id = ? AND status = 'active'").get(userId, programId) as EnrolmentRow | null,
  seatsTaken: (batchId: number) => (db.query("SELECT COUNT(*) AS n FROM program_enrolments WHERE batch_id = ? AND status != 'cancelled'").get(batchId) as { n: number }).n,
  create: (e: { userId: number; programId: number; batchId: number; paid: number; karmaUsed: number }) => {
    const res = db.run('INSERT INTO program_enrolments (user_id, program_id, batch_id, paid, karma_used, status, created_at) VALUES (?,?,?,?,?,?,?)', [e.userId, e.programId, e.batchId, e.paid, e.karmaUsed, 'active', Date.now()]);
    return enrolments.byId(Number(res.lastInsertRowid))!;
  },
  setStatus: (id: number, status: EnrolmentRow['status']) => db.run('UPDATE program_enrolments SET status = ? WHERE id = ?', [status, id]),
  completedWithCoach: (userId: number, coachIds: number[]) =>
    coachIds.length > 0 && !!db.query(`SELECT 1 FROM program_enrolments WHERE user_id = ? AND status = 'completed' AND program_id / 10 IN (${coachIds.join(',')}) LIMIT 1`).get(userId),
};

export const coachSessions = {
  byId: (id: number) => db.query('SELECT * FROM coach_sessions WHERE id = ?').get(id) as CoachSessionRow | null,
  forUser: (userId: number) => db.query('SELECT * FROM coach_sessions WHERE user_id = ? ORDER BY starts_at DESC').all(userId) as CoachSessionRow[],
  taken: (coachId: number, date: string) =>
    (db.query("SELECT time FROM coach_sessions WHERE coach_id = ? AND date = ? AND status != 'cancelled'").all(coachId, date) as { time: string }[]).map((r) => r.time),
  create: (s: { userId: number; coachId: number; date: string; time: string; price: number; paid: number; karmaUsed: number; startsAt: number }) => {
    const res = db.run('INSERT INTO coach_sessions (user_id, coach_id, date, time, price, paid, karma_used, status, starts_at, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)', [s.userId, s.coachId, s.date, s.time, s.price, s.paid, s.karmaUsed, 'confirmed', s.startsAt, Date.now()]);
    return coachSessions.byId(Number(res.lastInsertRowid))!;
  },
  setStatus: (id: number, status: CoachSessionRow['status']) => db.run('UPDATE coach_sessions SET status = ? WHERE id = ?', [status, id]),
  attended: (userId: number, coachId: number) => !!db.query("SELECT 1 FROM coach_sessions WHERE user_id = ? AND coach_id = ? AND status = 'attended'").get(userId, coachId),
};

export const eventRegs = {
  byEventUser: (eventId: number, userId: number) => db.query('SELECT * FROM event_regs WHERE event_id = ? AND user_id = ?').get(eventId, userId) as EventRegRow | null,
  forEvent: (eventId: number) => db.query("SELECT * FROM event_regs WHERE event_id = ? AND status != 'cancelled' ORDER BY id").all(eventId) as EventRegRow[],
  count: (eventId: number) => (db.query("SELECT COUNT(*) AS n FROM event_regs WHERE event_id = ? AND status = 'going'").get(eventId) as { n: number }).n,
  forUser: (userId: number) => db.query("SELECT * FROM event_regs WHERE user_id = ? AND status != 'cancelled' ORDER BY id DESC").all(userId) as EventRegRow[],
  nextBib: (eventId: number) => 1001 + (db.query('SELECT COUNT(*) AS n FROM event_regs WHERE event_id = ? AND bib IS NOT NULL').get(eventId) as { n: number }).n,
  upsert: (r: { eventId: number; userId: number; category: string | null; bib: number | null; paid: number; status: 'going' | 'maybe' }) => {
    db.run(
      `INSERT INTO event_regs (event_id, user_id, category, bib, paid, status, created_at) VALUES (?,?,?,?,?,?,?)
       ON CONFLICT(event_id, user_id) DO UPDATE SET category = excluded.category, bib = COALESCE(event_regs.bib, excluded.bib), paid = excluded.paid, status = excluded.status`,
      [r.eventId, r.userId, r.category, r.bib, r.paid, r.status, Date.now()]
    );
    return eventRegs.byEventUser(r.eventId, r.userId)!;
  },
  cancel: (eventId: number, userId: number) => db.run("UPDATE event_regs SET status = 'cancelled' WHERE event_id = ? AND user_id = ?", [eventId, userId]),
};

export const customEvents = {
  list: () => db.query('SELECT * FROM events_custom ORDER BY id').all() as { id: number; host_id: number; data: string; created_at: number }[],
  add: (hostId: number, data: unknown) => 100_000 + Number(db.run('INSERT INTO events_custom (host_id, data, created_at) VALUES (?,?,?)', [hostId, JSON.stringify(data), Date.now()]).lastInsertRowid),
};
