import { db } from '../db/connection';
import type { GiftCardRow, KarmaTxRow, PassRow, SubscriptionRow, WalletTxRow } from '../db/rows';
import { HttpError } from '../lib/http';

export const wallet = {
  balance: (userId: number) => (db.query('SELECT wallet FROM users WHERE id = ?').get(userId) as { wallet: number }).wallet,

  transactions: (userId: number, limit = 40) =>
    db.query('SELECT * FROM wallet_tx WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit) as WalletTxRow[],

  /** Adds (or takes, if negative) money and records it. Refuses to go below zero. Returns the new balance. */
  adjust: (userId: number, amount: number, kind: string, note: string) => {
    const tx = db.transaction(() => {
      const before = wallet.balance(userId);
      if (before + amount < 0) throw new HttpError(402, 'Not enough money in your wallet');
      db.run('UPDATE users SET wallet = wallet + ? WHERE id = ?', [amount, userId]);
      db.run('INSERT INTO wallet_tx (user_id, amount, kind, note, created_at) VALUES (?,?,?,?,?)', [userId, amount, kind, note, Date.now()]);
      return before + amount;
    });
    return tx();
  },
};

export const karma = {
  balance: (userId: number) => (db.query('SELECT COALESCE(SUM(points), 0) AS n FROM karma_tx WHERE user_id = ?').get(userId) as { n: number }).n,
  history: (userId: number, limit = 40) => db.query('SELECT * FROM karma_tx WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit) as KarmaTxRow[],
  add: (userId: number, points: number, kind: string, note: string, ref: string | null = null) =>
    db.run('INSERT INTO karma_tx (user_id, points, kind, note, ref, created_at) VALUES (?,?,?,?,?,?)', [userId, points, kind, note, ref, Date.now()]),
  earnedFor: (userId: number, ref: string) =>
    (db.query("SELECT COALESCE(SUM(points), 0) AS n FROM karma_tx WHERE user_id = ? AND ref = ? AND points > 0 AND kind != 'refund'").get(userId, ref) as { n: number }).n,
};

export const subscriptions = {
  latest: (userId: number) => db.query('SELECT * FROM subscriptions WHERE user_id = ? ORDER BY id DESC LIMIT 1').get(userId) as SubscriptionRow | null,
  create: (userId: number, plan: 'monthly' | 'yearly', renewsAt: number, paid: number) =>
    db.run('INSERT INTO subscriptions (user_id, plan, started_at, renews_at, paid) VALUES (?,?,?,?,?)', [userId, plan, Date.now(), renewsAt, paid]),
  extend: (id: number, renewsAt: number, plan: 'monthly' | 'yearly', paid: number) =>
    db.run('UPDATE subscriptions SET renews_at = ?, plan = ?, paid = ?, cancelled_at = NULL WHERE id = ?', [renewsAt, plan, paid, id]),
  cancel: (id: number) => db.run('UPDATE subscriptions SET cancelled_at = ? WHERE id = ?', [Date.now(), id]),
};

export const passes = {
  byId: (id: number) => db.query('SELECT * FROM venue_passes WHERE id = ?').get(id) as PassRow | null,
  forUser: (userId: number) => db.query('SELECT * FROM venue_passes WHERE user_id = ? ORDER BY id DESC').all(userId) as PassRow[],
  create: (p: { userId: number; venueId: number; kind: 'daily' | 'monthly'; validDate: string | null; hours: number; validUntil: number; paid: number }) => {
    const res = db.run(
      'INSERT INTO venue_passes (user_id, venue_id, kind, valid_date, hours_total, hours_left, valid_until, paid, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [p.userId, p.venueId, p.kind, p.validDate, p.hours, p.hours, p.validUntil, p.paid, Date.now()]
    );
    return passes.byId(Number(res.lastInsertRowid))!;
  },
  addHours: (id: number, delta: number) => db.run('UPDATE venue_passes SET hours_left = hours_left + ? WHERE id = ?', [delta, id]),
};

export const giftCards = {
  byCode: (code: string) => db.query('SELECT * FROM gift_cards WHERE code = ?').get(code.trim().toUpperCase()) as GiftCardRow | null,
  create: (g: { code: string; amount: number; buyerId: number; recipientId: number | null; message: string; expiresAt: number }) =>
    db.run('INSERT INTO gift_cards (code, amount, buyer_id, recipient_id, message, created_at, expires_at) VALUES (?,?,?,?,?,?,?)', [g.code, g.amount, g.buyerId, g.recipientId, g.message, Date.now(), g.expiresAt]),
  bought: (userId: number) => db.query('SELECT * FROM gift_cards WHERE buyer_id = ? ORDER BY created_at DESC').all(userId) as GiftCardRow[],
  received: (userId: number) => db.query('SELECT * FROM gift_cards WHERE recipient_id = ? ORDER BY created_at DESC').all(userId) as GiftCardRow[],
  redeem: (code: string, userId: number) => db.run('UPDATE gift_cards SET redeemed_by = ?, redeemed_at = ? WHERE code = ? AND redeemed_by IS NULL', [userId, Date.now(), code]).changes > 0,
};

export const tournamentRegs = {
  has: (tournamentId: number, userId: number) => !!db.query('SELECT 1 FROM tournament_regs WHERE tournament_id = ? AND user_id = ?').get(tournamentId, userId),
  count: (tournamentId: number) => (db.query('SELECT COUNT(*) AS n FROM tournament_regs WHERE tournament_id = ?').get(tournamentId) as { n: number }).n,
  add: (tournamentId: number, userId: number, paid: number) =>
    db.run('INSERT INTO tournament_regs (tournament_id, user_id, paid, created_at) VALUES (?,?,?,?)', [tournamentId, userId, paid, Date.now()]),
};

export const coachEnquiries = {
  add: (coachId: number, userId: number, message: string) =>
    db.run('INSERT INTO coach_enquiries (coach_id, user_id, message, created_at) VALUES (?,?,?,?)', [coachId, userId, message, Date.now()]),
};
