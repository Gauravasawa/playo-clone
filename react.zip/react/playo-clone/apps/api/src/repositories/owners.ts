import { db } from '../db/connection';

export interface OverrideRow { venue_id: number; price_inr: number | null; peak_extra: number | null }
export interface CustomVenueRow { id: number; owner_id: number; data: string }

export const owners = {
  ownerOf: (venueId: number) => (db.query('SELECT owner_id FROM venue_owners WHERE venue_id = ?').get(venueId) as { owner_id: number } | null)?.owner_id ?? null,
  allOwners: () => new Map((db.query('SELECT venue_id, owner_id FROM venue_owners').all() as { venue_id: number; owner_id: number }[]).map((r) => [r.venue_id, r.owner_id])),
  venuesOf: (ownerId: number) => (db.query('SELECT venue_id FROM venue_owners WHERE owner_id = ?').all(ownerId) as { venue_id: number }[]).map((r) => r.venue_id),
  claim: (venueId: number, ownerId: number) => db.run('INSERT OR IGNORE INTO venue_owners (venue_id, owner_id) VALUES (?,?)', [venueId, ownerId]).changes > 0,
  release: (venueId: number) => db.run('DELETE FROM venue_owners WHERE venue_id = ?', [venueId]),

  overrides: () => db.query('SELECT * FROM venue_overrides').all() as OverrideRow[],
  setOverride: (venueId: number, priceInr: number | null, peakExtra: number | null) =>
    db.run('INSERT INTO venue_overrides (venue_id, price_inr, peak_extra) VALUES (?,?,?) ON CONFLICT(venue_id) DO UPDATE SET price_inr = excluded.price_inr, peak_extra = excluded.peak_extra', [venueId, priceInr, peakExtra]),

  blockedFor: (venueId: number, date: string) => (db.query('SELECT time FROM blocked_slots WHERE venue_id = ? AND date = ?').all(venueId, date) as { time: string }[]).map((r) => r.time),
  block: (venueId: number, date: string, time: string) => db.run('INSERT OR IGNORE INTO blocked_slots (venue_id, date, time) VALUES (?,?,?)', [venueId, date, time]),
  unblock: (venueId: number, date: string, time: string) => db.run('DELETE FROM blocked_slots WHERE venue_id = ? AND date = ? AND time = ?', [venueId, date, time]),
  isBlocked: (venueId: number, date: string, time: string) => !!db.query('SELECT 1 FROM blocked_slots WHERE venue_id = ? AND date = ? AND time = ?').get(venueId, date, time),

  customVenues: () => db.query('SELECT * FROM custom_venues ORDER BY id').all() as CustomVenueRow[],
  addCustom: (ownerId: number, data: unknown) => {
    const res = db.run('INSERT INTO custom_venues (owner_id, data) VALUES (?, ?)', [ownerId, JSON.stringify(data)]);
    const id = 100_000 + Number(res.lastInsertRowid);
    owners.claim(id, ownerId);
    return id;
  },

  reply: (reviewId: number) => db.query('SELECT * FROM review_replies WHERE review_id = ?').get(reviewId) as { review_id: number; owner_id: number; body: string; created_at: number } | null,
  setReply: (reviewId: number, ownerId: number, body: string) =>
    db.run('INSERT INTO review_replies (review_id, owner_id, body, created_at) VALUES (?,?,?,?) ON CONFLICT(review_id) DO UPDATE SET body = excluded.body, created_at = excluded.created_at', [reviewId, ownerId, body, Date.now()]),
};
