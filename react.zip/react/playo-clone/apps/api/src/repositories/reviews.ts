import { db } from '../db/connection';
import type { ReviewRow } from '../db/rows';

export const reviews = {
  /** One review per author per target (and per game, for players). Returns false if it already exists. */
  add: (r: { kind: 'venue' | 'player' | 'coach'; targetId: number; authorId: number; rating: number; body: string; contextId?: number }) => {
    try {
      db.run('INSERT INTO reviews (kind, target_id, author_id, rating, body, context_id, created_at) VALUES (?,?,?,?,?,?,?)', [
        r.kind, r.targetId, r.authorId, r.rating, r.body, r.contextId ?? 0, Date.now(),
      ]);
      return true;
    } catch {
      return false;
    }
  },
  forTarget: (kind: 'venue' | 'player' | 'coach', targetId: number) =>
    db.query('SELECT * FROM reviews WHERE kind = ? AND target_id = ? ORDER BY id DESC LIMIT 50').all(kind, targetId) as ReviewRow[],
  hasReviewed: (kind: 'venue' | 'player' | 'coach', targetId: number, authorId: number, contextId = 0) =>
    !!db.query('SELECT 1 FROM reviews WHERE kind = ? AND target_id = ? AND author_id = ? AND context_id = ?').get(kind, targetId, authorId, contextId),
  countByAuthor: (authorId: number) => (db.query('SELECT COUNT(*) AS n FROM reviews WHERE author_id = ?').get(authorId) as { n: number }).n,
};
