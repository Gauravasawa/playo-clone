import { db } from '../db/connection';
import type { ReportRow } from '../db/rows';

export const blocks = {
  add: (blocker: number, blocked: number) => db.run('INSERT OR IGNORE INTO blocks (blocker_id, blocked_id, created_at) VALUES (?,?,?)', [blocker, blocked, Date.now()]),
  remove: (blocker: number, blocked: number) => db.run('DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?', [blocker, blocked]).changes > 0,
  /** Is there a block between these two, in either direction? */
  either: (a: number, b: number) => !!db.query('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)').get(a, b, b, a),
  byMe: (blocker: number, blocked: number) => !!db.query('SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ?').get(blocker, blocked),
  blockedBy: (blocker: number) => (db.query('SELECT blocked_id AS id FROM blocks WHERE blocker_id = ? ORDER BY created_at DESC').all(blocker) as { id: number }[]).map((r) => r.id),
  /** Everyone this person can't see or be seen by: those they blocked, and those who blocked them */
  hiddenFrom: (userId: number) =>
    new Set((db.query('SELECT blocked_id AS id FROM blocks WHERE blocker_id = ? UNION SELECT blocker_id AS id FROM blocks WHERE blocked_id = ?').all(userId, userId) as { id: number }[]).map((r) => r.id)),
};

export const reports = {
  create: (r: { reporterId: number; kind: string; targetId: number; reason: string; details: string }) => {
    const res = db.run('INSERT INTO reports (reporter_id, kind, target_id, reason, details, status, created_at) VALUES (?,?,?,?,?,?,?)', [r.reporterId, r.kind, r.targetId, r.reason, r.details, 'open', Date.now()]);
    return reports.byId(Number(res.lastInsertRowid))!;
  },
  byId: (id: number) => db.query('SELECT * FROM reports WHERE id = ?').get(id) as ReportRow | null,
  list: (status: string | null) => db.query('SELECT * FROM reports WHERE (? IS NULL OR status = ?) ORDER BY id DESC LIMIT 200').all(status, status) as ReportRow[],
  setStatus: (id: number, status: ReportRow['status']) => db.run('UPDATE reports SET status = ? WHERE id = ?', [status, id]),
  alreadyReported: (reporterId: number, kind: string, targetId: number) => !!db.query("SELECT 1 FROM reports WHERE reporter_id = ? AND kind = ? AND target_id = ? AND status = 'open'").get(reporterId, kind, targetId),
};
