import { db } from '../db/connection';
import type { FollowRow, FriendshipRow, NotificationRow } from '../db/rows';

export const friendships = {
  /** The row between two users, whoever asked */
  between: (a: number, b: number) =>
    db.query('SELECT * FROM friendships WHERE (requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?)').get(a, b, b, a) as FriendshipRow | null,
  byId: (id: number) => db.query('SELECT * FROM friendships WHERE id = ?').get(id) as FriendshipRow | null,
  request: (from: number, to: number) => {
    const res = db.run('INSERT INTO friendships (requester_id, addressee_id, status, created_at) VALUES (?,?,?,?)', [from, to, 'pending', Date.now()]);
    return friendships.byId(Number(res.lastInsertRowid))!;
  },
  accept: (id: number) => db.run("UPDATE friendships SET status = 'accepted' WHERE id = ?", [id]),
  remove: (id: number) => db.run('DELETE FROM friendships WHERE id = ?', [id]),
  /** Ids of accepted friends */
  friendIds: (userId: number) =>
    (db.query("SELECT CASE WHEN requester_id = ? THEN addressee_id ELSE requester_id END AS other FROM friendships WHERE status = 'accepted' AND (requester_id = ? OR addressee_id = ?)").all(userId, userId, userId) as { other: number }[]).map((r) => r.other),
  incoming: (userId: number) => db.query("SELECT * FROM friendships WHERE addressee_id = ? AND status = 'pending' ORDER BY id DESC").all(userId) as FriendshipRow[],
  outgoing: (userId: number) => db.query("SELECT * FROM friendships WHERE requester_id = ? AND status = 'pending' ORDER BY id DESC").all(userId) as FriendshipRow[],
};

export const follows = {
  get: (follower: number, followee: number) =>
    db.query('SELECT * FROM follows WHERE follower_id = ? AND followee_id = ?').get(follower, followee) as FollowRow | null,
  create: (follower: number, followee: number, status: 'pending' | 'accepted') =>
    db.run('INSERT OR REPLACE INTO follows (follower_id, followee_id, status, created_at) VALUES (?,?,?,?)', [follower, followee, status, Date.now()]),
  accept: (follower: number, followee: number) =>
    db.run("UPDATE follows SET status = 'accepted' WHERE follower_id = ? AND followee_id = ?", [follower, followee]),
  remove: (follower: number, followee: number) => db.run('DELETE FROM follows WHERE follower_id = ? AND followee_id = ?', [follower, followee]),
  followerIds: (userId: number) =>
    (db.query("SELECT follower_id AS id FROM follows WHERE followee_id = ? AND status = 'accepted' ORDER BY created_at DESC").all(userId) as { id: number }[]).map((r) => r.id),
  followingIds: (userId: number) =>
    (db.query("SELECT followee_id AS id FROM follows WHERE follower_id = ? AND status = 'accepted' ORDER BY created_at DESC").all(userId) as { id: number }[]).map((r) => r.id),
  pendingFor: (userId: number) => db.query("SELECT * FROM follows WHERE followee_id = ? AND status = 'pending' ORDER BY created_at DESC").all(userId) as FollowRow[],
};

export const notifications = {
  create: (userId: number, type: string, data: unknown) => {
    const res = db.run('INSERT INTO notifications (user_id, type, data, read, created_at) VALUES (?,?,?,0,?)', [userId, type, JSON.stringify(data), Date.now()]);
    return db.query('SELECT * FROM notifications WHERE id = ?').get(Number(res.lastInsertRowid)) as NotificationRow;
  },
  page: (userId: number, page: number, limit: number) =>
    db.query('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?').all(userId, limit, (page - 1) * limit) as NotificationRow[],
  total: (userId: number) => (db.query('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ?').get(userId) as { n: number }).n,
  unread: (userId: number) => (db.query('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read = 0').get(userId) as { n: number }).n,
  markRead: (userId: number, ids?: number[]) => {
    if (!ids) return db.run('UPDATE notifications SET read = 1 WHERE user_id = ?', [userId]);
    for (const id of ids) db.run('UPDATE notifications SET read = 1 WHERE user_id = ? AND id = ?', [userId, id]);
  },
};
