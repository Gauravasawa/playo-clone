import { db } from '../db/connection';
import type { TicketMessageRow, TicketRow } from '../db/rows';

export const tickets = {
  byId: (id: number) => db.query('SELECT * FROM support_tickets WHERE id = ?').get(id) as TicketRow | null,
  forUser: (userId: number) => db.query('SELECT * FROM support_tickets WHERE user_id = ? ORDER BY updated_at DESC').all(userId) as TicketRow[],
  create: (t: { userId: number; topic: string; subject: string; bookingId: number | null }) => {
    const now = Date.now();
    const res = db.run('INSERT INTO support_tickets (user_id, topic, subject, booking_id, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?)', [t.userId, t.topic, t.subject, t.bookingId, 'open', now, now]);
    return tickets.byId(Number(res.lastInsertRowid))!;
  },
  setStatus: (id: number, status: TicketRow['status']) => db.run('UPDATE support_tickets SET status = ?, updated_at = ? WHERE id = ?', [status, Date.now(), id]),
  messages: (ticketId: number) => db.query('SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY id').all(ticketId) as TicketMessageRow[],
  addMessage: (ticketId: number, sender: 'user' | 'agent', body: string) => {
    const res = db.run('INSERT INTO ticket_messages (ticket_id, sender, body, created_at) VALUES (?,?,?,?)', [ticketId, sender, body, Date.now()]);
    db.run('UPDATE support_tickets SET updated_at = ? WHERE id = ?', [Date.now(), ticketId]);
    return db.query('SELECT * FROM ticket_messages WHERE id = ?').get(Number(res.lastInsertRowid)) as TicketMessageRow;
  },
  last: (ticketId: number) => db.query('SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY id DESC LIMIT 1').get(ticketId) as TicketMessageRow | null,
};
