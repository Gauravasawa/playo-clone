import { db } from '../db/connection';
import type { UserRow } from '../db/rows';

export interface Plays { days: ('weekday' | 'weekend')[]; times: ('morning' | 'evening')[] }

export interface NewUser {
  phone: string; name: string; username?: string; city?: string; emoji?: string; color?: string;
  isPrivate?: boolean; bio?: string; isBot?: boolean; wallet?: number; plays?: Plays; isAdmin?: boolean; referredBy?: number | null;
}

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 20) || 'player';
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export const users = {
  byId: (id: number) => db.query('SELECT * FROM users WHERE id = ?').get(id) as UserRow | null,
  byPhone: (phone: string) => db.query('SELECT * FROM users WHERE phone = ?').get(phone) as UserRow | null,
  byUsername: (username: string) => db.query('SELECT * FROM users WHERE username = ?').get(username) as UserRow | null,
  byReferralCode: (code: string) => db.query('SELECT * FROM users WHERE referral_code = ?').get(code.trim().toUpperCase()) as UserRow | null,
  bots: () => db.query('SELECT * FROM users WHERE is_bot = 1 AND is_admin = 0 ORDER BY id').all() as UserRow[],
  admins: () => db.query('SELECT * FROM users WHERE is_admin = 1').all() as UserRow[],
  all: () => db.query('SELECT * FROM users ORDER BY id').all() as UserRow[],
  count: () => (db.query('SELECT COUNT(*) AS n FROM users').get() as { n: number }).n,

  byToken: (token: string) =>
    db.query('SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?').get(token) as UserRow | null,

  /** A username nobody has yet: `name`, then `name_2`, `name_3`... */
  freeUsername: (wanted: string) => {
    const base = slug(wanted);
    let candidate = base;
    for (let n = 2; users.byUsername(candidate); n++) candidate = `${base}_${n}`;
    return candidate;
  },

  freeReferralCode: () => {
    for (;;) {
      const code = Array.from({ length: 6 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join('');
      if (!users.byReferralCode(code)) return code;
    }
  },

  create: (u: NewUser) => {
    const username = users.freeUsername(u.username ?? u.name);
    db.run(
      `INSERT INTO users (phone, name, username, bio, city, avatar_emoji, avatar_color, is_private, wallet, is_bot, created_at, plays, referral_code, referred_by, is_admin)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        u.phone, u.name, username, u.bio ?? '', u.city ?? 'Bengaluru', u.emoji ?? '🙂', u.color ?? '#00b259', u.isPrivate ? 1 : 0, u.wallet ?? 0,
        u.isBot ? 1 : 0, Date.now(), JSON.stringify(u.plays ?? { days: [], times: [] }), users.freeReferralCode(), u.referredBy ?? null, u.isAdmin ? 1 : 0,
      ]
    );
    return users.byPhone(u.phone)!;
  },

  startSession: (userId: number) => {
    const token = crypto.randomUUID();
    db.run('INSERT INTO sessions (token, user_id) VALUES (?, ?)', [token, userId]);
    return token;
  },

  setFavorites: (userId: number, favorites: number[]) =>
    db.run('UPDATE users SET favorites = ? WHERE id = ?', [JSON.stringify(favorites), userId]),

  setLoginDay: (userId: number, day: string) => db.run('UPDATE users SET last_login_day = ? WHERE id = ?', [day, userId]),
  markReferralRewarded: (userId: number) => db.run('UPDATE users SET referral_rewarded = 1 WHERE id = ?', [userId]),
  referredBy: (referrerId: number) => db.query('SELECT * FROM users WHERE referred_by = ? ORDER BY id DESC').all(referrerId) as UserRow[],

  updateProfile: (id: number, p: { name: string; username: string; bio: string; city: string; avatarEmoji: string; avatarColor: string; isPrivate: boolean; plays: Plays }) =>
    db.run('UPDATE users SET name = ?, username = ?, bio = ?, city = ?, avatar_emoji = ?, avatar_color = ?, is_private = ?, plays = ? WHERE id = ?', [
      p.name, p.username, p.bio, p.city, p.avatarEmoji, p.avatarColor, p.isPrivate ? 1 : 0, JSON.stringify(p.plays), id,
    ]),

  search: (q: string, excludeId: number, limit = 20) => {
    const like = `%${q.toLowerCase()}%`;
    return db
      .query('SELECT * FROM users WHERE id != ? AND is_admin = 0 AND (LOWER(name) LIKE ? OR username LIKE ?) ORDER BY is_bot DESC, name LIMIT ?')
      .all(excludeId, like, like, limit) as UserRow[];
  },

  sports: (userId: number) => db.query('SELECT sport, level FROM user_sports WHERE user_id = ?').all(userId) as { sport: string; level: string }[],

  setSports: (userId: number, sports: { sport: string; level: string }[]) => {
    db.run('DELETE FROM user_sports WHERE user_id = ?', [userId]);
    for (const s of sports) db.run('INSERT OR REPLACE INTO user_sports (user_id, sport, level) VALUES (?,?,?)', [userId, s.sport, s.level]);
  },
};

export const playsOf = (u: UserRow): Plays => {
  try {
    return JSON.parse(u.plays) as Plays;
  } catch {
    return { days: [], times: [] };
  }
};
