import { CITY_INFO } from '../data/currency';
import { SPORTS } from '../data/sports';
import type { UserRow } from '../db/rows';
import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser } from '../middleware';
import { chats } from '../repositories/chats';
import { karma } from '../repositories/money';
import { notifications } from '../repositories/social';
import { playsOf, users, type Plays } from '../repositories/users';
import { dailyKarma } from '../services/karma';
import { plusStatus } from '../services/membership';
import { onboardUser } from '../services/onboarding';
import { localDay } from '../services/passes';
import { SKILL_LEVELS } from '../services/people';
import { otp } from '../services/providers';
import { referrerFor, rewardNewcomer } from '../services/referral';
import { filterText } from '../services/safety';

export const auth = new Router();

/** The signed-in user's own view of themselves */
export const meOut = (u: UserRow) => ({
  id: u.id, name: u.name, username: u.username, phone: u.phone, bio: u.bio, city: u.city,
  avatarEmoji: u.avatar_emoji, avatarColor: u.avatar_color, isPrivate: u.is_private === 1,
  wallet: u.wallet, karma: karma.balance(u.id), plus: plusStatus(u.id), referralCode: u.referral_code, isAdmin: u.is_admin === 1,
  plays: playsOf(u), favorites: JSON.parse(u.favorites) as number[], sports: users.sports(u.id),
});

auth.post('/api/auth/login', async ({ req }) => {
  const body = await readJson<{ phone: string; name: string; otp: string; referral: string }>(req);
  if (!body.phone || !/^\d{10}$/.test(body.phone)) throw new HttpError(400, 'Enter a 10 digit phone number');
  otp.verify(body.phone, body.otp ?? '');

  let user = users.byPhone(body.phone);
  const isNew = !user;
  if (!user) {
    const referrer = referrerFor(body.referral);
    if (body.referral?.trim() && !referrer) throw new HttpError(400, 'That referral code is not valid');
    const name = body.name?.trim() || `Player ${body.phone.slice(-4)}`;
    user = users.create({ phone: body.phone, name, username: name, referredBy: referrer?.id ?? null });
    onboardUser(user);
    rewardNewcomer(user);
  }
  if (!isNew) dailyKarma(user.id, localDay(), user.last_login_day, (d) => users.setLoginDay(user!.id, d));
  else users.setLoginDay(user.id, localDay());
  return json({ token: users.startSession(user.id) });
});

auth.get('/api/me', (ctx) => json(meOut(requireUser(ctx))));

auth.put('/api/favorites', async (ctx) => {
  const user = requireUser(ctx);
  const body = await readJson<{ favorites: number[] }>(ctx.req);
  if (!Array.isArray(body.favorites)) throw new HttpError(400, 'favorites must be a list of venue ids');
  users.setFavorites(user.id, body.favorites);
  return json({ ok: true });
});

auth.put('/api/me/profile', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{
    name: string; username: string; bio: string; city: string; avatarEmoji: string; avatarColor: string; isPrivate: boolean;
    sports: { sport: string; level: string }[]; plays: Plays;
  }>(ctx.req);

  const name = b.name?.trim() ?? '';
  const username = b.username?.trim().toLowerCase() ?? '';
  if (name.length < 2 || name.length > 40) throw new HttpError(400, 'Name must be 2 to 40 characters');
  if (!/^[a-z0-9_]{3,20}$/.test(username)) throw new HttpError(400, 'Username: 3 to 20 letters, numbers or _');
  const taken = users.byUsername(username);
  if (taken && taken.id !== user.id) throw new HttpError(409, 'That username is taken');
  if ((b.bio ?? '').length > 160) throw new HttpError(400, 'Bio is at most 160 characters');
  if (!b.city || !CITY_INFO[b.city]) throw new HttpError(400, 'Pick a city from the list');
  if (!b.avatarEmoji || b.avatarEmoji.length > 8) throw new HttpError(400, 'Pick an emoji');
  if (!/^#[0-9a-fA-F]{6}$/.test(b.avatarColor ?? '')) throw new HttpError(400, 'Pick a colour');
  const sports = (b.sports ?? []).filter((s) => SPORTS.some((x) => x.id === s.sport) && SKILL_LEVELS.includes(s.level));
  const plays: Plays = {
    days: (b.plays?.days ?? []).filter((d) => d === 'weekday' || d === 'weekend'),
    times: (b.plays?.times ?? []).filter((t) => t === 'morning' || t === 'evening'),
  };

  users.updateProfile(user.id, { name, username, bio: filterText(b.bio ?? ''), city: b.city!, avatarEmoji: b.avatarEmoji!, avatarColor: b.avatarColor!, isPrivate: !!b.isPrivate, plays });
  users.setSports(user.id, sports);
  return json(meOut(users.byId(user.id)!));
});

/** Small numbers for the header: unread notifications and unread chats */
auth.get('/api/badges', (ctx) => {
  const user = requireUser(ctx);
  return json({
    notifications: notifications.unread(user.id),
    chats: chats.forUser(user.id).reduce((sum, c) => sum + chats.unread(c.id, user.id), 0),
  });
});
