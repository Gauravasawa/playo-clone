import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser, wantsDecline } from '../middleware';
import { bookings } from '../repositories/bookings';
import { catalog } from '../services/catalog';
import { assertSlotsFree, bookingOut, cancelBooking, createBooking, rescheduleBooking } from '../services/bookings';
import { quoteBooking } from '../services/pricing';

export const bookingRoutes = new Router();

interface BookingBody {
  venueId: number; date: string; slots: string[]; sport: string; method: string; coupon: string;
  extras: string[]; karmaPoints: number; passId: number | null;
}

bookingRoutes.get('/api/bookings', (ctx) => {
  const user = requireUser(ctx);
  return json(bookings.forUser(user.id).map((b) => bookingOut(b, user.id)));
});

/** The authoritative price: the browser shows its own calculation while you pick, and checks it against this */
bookingRoutes.post('/api/bookings/quote', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<BookingBody>(ctx.req);
  if (!b.venueId || !b.date || !b.slots?.length) throw new HttpError(400, 'Pick a venue and at least one slot');
  const venue = catalog.find(b.venueId);
  if (!venue) throw new HttpError(404, 'Venue not found');
  assertSlotsFree(venue, b.date, b.slots);
  return json(quoteBooking({ userId: user.id, venueId: b.venueId, date: b.date, slots: b.slots, extras: b.extras, coupon: b.coupon, karmaPoints: b.karmaPoints, passId: b.passId }));
});

bookingRoutes.post('/api/bookings', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<BookingBody>(ctx.req);
  const booking = createBooking({
    userId: user.id, venueId: b.venueId as number, date: b.date as string, slots: b.slots as string[], sport: b.sport, method: b.method, extras: b.extras,
    coupon: b.coupon, karmaPoints: b.karmaPoints, passId: b.passId, simulateDecline: wantsDecline(ctx),
  });
  return json(bookingOut(booking, user.id), 201);
});

bookingRoutes.delete('/api/bookings/:id', (ctx) => {
  const user = requireUser(ctx);
  return json({ ok: true, ...cancelBooking(user.id, Number(ctx.params.id)) });
});

bookingRoutes.post('/api/bookings/:id/reschedule', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ date: string; slots: string[] }>(ctx.req);
  const moved = rescheduleBooking(user.id, Number(ctx.params.id), b.date as string, b.slots as string[], wantsDecline(ctx));
  return json(bookingOut(moved, user.id));
});

/** Demo: mark a booking as attended (a real app would do this after the slot passes), which unlocks the venue review */
bookingRoutes.post('/api/bookings/:id/attend', (ctx) => {
  const user = requireUser(ctx);
  const booking = bookings.byId(Number(ctx.params.id));
  if (!booking || booking.user_id !== user.id) throw new HttpError(404, 'Booking not found');
  bookings.markAttended(booking.id);
  return json(bookingOut(bookings.byId(booking.id)!, user.id));
});
