import { CITY_INFO, CURRENCIES, distanceKm } from '../data/currency';
import { SPORTS } from '../data/sports';
import { ALL_AMENITIES, hourOf, slotLabel, slotPrice, slotStart, takenByOthers } from '../data/venues';
import { HttpError, json } from '../lib/http';
import { Router } from '../lib/router';
import { bookings } from '../repositories/bookings';
import { owners } from '../repositories/owners';
import { catalog, type CatalogVenue } from '../services/catalog';
import { passesInfoFor } from '../services/passes';

export const catalogRoutes = new Router();

catalogRoutes.get('/api/health', () => json({ ok: true }));
catalogRoutes.get('/api/meta', () =>
  json({
    cities: Object.entries(CITY_INFO).map(([name, i]) => ({ name, ...i })),
    currencies: CURRENCIES,
    amenities: ALL_AMENITIES,
  })
);
catalogRoutes.get('/api/sports', () => json(SPORTS));

/** What the list and map need of a venue (not the heavy detail) */
const card = (v: CatalogVenue, near: { lat: number; lng: number } | null) => ({
  ...v,
  distanceKm: near ? Math.round(distanceKm(near, v) * 10) / 10 : null,
});

catalogRoutes.get('/api/venues', ({ url }) => {
  const q = url.searchParams;
  const city = q.get('city'), sport = q.get('sport'), text = q.get('q')?.toLowerCase();
  const sort = q.get('sort') ?? 'rating';
  const page = Math.max(1, Number(q.get('page') ?? 1));
  const limit = Math.min(60, Number(q.get('limit') ?? 6));
  const amenities = (q.get('amenities') ?? '').split(',').filter(Boolean);
  const minPrice = q.get('minPrice') ? Number(q.get('minPrice')) : null;
  const maxPrice = q.get('maxPrice') ? Number(q.get('maxPrice')) : null;
  const maxKm = q.get('maxKm') ? Number(q.get('maxKm')) : null;
  const lat = q.get('lat'), lng = q.get('lng');
  const near = lat && lng ? { lat: Number(lat), lng: Number(lng) } : sort === 'distance' || maxKm ? (city && CITY_INFO[city] ? CITY_INFO[city] : null) : null;

  let list = catalog.list().filter(
    (v) =>
      (!city || v.city === city) &&
      (!sport || sport === 'all' || v.sports.includes(sport)) &&
      (!text || `${v.name} ${v.area}`.toLowerCase().includes(text)) &&
      amenities.every((a) => v.amenities.includes(a)) &&
      (minPrice === null || v.pricePerHour >= minPrice) &&
      (maxPrice === null || v.pricePerHour <= maxPrice)
  );
  let withDistance = list.map((v) => card(v, near));
  if (maxKm !== null) withDistance = withDistance.filter((v) => v.distanceKm !== null && v.distanceKm <= maxKm);
  withDistance.sort((a, b) =>
    sort === 'price' ? a.pricePerHour - b.pricePerHour : sort === 'distance' ? (a.distanceKm ?? 0) - (b.distanceKm ?? 0) : b.rating - a.rating
  );
  list = withDistance;
  const items = withDistance.slice((page - 1) * limit, page * limit);
  return json({ items, page, total: withDistance.length, nextPage: page * limit < withDistance.length ? page + 1 : null });
});

catalogRoutes.get('/api/venues/:id', ({ params }) => {
  const venue = catalog.find(Number(params.id));
  if (!venue) throw new HttpError(404, 'Venue not found');
  return json({ ...venue, passes: passesInfoFor(venue) });
});

catalogRoutes.get('/api/venues/:id/slots', ({ params, url }) => {
  const venue = catalog.find(Number(params.id));
  const date = url.searchParams.get('date');
  if (!venue || !date) throw new HttpError(400, 'venue and date required');
  const mine = new Set(bookings.takenSlots(venue.id, date));
  const blocked = new Set(owners.blockedFor(venue.id, date));
  const now = Date.now();
  const slots = [];
  for (let hour = 6; hour < 23; hour++) {
    const time = slotLabel(hour);
    const reason = slotStart(date, time).getTime() <= now ? 'past' : blocked.has(time) ? 'blocked' : mine.has(time) || takenByOthers(venue.id, date, hour) ? 'taken' : null;
    slots.push({ time, price: slotPrice(venue, hour), available: reason === null, reason });
  }
  return json(slots);
});

void hourOf;
