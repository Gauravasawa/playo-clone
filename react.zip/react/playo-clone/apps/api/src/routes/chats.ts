import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser } from '../middleware';
import { hub } from '../realtime/hub';
import { chats } from '../repositories/chats';
import { friendships } from '../repositories/social';
import { blocks } from '../repositories/safety';
import { filterText } from '../services/safety';
import { users } from '../repositories/users';
import { botsReactToGroup } from '../services/bots';
import { chatOut, messageOut, pushChat, sendMessage } from '../services/chat';
import { notify } from '../services/notify';
import { summary } from '../services/people';

export const chatRoutes = new Router();

const MAX_IMAGE_CHARS = 1_500_000; // a data URL, about 1.1 MB of picture

function memberChat(userId: number, chatId: string) {
  const chat = chats.byId(Number(chatId));
  if (!chat || !chats.isMember(chat.id, userId)) throw new HttpError(404, 'Chat not found');
  return chat;
}

const isFriend = (a: number, b: number) => friendships.between(a, b)?.status === 'accepted';

chatRoutes.get('/api/chats', (ctx) => {
  const user = requireUser(ctx);
  const hidden = blocks.hiddenFrom(user.id);
  const list = chats
    .forUser(user.id)
    .filter((c) => c.kind !== 'direct' || !chats.memberIds(c.id).some((id) => hidden.has(id)))
    .map((c) => chatOut(c, user.id));
  list.sort((a, b) => (b.lastMessage?.createdAt ?? 0) - (a.lastMessage?.createdAt ?? 0) || b.id - a.id);
  return json(list);
});

chatRoutes.post('/api/chats', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ kind: 'direct' | 'group'; userId: number; title: string; memberIds: number[] }>(ctx.req);

  if (b.kind === 'direct') {
    const other = b.userId ? users.byId(b.userId) : null;
    if (!other || other.id === user.id) throw new HttpError(400, 'Pick another player');
    if (blocks.either(user.id, other.id)) throw new HttpError(403, "You can't chat with this player");
    if (!isFriend(user.id, other.id)) throw new HttpError(403, 'You can only chat with friends');
    const existing = chats.direct(user.id, other.id);
    if (existing) return json(chatOut(existing, user.id));
    const chat = chats.create({ kind: 'direct', createdBy: user.id, memberIds: [user.id, other.id] });
    pushChat(chat.id);
    return json(chatOut(chat, user.id), 201);
  }

  if (b.kind === 'group') {
    const title = b.title?.trim();
    const memberIds = [...new Set(b.memberIds ?? [])].filter((id) => id !== user.id);
    if (!title || title.length > 40) throw new HttpError(400, 'Give the group a name (up to 40 characters)');
    if (memberIds.length === 0) throw new HttpError(400, 'Add at least one friend');
    if (memberIds.some((id) => !isFriend(user.id, id))) throw new HttpError(403, 'You can only add friends to a group');
    const chat = chats.create({ kind: 'group', title, createdBy: user.id, memberIds: [user.id, ...memberIds] });
    for (const id of memberIds) notify(id, 'added_to_group', { chatId: chat.id, title, actor: summary(user) });
    pushChat(chat.id);
    botsReactToGroup(chat, user);
    return json(chatOut(chat, user.id), 201);
  }

  throw new HttpError(400, 'kind must be direct or group');
});

chatRoutes.get('/api/chats/:id/messages', (ctx) => {
  const user = requireUser(ctx);
  const chat = memberChat(user.id, ctx.params.id);
  const before = ctx.url.searchParams.get('before');
  const limit = Math.min(50, Number(ctx.url.searchParams.get('limit') ?? 30));
  const items = chats.messages(chat.id, before ? Number(before) : null, limit + 1);
  const hasMore = items.length > limit;
  // messages from people you blocked (in groups) are not shown to you
  const hidden = blocks.hiddenFrom(user.id);
  const shown = (hasMore ? items.slice(1) : items).filter((m) => !hidden.has(m.sender_id));
  return json({ items: shown.map(messageOut), hasMore, reads: chatOut(chat, user.id).reads });
});

chatRoutes.post('/api/chats/:id/messages', async (ctx) => {
  const user = requireUser(ctx);
  const chat = memberChat(user.id, ctx.params.id);
  const b = await readJson<{ body: string; image: string }>(ctx.req);
  const body = filterText((b.body ?? '').trim().slice(0, 2000));
  if (chat.kind === 'direct' && chats.memberIds(chat.id).some((id) => id !== user.id && blocks.either(user.id, id))) throw new HttpError(403, "You can't message this player");
  const image = b.image ?? null;
  if (!body && !image) throw new HttpError(400, 'Write something or attach a picture');
  if (image && (!image.startsWith('data:image/') || image.length > MAX_IMAGE_CHARS)) throw new HttpError(400, 'Pictures must be images under 1 MB');
  return json(sendMessage(chat, user.id, body, image), 201);
});

chatRoutes.post('/api/chats/:id/read', async (ctx) => {
  const user = requireUser(ctx);
  const chat = memberChat(user.id, ctx.params.id);
  const { upTo } = await readJson<{ upTo: number }>(ctx.req);
  if (!upTo) throw new HttpError(400, 'upTo is required');
  chats.setRead(chat.id, user.id, upTo);
  hub.sendToMany(chats.memberIds(chat.id), { type: 'read', chatId: chat.id, userId: user.id, upTo });
  return json({ ok: true });
});

chatRoutes.post('/api/chats/:id/members', async (ctx) => {
  const user = requireUser(ctx);
  const chat = memberChat(user.id, ctx.params.id);
  if (chat.kind !== 'group') throw new HttpError(400, 'Members can only be added to groups');
  const { userIds } = await readJson<{ userIds: number[] }>(ctx.req);
  const ids = [...new Set(userIds ?? [])].filter((id) => !chats.isMember(chat.id, id));
  if (ids.length === 0) throw new HttpError(400, 'Pick friends who are not in the group yet');
  if (ids.some((id) => !isFriend(user.id, id))) throw new HttpError(403, 'You can only add friends to a group');
  for (const id of ids) {
    chats.addMember(chat.id, id);
    notify(id, 'added_to_group', { chatId: chat.id, title: chat.title, actor: summary(user) });
  }
  pushChat(chat.id);
  botsReactToGroup(chat, user);
  return json(chatOut(chat, user.id));
});

chatRoutes.delete('/api/chats/:id/members/:userId', (ctx) => {
  const user = requireUser(ctx);
  const chat = memberChat(user.id, ctx.params.id);
  const target = Number(ctx.params.userId);
  if (chat.kind !== 'group') throw new HttpError(400, 'Leave a game from the game itself');
  if (target !== user.id && chat.created_by !== user.id) throw new HttpError(403, 'Only the group creator can remove others');
  chats.removeMember(chat.id, target);
  pushChat(chat.id, [target]);
  return json({ ok: true });
});
