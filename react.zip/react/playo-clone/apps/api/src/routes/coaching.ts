import { COACHES } from '../data/coaching';
import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser, wantsDecline } from '../middleware';
import { coachEnquiries } from '../repositories/money';
import { findCoach } from '../data/coaching';
import { bookSession, cancelEnrolment, cancelSession, coachCard, coachDetail, enrol, freeHours, learningFor, markAttended, reviewCoach } from '../services/learning';
import { notify } from '../services/notify';
import { enrolments } from '../repositories/learning';

export const coachingRoutes = new Router();

coachingRoutes.get('/api/coaches', ({ url }) => {
  const city = url.searchParams.get('city'), sport = url.searchParams.get('sport');
  const page = Math.max(1, Number(url.searchParams.get('page') ?? 1));
  const limit = Math.min(30, Number(url.searchParams.get('limit') ?? 6));
  const list = COACHES.filter((c) => (!city || c.city === city) && (!sport || sport === 'all' || c.sport === sport)).map(coachCard).sort((a, b) => b.rating - a.rating);
  return json({ items: list.slice((page - 1) * limit, page * limit), page, total: list.length, nextPage: page * limit < list.length ? page + 1 : null });
});

// "My learning": registered before /api/coaches/:id so "learning" isn't taken for an id
coachingRoutes.get('/api/learning', (ctx) => json(learningFor(requireUser(ctx).id)));

coachingRoutes.get('/api/coaches/:id', ({ params, user }) => {
  const c = findCoach(Number(params.id));
  if (!c) throw new HttpError(404, 'Coach not found');
  return json(coachDetail(c, user?.id ?? null));
});

coachingRoutes.get('/api/coaches/:id/slots', ({ params, url }) => {
  const c = findCoach(Number(params.id));
  const date = url.searchParams.get('date');
  if (!c || !date) throw new HttpError(400, 'Coach and date required');
  return json(freeHours(c.id, date));
});

coachingRoutes.post('/api/coaches/:id/sessions', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ date: string; time: string; method: string; karmaPoints: number }>(ctx.req);
  const s = bookSession({ userId: user.id, coachId: Number(ctx.params.id), date: b.date as string, time: b.time as string, method: b.method, karmaPoints: b.karmaPoints ?? 0, simulateDecline: wantsDecline(ctx) });
  return json(s, 201);
});

coachingRoutes.delete('/api/coach-sessions/:id', (ctx) => json({ ok: true, ...cancelSession(requireUser(ctx).id, Number(ctx.params.id)) }));

coachingRoutes.post('/api/programs/:id/enrol', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ batchId: number; method: string; karmaPoints: number }>(ctx.req);
  const e = enrol({ userId: user.id, programId: Number(ctx.params.id), batchId: b.batchId as number, method: b.method, karmaPoints: b.karmaPoints ?? 0, simulateDecline: wantsDecline(ctx) });
  return json(e, 201);
});

coachingRoutes.delete('/api/enrolments/:id', (ctx) => json({ ok: true, ...cancelEnrolment(requireUser(ctx).id, Number(ctx.params.id)) }));

coachingRoutes.post('/api/coaches/:id/reviews', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ rating: number; body: string }>(ctx.req);
  reviewCoach(user.id, Number(ctx.params.id), b.rating as number, b.body ?? '');
  return json({ ok: true }, 201);
});

coachingRoutes.post('/api/coaches/:id/enquiries', async (ctx) => {
  const user = requireUser(ctx);
  const coach = findCoach(Number(ctx.params.id));
  if (!coach) throw new HttpError(404, 'Coach not found');
  const { message } = await readJson<{ message: string }>(ctx.req);
  if (!message?.trim()) throw new HttpError(400, 'Write a short message');
  coachEnquiries.add(coach.id, user.id, message.trim().slice(0, 500));
  notify(user.id, 'coach_enquiry_sent', { coachId: coach.id, name: coach.name });
  return json({ ok: true }, 201);
});

/** Demo: mark a trial session attended, or a program completed, which unlocks reviewing the coach */
coachingRoutes.post('/api/dev/attend', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ kind: 'session' | 'enrolment'; id: number }>(ctx.req);
  if (b.kind !== 'session' && b.kind !== 'enrolment') throw new HttpError(400, 'kind is session or enrolment');
  markAttended(user.id, b.kind, b.id as number);
  return json({ ok: true });
});

void enrolments;
