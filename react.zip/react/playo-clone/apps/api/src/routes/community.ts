import { COUPONS, TOURNAMENTS, discountFor } from '../data/extras';
import { catalog } from '../services/catalog';
import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser } from '../middleware';
import { bookings } from '../repositories/bookings';
import { games } from '../repositories/games';
import { tournamentRegs, wallet } from '../repositories/money';
import { reviews } from '../repositories/reviews';
import { notify } from '../services/notify';
import { owners } from '../repositories/owners';
import { filterText } from '../services/safety';
import { summaryOf } from '../services/people';
import { hub } from '../realtime/hub';

export const communityRoutes = new Router();

/* ---------- Wallet and coupons ---------- */

communityRoutes.get('/api/wallet', (ctx) => {
  const user = requireUser(ctx);
  return json({
    balance: wallet.balance(user.id),
    transactions: wallet.transactions(user.id).map((t) => ({ id: t.id, amount: t.amount, kind: t.kind, note: t.note, createdAt: t.created_at })),
    coupons: COUPONS.map((c) => ({ code: c.code, label: c.label })),
  });
});

communityRoutes.post('/api/wallet/topup', async (ctx) => {
  const user = requireUser(ctx);
  const { amount, method } = await readJson<{ amount: number; method: 'upi' | 'card' }>(ctx.req);
  if (!amount || !Number.isInteger(amount) || amount < 100 || amount > 10_000) throw new HttpError(400, 'Top up between ₹100 and ₹10,000');
  if (method !== 'upi' && method !== 'card') throw new HttpError(400, 'Pay with UPI or card');
  if (ctx.req.headers.get('x-simulate-payment-failure') === '1') throw new HttpError(402, 'Payment declined by the bank');
  const balance = wallet.adjust(user.id, amount, 'topup', `Top up via ${method.toUpperCase()}`);
  hub.sendTo(user.id, { type: 'refresh', what: 'wallet' });
  return json({ balance }, 201);
});

communityRoutes.post('/api/coupons/validate', async (ctx) => {
  requireUser(ctx);
  const { code, amount } = await readJson<{ code: string; amount: number }>(ctx.req);
  const result = discountFor(code, amount ?? 0);
  if (!result) throw new HttpError(400, 'Enter a coupon code');
  if ('error' in result) throw new HttpError(400, result.error);
  return json({ code: result.coupon.code, label: result.coupon.label, discount: result.discount });
});

/* ---------- Reviews ---------- */

communityRoutes.get('/api/venues/:id/reviews', (ctx) => {
  const venueId = Number(ctx.params.id);
  if (!catalog.find(venueId)) throw new HttpError(404, 'Venue not found');
  const list = reviews.forTarget('venue', venueId);
  const viewer = ctx.user?.id;
  return json({
    avg: list.length ? Math.round((list.reduce((s, r) => s + r.rating, 0) / list.length) * 10) / 10 : 0,
    count: list.length,
    items: list.map((r) => ({ id: r.id, rating: r.rating, body: r.body, createdAt: r.created_at, author: summaryOf(r.author_id), reply: owners.reply(r.id) ? { body: owners.reply(r.id)!.body, createdAt: owners.reply(r.id)!.created_at } : null })),
    canReview: !!viewer && bookings.hasAttended(viewer, venueId) && !reviews.hasReviewed('venue', venueId, viewer),
  });
});

communityRoutes.post('/api/venues/:id/reviews', async (ctx) => {
  const user = requireUser(ctx);
  const venueId = Number(ctx.params.id);
  if (!catalog.find(venueId)) throw new HttpError(404, 'Venue not found');
  const { rating, body } = await readJson<{ rating: number; body: string }>(ctx.req);
  if (!rating || rating < 1 || rating > 5) throw new HttpError(400, 'Rating is 1 to 5');
  if (!bookings.hasAttended(user.id, venueId)) throw new HttpError(403, 'You can review a venue after attending a booking there');
  if (!reviews.add({ kind: 'venue', targetId: venueId, authorId: user.id, rating, body: filterText((body ?? '').slice(0, 300)) })) throw new HttpError(409, 'You already reviewed this venue');
  return json({ ok: true }, 201);
});

/* ---------- Leaderboard ---------- */

communityRoutes.get('/api/leaderboard', ({ url }) => {
  const sport = url.searchParams.get('sport');
  const city = url.searchParams.get('city');
  const rows = games.leaderboard(sport && sport !== 'all' ? sport : null, city && city !== 'all' ? city : null);
  return json(rows.flatMap((r, i) => {
    const player = summaryOf(r.id);
    return player ? [{ rank: i + 1, player, games: r.games, wins: r.wins, points: r.wins * 3 + r.games }] : [];
  }));
});

/* ---------- Tournaments ---------- */

communityRoutes.get('/api/tournaments', (ctx) => {
  const city = ctx.url.searchParams.get('city'), sport = ctx.url.searchParams.get('sport');
  const viewer = ctx.user?.id;
  return json(TOURNAMENTS
    .filter((t) => (!city || t.city === city) && (!sport || sport === 'all' || t.sport === sport))
    .map((t) => ({ ...t, registered: viewer ? tournamentRegs.has(t.id, viewer) : false, spotsLeft: t.capacity - tournamentRegs.count(t.id) })));
});

communityRoutes.post('/api/tournaments/:id/register', async (ctx) => {
  const user = requireUser(ctx);
  const t = TOURNAMENTS.find((x) => x.id === Number(ctx.params.id));
  if (!t) throw new HttpError(404, 'Tournament not found');
  if (tournamentRegs.has(t.id, user.id)) throw new HttpError(409, 'You are already registered');
  if (t.capacity - tournamentRegs.count(t.id) <= 0) throw new HttpError(409, 'This tournament is full');
  wallet.adjust(user.id, -t.fee, 'tournament', `Entry fee · ${t.name}`);
  tournamentRegs.add(t.id, user.id, t.fee);
  notify(user.id, 'tournament_registered', { tournamentId: t.id, name: t.name, fee: t.fee });
  hub.sendTo(user.id, { type: 'refresh', what: 'wallet' });
  return json({ ok: true }, 201);
});

