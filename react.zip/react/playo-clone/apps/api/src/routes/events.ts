import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser, wantsDecline } from '../middleware';
import { allEvents, cancelRegistration, createMeetup, eventOut, findEvent, registerForEvent } from '../services/events';

export const eventRoutes = new Router();

eventRoutes.get('/api/events', ({ url, user }) => {
  const type = url.searchParams.get('type'), city = url.searchParams.get('city'), q = url.searchParams.get('q')?.toLowerCase();
  const list = allEvents()
    .filter((e) => (!type || type === 'all' || e.type === type) && (!city || e.city === city) && (!q || `${e.title} ${e.place}`.toLowerCase().includes(q)))
    .sort((a, b) => Date.parse(a.startsAt) - Date.parse(b.startsAt))
    .map((e) => eventOut(e, user?.id ?? null));
  return json(list);
});

eventRoutes.get('/api/events/:id', ({ params, user }) => {
  const e = findEvent(Number(params.id));
  if (!e) throw new HttpError(404, 'Event not found');
  return json(eventOut(e, user?.id ?? null, true));
});

eventRoutes.post('/api/events', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<Parameters<typeof createMeetup>[1]>(ctx.req);
  const id = createMeetup(user, b);
  return json(eventOut(findEvent(id)!, user.id, true), 201);
});

eventRoutes.post('/api/events/:id/register', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ category: string; answer: string; method: string; karmaPoints: number }>(ctx.req);
  registerForEvent({ userId: user.id, eventId: Number(ctx.params.id), category: b.category, answer: b.answer, method: b.method, karmaPoints: b.karmaPoints ?? 0, simulateDecline: wantsDecline(ctx) });
  return json(eventOut(findEvent(Number(ctx.params.id))!, user.id, true), 201);
});

eventRoutes.delete('/api/events/:id/register', (ctx) => json({ ok: true, ...cancelRegistration(requireUser(ctx).id, Number(ctx.params.id)) }));
