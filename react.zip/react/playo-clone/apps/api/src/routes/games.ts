import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser, wantsDecline } from '../middleware';
import { games } from '../repositories/games';
import { catalog } from '../services/catalog';
import { filterText } from '../services/safety';
import { SKILL_LEVELS } from '../services/people';
import { afterGameCreated, canSee, cancelRequest, decideRequest, endGame, gameOut, inviteToGame, joinGame, leaveGame, setRsvp } from '../services/games';

export const gameRoutes = new Router();

const load = (id: string) => {
  const g = games.byId(Number(id));
  if (!g) throw new HttpError(404, 'Game not found');
  return g;
};

gameRoutes.get('/api/games', ({ url, user }) => {
  const city = url.searchParams.get('city'), sport = url.searchParams.get('sport');
  const status = url.searchParams.get('status') ?? 'open';
  const mine = url.searchParams.get('mine') === '1';
  const viewer = user?.id ?? null;
  return json(
    games.all()
      .filter((g) => g.status === status && canSee(g, viewer) && (!mine || (viewer !== null && games.isPlayer(g.id, viewer))))
      .filter((g) => mine || ((!city || g.city === city) && (!sport || sport === 'all' || g.sport === sport)))
      .map((g) => gameOut(g, viewer))
  );
});

gameRoutes.post('/api/games', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{
    title: string; sport: string; venueId: number; startsAt: string; capacity: number; level: string;
    joinMode: 'open' | 'approval'; visibility: 'public' | 'private'; minLevel: string | null; priceInr: number;
  }>(ctx.req);
  const venue = b.venueId ? catalog.find(b.venueId) : undefined;
  if (!venue || !b.title?.trim() || !b.sport || !b.startsAt) throw new HttpError(400, 'Title, sport, venue and start time are required');
  if (!venue.sports.includes(b.sport)) throw new HttpError(400, `${venue.name} doesn't offer ${b.sport}`);
  if (Date.parse(b.startsAt) <= Date.now()) throw new HttpError(400, 'Pick a start time in the future');
  const capacity = b.capacity ?? 6;
  if (!Number.isInteger(capacity) || capacity < 2 || capacity > 40) throw new HttpError(400, 'A game has 2 to 40 players');
  const price = b.priceInr ?? 0;
  if (!Number.isInteger(price) || price < 0 || price > 5000) throw new HttpError(400, 'The price per player is ₹0 to ₹5,000');
  if (b.minLevel && !SKILL_LEVELS.includes(b.minLevel)) throw new HttpError(400, 'Unknown skill level');
  const created = games.create({
    hostId: user.id, hostName: user.name, title: filterText(b.title.trim()), sport: b.sport, city: venue.city,
    venueId: venue.id, startsAt: b.startsAt, capacity, level: b.level ?? 'Intermediate',
    joinMode: b.joinMode === 'approval' ? 'approval' : 'open', visibility: b.visibility === 'private' ? 'private' : 'public',
    minLevel: b.minLevel || null, priceInr: price,
  });
  afterGameCreated(created, user);
  return json(gameOut(created, user.id), 201);
});

/** Opening an invite link: anyone can see the game it points to (joining still needs a login) */
gameRoutes.get('/api/games/by-code/:code', ({ params, user }) => {
  const g = games.byInviteCode(params.code);
  if (!g) throw new HttpError(404, 'That invite link is not valid');
  return json({ ...gameOut(g, user?.id ?? null), viaCode: true });
});

gameRoutes.get('/api/games/:id', ({ params, user }) => {
  const g = load(params.id);
  if (!canSee(g, user?.id ?? null)) throw new HttpError(404, 'Game not found');
  return json(gameOut(g, user?.id ?? null));
});

gameRoutes.post('/api/games/:id/join', async (ctx) => {
  const user = requireUser(ctx);
  const g = load(ctx.params.id);
  const b = await readJson<{ method: string; karmaPoints: number; code: string }>(ctx.req);
  const result = joinGame(g, user, { method: b.method, karmaPoints: b.karmaPoints, code: b.code, simulateDecline: wantsDecline(ctx) });
  return json({ ...result, game: gameOut(games.byId(g.id)!, user.id) });
});

gameRoutes.post('/api/games/:id/leave', (ctx) => {
  const user = requireUser(ctx);
  const g = load(ctx.params.id);
  const result = leaveGame(g, user);
  return json({ ...result, game: gameOut(games.byId(g.id)!, user.id) });
});

gameRoutes.delete('/api/games/:id/requests', (ctx) => {
  const user = requireUser(ctx);
  cancelRequest(load(ctx.params.id), user);
  return json({ ok: true });
});

gameRoutes.post('/api/games/:id/requests/:userId/:decision', (ctx) => {
  const host = requireUser(ctx);
  const { decision } = ctx.params;
  if (decision !== 'approve' && decision !== 'decline') throw new HttpError(404, 'Not found');
  decideRequest(load(ctx.params.id), host, Number(ctx.params.userId), decision === 'approve');
  return json(gameOut(games.byId(Number(ctx.params.id))!, host.id));
});

gameRoutes.post('/api/games/:id/invites', async (ctx) => {
  const user = requireUser(ctx);
  const { userIds } = await readJson<{ userIds: number[] }>(ctx.req);
  const sent = inviteToGame(load(ctx.params.id), user, userIds ?? []);
  return json({ invited: sent.length }, 201);
});

gameRoutes.post('/api/games/:id/rsvp', async (ctx) => {
  const user = requireUser(ctx);
  const { answer } = await readJson<{ answer: string }>(ctx.req);
  setRsvp(load(ctx.params.id), user, answer as string);
  return json(gameOut(games.byId(Number(ctx.params.id))!, user.id));
});

gameRoutes.post('/api/games/:id/end', async (ctx) => {
  const user = requireUser(ctx);
  const g = load(ctx.params.id);
  if (g.host_id !== user.id) throw new HttpError(403, 'Only the host can end the game');
  if (g.status !== 'open') throw new HttpError(409, 'This game has already ended');
  const b = await readJson<{ winnerIds: number[]; attendedIds: number[] }>(ctx.req);
  const inGame = new Set(games.players(g.id).map((p) => p.user_id));
  const winners = (b.winnerIds ?? []).filter((w) => inGame.has(w));
  const attended = b.attendedIds ? b.attendedIds.filter((a) => inGame.has(a)) : undefined;
  return json(gameOut(endGame(g, winners, attended), user.id));
});
