import { ARTICLES, FAQS, TICKET_TOPICS } from '../data/help';
import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser } from '../middleware';
import { bookings } from '../repositories/bookings';
import { tickets } from '../repositories/tickets';
import { catalog } from '../services/catalog';
import { filterText } from '../services/safety';
import { agentWillReply } from '../services/support';
import type { TicketRow } from '../db/rows';

export const helpRoutes = new Router();

helpRoutes.get('/api/faq', ({ url }) => {
  const q = (url.searchParams.get('q') ?? '').trim().toLowerCase();
  const items = FAQS.filter((f) => !q || `${f.question} ${f.answer}`.toLowerCase().includes(q));
  return json({ items, categories: [...new Set(FAQS.map((f) => f.category))], total: FAQS.length });
});

helpRoutes.get('/api/articles', ({ url }) => {
  const tag = url.searchParams.get('tag'), q = (url.searchParams.get('q') ?? '').toLowerCase();
  const list = ARTICLES.filter((a) => (!tag || a.tags.includes(tag)) && (!q || `${a.title} ${a.summary} ${a.tags.join(" ")} ${a.sport ?? ""}`.toLowerCase().includes(q)));
  return json({
    items: list.map(({ body: _body, ...rest }) => rest).sort((a, b) => b.publishedAt.localeCompare(a.publishedAt)),
    tags: [...new Set(ARTICLES.flatMap((a) => a.tags))].sort(),
  });
});

helpRoutes.get('/api/articles/:slug', ({ params, url }) => {
  const a = ARTICLES.find((x) => x.slug === params.slug);
  if (!a) throw new HttpError(404, 'Article not found');
  const city = url.searchParams.get('city');
  const related = a.sport ? catalog.list().filter((v) => v.sports.includes(a.sport!) && (!city || v.city === city)).sort((x, y) => y.rating - x.rating).slice(0, 3) : [];
  return json({ ...a, relatedVenues: related });
});

const ticketOut = (t: TicketRow, withMessages = false) => {
  const last = tickets.last(t.id);
  return {
    id: t.id, topic: t.topic, subject: t.subject, bookingId: t.booking_id, status: t.status, createdAt: t.created_at, updatedAt: t.updated_at,
    lastMessage: last ? { sender: last.sender, body: last.body, createdAt: last.created_at } : null,
    messages: withMessages ? tickets.messages(t.id).map((m) => ({ id: m.id, sender: m.sender, body: m.body, createdAt: m.created_at })) : undefined,
  };
};

helpRoutes.get('/api/tickets', (ctx) => json(tickets.forUser(requireUser(ctx).id).map((t) => ticketOut(t))));

helpRoutes.post('/api/tickets', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ topic: string; subject: string; message: string; bookingId: number | null }>(ctx.req);
  const topic = TICKET_TOPICS.includes(b.topic as never) ? (b.topic as string) : 'Other';
  const subject = filterText((b.subject ?? '').trim());
  const message = filterText((b.message ?? '').trim());
  if (subject.length < 3 || subject.length > 100) throw new HttpError(400, 'Give the ticket a subject (3 to 100 characters)');
  if (message.length < 5 || message.length > 2000) throw new HttpError(400, 'Describe the problem (5 to 2000 characters)');
  let bookingId: number | null = null;
  if (b.bookingId) {
    const booking = bookings.byId(b.bookingId);
    if (!booking || booking.user_id !== user.id) throw new HttpError(400, 'That booking is not yours');
    bookingId = booking.id;
  }
  const t = tickets.create({ userId: user.id, topic, subject, bookingId });
  tickets.addMessage(t.id, 'user', message);
  agentWillReply(t.id, message);
  return json(ticketOut(t, true), 201);
});

helpRoutes.get('/api/tickets/:id', (ctx) => {
  const user = requireUser(ctx);
  const t = tickets.byId(Number(ctx.params.id));
  if (!t || t.user_id !== user.id) throw new HttpError(404, 'Ticket not found');
  return json(ticketOut(t, true));
});

helpRoutes.post('/api/tickets/:id/messages', async (ctx) => {
  const user = requireUser(ctx);
  const t = tickets.byId(Number(ctx.params.id));
  if (!t || t.user_id !== user.id) throw new HttpError(404, 'Ticket not found');
  if (t.status === 'closed') throw new HttpError(409, 'This ticket is closed');
  const { body } = await readJson<{ body: string }>(ctx.req);
  const text = filterText((body ?? '').trim());
  if (!text || text.length > 2000) throw new HttpError(400, 'Write a message (up to 2000 characters)');
  const m = tickets.addMessage(t.id, 'user', text);
  tickets.setStatus(t.id, 'open');
  agentWillReply(t.id, text, 2000);
  return json({ id: m.id, sender: m.sender, body: m.body, createdAt: m.created_at }, 201);
});

helpRoutes.post('/api/tickets/:id/close', (ctx) => {
  const user = requireUser(ctx);
  const t = tickets.byId(Number(ctx.params.id));
  if (!t || t.user_id !== user.id) throw new HttpError(404, 'Ticket not found');
  tickets.setStatus(t.id, 'closed');
  return json(ticketOut(tickets.byId(t.id)!, true));
});
