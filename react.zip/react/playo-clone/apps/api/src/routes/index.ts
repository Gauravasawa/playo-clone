import { Router } from '../lib/router';
import { authenticate, latency, simulateFailure } from '../middleware';
import { rateLimit } from '../middleware/rateLimit';
import { auth } from './auth';
import { bookingRoutes } from './bookings';
import { catalogRoutes } from './catalog';
import { chatRoutes } from './chats';
import { coachingRoutes } from './coaching';
import { communityRoutes } from './community';
import { eventRoutes } from './events';
import { gameRoutes } from './games';
import { helpRoutes } from './help';
import { moneyRoutes } from './money';
import { ownerRoutes } from './owner';
import { playerRoutes } from './players';
import { safetyRoutes } from './safety';
import { socialRoutes } from './social';

/** All routes and the middleware around them, in order: latency → failure switch → auth → handler */
export const router = new Router()
  .use(latency)
  .use(simulateFailure)
  .use(authenticate)
  .use(rateLimit)
  .mount(catalogRoutes)
  .mount(auth)
  .mount(playerRoutes)
  .mount(socialRoutes)
  .mount(chatRoutes)
  .mount(bookingRoutes)
  .mount(gameRoutes)
  .mount(moneyRoutes)
  .mount(safetyRoutes)
  .mount(helpRoutes)
  .mount(ownerRoutes)
  .mount(coachingRoutes)
  .mount(eventRoutes)
  .mount(communityRoutes);
