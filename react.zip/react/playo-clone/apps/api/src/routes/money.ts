import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser, wantsDecline } from '../middleware';
import { giftCards, karma, passes } from '../repositories/money';
import { users } from '../repositories/users';
import { buyGiftCard, giftCardOut, redeemGiftCard } from '../services/giftcards';
import { cancelPlus, plusStatus, subscribe } from '../services/membership';
import { buyPass, passOut } from '../services/passes';
import { requireMethod } from '../services/payments';
import { summaryOf } from '../services/people';
import { POLICY } from '../services/policy';

export const moneyRoutes = new Router();

/** The rules, as numbers: the Policy page reads them from here so it never disagrees with the server */
moneyRoutes.get('/api/policy', () => json(POLICY));

/* ---------- Karma ---------- */

moneyRoutes.get('/api/karma', (ctx) => {
  const user = requireUser(ctx);
  return json({
    balance: karma.balance(user.id),
    history: karma.history(user.id).map((t) => ({ id: t.id, points: t.points, kind: t.kind, note: t.note, createdAt: t.created_at })),
    multiplier: plusStatus(user.id).active ? POLICY.plus.karmaMultiplier : 1,
  });
});

/* ---------- Playo Plus ---------- */

moneyRoutes.get('/api/plus', (ctx) => json(plusStatus(requireUser(ctx).id)));

moneyRoutes.post('/api/plus', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ plan: 'monthly' | 'yearly'; method: string; karmaPoints: number }>(ctx.req);
  if (b.plan !== 'monthly' && b.plan !== 'yearly') throw new HttpError(400, 'Choose monthly or yearly');
  return json(subscribe(user.id, b.plan, requireMethod(b.method), b.karmaPoints ?? 0, wantsDecline(ctx)), 201);
});

moneyRoutes.delete('/api/plus', (ctx) => json(cancelPlus(requireUser(ctx).id)));

/* ---------- Venue passes ---------- */

moneyRoutes.get('/api/passes', (ctx) => json(passes.forUser(requireUser(ctx).id).map(passOut)));

moneyRoutes.post('/api/passes', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ venueId: number; kind: 'daily' | 'monthly'; date: string; method: string; karmaPoints: number }>(ctx.req);
  if (b.kind !== 'daily' && b.kind !== 'monthly') throw new HttpError(400, 'Choose a day pass or a monthly membership');
  const pass = buyPass({ userId: user.id, venueId: b.venueId as number, kind: b.kind, date: b.date, method: requireMethod(b.method), karmaPoints: b.karmaPoints ?? 0, simulateDecline: wantsDecline(ctx) });
  return json(passOut(pass), 201);
});

/* ---------- Gift cards ---------- */

moneyRoutes.get('/api/gift-cards', (ctx) => {
  const user = requireUser(ctx);
  return json({
    bought: giftCards.bought(user.id).map((g) => giftCardOut(g, user.id)),
    received: giftCards.received(user.id).map((g) => giftCardOut(g, user.id)),
  });
});

moneyRoutes.post('/api/gift-cards', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ amount: number; recipientId: number; message: string; method: string }>(ctx.req);
  const card = buyGiftCard({ buyerId: user.id, amount: Number(b.amount), recipientId: b.recipientId ?? null, message: b.message, method: requireMethod(b.method), simulateDecline: wantsDecline(ctx) });
  return json(giftCardOut(card, user.id), 201);
});

moneyRoutes.post('/api/gift-cards/redeem', async (ctx) => {
  const user = requireUser(ctx);
  const { code } = await readJson<{ code: string }>(ctx.req);
  if (!code?.trim()) throw new HttpError(400, 'Enter the gift card code');
  return json(redeemGiftCard(user.id, code), 201);
});

/* ---------- Referrals ---------- */

moneyRoutes.get('/api/referrals', (ctx) => {
  const user = requireUser(ctx);
  return json({
    code: user.referral_code,
    newcomerBonus: POLICY.referral.newcomer,
    referrerBonus: POLICY.referral.referrer,
    referrerKarma: POLICY.karma.referrer,
    referred: users.referredBy(user.id).map((u) => ({ player: summaryOf(u.id), rewarded: u.referral_rewarded === 1, joinedAt: u.created_at })),
  });
});
