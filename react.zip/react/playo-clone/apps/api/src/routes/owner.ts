import { CITY_INFO } from '../data/currency';
import { SPORTS } from '../data/sports';
import { ALL_AMENITIES, slotLabel, slotStart } from '../data/venues';
import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser } from '../middleware';
import { hub } from '../realtime/hub';
import { bookings } from '../repositories/bookings';
import { owners } from '../repositories/owners';
import { reviews } from '../repositories/reviews';
import { catalog, type CatalogVenue } from '../services/catalog';
import { notify } from '../services/notify';
import { summaryOf } from '../services/people';
import { filterText } from '../services/safety';
import { localDay } from '../services/passes';
import type { UserRow } from '../db/rows';

export const ownerRoutes = new Router();

const myVenue = (user: UserRow, idParam: string): CatalogVenue => {
  const v = catalog.find(Number(idParam));
  if (!v) throw new HttpError(404, 'Venue not found');
  if (v.ownerId !== user.id) throw new HttpError(403, 'This is not your venue');
  return v;
};

const summaryFor = (v: CatalogVenue) => {
  const rows = bookings.forVenue(v.id);
  const today = localDay();
  return {
    ...v,
    stats: {
      bookings: rows.length,
      upcoming: rows.filter((b) => b.date >= today && b.status === 'confirmed').length,
      revenueInr: rows.reduce((s, b) => s + b.paid, 0),
    },
  };
};

ownerRoutes.get('/api/owner/venues', (ctx) => {
  const user = requireUser(ctx);
  return json(catalog.list().filter((v) => v.ownerId === user.id).map(summaryFor));
});

/** Seeded venues nobody runs yet, in the owner's city: the demo way to "claim" one */
ownerRoutes.get('/api/owner/claimable', (ctx) => {
  const user = requireUser(ctx);
  const city = ctx.url.searchParams.get('city') ?? user.city;
  return json(catalog.list().filter((v) => v.ownerId === null && !v.custom && v.city === city).slice(0, 24));
});

ownerRoutes.post('/api/owner/venues/:id/claim', (ctx) => {
  const user = requireUser(ctx);
  const v = catalog.find(Number(ctx.params.id));
  if (!v || v.custom) throw new HttpError(404, 'Venue not found');
  if (v.ownerId) throw new HttpError(409, 'This venue already has an owner');
  if (!owners.claim(v.id, user.id)) throw new HttpError(409, 'This venue already has an owner');
  notify(user.id, 'venue_claimed', { venueId: v.id, name: v.name });
  return json(summaryFor(catalog.find(v.id)!), 201);
});

ownerRoutes.post('/api/owner/venues', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ name: string; city: string; area: string; sports: string[]; pricePerHourLocal: number; amenities: string[]; address: string; description: string }>(ctx.req);
  const name = b.name?.trim();
  if (!name || name.length > 60) throw new HttpError(400, 'Give the venue a name (up to 60 characters)');
  if (!b.city || !CITY_INFO[b.city]) throw new HttpError(400, 'Pick a city');
  const sports = (b.sports ?? []).filter((s) => SPORTS.some((x) => x.id === s));
  if (!sports.length) throw new HttpError(400, 'Pick at least one sport');
  const price = Number(b.pricePerHourLocal);
  if (!Number.isInteger(price) || price < 1 || price > 100_000) throw new HttpError(400, 'Enter the price per hour as a whole number');
  const id = owners.addCustom(user.id, {
    name: filterText(name), city: b.city, area: filterText((b.area ?? '').trim() || 'Central'), sports, pricePerHourLocal: price,
    amenities: (b.amenities ?? []).filter((a) => ALL_AMENITIES.includes(a)), address: filterText((b.address ?? '').trim() || `${b.city}`),
    description: filterText((b.description ?? '').trim().slice(0, 400) || `${name} is a new venue on Playo clone.`),
  });
  return json(summaryFor(catalog.find(id)!), 201);
});

ownerRoutes.get('/api/owner/venues/:id', (ctx) => {
  const user = requireUser(ctx);
  const v = myVenue(user, ctx.params.id);
  const date = ctx.url.searchParams.get('date') ?? localDay();
  const all = bookings.forVenue(v.id);
  const today = localDay();
  const base = catalog.find(v.id)!;
  const since = Date.now() - 30 * 86_400_000;
  const reviewList = reviews.forTarget('venue', v.id);
  return json({
    venue: summaryFor(v),
    pricing: { pricePerHour: base.pricePerHour, peakExtra: base.peakExtra, currency: base.currency, pricePerHourLocal: base.pricePerHourLocal },
    bookings: all.filter((b) => b.date >= today).slice(0, 100).map((b) => ({
      id: b.id, date: b.date, slots: JSON.parse(b.slots) as string[], paid: b.paid, status: b.status, method: b.method, player: summaryOf(b.user_id),
    })),
    blocked: { date, times: owners.blockedFor(v.id, date) },
    revenue: bookings.revenueByDay(v.id, since),
    reviews: reviewList.map((r) => ({ id: r.id, rating: r.rating, body: r.body, createdAt: r.created_at, author: summaryOf(r.author_id), reply: owners.reply(r.id) ? { body: owners.reply(r.id)!.body, createdAt: owners.reply(r.id)!.created_at } : null })),
  });
});

ownerRoutes.put('/api/owner/venues/:id/pricing', async (ctx) => {
  const user = requireUser(ctx);
  const v = myVenue(user, ctx.params.id);
  const b = await readJson<{ pricePerHour: number; peakExtra: number }>(ctx.req);
  const price = Number(b.pricePerHour), peak = Number(b.peakExtra);
  if (!Number.isInteger(price) || price < 50 || price > 100_000) throw new HttpError(400, 'The hourly price is ₹50 to ₹1,00,000');
  if (!Number.isInteger(peak) || peak < 0 || peak > 50_000) throw new HttpError(400, 'The peak extra is ₹0 to ₹50,000');
  owners.setOverride(v.id, price, peak);
  return json({ pricePerHour: price, peakExtra: peak });
});

const checkTimes = (times: unknown): string[] => {
  const list = Array.isArray(times) ? (times as string[]) : [];
  const valid = new Set(Array.from({ length: 17 }, (_, i) => slotLabel(6 + i)));
  if (!list.length || list.some((t) => !valid.has(t))) throw new HttpError(400, 'Pick hours between 06:00 and 22:00');
  return list;
};

ownerRoutes.post('/api/owner/venues/:id/blocks', async (ctx) => {
  const user = requireUser(ctx);
  const v = myVenue(user, ctx.params.id);
  const { date, times } = await readJson<{ date: string; times: string[] }>(ctx.req);
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new HttpError(400, 'Pick a date');
  const list = checkTimes(times);
  const booked = new Set(bookings.takenSlots(v.id, date));
  const clash = list.find((t) => booked.has(t));
  if (clash) throw new HttpError(409, `${clash} already has a booking: it can't be blocked`);
  for (const t of list) if (slotStart(date, t).getTime() > Date.now()) owners.block(v.id, date, t);
  hub.sendToMany([user.id], { type: 'refresh', what: 'owner' });
  return json({ date, times: owners.blockedFor(v.id, date) });
});

ownerRoutes.delete('/api/owner/venues/:id/blocks', async (ctx) => {
  const user = requireUser(ctx);
  const v = myVenue(user, ctx.params.id);
  const { date, times } = await readJson<{ date: string; times: string[] }>(ctx.req);
  for (const t of checkTimes(times)) owners.unblock(v.id, date as string, t);
  return json({ date, times: owners.blockedFor(v.id, date as string) });
});

ownerRoutes.post('/api/owner/reviews/:id/reply', async (ctx) => {
  const user = requireUser(ctx);
  const reviewId = Number(ctx.params.id);
  const { body } = await readJson<{ body: string }>(ctx.req);
  if (!body?.trim()) throw new HttpError(400, 'Write a reply');
  // find the review among venues this user owns
  const owned = catalog.list().filter((v) => v.ownerId === user.id);
  const target = owned.flatMap((v) => reviews.forTarget('venue', v.id)).find((r) => r.id === reviewId);
  if (!target) throw new HttpError(404, 'Review not found on your venues');
  owners.setReply(reviewId, user.id, filterText(body.trim().slice(0, 300)));
  notify(target.author_id, 'review_reply', { venueId: target.target_id, reviewId });
  return json({ ok: true }, 201);
});
