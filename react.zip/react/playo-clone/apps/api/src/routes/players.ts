import { HttpError, json } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser } from '../middleware';
import { games } from '../repositories/games';
import { reviews } from '../repositories/reviews';
import { follows } from '../repositories/social';
import { blocks } from '../repositories/safety';
import { filterText } from '../services/safety';
import { playsOf, users } from '../repositories/users';
import { suggestionsFor } from '../services/matchmaking';
import { badges, canSeeDetails, relationship, stats, summary, summaryOf } from '../services/people';
import type { UserRow } from '../db/rows';

export const playerRoutes = new Router();

/** A player's page: a private profile shows only the basics to people who aren't friends or followers */
export function profileOut(target: UserRow, viewerId: number | null) {
  const visible = canSeeDetails(viewerId, target);
  const full = stats(target.id);
  const ratings = reviews.forTarget('player', target.id);
  const avg = ratings.length ? Math.round((ratings.reduce((s, r) => s + r.rating, 0) / ratings.length) * 10) / 10 : 0;
  const rel = viewerId && viewerId !== target.id ? relationship(viewerId, target.id) : null;
  const ratable = viewerId && viewerId !== target.id
    ? games.sharedEnded(viewerId, target.id).filter((g) => !reviews.hasReviewed('player', target.id, viewerId, g.id)).map((g) => ({ id: g.id, title: g.title }))
    : [];
  return {
    ...summary(target), bio: target.bio, restricted: !visible, isMe: viewerId === target.id,
    sports: visible ? users.sports(target.id) : [],
    plays: visible ? playsOf(target) : { days: [], times: [] },
    stats: visible ? full : { followers: full.followers, following: full.following, friends: full.friends },
    badges: visible ? badges(full) : [],
    rating: { avg, count: ratings.length },
    ratings: visible ? ratings.slice(0, 10).map((r) => ({ id: r.id, rating: r.rating, body: r.body, createdAt: r.created_at, author: summaryOf(r.author_id) })) : [],
    relationship: rel, ratable,
    blockedByMe: viewerId !== null && viewerId !== target.id && blocks.byMe(viewerId, target.id),
  };
}

playerRoutes.get('/api/players/search', (ctx) => {
  const user = requireUser(ctx);
  const q = (ctx.url.searchParams.get('q') ?? '').trim();
  if (q.length < 2) return json([]);
  const hidden = blocks.hiddenFrom(user.id);
  return json(users.search(q, user.id).filter((u) => !hidden.has(u.id)).map((u) => ({ ...summary(u), relationship: relationship(user.id, u.id) })));
});

/** "Players for you": ranked by shared sports and level, city and the times you both play */
playerRoutes.get('/api/players/suggested', (ctx) => json(suggestionsFor(requireUser(ctx))));

playerRoutes.get('/api/players/me/played-with', (ctx) => {
  const user = requireUser(ctx);
  const hidden = blocks.hiddenFrom(user.id);
  return json(
    games.playedWith(user.id).flatMap((row) => {
      const u = users.byId(row.other);
      return u && !hidden.has(u.id) ? [{ player: summary(u), games: row.games, lastAt: row.last_at, relationship: relationship(user.id, u.id) }] : [];
    })
  );
});

playerRoutes.get('/api/players/:username', (ctx) => {
  const target = users.byUsername(ctx.params.username);
  if (!target || (ctx.user && blocks.byMe(target.id, ctx.user.id))) throw new HttpError(404, 'Player not found');
  return json(profileOut(target, ctx.user?.id ?? null));
});

const listOf = (ids: number[]) => ids.flatMap((id) => { const p = summaryOf(id); return p ? [p] : []; });

playerRoutes.get('/api/players/:username/followers', (ctx) => {
  const target = users.byUsername(ctx.params.username);
  if (!target) throw new HttpError(404, 'Player not found');
  if (!canSeeDetails(ctx.user?.id ?? null, target)) throw new HttpError(403, 'This profile is private');
  return json(listOf(follows.followerIds(target.id)));
});

playerRoutes.get('/api/players/:username/following', (ctx) => {
  const target = users.byUsername(ctx.params.username);
  if (!target) throw new HttpError(404, 'Player not found');
  if (!canSeeDetails(ctx.user?.id ?? null, target)) throw new HttpError(403, 'This profile is private');
  return json(listOf(follows.followingIds(target.id)));
});

playerRoutes.post('/api/players/:id/ratings', async (ctx) => {
  const user = requireUser(ctx);
  const targetId = Number(ctx.params.id);
  const { gameId, rating, body } = (await ctx.req.json().catch(() => ({}))) as { gameId?: number; rating?: number; body?: string };
  const target = users.byId(targetId);
  if (!target || targetId === user.id) throw new HttpError(400, 'Pick another player');
  if (!gameId || !games.sharedEnded(user.id, targetId).some((g) => g.id === gameId)) throw new HttpError(403, "You can only rate players from a game you both played");
  if (!rating || rating < 1 || rating > 5) throw new HttpError(400, 'Rating is 1 to 5');
  if (!reviews.add({ kind: 'player', targetId, authorId: user.id, rating, body: filterText((body ?? '').slice(0, 300)), contextId: gameId })) throw new HttpError(409, 'You already rated this player for that game');
  return json({ ok: true }, 201);
});
