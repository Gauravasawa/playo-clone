import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser } from '../middleware';
import { chats } from '../repositories/chats';
import { games } from '../repositories/games';
import { db } from '../db/connection';
import { blocks, reports } from '../repositories/safety';
import { friendships } from '../repositories/social';
import { users } from '../repositories/users';
import { hub } from '../realtime/hub';
import { summaryOf } from '../services/people';
import { notify } from '../services/notify';
import type { ReportRow } from '../db/rows';

export const safetyRoutes = new Router();

/* ---------- Blocking ---------- */

safetyRoutes.get('/api/blocks', (ctx) => {
  const user = requireUser(ctx);
  return json(blocks.blockedBy(user.id).flatMap((id) => { const p = summaryOf(id); return p ? [p] : []; }));
});

safetyRoutes.post('/api/blocks', async (ctx) => {
  const user = requireUser(ctx);
  const { userId } = await readJson<{ userId: number }>(ctx.req);
  const target = userId ? users.byId(userId) : null;
  if (!target || target.id === user.id || target.is_admin === 1) throw new HttpError(400, 'Pick another player');
  blocks.add(user.id, target.id);
  // Blocking ends any friendship and follows, both ways
  const f = friendships.between(user.id, target.id);
  if (f) friendships.remove(f.id);
  db.run('DELETE FROM follows WHERE (follower_id = ? AND followee_id = ?) OR (follower_id = ? AND followee_id = ?)', [user.id, target.id, target.id, user.id]);
  hub.sendToMany([user.id, target.id], { type: 'refresh', what: 'friends' });
  hub.sendToMany([user.id, target.id], { type: 'chat', chatId: 0 });
  return json({ ok: true }, 201);
});

safetyRoutes.delete('/api/blocks/:userId', (ctx) => {
  const user = requireUser(ctx);
  if (!blocks.remove(user.id, Number(ctx.params.userId))) throw new HttpError(404, 'You have not blocked this player');
  hub.sendTo(user.id, { type: 'chat', chatId: 0 });
  return json({ ok: true });
});

/* ---------- Reports ---------- */

const KINDS = ['player', 'message', 'game', 'review'] as const;
const REASONS = ['Spam', 'Abuse or harassment', 'Fake profile', 'Inappropriate content', 'Cheating or no-show', 'Something else'];

safetyRoutes.get('/api/report-reasons', () => json(REASONS));

safetyRoutes.post('/api/reports', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson<{ kind: string; targetId: number; reason: string; details: string }>(ctx.req);
  if (!KINDS.includes(b.kind as never)) throw new HttpError(400, 'You can report a player, message, game or review');
  if (!REASONS.includes(b.reason as string)) throw new HttpError(400, 'Choose a reason');
  const target = b.targetId as number;
  const exists =
    b.kind === 'player' ? !!users.byId(target)
    : b.kind === 'game' ? !!games.byId(target)
    : b.kind === 'message' ? !!db.query('SELECT 1 FROM messages WHERE id = ?').get(target)
    : !!db.query('SELECT 1 FROM reviews WHERE id = ?').get(target);
  if (!exists) throw new HttpError(404, `That ${b.kind} doesn't exist`);
  if (b.kind === 'player' && target === user.id) throw new HttpError(400, "You can't report yourself");
  if (b.kind === 'message') {
    const m = db.query('SELECT chat_id FROM messages WHERE id = ?').get(target) as { chat_id: number };
    if (!chats.isMember(m.chat_id, user.id)) throw new HttpError(403, 'You can only report messages from your chats');
  }
  if (reports.alreadyReported(user.id, b.kind as string, target)) throw new HttpError(409, 'You already reported this. We are looking at it.');
  const r = reports.create({ reporterId: user.id, kind: b.kind as string, targetId: target, reason: b.reason as string, details: (b.details ?? '').slice(0, 500) });
  for (const admin of users.admins()) notify(admin.id, 'report_filed', { reportId: r.id, kind: r.kind, reason: r.reason });
  return json({ id: r.id }, 201);
});

/* ---------- Admin ---------- */

function requireAdmin(ctx: Parameters<typeof requireUser>[0]) {
  const user = requireUser(ctx);
  if (user.is_admin !== 1) throw new HttpError(403, 'Admins only');
  return user;
}

const describeTarget = (r: ReportRow) => {
  if (r.kind === 'player') { const p = summaryOf(r.target_id); return p ? `${p.name} (@${p.username})` : 'Deleted player'; }
  if (r.kind === 'game') return games.byId(r.target_id)?.title ?? 'Deleted game';
  if (r.kind === 'message') return (db.query('SELECT body FROM messages WHERE id = ?').get(r.target_id) as { body: string } | null)?.body || '(picture)';
  return (db.query('SELECT body FROM reviews WHERE id = ?').get(r.target_id) as { body: string } | null)?.body ?? 'Deleted review';
};

safetyRoutes.get('/api/admin/reports', (ctx) => {
  requireAdmin(ctx);
  const status = ctx.url.searchParams.get('status');
  return json(reports.list(status && status !== 'all' ? status : null).map((r) => ({
    id: r.id, kind: r.kind, targetId: r.target_id, target: describeTarget(r), reason: r.reason, details: r.details, status: r.status, createdAt: r.created_at, reporter: summaryOf(r.reporter_id),
  })));
});

safetyRoutes.post('/api/admin/reports/:id/:decision', (ctx) => {
  requireAdmin(ctx);
  const { decision } = ctx.params;
  if (decision !== 'resolve' && decision !== 'dismiss') throw new HttpError(404, 'Not found');
  const r = reports.byId(Number(ctx.params.id));
  if (!r) throw new HttpError(404, 'Report not found');
  reports.setStatus(r.id, decision === 'resolve' ? 'resolved' : 'dismissed');
  notify(r.reporter_id, 'report_update', { reportId: r.id, status: decision === 'resolve' ? 'resolved' : 'dismissed' });
  return json({ ok: true });
});
