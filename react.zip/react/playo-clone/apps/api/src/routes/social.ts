import { HttpError, json, readJson } from '../lib/http';
import { Router } from '../lib/router';
import { requireUser } from '../middleware';
import { games } from '../repositories/games';
import { follows, friendships, notifications } from '../repositories/social';
import { users } from '../repositories/users';
import { hub } from '../realtime/hub';
import { blocks } from '../repositories/safety';
import { botsReactToFriendRequest, botsReactToFollowRequest } from '../services/bots';
import { notificationOut, notify } from '../services/notify';
import { summary, summaryOf } from '../services/people';

export const socialRoutes = new Router();

const NOT_PLAYED = "You can only send requests to players you've played with";

/* ---------- Friends ---------- */

socialRoutes.get('/api/friends', (ctx) => {
  const user = requireUser(ctx);
  const withPlayer = (f: { id: number; created_at: number }, otherId: number) => {
    const player = summaryOf(otherId);
    return player ? [{ id: f.id, player, createdAt: f.created_at }] : [];
  };
  return json({
    friends: friendships.friendIds(user.id).flatMap((id) => { const p = summaryOf(id); return p ? [p] : []; }),
    incoming: friendships.incoming(user.id).flatMap((f) => withPlayer(f, f.requester_id)),
    outgoing: friendships.outgoing(user.id).flatMap((f) => withPlayer(f, f.addressee_id)),
  });
});

socialRoutes.post('/api/friends/requests', async (ctx) => {
  const user = requireUser(ctx);
  const { userId } = await readJson<{ userId: number }>(ctx.req);
  const target = userId ? users.byId(userId) : null;
  if (!target || target.id === user.id) throw new HttpError(400, 'Pick another player');
  if (friendships.between(user.id, target.id)) throw new HttpError(409, 'There is already a request or friendship with this player');
  if (blocks.either(user.id, target.id)) throw new HttpError(403, "You can't send requests to this player");
  if (!games.hasPlayedWith(user.id, target.id)) throw new HttpError(403, NOT_PLAYED);

  const request = friendships.request(user.id, target.id);
  notify(target.id, 'friend_request', { requestId: request.id, actor: summary(user) });
  hub.sendToMany([user.id, target.id], { type: 'refresh', what: 'friends' });
  botsReactToFriendRequest(request.id, user, target);
  return json({ id: request.id }, 201);
});

socialRoutes.post('/api/friends/requests/:id/accept', (ctx) => {
  const user = requireUser(ctx);
  const request = friendships.byId(Number(ctx.params.id));
  if (!request || request.addressee_id !== user.id || request.status !== 'pending') throw new HttpError(404, 'Request not found');
  friendships.accept(request.id);
  notify(request.requester_id, 'friend_accepted', { actor: summary(user) });
  hub.sendToMany([user.id, request.requester_id], { type: 'refresh', what: 'friends' });
  return json({ ok: true });
});

socialRoutes.post('/api/friends/requests/:id/decline', (ctx) => {
  const user = requireUser(ctx);
  const request = friendships.byId(Number(ctx.params.id));
  if (!request || request.addressee_id !== user.id || request.status !== 'pending') throw new HttpError(404, 'Request not found');
  friendships.remove(request.id);
  hub.sendToMany([user.id, request.requester_id], { type: 'refresh', what: 'friends' });
  return json({ ok: true });
});

socialRoutes.delete('/api/friends/requests/:id', (ctx) => {
  const user = requireUser(ctx);
  const request = friendships.byId(Number(ctx.params.id));
  if (!request || request.requester_id !== user.id || request.status !== 'pending') throw new HttpError(404, 'Request not found');
  friendships.remove(request.id);
  hub.sendToMany([user.id, request.addressee_id], { type: 'refresh', what: 'friends' });
  return json({ ok: true });
});

socialRoutes.delete('/api/friends/:userId', (ctx) => {
  const user = requireUser(ctx);
  const other = Number(ctx.params.userId);
  const row = friendships.between(user.id, other);
  if (!row || row.status !== 'accepted') throw new HttpError(404, 'Not friends');
  friendships.remove(row.id);
  hub.sendToMany([user.id, other], { type: 'refresh', what: 'friends' });
  return json({ ok: true });
});

/* ---------- Follows: instant on public profiles, needs approval on private ones ---------- */

socialRoutes.post('/api/follows', async (ctx) => {
  const user = requireUser(ctx);
  const { userId } = await readJson<{ userId: number }>(ctx.req);
  const target = userId ? users.byId(userId) : null;
  if (!target || target.id === user.id) throw new HttpError(400, 'Pick another player');
  if (follows.get(user.id, target.id)) throw new HttpError(409, 'You already follow (or asked to follow) this player');
  if (blocks.either(user.id, target.id)) throw new HttpError(403, "You can't send requests to this player");
  if (!games.hasPlayedWith(user.id, target.id)) throw new HttpError(403, NOT_PLAYED);

  const status = target.is_private === 1 ? 'pending' : 'accepted';
  follows.create(user.id, target.id, status);
  notify(target.id, status === 'pending' ? 'follow_request' : 'new_follower', { actor: summary(user) });
  hub.sendToMany([user.id, target.id], { type: 'refresh', what: 'followRequests' });
  if (status === 'pending') botsReactToFollowRequest(user, target);
  return json({ status: status === 'pending' ? 'pending' : 'following' }, 201);
});

socialRoutes.delete('/api/follows/:userId', (ctx) => {
  const user = requireUser(ctx);
  const target = Number(ctx.params.userId);
  if (!follows.get(user.id, target)) throw new HttpError(404, 'You are not following this player');
  follows.remove(user.id, target);
  hub.sendToMany([user.id, target], { type: 'refresh', what: 'followRequests' });
  return json({ ok: true });
});

socialRoutes.get('/api/follows/requests', (ctx) => {
  const user = requireUser(ctx);
  return json(follows.pendingFor(user.id).flatMap((f) => { const player = summaryOf(f.follower_id); return player ? [{ player, createdAt: f.created_at }] : []; }));
});

socialRoutes.post('/api/follows/requests/:followerId/:action', (ctx) => {
  const user = requireUser(ctx);
  const followerId = Number(ctx.params.followerId);
  const { action } = ctx.params;
  if (action !== 'accept' && action !== 'decline') throw new HttpError(404, 'Not found');
  const row = follows.get(followerId, user.id);
  if (!row || row.status !== 'pending') throw new HttpError(404, 'Request not found');
  if (action === 'accept') {
    follows.accept(followerId, user.id);
    notify(followerId, 'follow_accepted', { actor: summary(user) });
  } else {
    follows.remove(followerId, user.id);
  }
  hub.sendToMany([user.id, followerId], { type: 'refresh', what: 'followRequests' });
  return json({ ok: true });
});

/* ---------- Notifications ---------- */

socialRoutes.get('/api/notifications', (ctx) => {
  const user = requireUser(ctx);
  const page = Math.max(1, Number(ctx.url.searchParams.get('page') ?? 1));
  const limit = Math.min(50, Number(ctx.url.searchParams.get('limit') ?? 10));
  const total = notifications.total(user.id);
  return json({
    items: notifications.page(user.id, page, limit).map(notificationOut),
    page, total, nextPage: page * limit < total ? page + 1 : null, unread: notifications.unread(user.id),
  });
});

socialRoutes.post('/api/notifications/read', async (ctx) => {
  const user = requireUser(ctx);
  const body = await ctx.req.json().catch(() => ({})) as { ids?: number[] };
  notifications.markRead(user.id, Array.isArray(body.ids) ? body.ids : undefined);
  return json({ unread: notifications.unread(user.id) });
});

/** Demo helper (used by the Store lab): makes many notifications at once, to try paging */
socialRoutes.post('/api/dev/notifications', async (ctx) => {
  const user = requireUser(ctx);
  const { count } = (await ctx.req.json().catch(() => ({}))) as { count?: number };
  const n = Math.min(200, Math.max(1, count ?? 40));
  for (let i = 1; i <= n; i++) notify(user.id, 'generic', { text: `Demo notification ${i} of ${n}` });
  return json({ created: n }, 201);
});
