import type { BookingRow } from '../db/rows';
import { hourOf, slotPrice, slotStart, takenByOthers } from '../data/venues';
import { HttpError } from '../lib/http';
import { hub } from '../realtime/hub';
import { bookings } from '../repositories/bookings';
import { karma, passes, wallet } from '../repositories/money';
import { owners } from '../repositories/owners';
import { users } from '../repositories/users';
import { catalog, type CatalogVenue } from './catalog';
import { earnKarma } from './karma';
import { isPlus } from './membership';
import { notify } from './notify';
import { charge, refundToWallet, requireMethod } from './payments';
import { checkPass } from './passes';
import { hoursUntil, POLICY, refundPercent } from './policy';
import { quoteBooking, type Quote } from './pricing';
import { rewardReferrerIfFirstBooking } from './referral';
import { summaryOf } from './people';

/** A booking as the browser sees it, including what cancelling or moving it would do right now */
export function bookingOut(b: BookingRow, viewerId: number) {
  const v = catalog.find(b.venue_id);
  const hours = hoursUntil(b.starts_at);
  const plus = isPlus(viewerId);
  return {
    id: b.id, venueId: b.venue_id, venueName: v?.name ?? 'Venue', area: v?.area ?? '', city: v?.city ?? '', currency: v?.currency ?? 'INR',
    sport: b.sport, date: b.date, slots: JSON.parse(b.slots) as string[], startsAt: b.starts_at,
    total: b.total, slotsInr: b.slots_inr, extras: JSON.parse(b.extras) as Quote['extras'], extrasInr: b.extras_inr,
    discount: b.discount, coupon: b.coupon, passId: b.pass_id, passCovered: b.pass_covered, fee: b.fee,
    karmaUsed: b.karma_used, karmaDiscount: b.karma_discount, paid: b.paid, method: b.method, status: b.status, createdAt: b.created_at,
    refundPercent: b.status === 'confirmed' && hours > 0 ? refundPercent(hours, plus) : 0,
    canCancel: b.status === 'confirmed' && hours > 0,
    canReschedule: b.status === 'confirmed' && hours >= POLICY.rescheduleUntilHoursBefore,
  };
}

/** Throws unless every slot can be booked: not in the past, not blocked by the venue, not taken */
export function assertSlotsFree(venue: CatalogVenue, date: string, slots: string[], exceptBookingId = 0) {
  const taken = new Set(bookings.takenSlots(venue.id, date, exceptBookingId));
  const now = Date.now();
  for (const s of slots) {
    if (slotStart(date, s).getTime() <= now) throw new HttpError(409, `${s} has already started`);
    if (owners.isBlocked(venue.id, date, s)) throw new HttpError(409, `${s} is closed by the venue`);
    if (taken.has(s) || takenByOthers(venue.id, date, hourOf(s))) throw new HttpError(409, `${s} was just booked by someone else`);
  }
}

export interface CreateBookingInput {
  userId: number; venueId: number; date: string; slots: string[]; sport?: string; method?: unknown; extras?: string[];
  coupon?: string | null; karmaPoints?: number; passId?: number | null; simulateDecline: boolean;
}

export function createBooking(input: CreateBookingInput) {
  const venue = catalog.find(input.venueId);
  if (!venue || !input.date || !input.slots?.length) throw new HttpError(400, 'Pick a venue and at least one slot');
  const sport = input.sport && venue.sports.includes(input.sport) ? input.sport : venue.sports[0];
  assertSlotsFree(venue, input.date, input.slots);

  const method = requireMethod(input.method);
  const q = quoteBooking({ userId: input.userId, venueId: venue.id, date: input.date, slots: input.slots, extras: input.extras, coupon: input.coupon, karmaPoints: input.karmaPoints, passId: input.passId });

  // Pay first: if the payment is declined nothing else happens
  charge({ userId: input.userId, amountInr: q.payableInr, method, kind: 'booking', note: `${venue.name} · ${input.date}`, reference: `booking_${input.userId}`, simulateDecline: input.simulateDecline });
  if (q.karmaPointsUsed > 0) karma.add(input.userId, -q.karmaPointsUsed, 'redeem', `Used at ${venue.name}`);
  if (q.passId && q.passHours > 0) passes.addHours(q.passId, -q.passHours);

  const booking = bookings.create({
    userId: input.userId, venueId: venue.id, sport, date: input.date, slots: q.slots.map((s) => s.time), startsAt: q.startsAt,
    slotsInr: q.slotsInr, extras: q.extras, extrasInr: q.extrasInr, passId: q.passId, passCovered: q.passCoveredInr,
    coupon: q.coupon, couponDiscount: q.couponDiscountInr, karmaUsed: q.karmaPointsUsed, karmaDiscount: q.karmaDiscountInr,
    fee: q.feeInr, paid: q.payableInr, method,
  });

  earnKarma(input.userId, Math.floor(q.payableInr / POLICY.karma.perRupees), 'booking', `${venue.name} · ${input.date}`, `booking:${booking.id}`);
  const user = users.byId(input.userId)!;
  notify(user.id, 'booking_confirmed', { bookingId: booking.id, venue: venue.name, date: input.date, slots: q.slots.map((s) => s.time), paid: q.payableInr });
  if (venue.ownerId && venue.ownerId !== user.id) {
    notify(venue.ownerId, 'owner_booking', { bookingId: booking.id, venue: venue.name, venueId: venue.id, date: input.date, slots: q.slots.map((s) => s.time), paid: q.payableInr, actor: summaryOf(user.id) });
    hub.sendTo(venue.ownerId, { type: 'refresh', what: 'owner' });
  }
  rewardReferrerIfFirstBooking(user);
  hub.sendTo(user.id, { type: 'refresh', what: 'wallet' });
  return booking;
}

export function cancelBooking(userId: number, bookingId: number) {
  const b = bookings.byId(bookingId);
  if (!b || b.user_id !== userId) throw new HttpError(404, 'Booking not found');
  if (b.status === 'attended') throw new HttpError(409, 'You already attended this booking');
  const hours = hoursUntil(b.starts_at);
  if (hours <= 0) throw new HttpError(409, 'This booking has already started');

  const pct = refundPercent(hours, isPlus(userId));
  const cashBack = Math.round((b.paid * pct) / 100);
  const karmaBack = Math.round((b.karma_used * pct) / 100);
  bookings.remove(b.id);
  refundToWallet(userId, cashBack, 'refund', `Cancelled booking #${b.id} (${pct}% refund)`);
  if (karmaBack > 0) karma.add(userId, karmaBack, 'refund', `Cancelled booking #${b.id}`, `booking:${b.id}`);
  if (b.pass_id && pct > 0) {
    const pass = passes.byId(b.pass_id);
    if (pass?.kind === 'monthly') passes.addHours(pass.id, JSON.parse(b.slots).length);
  }
  // Karma earned from this booking goes back (as far as the balance allows)
  const earned = karma.earnedFor(userId, `booking:${b.id}`);
  const reverse = Math.min(earned, Math.max(0, karma.balance(userId)));
  if (reverse > 0) karma.add(userId, -reverse, 'reversal', `Cancelled booking #${b.id}`, `booking:${b.id}`);

  const v = catalog.find(b.venue_id);
  notify(userId, 'booking_cancelled', { bookingId: b.id, refunded: cashBack, percent: pct });
  if (v?.ownerId && v.ownerId !== userId) hub.sendTo(v.ownerId, { type: 'refresh', what: 'owner' });
  hub.sendTo(userId, { type: 'refresh', what: 'wallet' });
  return { refunded: cashBack, percent: pct, karmaRefunded: karmaBack };
}

/** Move a booking to other slots at the same venue; the difference in slot price goes through the wallet */
export function rescheduleBooking(userId: number, bookingId: number, date: string, slots: string[], simulateDecline: boolean) {
  const b = bookings.byId(bookingId);
  if (!b || b.user_id !== userId) throw new HttpError(404, 'Booking not found');
  if (b.status !== 'confirmed') throw new HttpError(409, 'Only a confirmed booking can be moved');
  if (hoursUntil(b.starts_at) < POLICY.rescheduleUntilHoursBefore) throw new HttpError(409, `A booking can be moved until ${POLICY.rescheduleUntilHoursBefore} hours before it starts`);
  const venue = catalog.find(b.venue_id);
  if (!venue || !date || !slots?.length) throw new HttpError(400, 'Pick a day and slots');

  const oldCount = (JSON.parse(b.slots) as string[]).length;
  const unique = [...new Set(slots)].sort();
  if (b.pass_id) {
    const pass = passes.byId(b.pass_id)!;
    if (unique.length !== oldCount) throw new HttpError(409, 'A booking paid with a pass has to keep the same number of hours');
    const problem = pass.kind === 'daily' ? (pass.valid_date === date ? null : `That day pass is for ${pass.valid_date}`) : null;
    if (problem) throw new HttpError(409, problem);
  }
  assertSlotsFree(venue, date, unique, b.id);

  const newSlotsInr = b.pass_id ? b.slots_inr : unique.reduce((s, t) => s + slotPrice(venue, hourOf(t)), 0);
  const diff = b.pass_id ? 0 : newSlotsInr - b.slots_inr;
  if (diff > 0) charge({ userId, amountInr: diff, method: 'wallet', kind: 'reschedule', note: `Moved booking #${b.id}`, reference: `resched_${b.id}`, simulateDecline });
  else if (diff < 0) refundToWallet(userId, -diff, 'refund', `Moved booking #${b.id} to cheaper slots`);

  bookings.move(b.id, date, unique, slotStart(date, unique[0]).getTime(), newSlotsInr, b.extras_inr);
  if (diff !== 0 && !b.pass_id) db_setPaid(b.id, b.paid + diff);
  notify(userId, 'booking_rescheduled', { bookingId: b.id, venue: venue.name, date, slots: unique, difference: diff });
  hub.sendTo(userId, { type: 'refresh', what: 'wallet' });
  return bookings.byId(b.id)!;
}

import { db } from '../db/connection';
const db_setPaid = (id: number, paid: number) => db.run('UPDATE bookings SET paid = ? WHERE id = ?', [paid, id]);

void wallet;
void checkPass;
