import { BOTS } from '../data/bots';
import type { ChatRow, GameRow, MessageRow, UserRow } from '../db/rows';
import { hub } from '../realtime/hub';
import { chats } from '../repositories/chats';
import { games } from '../repositories/games';
import { follows, friendships } from '../repositories/social';
import { users } from '../repositories/users';
import { sendMessage, pushChat } from './chat';
import { decideRequest, endGame, levelOf } from './games';
import { notify } from './notify';
import { summaryOf } from './people';

/**
 * The demo players act like people: they accept requests, reply in chat, join and end games.
 * Everything is delayed, so the UI's live updates can be seen.
 */
const later = (ms: number, fn: () => void) =>
  setTimeout(() => {
    try {
      fn();
    } catch (e) {
      console.error('[bot]', e);
    }
  }, ms);

const pick = <T,>(list: T[]) => list[Math.floor(Math.random() * list.length)];
const botSpec = (u: UserRow) => BOTS.find((b) => b.username === u.username);

/** Someone asked a demo player to be friends */
export function botsReactToFriendRequest(requestId: number, from: UserRow, to: UserRow) {
  if (to.is_bot !== 1) return;
  later(2500, () => {
    const row = friendships.byId(requestId);
    if (!row || row.status !== 'pending') return;
    if (botSpec(to)?.declinesFriends) {
      friendships.remove(requestId);
      notify(from.id, 'friend_declined', { actor: summaryOf(to.id) });
    } else {
      friendships.accept(requestId);
      notify(from.id, 'friend_accepted', { actor: summaryOf(to.id) });
      // say hello in a new chat
      const chat = chats.direct(from.id, to.id) ?? chats.create({ kind: 'direct', createdBy: to.id, memberIds: [from.id, to.id] });
      pushChat(chat.id);
      later(800, () => sendMessage(chat, to.id, `Hey ${from.name.split(' ')[0]}! Thanks for adding me 👋`, null));
    }
    hub.sendTo(from.id, { type: 'refresh', what: 'friends' });
  });
}

/** Someone asked to follow a private demo player */
export function botsReactToFollowRequest(follower: UserRow, followee: UserRow) {
  if (followee.is_bot !== 1) return;
  later(3000, () => {
    const row = follows.get(follower.id, followee.id);
    if (!row || row.status !== 'pending') return;
    follows.accept(follower.id, followee.id);
    notify(follower.id, 'follow_accepted', { actor: summaryOf(followee.id) });
    hub.sendTo(follower.id, { type: 'refresh', what: 'friends' });
    hub.sendTo(follower.id, { type: 'refresh', what: 'player' });
  });
}

const REPLIES: [RegExp, string[]][] = [
  [/\b(hi|hello|hey)\b/i, ['Hey! 👋', 'Hello! How are you?', 'Hi there!']],
  [/\b(game|play|match)\b/i, ['I\'m free this weekend, want to host a game?', 'Count me in for the next one 🙌', 'Let\'s play soon!']],
  [/\b(when|time|where)\b/i, ['Evening works for me, after 6.', 'Anywhere in Indiranagar is fine.', 'Let\'s see what\'s open on the venues page.']],
  [/\?/, ['Good question, let me think 🤔', 'Not sure, what do you think?', 'Probably yes!']],
  [/\b(thanks|thank you)\b/i, ['Anytime!', 'No problem 😊']],
];
const FALLBACK = ['Sounds good!', '👍', 'Haha nice', 'Same here', 'Cool, let\'s do it'];

/** A message was sent in a chat: demo players in it may type and answer */
export function botsReactToMessage(chat: ChatRow, message: MessageRow) {
  const sender = users.byId(message.sender_id);
  if (!sender || sender.is_bot === 1) return;
  const members = chats.memberIds(chat.id).map((id) => users.byId(id)).filter((u): u is UserRow => !!u);
  const bots = members.filter((u) => u.is_bot === 1);
  if (bots.length === 0) return;
  // In a group only one answers; the others stay quiet
  const replier = chat.kind === 'direct' ? bots[0] : pick(bots);
  const human = members.filter((u) => u.is_bot === 0).map((u) => u.id);

  later(600, () => hub.sendToMany(human, { type: 'typing', chatId: chat.id, userId: replier.id }));
  later(1800, () => {
    // the demo player "reads" the message first
    chats.setRead(chat.id, replier.id, message.id);
    hub.sendToMany(human, { type: 'read', chatId: chat.id, userId: replier.id, upTo: message.id });
    const rule = REPLIES.find(([re]) => re.test(message.body));
    sendMessage(chat, replier.id, pick(rule ? rule[1] : FALLBACK), null);
  });
}

/** Someone created or joined a game: demo players join the user's game, or the demo host ends theirs */
export function botsReactToJoin(game: GameRow, user: UserRow, how: 'hosted' | 'joined') {
  if (user.is_bot === 1) return;

  if (how === 'hosted') {
    // Demo players only turn up to public games, are not charged, and respect the host's skill limit
    if (game.visibility === 'private') return;
    const rank: Record<string, number> = { Beginner: 0, Intermediate: 1, Advanced: 2 };
    const candidates = users.bots().filter(
      (b) => (b.city === game.city || b.city === user.city) && (!game.min_level || rank[levelOf(b.id, game.sport)] >= rank[game.min_level])
    );
    for (const [i, bot] of candidates.slice(0, 2).entries()) {
      later(4000 + i * 2500, () => {
        const g = games.byId(game.id);
        if (!g || g.status !== 'open' || games.playerCount(g.id) >= g.capacity || games.isPlayer(g.id, bot.id)) return;
        if (g.join_mode === 'approval') {
          // they ask, and the (human) host decides
          if (games.requestFor(g.id, bot.id)) return;
          games.createRequest(g.id, bot.id, 0, 0);
          notify(g.host_id, 'game_join_request', { gameId: g.id, title: g.title, actor: summaryOf(bot.id), level: levelOf(bot.id, g.sport) });
          hub.sendTo(g.host_id, { type: 'refresh', what: 'games' });
          return;
        }
        games.join(g.id, bot.id, bot.name);
        const chat = chats.byGame(g.id);
        if (chat) {
          chats.addMember(chat.id, bot.id);
          pushChat(chat.id);
        }
        notify(g.host_id, 'game_joined', { gameId: g.id, title: g.title, actor: summaryOf(bot.id) });
        hub.sendToMany(games.players(g.id).map((p) => p.user_id), { type: 'refresh', what: 'games' });
      });
    }
    return;
  }

  // The user joined a game hosted by a demo player: the host ends it soon, with a result
  const host = users.byId(game.host_id);
  if (host?.is_bot === 1) {
    later(10_000, () => {
      const g = games.byId(game.id);
      if (!g || g.status !== 'open') return;
      const ids = games.players(g.id).map((p) => p.user_id);
      endGame(g, [pick(ids)]);
    });
  }
}

/** Someone asked to join a game a demo player hosts: they say yes after a moment */
export function botsReactToJoinRequest(game: GameRow, requester: UserRow) {
  const host = users.byId(game.host_id);
  if (!host || host.is_bot !== 1 || requester.is_bot === 1) return;
  later(3000, () => {
    const g = games.byId(game.id);
    if (!g || g.status !== 'open') return;
    try {
      decideRequest(g, host, requester.id, true);
    } catch {
      // full, or already decided: nothing to do
    }
  });
}

/** Someone was added to a group chat with demo players in it */
export function botsReactToGroup(chat: ChatRow, addedBy: UserRow) {
  const bots = chats.memberIds(chat.id).map((id) => users.byId(id)).filter((u): u is UserRow => !!u && u.is_bot === 1);
  if (bots.length === 0) return;
  later(1500, () => sendMessage(chat, pick(bots).id, `Hi all! Thanks for adding us, ${addedBy.name.split(' ')[0]} 🙌`, null));
}

/** First login: a demo player says hello, asks to be friends, and another follows */
export function welcomeNewUser(user: UserRow) {
  const aarav = users.byUsername('aarav_k');
  const diya = users.byUsername('diya_s');
  if (aarav) {
    later(4000, () => {
      if (friendships.between(aarav.id, user.id)) return;
      const req = friendships.request(aarav.id, user.id);
      notify(user.id, 'friend_request', { requestId: req.id, actor: summaryOf(aarav.id) });
      hub.sendTo(user.id, { type: 'refresh', what: 'friends' });
    });
  }
  if (diya) {
    later(7000, () => {
      follows.create(diya.id, user.id, user.is_private === 1 ? 'pending' : 'accepted');
      notify(user.id, user.is_private === 1 ? 'follow_request' : 'new_follower', { actor: summaryOf(diya.id) });
      hub.sendTo(user.id, { type: 'refresh', what: 'followRequests' });
    });
  }
}
