import { CITY_INFO, toInr } from '../data/currency';
import { STATIC_VENUES, type Venue } from '../data/venues';
import { owners } from '../repositories/owners';

export interface CatalogVenue extends Venue { ownerId: number | null; custom: boolean }

/** The data an owner gives when listing a new venue */
export interface NewVenueInput {
  name: string; city: string; area: string; sports: string[]; pricePerHourLocal: number;
  amenities: string[]; address: string; description: string;
}

const equipmentFor = (sports: string[], tier: number): Venue['equipment'] => {
  const base: Record<string, [string, number][]> = {
    badminton: [['Racket', 50]], football: [['Ball', 60]], cricket: [['Bat', 80]], tennis: [['Racket', 80]], basketball: [['Ball', 50]],
    swimming: [['Goggles', 30]], tabletennis: [['Bat', 30]], pickleball: [['Paddle', 60]], padel: [['Racket', 120]],
  };
  return sports.flatMap((s) => (base[s] ?? []).map(([n, p]) => ({ id: `${s}:${n}`, name: n, priceInr: p * tier })));
};

function fromCustom(id: number, data: NewVenueInput): Venue {
  const info = CITY_INFO[data.city];
  const priceInr = Math.round(toInr(data.pricePerHourLocal, info.currency) / 10) * 10;
  const jitter = (k: number) => (((Math.imul(id, 2654435761) >>> (k * 8)) & 255) / 255 - 0.5) * 0.12;
  return {
    id, name: data.name, city: data.city, area: data.area, sports: data.sports,
    pricePerHour: priceInr, peakExtra: Math.max(100, Math.round((priceInr * 0.15) / 10) * 10),
    currency: info.currency, pricePerHourLocal: data.pricePerHourLocal,
    rating: 0, reviews: 0,
    image: `https://picsum.photos/seed/playo-c${id}/640/360`,
    images: Array.from({ length: 3 }, (_, k) => `https://picsum.photos/seed/playo-c${id}-${k}/960/540`),
    amenities: data.amenities, address: data.address, description: data.description,
    lat: Math.round((info.lat + jitter(0)) * 10000) / 10000, lng: Math.round((info.lng + jitter(1)) * 10000) / 10000,
    equipment: equipmentFor(data.sports, info.currency === 'INR' ? 1 : 8),
  };
}

/**
 * Every venue: the built-in ones plus venues owners listed, with the owners' price changes applied.
 * Everything that needs a venue asks here, never the static list directly.
 */
export const catalog = {
  list(): CatalogVenue[] {
    const over = new Map(owners.overrides().map((o) => [o.venue_id, o]));
    const ownerIds = owners.allOwners();
    const customs = owners.customVenues().map((r) => ({ v: fromCustom(100_000 + r.id, JSON.parse(r.data)), custom: true }));
    return [...STATIC_VENUES.map((v) => ({ v, custom: false })), ...customs].map(({ v, custom }) => {
      const o = over.get(v.id);
      const price = o?.price_inr ?? v.pricePerHour;
      const info = CITY_INFO[v.city];
      return {
        ...v,
        pricePerHour: price,
        peakExtra: o?.peak_extra ?? v.peakExtra,
        pricePerHourLocal: o?.price_inr ? Math.round(price / (info.currency === 'INR' ? 1 : toInr(1, info.currency))) : v.pricePerHourLocal,
        ownerId: ownerIds.get(v.id) ?? null,
        custom,
      };
    });
  },
  find(id: number): CatalogVenue | undefined {
    return catalog.list().find((v) => v.id === id);
  },
};
