import type { ChatRow, GameRow, MessageRow } from '../db/rows';
import { hub } from '../realtime/hub';
import { chats } from '../repositories/chats';
import { blocks } from '../repositories/safety';
import { games } from '../repositories/games';
import { summaryOf } from './people';
import { botsReactToMessage } from './bots';

export const messageOut = (m: MessageRow) => ({
  id: m.id, chatId: m.chat_id, senderId: m.sender_id, body: m.body, image: m.image, createdAt: m.created_at,
});

export function chatOut(chat: ChatRow, viewerId: number) {
  const last = chats.lastMessage(chat.id);
  const members = chats.members(chat.id);
  return {
    id: chat.id, kind: chat.kind, title: chat.title, gameId: chat.game_id, createdBy: chat.created_by,
    members: members.map((m) => summaryOf(m.user_id)).filter((p) => p !== null),
    reads: Object.fromEntries(members.map((m) => [m.user_id, m.last_read_id])),
    lastMessage: last ? messageOut(last) : null,
    unread: chats.unread(chat.id, viewerId),
  };
}

/** Tells every member's open tabs that this chat changed (new chat, members added or removed) */
export function pushChat(chatId: number, extraUserIds: number[] = []) {
  hub.sendToMany([...chats.memberIds(chatId), ...extraUserIds], { type: 'chat', chatId });
}

export function sendMessage(chat: ChatRow, senderId: number, body: string, image: string | null) {
  const row = chats.insertMessage(chat.id, senderId, body, image);
  const message = messageOut(row);
  // people who blocked the sender (or were blocked by them) are not sent it live
  hub.sendToMany(chats.memberIds(chat.id).filter((id) => id === senderId || !blocks.either(id, senderId)), { type: 'message', message });
  botsReactToMessage(chat, row);
  return message;
}

/** The chat every game has: its players are the members */
export function ensureGameChat(game: GameRow) {
  const existing = chats.byGame(game.id);
  if (existing) return existing;
  return chats.create({
    kind: 'game', title: game.title, gameId: game.id, createdBy: game.host_id,
    memberIds: games.players(game.id).map((p) => p.user_id),
  });
}
