import { CITY_INFO } from '../data/currency';
import { STATIC_EVENTS, type SportEvent } from '../data/events';
import { HttpError } from '../lib/http';
import { hub } from '../realtime/hub';
import { customEvents, eventRegs } from '../repositories/learning';
import { karma } from '../repositories/money';
import { users } from '../repositories/users';
import { earnKarma, karmaForSpend } from './karma';
import { isPlus } from './membership';
import { notify } from './notify';
import { applyKarma, charge, refundToWallet, requireMethod } from './payments';
import { hoursUntil, refundPercent } from './policy';
import { filterText } from './safety';

interface CustomData { title: string; city: string; startsAt: string; place: string; description: string; feeInr: number; capacity: number; sport?: string; hostName: string }

export function allEvents(): SportEvent[] {
  const custom = customEvents.list().map(
    (r): SportEvent => {
      const d = JSON.parse(r.data) as CustomData;
      return { id: 100_000 + r.id, type: 'meetup', title: d.title, city: d.city, startsAt: d.startsAt, place: d.place, description: d.description, feeInr: d.feeInr, capacity: d.capacity, hostName: d.hostName, hostId: r.host_id, sport: d.sport };
    }
  );
  return [...STATIC_EVENTS, ...custom];
}
export const findEvent = (id: number) => allEvents().find((e) => e.id === id);

export function eventOut(e: SportEvent, viewerId: number | null, withParticipants = false) {
  const going = eventRegs.count(e.id);
  const mine = viewerId ? eventRegs.byEventUser(e.id, viewerId) : null;
  const startsAt = Date.parse(e.startsAt);
  const active = mine && mine.status !== 'cancelled' ? mine : null;
  return {
    ...e, going, spotsLeft: Math.max(0, e.capacity - going), currency: CITY_INFO[e.city]?.currency ?? 'INR',
    mine: active ? { status: active.status, category: active.category, bib: active.bib, paid: active.paid, refundPercent: startsAt > Date.now() ? refundPercent(hoursUntil(startsAt), isPlus(viewerId!)) : 0 } : null,
    isHost: viewerId !== null && e.hostId === viewerId,
    past: startsAt <= Date.now(),
    participants: withParticipants
      ? eventRegs.forEvent(e.id).map((r) => {
          const u = users.byId(r.user_id)!;
          return { id: u.id, name: u.name, username: u.username, avatarEmoji: u.avatar_emoji, avatarColor: u.avatar_color, bib: r.bib, category: r.category, status: r.status };
        })
      : undefined,
  };
}

export function registerForEvent(opts: { userId: number; eventId: number; category?: string; answer?: string; method: unknown; karmaPoints: number; simulateDecline: boolean }) {
  const e = findEvent(opts.eventId);
  if (!e) throw new HttpError(404, 'Event not found');
  if (Date.parse(e.startsAt) <= Date.now()) throw new HttpError(409, 'This event has already started');
  const existing = eventRegs.byEventUser(e.id, opts.userId);
  const answer = e.type === 'meetup' && opts.answer === 'maybe' ? 'maybe' : 'going';

  let fee = e.feeInr;
  let category: string | null = null;
  if (e.type === 'marathon') {
    const c = e.categories?.find((x) => x.id === opts.category);
    if (!c) throw new HttpError(400, 'Choose a distance');
    category = c.id;
    fee = c.feeInr;
  }
  const alreadyPaid = existing && existing.status === 'going' ? existing.paid : 0;
  if (existing?.status === 'going' && answer === 'going') throw new HttpError(409, 'You are already registered');
  if (answer === 'going' && eventRegs.count(e.id) >= e.capacity) throw new HttpError(409, 'This event is full');

  let paid = alreadyPaid;
  if (answer === 'going' && fee > 0) {
    const k = applyKarma(opts.userId, fee, opts.karmaPoints);
    paid = fee - k.discountInr;
    charge({ userId: opts.userId, amountInr: paid, method: requireMethod(opts.method), kind: 'event', note: e.title, reference: `event_${e.id}`, simulateDecline: opts.simulateDecline });
    if (k.pointsUsed > 0) karma.add(opts.userId, -k.pointsUsed, 'redeem', e.title, `event:${e.id}`);
    earnKarma(opts.userId, karmaForSpend(paid), 'purchase', e.title, `event:${e.id}:${opts.userId}`);
  }
  const bib = e.type === 'marathon' && answer === 'going' ? eventRegs.nextBib(e.id) : null;
  const reg = eventRegs.upsert({ eventId: e.id, userId: opts.userId, category, bib, paid, status: answer });
  if (e.hostId && e.hostId !== opts.userId) notify(e.hostId, 'event_rsvp', { eventId: e.id, title: e.title, answer });
  if (answer === 'going') notify(opts.userId, 'event_registered', { eventId: e.id, title: e.title, bib: reg.bib });
  hub.sendToMany([opts.userId], { type: 'refresh', what: 'events' });
  hub.sendTo(opts.userId, { type: 'refresh', what: 'wallet' });
  return reg;
}

export function cancelRegistration(userId: number, eventId: number) {
  const e = findEvent(eventId);
  const reg = eventRegs.byEventUser(eventId, userId);
  if (!e || !reg || reg.status === 'cancelled') throw new HttpError(404, 'You are not registered');
  const hours = hoursUntil(Date.parse(e.startsAt));
  if (hours <= 0) throw new HttpError(409, 'This event has already started');
  const pct = refundPercent(hours, isPlus(userId));
  eventRegs.cancel(eventId, userId);
  const refund = Math.round((reg.paid * pct) / 100);
  refundToWallet(userId, refund, 'refund', `Cancelled: ${e.title}`);
  hub.sendTo(userId, { type: 'refresh', what: 'events' });
  hub.sendTo(userId, { type: 'refresh', what: 'wallet' });
  return { percent: pct, refunded: refund };
}

export function createMeetup(host: { id: number; name: string }, b: Partial<CustomData>) {
  const title = b.title?.trim();
  if (!title || title.length > 60) throw new HttpError(400, 'Give the meet-up a name (up to 60 characters)');
  if (!b.city || !CITY_INFO[b.city]) throw new HttpError(400, 'Pick a city');
  if (!b.startsAt || Date.parse(b.startsAt) <= Date.now()) throw new HttpError(400, 'Pick a start time in the future');
  if (!b.place?.trim()) throw new HttpError(400, 'Where is it?');
  const fee = b.feeInr ?? 0;
  if (!Number.isInteger(fee) || fee < 0 || fee > 5000) throw new HttpError(400, 'The fee is ₹0 to ₹5,000');
  const capacity = b.capacity ?? 20;
  if (!Number.isInteger(capacity) || capacity < 2 || capacity > 200) throw new HttpError(400, 'A meet-up has 2 to 200 places');
  const id = customEvents.add(host.id, {
    title: filterText(title), city: b.city, startsAt: b.startsAt, place: filterText(b.place.trim()), description: filterText((b.description ?? '').slice(0, 500)),
    feeInr: fee, capacity, sport: b.sport, hostName: host.name,
  } satisfies CustomData);
  eventRegs.upsert({ eventId: id, userId: host.id, category: null, bib: null, paid: 0, status: 'going' });
  return id;
}
