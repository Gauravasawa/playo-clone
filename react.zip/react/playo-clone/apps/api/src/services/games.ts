import type { GameRow, UserRow } from '../db/rows';
import { HttpError } from '../lib/http';
import { hub } from '../realtime/hub';
import { chats } from '../repositories/chats';
import { games } from '../repositories/games';
import { karma } from '../repositories/money';
import { friendships } from '../repositories/social';
import { users } from '../repositories/users';
import { botsReactToJoin, botsReactToJoinRequest } from './bots';
import { catalog } from './catalog';
import { ensureGameChat, pushChat } from './chat';
import { earnKarma } from './karma';
import { notify } from './notify';
import { applyKarma, charge, refundToWallet, requireMethod } from './payments';
import { summaryOf } from './people';
import { hoursUntil, POLICY } from './policy';
import { wallet } from '../repositories/money';

const LEVEL: Record<string, number> = { Beginner: 0, Intermediate: 1, Advanced: 2 };
export const levelOf = (userId: number, sport: string) => users.sports(userId).find((s) => s.sport === sport)?.level ?? 'Beginner';
const startOf = (g: GameRow) => Date.parse(g.starts_at);

/** What a viewer may do with a game, and what they're allowed to see of it */
function relation(g: GameRow, viewerId: number | null) {
  const isHost = viewerId === g.host_id;
  const isPlayer = viewerId !== null && games.isPlayer(g.id, viewerId);
  return { isHost, isPlayer, invited: viewerId !== null && games.isInvited(g.id, viewerId) };
}

/** Public games are visible to everyone; a private one only to its host, players and invitees */
export function canSee(g: GameRow, viewerId: number | null) {
  if (g.visibility === 'public') return true;
  const r = relation(g, viewerId);
  return r.isHost || r.isPlayer || r.invited;
}

export function gameOut(g: GameRow, viewerId: number | null = null) {
  const venue = catalog.find(g.venue_id);
  const rel = relation(g, viewerId);
  const rsvps = games.rsvps(g.id);
  const myRequest = viewerId ? games.requestFor(g.id, viewerId) : null;
  return {
    id: g.id, title: g.title, sport: g.sport, city: g.city, hostName: g.host_name, hostId: g.host_id,
    startsAt: g.starts_at, capacity: g.capacity, level: g.level, status: g.status, endedAt: g.ended_at,
    joinMode: g.join_mode, visibility: g.visibility, minLevel: g.min_level, priceInr: g.price_inr,
    inviteCode: rel.isHost || rel.isPlayer ? g.invite_code : null,
    chatId: chats.byGame(g.id)?.id ?? null,
    venue: venue ? { id: venue.id, name: venue.name, area: venue.area, currency: venue.currency } : null,
    players: games.players(g.id).map((p) => ({
      id: p.user_id, name: p.name, username: summaryOf(p.user_id)?.username ?? '', won: p.won === 1,
      attended: p.attended === null ? null : p.attended === 1, paidInr: rel.isHost ? p.paid_inr : undefined,
    })),
    rsvp: {
      going: rsvps.filter((r) => r.answer === 'going').length, maybe: rsvps.filter((r) => r.answer === 'maybe').length, no: rsvps.filter((r) => r.answer === 'no').length,
      mine: viewerId ? rsvps.find((r) => r.user_id === viewerId)?.answer ?? null : null,
    },
    requests: rel.isHost
      ? games.requests(g.id).map((r) => ({ id: r.id, player: summaryOf(r.user_id), level: levelOf(r.user_id, g.sport), paidInr: r.paid_inr, createdAt: r.created_at }))
      : undefined,
    me: { isHost: rel.isHost, isPlayer: rel.isPlayer, invited: rel.invited, request: myRequest?.status ?? null },
  };
}

/** A game was created: it gets its chat, and demo players may show up */
export function afterGameCreated(game: GameRow, host: UserRow) {
  ensureGameChat(game);
  pushChat(chats.byGame(game.id)!.id);
  botsReactToJoin(game, host, 'hosted');
}

const refreshGame = (g: GameRow, extra: number[] = []) =>
  hub.sendToMany([...games.players(g.id).map((p) => p.user_id), g.host_id, ...extra], { type: 'refresh', what: 'games' });

/** Someone is now in the game: add them to its chat and tell the others */
function completeJoin(g: GameRow, user: UserRow, paidInr: number, karmaUsed: number) {
  games.join(g.id, user.id, user.name, paidInr, karmaUsed);
  const chat = ensureGameChat(g);
  chats.addMember(chat.id, user.id);
  pushChat(chat.id);
  if (g.host_id !== user.id) notify(g.host_id, 'game_joined', { gameId: g.id, title: g.title, actor: summaryOf(user.id) });
  refreshGame(g);
  botsReactToJoin(g, user, 'joined');
}

export interface JoinOptions { method?: unknown; karmaPoints?: number; code?: string; simulateDecline: boolean }

/** What has to be true before this person can join (or ask to join) */
function assertCanJoin(g: GameRow, user: UserRow, code?: string) {
  if (g.status !== 'open') throw new HttpError(409, 'This game has ended');
  if (startOf(g) <= Date.now()) throw new HttpError(409, 'This game has already started');
  if (games.isPlayer(g.id, user.id)) throw new HttpError(409, 'You are already in this game');
  if (g.visibility === 'private' && !canSee(g, user.id) && code?.trim().toUpperCase() !== g.invite_code) {
    throw new HttpError(403, 'This is a private game. You need an invite or its code.');
  }
  if (g.min_level) {
    const mine = levelOf(user.id, g.sport);
    if (LEVEL[mine] < LEVEL[g.min_level]) throw new HttpError(403, `This game is for ${g.min_level} level or above. Your ${g.sport} level is ${mine}. Change it on your profile.`);
  }
}

export function joinGame(g: GameRow, user: UserRow, o: JoinOptions) {
  assertCanJoin(g, user, o.code);
  const invited = games.isInvited(g.id, user.id);
  const needsApproval = g.join_mode === 'approval' && !invited && g.host_id !== user.id;
  if (needsApproval && games.requestFor(g.id, user.id)?.status === 'pending') throw new HttpError(409, 'You already asked to join. Waiting for the host.');
  if (!needsApproval && games.playerCount(g.id) >= g.capacity) throw new HttpError(409, 'This game is full');

  // The price is paid now; for an approval game it is held until the host decides
  let paidInr = 0, karmaUsed = 0;
  if (g.price_inr > 0) {
    const method = requireMethod(o.method);
    const k = applyKarma(user.id, g.price_inr, o.karmaPoints ?? 0);
    paidInr = g.price_inr - k.discountInr;
    charge({ userId: user.id, amountInr: paidInr, method, kind: 'game', note: `Game: ${g.title}`, reference: `game_${g.id}`, simulateDecline: o.simulateDecline });
    if (k.pointsUsed > 0) karma.add(user.id, -k.pointsUsed, 'redeem', `Game: ${g.title}`, `game:${g.id}`);
    karmaUsed = k.pointsUsed;
  }

  if (needsApproval) {
    games.createRequest(g.id, user.id, paidInr, karmaUsed);
    notify(g.host_id, 'game_join_request', { gameId: g.id, title: g.title, actor: summaryOf(user.id), level: levelOf(user.id, g.sport) });
    hub.sendToMany([g.host_id, user.id], { type: 'refresh', what: 'games' });
    botsReactToJoinRequest(g, user);
    return { joined: false, pending: true };
  }
  completeJoin(g, user, paidInr, karmaUsed);
  return { joined: true, pending: false };
}

/** Gives back what a request or a player paid */
function refundGamePayment(userId: number, paidInr: number, karmaUsed: number, g: GameRow) {
  refundToWallet(userId, paidInr, 'refund', `Game: ${g.title}`);
  if (karmaUsed > 0) karma.add(userId, karmaUsed, 'refund', `Game: ${g.title}`, `game:${g.id}`);
}

export function decideRequest(g: GameRow, host: UserRow, requesterId: number, approve: boolean) {
  if (g.host_id !== host.id) throw new HttpError(403, 'Only the host decides');
  const req = games.requestFor(g.id, requesterId);
  if (!req || req.status !== 'pending') throw new HttpError(404, 'Request not found');
  const requester = users.byId(requesterId)!;
  if (approve) {
    if (g.status !== 'open') throw new HttpError(409, 'This game has ended');
    if (games.playerCount(g.id) >= g.capacity) throw new HttpError(409, 'This game is full');
    games.setRequestStatus(req.id, 'approved');
    completeJoin(g, requester, req.paid_inr, req.karma_used);
    notify(requester.id, 'game_request_approved', { gameId: g.id, title: g.title, actor: summaryOf(host.id) });
  } else {
    games.setRequestStatus(req.id, 'declined');
    refundGamePayment(requester.id, req.paid_inr, req.karma_used, g);
    notify(requester.id, 'game_request_declined', { gameId: g.id, title: g.title, refunded: req.paid_inr, actor: summaryOf(host.id) });
  }
  hub.sendToMany([host.id, requester.id], { type: 'refresh', what: 'games' });
  hub.sendTo(requester.id, { type: 'refresh', what: 'wallet' });
}

/** The requester changed their mind */
export function cancelRequest(g: GameRow, user: UserRow) {
  const req = games.requestFor(g.id, user.id);
  if (!req || req.status !== 'pending') throw new HttpError(404, 'No pending request');
  games.setRequestStatus(req.id, 'declined');
  refundGamePayment(user.id, req.paid_inr, req.karma_used, g);
  hub.sendToMany([g.host_id, user.id], { type: 'refresh', what: 'games' });
  hub.sendTo(user.id, { type: 'refresh', what: 'wallet' });
}

export function leaveGame(g: GameRow, user: UserRow) {
  if (g.host_id === user.id) throw new HttpError(409, 'The host can end the game, not leave it');
  if (g.status !== 'open') throw new HttpError(409, 'This game has ended');
  const me = games.players(g.id).find((p) => p.user_id === user.id);
  if (!me) throw new HttpError(404, 'You are not in this game');
  games.leave(g.id, user.id);
  // Leaving early gives the money back; leaving late doesn't
  const early = hoursUntil(startOf(g)) >= POLICY.gameLeaveRefundHoursBefore;
  if (early && (me.paid_inr > 0 || me.karma_used > 0)) refundGamePayment(user.id, me.paid_inr, me.karma_used, g);
  const chat = chats.byGame(g.id);
  if (chat) {
    chats.removeMember(chat.id, user.id);
    pushChat(chat.id, [user.id]);
  }
  refreshGame(g, [user.id]);
  hub.sendTo(user.id, { type: 'refresh', what: 'wallet' });
  return { refunded: early ? me.paid_inr : 0, early };
}

export function inviteToGame(g: GameRow, inviter: UserRow, userIds: number[]) {
  if (!games.isPlayer(g.id, inviter.id)) throw new HttpError(403, 'Only players can invite');
  if (g.status !== 'open') throw new HttpError(409, 'This game has ended');
  const sent: number[] = [];
  for (const id of new Set(userIds)) {
    if (id === inviter.id || games.isPlayer(g.id, id)) continue;
    if (friendships.between(inviter.id, id)?.status !== 'accepted' && !games.hasPlayedWith(inviter.id, id)) throw new HttpError(403, 'You can invite friends or players you have played with');
    games.invite(g.id, id, inviter.id);
    notify(id, 'game_invite', { gameId: g.id, title: g.title, inviteCode: g.invite_code, actor: summaryOf(inviter.id) });
    sent.push(id);
  }
  if (sent.length === 0) throw new HttpError(400, 'Pick friends who are not in the game yet');
  return sent;
}

export function setRsvp(g: GameRow, user: UserRow, answer: string) {
  if (!games.isPlayer(g.id, user.id)) throw new HttpError(403, 'Join the game to answer');
  if (!['going', 'maybe', 'no'].includes(answer)) throw new HttpError(400, 'Answer going, maybe or no');
  games.setRsvp(g.id, user.id, answer);
  refreshGame(g);
}

/** Ends a game: records winners and who showed up, pays the host, and tells everyone */
export function endGame(game: GameRow, winnerIds: number[], attendedIds?: number[]) {
  const players = games.players(game.id);
  const all = players.map((p) => p.user_id);
  const attended = attendedIds ? all.filter((id) => attendedIds.includes(id) || id === game.host_id) : all;
  games.end(game.id, winnerIds.filter((w) => attended.includes(w)));
  games.setAttendance(game.id, attended);

  // The host receives what the players paid
  const collected = players.filter((p) => p.user_id !== game.host_id).reduce((s, p) => s + p.paid_inr, 0);
  if (collected > 0 && game.paid_out === 0) {
    wallet.adjust(game.host_id, collected, 'game_payout', `Players of “${game.title}”`);
    games.markPaidOut(game.id);
    hub.sendTo(game.host_id, { type: 'refresh', what: 'wallet' });
  }

  for (const p of players) {
    const showed = attended.includes(p.user_id);
    if (showed) earnKarma(p.user_id, POLICY.karma.game, 'game', `Played “${game.title}”`, `game:${game.id}`);
    notify(p.user_id, 'game_ended', { gameId: game.id, title: game.title, winnerIds, won: winnerIds.includes(p.user_id) && showed, attended: showed });
    hub.sendTo(p.user_id, { type: 'refresh', what: 'games' });
    hub.sendTo(p.user_id, { type: 'refresh', what: 'player' });
  }
  return games.byId(game.id)!;
}

export const hostOf = (game: GameRow) => users.byId(game.host_id);
