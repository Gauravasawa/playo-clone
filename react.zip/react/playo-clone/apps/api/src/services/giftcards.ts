import type { GiftCardRow } from '../db/rows';
import { HttpError } from '../lib/http';
import { hub } from '../realtime/hub';
import { giftCards, wallet } from '../repositories/money';
import { friendships } from '../repositories/social';
import { users } from '../repositories/users';
import { notify } from './notify';
import { charge, type PayMethod } from './payments';
import { summaryOf } from './people';
import { POLICY } from './policy';

const part = () => Array.from({ length: 4 }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
const newCode = () => {
  for (;;) {
    const c = `PLAYO-${part()}-${part()}`;
    if (!giftCards.byCode(c)) return c;
  }
};

export const giftCardOut = (g: GiftCardRow, viewerId: number) => ({
  code: g.code, amount: g.amount, message: g.message, createdAt: g.created_at, expiresAt: g.expires_at,
  buyer: summaryOf(g.buyer_id), recipient: g.recipient_id ? summaryOf(g.recipient_id) : null,
  redeemed: g.redeemed_by !== null, redeemedAt: g.redeemed_at, expired: g.expires_at < Date.now() && g.redeemed_by === null,
  mine: g.buyer_id === viewerId,
});

export function buyGiftCard(opts: { buyerId: number; amount: number; recipientId?: number | null; message?: string; method: PayMethod; simulateDecline: boolean }) {
  const { min, max, validMs } = POLICY.giftCard;
  if (!Number.isInteger(opts.amount) || opts.amount < min || opts.amount > max) throw new HttpError(400, `A gift card is between ₹${min} and ₹${max}`);
  if (opts.recipientId) {
    const r = users.byId(opts.recipientId);
    if (!r || r.id === opts.buyerId) throw new HttpError(400, 'Pick a friend to send it to');
    if (friendships.between(opts.buyerId, r.id)?.status !== 'accepted') throw new HttpError(403, 'You can send gift cards to friends');
  }
  charge({ userId: opts.buyerId, amountInr: opts.amount, method: opts.method, kind: 'gift_card', note: 'Gift card', reference: `gift_${opts.buyerId}`, simulateDecline: opts.simulateDecline });
  const code = newCode();
  giftCards.create({ code, amount: opts.amount, buyerId: opts.buyerId, recipientId: opts.recipientId ?? null, message: (opts.message ?? '').slice(0, 200), expiresAt: Date.now() + validMs });
  if (opts.recipientId) notify(opts.recipientId, 'gift_card_received', { code, amount: opts.amount, message: (opts.message ?? '').slice(0, 200), actor: summaryOf(opts.buyerId) });
  hub.sendTo(opts.buyerId, { type: 'refresh', what: 'wallet' });
  return giftCards.byCode(code)!;
}

/** Turns a code into wallet money, once */
export function redeemGiftCard(userId: number, rawCode: string) {
  const g = giftCards.byCode(rawCode);
  if (!g) throw new HttpError(404, 'That code is not valid');
  if (g.redeemed_by !== null) throw new HttpError(409, 'That gift card has already been used');
  if (g.expires_at < Date.now()) throw new HttpError(410, 'That gift card has expired');
  if (g.recipient_id && g.recipient_id !== userId) throw new HttpError(403, 'That gift card was sent to someone else');
  if (!giftCards.redeem(g.code, userId)) throw new HttpError(409, 'That gift card has already been used');
  const balance = wallet.adjust(userId, g.amount, 'gift_card', `Gift card ${g.code}`);
  if (g.buyer_id !== userId) notify(g.buyer_id, 'gift_card_redeemed', { code: g.code, amount: g.amount, actor: summaryOf(userId) });
  hub.sendTo(userId, { type: 'refresh', what: 'wallet' });
  return { amount: g.amount, balance };
}
