import { hub } from '../realtime/hub';
import { karma } from '../repositories/money';
import { isPlus } from './membership';
import { POLICY } from './policy';

/** Karma for something you did. Plus members get double. */
export function earnKarma(userId: number, basePoints: number, kind: string, note: string, ref: string | null = null) {
  if (basePoints <= 0) return 0;
  const points = basePoints * (isPlus(userId) ? POLICY.plus.karmaMultiplier : 1);
  karma.add(userId, points, kind, note, ref);
  hub.sendTo(userId, { type: 'refresh', what: 'wallet' });
  return points;
}

/** One login a day gives a few points */
export function dailyKarma(userId: number, today: string, lastDay: string | null, setDay: (day: string) => void) {
  if (lastDay === today) return 0;
  setDay(today);
  return earnKarma(userId, POLICY.karma.daily, 'daily', 'Daily login');
}

/** Karma for money spent: 1 point per ₹10 */
export const karmaForSpend = (payableInr: number) => Math.floor(payableInr / POLICY.karma.perRupees);
