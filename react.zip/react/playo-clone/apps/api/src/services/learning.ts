import { COACHES, PROGRAMS, coachHours, findBatch, findCoach, findProgram, type Coach, type Program } from '../data/coaching';
import { HttpError } from '../lib/http';
import { hub } from '../realtime/hub';
import { coachSessions, enrolments } from '../repositories/learning';
import { karma } from '../repositories/money';
import { reviews } from '../repositories/reviews';
import { earnKarma, karmaForSpend } from './karma';
import { isPlus } from './membership';
import { notify } from './notify';
import { applyKarma, charge, refundToWallet, requireMethod } from './payments';
import { summaryOf } from './people';
import { hoursUntil, POLICY, refundPercent } from './policy';
import { filterText } from './safety';

export const batchStart = (startsOn: string, time: string) => new Date(`${startsOn}T${time}:00`).getTime();

export function ratingOf(coach: Coach) {
  const list = reviews.forTarget('coach', coach.id);
  return list.length ? { avg: Math.round((list.reduce((s, r) => s + r.rating, 0) / list.length) * 10) / 10, count: list.length } : { avg: coach.rating, count: 0 };
}

export const programOut = (p: Program) => ({
  ...p,
  batches: p.batches.map((b) => ({ ...b, seatsLeft: b.seats - enrolments.seatsTaken(b.id), startsAt: batchStart(b.startsOn, b.time) })),
});

export const coachCard = (c: Coach) => ({ ...c, rating: ratingOf(c).avg, reviewCount: ratingOf(c).count });

export function coachDetail(c: Coach, viewerId: number | null) {
  const list = reviews.forTarget('coach', c.id);
  return {
    ...coachCard(c),
    programs: PROGRAMS.filter((p) => p.coachId === c.id).map(programOut),
    reviews: list.map((r) => ({ id: r.id, rating: r.rating, body: r.body, createdAt: r.created_at, author: summaryOf(r.author_id) })),
    canReview: viewerId !== null && canReviewCoach(viewerId, c.id) && !reviews.hasReviewed('coach', c.id, viewerId),
  };
}

/** You can review a coach after attending a session with them or completing one of their programs */
const canReviewCoach = (userId: number, coachId: number) =>
  coachSessions.attended(userId, coachId) || enrolments.completedWithCoach(userId, [coachId]);

export function reviewCoach(userId: number, coachId: number, rating: number, body: string) {
  if (!findCoach(coachId)) throw new HttpError(404, 'Coach not found');
  if (!rating || rating < 1 || rating > 5) throw new HttpError(400, 'Rating is 1 to 5');
  if (!canReviewCoach(userId, coachId)) throw new HttpError(403, 'You can review a coach after a session with them or finishing one of their programs');
  if (!reviews.add({ kind: 'coach', targetId: coachId, authorId: userId, rating, body: filterText((body ?? '').slice(0, 300)) })) throw new HttpError(409, 'You already reviewed this coach');
  earnKarma(userId, POLICY.karma.review, 'review', 'Reviewed a coach', `coachreview:${coachId}`);
}

/* ---------- Programs ---------- */

export function enrol(opts: { userId: number; programId: number; batchId: number; method: unknown; karmaPoints: number; simulateDecline: boolean }) {
  const program = findProgram(opts.programId);
  const batch = findBatch(opts.batchId);
  if (!program || !batch || batch.programId !== program.id) throw new HttpError(404, 'Program or batch not found');
  const start = batchStart(batch.startsOn, batch.time);
  if (start <= Date.now()) throw new HttpError(409, 'That batch has already started');
  if (enrolments.activeIn(opts.userId, program.id)) throw new HttpError(409, 'You are already enrolled in this program');
  if (batch.seats - enrolments.seatsTaken(batch.id) <= 0) throw new HttpError(409, 'That batch is full');

  const k = applyKarma(opts.userId, program.priceInr, opts.karmaPoints);
  const cash = program.priceInr - k.discountInr;
  charge({ userId: opts.userId, amountInr: cash, method: requireMethod(opts.method), kind: 'program', note: program.title, reference: `enrol_${opts.userId}`, simulateDecline: opts.simulateDecline });
  if (k.pointsUsed > 0) karma.add(opts.userId, -k.pointsUsed, 'redeem', program.title, `enrol:${program.id}`);
  const e = enrolments.create({ userId: opts.userId, programId: program.id, batchId: batch.id, paid: cash, karmaUsed: k.pointsUsed });
  earnKarma(opts.userId, karmaForSpend(cash), 'purchase', program.title, `enrolment:${e.id}`);
  notify(opts.userId, 'program_enrolled', { enrolmentId: e.id, title: program.title, startsOn: batch.startsOn });
  hub.sendTo(opts.userId, { type: 'refresh', what: 'learning' });
  return e;
}

export function cancelEnrolment(userId: number, id: number) {
  const e = enrolments.byId(id);
  if (!e || e.user_id !== userId || e.status !== 'active') throw new HttpError(404, 'Enrolment not found');
  const batch = findBatch(e.batch_id)!;
  const hours = hoursUntil(batchStart(batch.startsOn, batch.time));
  if (hours <= 0) throw new HttpError(409, 'This program has already started');
  const pct = refundPercent(hours, isPlus(userId));
  enrolments.setStatus(e.id, 'cancelled');
  refundToWallet(userId, Math.round((e.paid * pct) / 100), 'refund', `Cancelled: ${findProgram(e.program_id)?.title}`);
  if (e.karma_used > 0 && pct > 0) karma.add(userId, Math.round((e.karma_used * pct) / 100), 'refund', 'Cancelled a program', `enrolment:${e.id}`);
  hub.sendTo(userId, { type: 'refresh', what: 'learning' });
  hub.sendTo(userId, { type: 'refresh', what: 'wallet' });
  return { percent: pct, refunded: Math.round((e.paid * pct) / 100) };
}

/* ---------- Trial sessions ---------- */

export function freeHours(coachId: number, date: string) {
  const busy = new Set(coachSessions.taken(coachId, date));
  const now = Date.now();
  return coachHours(coachId, date).map((time) => {
    const past = new Date(`${date}T${time}:00`).getTime() <= now;
    return { time, available: !past && !busy.has(time), reason: past ? 'past' : busy.has(time) ? 'taken' : null };
  });
}

export function bookSession(opts: { userId: number; coachId: number; date: string; time: string; method: unknown; karmaPoints: number; simulateDecline: boolean }) {
  const coach = findCoach(opts.coachId);
  if (!coach) throw new HttpError(404, 'Coach not found');
  const slot = freeHours(coach.id, opts.date).find((s) => s.time === opts.time);
  if (!slot) throw new HttpError(400, 'The coach does not take sessions at that time');
  if (!slot.available) throw new HttpError(409, slot.reason === 'past' ? 'That time has passed' : 'That time was just taken');

  const k = applyKarma(opts.userId, coach.pricePerSession, opts.karmaPoints);
  const cash = coach.pricePerSession - k.discountInr;
  charge({ userId: opts.userId, amountInr: cash, method: requireMethod(opts.method), kind: 'session', note: `Trial session · ${coach.name}`, reference: `session_${opts.userId}`, simulateDecline: opts.simulateDecline });
  if (k.pointsUsed > 0) karma.add(opts.userId, -k.pointsUsed, 'redeem', `Session with ${coach.name}`);
  const s = coachSessions.create({ userId: opts.userId, coachId: coach.id, date: opts.date, time: opts.time, price: coach.pricePerSession, paid: cash, karmaUsed: k.pointsUsed, startsAt: new Date(`${opts.date}T${opts.time}:00`).getTime() });
  earnKarma(opts.userId, karmaForSpend(cash), 'purchase', `Session with ${coach.name}`, `session:${s.id}`);
  notify(opts.userId, 'session_booked', { sessionId: s.id, coach: coach.name, date: opts.date, time: opts.time });
  hub.sendTo(opts.userId, { type: 'refresh', what: 'learning' });
  return s;
}

export function cancelSession(userId: number, id: number) {
  const s = coachSessions.byId(id);
  if (!s || s.user_id !== userId || s.status !== 'confirmed') throw new HttpError(404, 'Session not found');
  const hours = hoursUntil(s.starts_at);
  if (hours <= 0) throw new HttpError(409, 'That session has already started');
  const pct = refundPercent(hours, isPlus(userId));
  coachSessions.setStatus(s.id, 'cancelled');
  refundToWallet(userId, Math.round((s.paid * pct) / 100), 'refund', 'Cancelled a trial session');
  if (s.karma_used > 0 && pct > 0) karma.add(userId, Math.round((s.karma_used * pct) / 100), 'refund', 'Cancelled a trial session', `session:${s.id}`);
  hub.sendTo(userId, { type: 'refresh', what: 'learning' });
  hub.sendTo(userId, { type: 'refresh', what: 'wallet' });
  return { percent: pct, refunded: Math.round((s.paid * pct) / 100) };
}

/** Demo: marks a session attended or a program completed, which allows reviewing the coach */
export function markAttended(userId: number, kind: 'session' | 'enrolment', id: number) {
  if (kind === 'session') {
    const s = coachSessions.byId(id);
    if (!s || s.user_id !== userId) throw new HttpError(404, 'Session not found');
    coachSessions.setStatus(id, 'attended');
  } else {
    const e = enrolments.byId(id);
    if (!e || e.user_id !== userId) throw new HttpError(404, 'Enrolment not found');
    enrolments.setStatus(id, 'completed');
  }
}

export const learningFor = (userId: number) => ({
  enrolments: enrolments.forUser(userId).map((e) => {
    const p = findProgram(e.program_id)!, b = findBatch(e.batch_id)!, c = findCoach(p.coachId)!;
    const startsAt = batchStart(b.startsOn, b.time);
    return {
      id: e.id, status: e.status, paid: e.paid, createdAt: e.created_at, program: { id: p.id, title: p.title, sport: p.sport, sessions: p.sessions },
      coach: { id: c.id, name: c.name, city: c.city }, batch: { id: b.id, days: b.days, time: b.time, startsOn: b.startsOn },
      startsAt, refundPercent: e.status === 'active' && startsAt > Date.now() ? refundPercent(hoursUntil(startsAt), isPlus(userId)) : 0,
    };
  }),
  sessions: coachSessions.forUser(userId).map((s) => {
    const c = findCoach(s.coach_id)!;
    return {
      id: s.id, status: s.status, date: s.date, time: s.time, paid: s.paid, startsAt: s.starts_at, coach: { id: c.id, name: c.name, city: c.city, sport: c.sport },
      refundPercent: s.status === 'confirmed' && s.starts_at > Date.now() ? refundPercent(hoursUntil(s.starts_at), isPlus(userId)) : 0,
    };
  }),
});

export { COACHES };
