import type { UserRow } from '../db/rows';
import { games } from '../repositories/games';
import { friendships } from '../repositories/social';
import { playsOf, users } from '../repositories/users';
import { isPlus } from './membership';
import { relationship, summary } from './people';
import { canSee } from './games';
import { blocks } from '../repositories/safety';

const RANK: Record<string, number> = { Beginner: 0, Intermediate: 1, Advanced: 2 };
const MAX_SCORE = 15; // best sport 5 + two more sports 2 + city 3 + times 4 + Plus 1

/**
 * "Players for you": who is likely to be a good partner. Score (0–15):
 *   sports   a shared sport is 2, plus 3 for the same level or 1 for a neighbouring level (best sport),
 *            and 1 more for each other shared sport (up to 2 more)
 *   city     3 for the same city
 *   times    1 for each day type (weekday / weekend) and each time of day (morning / evening) you both play
 *   Plus     1 if they are a Plus member (Plus gets priority)
 */
export function suggestionsFor(me: UserRow, limit = 20) {
  const mySports = new Map(users.sports(me.id).map((s) => [s.sport, s.level]));
  const myPlays = playsOf(me);
  const friends = new Set(friendships.friendIds(me.id));
  const hidden = blocks.hiddenFrom(me.id);
  const openGames = games.all().filter((g) => g.status === 'open' && canSee(g, me.id) && !games.isPlayer(g.id, me.id));

  const out = [];
  for (const u of users.all()) {
    if (u.id === me.id || u.is_admin === 1 || friends.has(u.id) || hidden.has(u.id)) continue;
    const theirSports = users.sports(u.id);
    const shared = theirSports.filter((s) => mySports.has(s.sport)).map((s) => ({ sport: s.sport, mine: mySports.get(s.sport)!, theirs: s.level }));

    const reasons: string[] = [];
    let score = 0;
    if (shared.length) {
      const closeness = (a: string, b: string) => (a === b ? 3 : Math.abs(RANK[a] - RANK[b]) === 1 ? 1 : 0);
      const ranked = [...shared].sort((a, b) => closeness(b.mine, b.theirs) - closeness(a.mine, a.theirs));
      score += 2 + closeness(ranked[0].mine, ranked[0].theirs) + Math.min(2, shared.length - 1);
      const best = ranked[0];
      reasons.push(best.mine === best.theirs ? `Plays ${best.sport} at your level (${best.mine})` : `Plays ${best.sport} (${best.theirs}, you're ${best.mine})`);
      if (shared.length > 1) reasons.push(`${shared.length} sports in common`);
    }
    if (u.city === me.city) { score += 3; reasons.push(`Also in ${u.city}`); }

    const theirPlays = playsOf(u);
    const days = myPlays.days.filter((d) => theirPlays.days.includes(d));
    const times = myPlays.times.filter((t) => theirPlays.times.includes(t));
    if (days.length + times.length) {
      score += days.length + times.length;
      reasons.push(`Free at similar times (${[...days, ...times].join(', ')})`);
    }
    const plus = isPlus(u.id);
    if (plus && score > 0) score += 1;
    if (score <= 0) continue;

    const sharedSports = new Set(shared.map((s) => s.sport));
    out.push({
      player: { ...summary(u), plus },
      matchPercent: Math.min(100, Math.round((score / MAX_SCORE) * 100)),
      reasons,
      sharedSports: shared,
      relationship: relationship(me.id, u.id),
      // games they are in that you could join together
      sharedGames: openGames.filter((g) => sharedSports.has(g.sport) && games.isPlayer(g.id, u.id)).slice(0, 2).map((g) => ({ id: g.id, title: g.title })),
      score,
    });
  }
  return out.sort((a, b) => b.score - a.score || a.player.name.localeCompare(b.player.name)).slice(0, limit);
}
