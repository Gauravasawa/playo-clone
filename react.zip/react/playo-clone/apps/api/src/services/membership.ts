import { HttpError } from '../lib/http';
import { hub } from '../realtime/hub';
import { subscriptions } from '../repositories/money';
import { applyKarma, charge, type PayMethod } from './payments';
import { karma } from '../repositories/money';
import { POLICY } from './policy';
import { notify } from './notify';

export interface PlusStatus { active: boolean; plan: 'monthly' | 'yearly' | null; renewsAt: number | null; cancelled: boolean; priceMonthly: number; priceYearly: number }

/** Playo Plus: active until the end of the period you paid for, even after cancelling */
export function plusStatus(userId: number): PlusStatus {
  const s = subscriptions.latest(userId);
  const active = !!s && s.renews_at > Date.now();
  return {
    active, plan: active ? s!.plan : null, renewsAt: active ? s!.renews_at : null, cancelled: active && s!.cancelled_at !== null,
    priceMonthly: POLICY.plus.monthly, priceYearly: POLICY.plus.yearly,
  };
}
export const isPlus = (userId: number) => plusStatus(userId).active;

export function subscribe(userId: number, plan: 'monthly' | 'yearly', method: PayMethod, karmaPoints: number, simulateDecline: boolean) {
  const price = plan === 'yearly' ? POLICY.plus.yearly : POLICY.plus.monthly;
  const k = applyKarma(userId, price, karmaPoints);
  const cash = price - k.discountInr;
  charge({ userId, amountInr: cash, method, kind: 'plus', note: `Playo Plus (${plan})`, reference: `plus_${userId}`, simulateDecline });
  if (k.pointsUsed > 0) karma.add(userId, -k.pointsUsed, 'redeem', 'Used on Playo Plus', `plus:${userId}`);

  const existing = subscriptions.latest(userId);
  const length = plan === 'yearly' ? POLICY.plus.yearMs : POLICY.plus.monthMs;
  const from = existing && existing.renews_at > Date.now() ? existing.renews_at : Date.now(); // renewing early adds on
  if (existing) subscriptions.extend(existing.id, from + length, plan, cash);
  else subscriptions.create(userId, plan, from + length, cash);

  notify(userId, 'plus_started', { plan, renewsAt: from + length });
  hub.sendTo(userId, { type: 'refresh', what: 'wallet' });
  return plusStatus(userId);
}

export function cancelPlus(userId: number) {
  const s = subscriptions.latest(userId);
  if (!s || s.renews_at <= Date.now()) throw new HttpError(409, 'You are not a Plus member');
  if (s.cancelled_at) throw new HttpError(409, 'Already cancelled. Plus stays until the end of the period you paid for.');
  subscriptions.cancel(s.id);
  return plusStatus(userId);
}
