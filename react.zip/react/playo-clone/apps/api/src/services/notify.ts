import type { NotificationRow } from '../db/rows';
import { hub } from '../realtime/hub';
import { notifications } from '../repositories/social';

export const notificationOut = (n: NotificationRow) => ({
  id: n.id, type: n.type, data: JSON.parse(n.data) as Record<string, unknown>, read: n.read === 1, createdAt: n.created_at,
});

/** Saves a notification and pushes it to the user's open tabs */
export function notify(userId: number, type: string, data: Record<string, unknown>) {
  const row = notifications.create(userId, type, data);
  hub.sendTo(userId, { type: 'notification', notification: notificationOut(row) });
  return row;
}
