import { POLICY } from './policy';
import type { UserRow } from '../db/rows';
import { createGameWith, venueFor } from '../db/seed';
import { users } from '../repositories/users';
import { wallet } from '../repositories/money';

import { notify } from './notify';
import { welcomeNewUser } from './bots';

const DAY = 24 * 3600 * 1000;

/**
 * First login. This is demo data, on purpose: ₹1000 in the wallet, and two finished games with
 * demo players, so there are people to befriend and follow straight away ("played with").
 */
export function onboardUser(user: UserRow) {
  wallet.adjust(user.id, POLICY.welcomeBonus, 'welcome', 'Welcome bonus');
  const bots = users.bots().filter((b) => b.city === user.city);
  const pool = bots.length >= 3 ? bots : users.bots();
  const mine = { id: user.id, name: user.name };

  const history: [string, number][] = [['badminton', 6], ['football', 12]];
  history.forEach(([sport, daysAgo], i) => {
    const group = pool.slice(i * 2, i * 2 + 3);
    const [host, ...others] = group.length >= 2 ? group : pool.slice(0, 3);
    createGameWith({
      host, others: [...others, mine], venue: venueFor(user.city, sport), sport, status: 'ended',
      winners: [i === 0 ? host.id : user.id], startsAt: new Date(Date.now() - daysAgo * DAY),
      title: `${sport === 'badminton' ? 'Badminton doubles' : 'Football 5-a-side'} (past game)`,
    });
  });

  notify(user.id, 'welcome', { text: 'Welcome! ₹1000 was added to your wallet, and two past games with players you can now connect with.' });
  welcomeNewUser(user);
}
