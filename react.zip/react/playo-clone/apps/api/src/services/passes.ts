import { HttpError } from '../lib/http';
import type { PassRow } from '../db/rows';
import { karma, passes } from '../repositories/money';
import { earnKarma, karmaForSpend } from './karma';
import { notify } from './notify';
import { applyKarma, charge, type PayMethod } from './payments';
import { POLICY } from './policy';
import { catalog, type CatalogVenue } from './catalog';

/** What a venue sells as passes (prices in rupees) */
export function passesInfoFor(v: Pick<CatalogVenue, 'pricePerHour'>) {
  return {
    daily: { hours: POLICY.passes.dailyHours, priceInr: v.pricePerHour * POLICY.passes.dailyHours, note: 'Unlimited hours on one day you choose' },
    monthly: {
      hours: POLICY.passes.monthlyHours,
      priceInr: Math.round((v.pricePerHour * POLICY.passes.monthlyHours * (1 - POLICY.passes.monthlyDiscount)) / 10) * 10,
      note: `${POLICY.passes.monthlyHours} hours to use this month, ${POLICY.passes.monthlyDiscount * 100}% cheaper than hourly`,
    },
  };
}

const endOfMonth = (now = new Date()) => new Date(now.getFullYear(), now.getMonth() + 1, 1).getTime() - 1;

export const passOut = (p: PassRow) => {
  const v = catalog.find(p.venue_id);
  return {
    id: p.id, venueId: p.venue_id, venueName: v?.name ?? 'Venue', city: v?.city ?? '', kind: p.kind, validDate: p.valid_date,
    hoursTotal: p.hours_total, hoursLeft: p.hours_left, validUntil: p.valid_until, paid: p.paid, active: isUsable(p),
  };
};

export const isUsable = (p: PassRow, now = Date.now()) => p.valid_until > now && (p.kind === 'daily' || p.hours_left > 0);

/** Can this pass pay for these slots? Returns why not as an error message. */
export function checkPass(p: PassRow | null, userId: number, venueId: number, date: string, hours: number, startsAt: number): string | null {
  if (!p || p.user_id !== userId) return 'That pass is not yours';
  if (p.venue_id !== venueId) return 'That pass is for another venue';
  if (p.valid_until <= startsAt) return 'That pass has expired by then';
  if (p.kind === 'daily') return p.valid_date === date ? null : `That day pass is for ${p.valid_date}`;
  return p.hours_left >= hours ? null : `Only ${p.hours_left} hour${p.hours_left === 1 ? '' : 's'} left on that membership`;
}

export function buyPass(opts: {
  userId: number; venueId: number; kind: 'daily' | 'monthly'; date?: string; method: PayMethod; karmaPoints: number; simulateDecline: boolean;
}) {
  const venue = catalog.find(opts.venueId);
  if (!venue) throw new HttpError(404, 'Venue not found');
  const info = passesInfoFor(venue)[opts.kind];
  let validUntil: number;
  let validDate: string | null = null;
  if (opts.kind === 'daily') {
    if (!opts.date || !/^\d{4}-\d{2}-\d{2}$/.test(opts.date)) throw new HttpError(400, 'Pick the day for the pass');
    if (opts.date < localDay()) throw new HttpError(400, 'That day has passed');
    validDate = opts.date;
    validUntil = new Date(`${opts.date}T23:59:59`).getTime();
  } else {
    validUntil = endOfMonth();
  }
  const k = applyKarma(opts.userId, info.priceInr, opts.karmaPoints);
  const cash = info.priceInr - k.discountInr;
  charge({ userId: opts.userId, amountInr: cash, method: opts.method, kind: 'pass', note: `${opts.kind === 'daily' ? 'Day pass' : 'Monthly membership'} · ${venue.name}`, reference: `pass_${opts.userId}`, simulateDecline: opts.simulateDecline });
  if (k.pointsUsed > 0) karma.add(opts.userId, -k.pointsUsed, 'redeem', `Used on a pass at ${venue.name}`);
  const pass = passes.create({ userId: opts.userId, venueId: venue.id, kind: opts.kind, validDate, hours: info.hours, validUntil, paid: cash });
  earnKarma(opts.userId, karmaForSpend(cash), 'purchase', `Pass at ${venue.name}`, `pass:${pass.id}`);
  notify(opts.userId, 'pass_bought', { passId: pass.id, venue: venue.name, kind: opts.kind });
  return pass;
}

export const localDay = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
