import { HttpError } from '../lib/http';
import { karma, wallet } from '../repositories/money';
import { POLICY } from './policy';
import { payments } from './providers';

export type PayMethod = 'wallet' | 'upi' | 'card';
export const isMethod = (m: unknown): m is PayMethod => m === 'wallet' || m === 'upi' || m === 'card';

/**
 * How much Karma can pay for, and what it takes off: 10 points = ₹1, never more than 20% of what is
 * being paid. Asking for more than you have, or than is allowed, simply uses less.
 */
export function applyKarma(userId: number, amountInr: number, requestedPoints: number) {
  const usable = Math.max(0, Math.min(Math.floor(requestedPoints || 0), karma.balance(userId)));
  const cap = Math.floor(Math.max(0, amountInr) * POLICY.karma.maxShareOfPayable);
  const discountInr = Math.min(Math.floor(usable * POLICY.karma.rupeesPerPoint), cap);
  return { pointsUsed: Math.round(discountInr / POLICY.karma.rupeesPerPoint), discountInr };
}

/**
 * Takes a payment. The wallet is charged for real; UPI and card go to the payment provider (the demo one,
 * which the Lab can make decline). Does nothing for a zero amount.
 */
export function charge(opts: { userId: number; amountInr: number; method: PayMethod; kind: string; note: string; reference: string; simulateDecline: boolean }) {
  if (opts.amountInr <= 0) return;
  if (opts.method === 'wallet') wallet.adjust(opts.userId, -opts.amountInr, opts.kind, opts.note);
  else payments.charge({ amountInr: opts.amountInr, method: opts.method, reference: opts.reference, simulateDecline: opts.simulateDecline });
}

/** Gives money back: always into the wallet, whatever it was paid with */
export function refundToWallet(userId: number, amountInr: number, kind: string, note: string) {
  if (amountInr > 0) wallet.adjust(userId, amountInr, kind, note);
}

export function requireMethod(raw: unknown): PayMethod {
  const method = raw ?? 'wallet';
  if (!isMethod(method)) throw new HttpError(400, 'Unknown payment method');
  return method;
}
