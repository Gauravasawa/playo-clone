import type { UserRow } from '../db/rows';
import { hub } from '../realtime/hub';
import { follows, friendships } from '../repositories/social';
import { games } from '../repositories/games';
import { bookings } from '../repositories/bookings';
import { reviews } from '../repositories/reviews';
import { playsOf, users } from '../repositories/users';
import { isPlus } from './membership';

export interface PlayerSummary {
  id: number; username: string; name: string; avatarEmoji: string; avatarColor: string; city: string; isPrivate: boolean; online: boolean; plus: boolean;
}

export interface Relationship {
  friend: 'none' | 'pending_out' | 'pending_in' | 'friends';
  friendshipId: number | null;
  follow: 'none' | 'pending' | 'following';
  followsMe: boolean;
  /** Requests are only allowed to players you've shared an ended game with */
  playedWith: boolean;
}

export const isOnline = (u: UserRow) => u.is_bot === 1 || hub.hasSocket(u.id);

export const summary = (u: UserRow): PlayerSummary => ({
  id: u.id, username: u.username, name: u.name, avatarEmoji: u.avatar_emoji, avatarColor: u.avatar_color,
  city: u.city, isPrivate: u.is_private === 1, online: isOnline(u), plus: isPlus(u.id),
});

export const summaryOf = (id: number) => {
  const u = users.byId(id);
  return u ? summary(u) : null;
};

export function relationship(viewerId: number, targetId: number): Relationship {
  const f = friendships.between(viewerId, targetId);
  const out = follows.get(viewerId, targetId);
  const back = follows.get(targetId, viewerId);
  return {
    friend: !f ? 'none' : f.status === 'accepted' ? 'friends' : f.requester_id === viewerId ? 'pending_out' : 'pending_in',
    friendshipId: f?.id ?? null,
    follow: !out ? 'none' : out.status === 'accepted' ? 'following' : 'pending',
    followsMe: back?.status === 'accepted',
    playedWith: games.hasPlayedWith(viewerId, targetId),
  };
}

export const SKILL_LEVELS = ['Beginner', 'Intermediate', 'Advanced'];

export function stats(userId: number) {
  const g = games.stats(userId);
  return {
    gamesPlayed: g.played, wins: g.wins, bookings: bookings.count(userId),
    friends: friendships.friendIds(userId).length,
    followers: follows.followerIds(userId).length,
    following: follows.followingIds(userId).length,
    reviewsWritten: reviews.countByAuthor(userId),
  };
}

export function badges(s: ReturnType<typeof stats>) {
  const list: { id: string; label: string; emoji: string }[] = [];
  if (s.gamesPlayed >= 1) list.push({ id: 'first-game', label: 'First game', emoji: '🎮' });
  if (s.gamesPlayed >= 5) list.push({ id: 'regular', label: 'Regular', emoji: '🔁' });
  if (s.wins >= 3) list.push({ id: 'winner', label: 'Winner', emoji: '🏆' });
  if (s.friends >= 3) list.push({ id: 'social', label: 'Social', emoji: '🤝' });
  if (s.bookings >= 3) list.push({ id: 'booker', label: 'Court regular', emoji: '📅' });
  if (s.reviewsWritten >= 1) list.push({ id: 'reviewer', label: 'Reviewer', emoji: '⭐' });
  return list;
}

/** What a viewer may see: everything on public profiles; on private ones, details only for friends and followers */
export function canSeeDetails(viewerId: number | null, target: UserRow) {
  if (target.is_private === 0) return true;
  if (viewerId === target.id) return true;
  if (!viewerId) return false;
  const rel = relationship(viewerId, target.id);
  return rel.friend === 'friends' || rel.follow === 'following';
}
