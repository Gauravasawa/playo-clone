/**
 * Every money rule in one place. The Policy page reads these numbers from `GET /api/policy`,
 * so what the page says and what the server does can't drift apart.
 */
export const POLICY = {
  convenienceFee: { percent: 3, min: 10, max: 100 },
  /** Refund by how long before the first slot a booking is cancelled: the first row that fits applies */
  refund: {
    standard: [{ hoursBefore: 24, percent: 100 }, { hoursBefore: 2, percent: 50 }, { hoursBefore: 0, percent: 0 }],
    plus: [{ hoursBefore: 2, percent: 100 }, { hoursBefore: 0, percent: 0 }],
  },
  rescheduleUntilHoursBefore: 2,
  gameLeaveRefundHoursBefore: 3,
  karma: { rupeesPerPoint: 0.1, maxShareOfPayable: 0.2, perRupees: 10, review: 10, game: 20, daily: 5, referrer: 50 },
  plus: { monthly: 149, yearly: 1199, karmaMultiplier: 2, monthMs: 30 * 86_400_000, yearMs: 365 * 86_400_000 },
  passes: { dailyHours: 6, monthlyHours: 12, monthlyDiscount: 0.25 },
  giftCard: { min: 200, max: 20_000, validMs: 365 * 86_400_000 },
  referral: { newcomer: 100, referrer: 100 },
  welcomeBonus: 1000,
} as const;

/** Share of the paid amount that comes back when cancelling `hoursBefore` hours ahead */
export function refundPercent(hoursBefore: number, isPlus: boolean): number {
  const rows = isPlus ? POLICY.refund.plus : POLICY.refund.standard;
  return rows.find((r) => hoursBefore >= r.hoursBefore)?.percent ?? 0;
}

/** The fee for booking online: nothing for Plus members or when nothing is being charged */
export function convenienceFee(chargeableInr: number, isPlus: boolean): number {
  if (isPlus || chargeableInr <= 0) return 0;
  const { percent, min, max } = POLICY.convenienceFee;
  return Math.min(max, Math.max(min, Math.round((chargeableInr * percent) / 100)));
}

export const hoursUntil = (startsAt: number, now = Date.now()) => (startsAt - now) / 3_600_000;
