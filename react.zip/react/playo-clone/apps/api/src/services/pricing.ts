import { discountFor } from '../data/extras';
import { hourOf, slotPrice, slotStart } from '../data/venues';
import { HttpError } from '../lib/http';
import { karma, passes } from '../repositories/money';
import { karmaForSpend } from './karma';
import { isPlus } from './membership';
import { applyKarma } from './payments';
import { checkPass } from './passes';
import { convenienceFee, POLICY } from './policy';
import { catalog } from './catalog';

export interface QuoteInput {
  userId: number; venueId: number; date: string; slots: string[]; extras?: string[];
  coupon?: string | null; karmaPoints?: number; passId?: number | null;
}

export interface Quote {
  venueId: number; date: string; startsAt: number;
  slots: { time: string; price: number }[];
  slotsInr: number;
  extras: { id: string; name: string; hours: number; priceInr: number }[];
  extrasInr: number;
  passId: number | null; passCoveredInr: number; passHours: number;
  /** What would be charged before coupon, Karma and the fee */
  chargeableInr: number;
  coupon: string | null; couponDiscountInr: number;
  karmaPointsUsed: number; karmaDiscountInr: number;
  feeInr: number;
  /** What the person pays */
  payableInr: number;
  isPlus: boolean;
  /** Karma the booking earns once it is made */
  earnKarma: number;
}

/**
 * The one place a booking's price is worked out: slots (with the evening peak), rentals, a pass that
 * pays for the slots, a coupon, Karma, and the convenience fee. Used to quote, to book, and to check
 * that what the browser calculated is what the server charges.
 */
export function quoteBooking(input: QuoteInput): Quote {
  const venue = catalog.find(input.venueId);
  if (!venue) throw new HttpError(404, 'Venue not found');
  if (!input.slots.length) throw new HttpError(400, 'Pick at least one slot');
  const slots = [...new Set(input.slots)].sort().map((time) => ({ time, price: slotPrice(venue, hourOf(time)) }));
  const startsAt = slotStart(input.date, slots[0].time).getTime();
  const slotsInr = slots.reduce((s, x) => s + x.price, 0);

  const extras = (input.extras ?? []).map((id) => {
    const item = venue.equipment.find((e) => e.id === id);
    if (!item) throw new HttpError(400, `This venue doesn't rent "${id}"`);
    return { id, name: item.name, hours: slots.length, priceInr: item.priceInr * slots.length };
  });
  const extrasInr = extras.reduce((s, x) => s + x.priceInr, 0);

  let passCoveredInr = 0;
  let passHours = 0;
  if (input.passId) {
    const pass = passes.byId(input.passId);
    const problem = checkPass(pass, input.userId, venue.id, input.date, slots.length, startsAt);
    if (problem) throw new HttpError(409, problem);
    passCoveredInr = slotsInr;
    passHours = pass!.kind === 'monthly' ? slots.length : 0;
  }

  const chargeableInr = slotsInr - passCoveredInr + extrasInr;
  const plus = isPlus(input.userId);

  let couponDiscountInr = 0;
  let coupon: string | null = null;
  if (input.coupon) {
    const found = discountFor(input.coupon, chargeableInr);
    if (found && 'error' in found) throw new HttpError(400, found.error);
    if (found) { couponDiscountInr = found.discount; coupon = found.coupon.code; }
  }

  const afterCoupon = chargeableInr - couponDiscountInr;
  const k = applyKarma(input.userId, afterCoupon, input.karmaPoints ?? 0);
  const feeInr = convenienceFee(chargeableInr, plus);
  const payableInr = Math.max(0, afterCoupon - k.discountInr + feeInr);

  return {
    venueId: venue.id, date: input.date, startsAt, slots, slotsInr, extras, extrasInr,
    passId: input.passId ?? null, passCoveredInr, passHours,
    chargeableInr, coupon, couponDiscountInr, karmaPointsUsed: k.pointsUsed, karmaDiscountInr: k.discountInr,
    feeInr, payableInr, isPlus: plus,
    earnKarma: karmaForSpend(payableInr) * (plus ? POLICY.plus.karmaMultiplier : 1),
  };
}

void karma;
