import { config } from '../../config';
import { HttpError } from '../../lib/http';

/**
 * The two outside services the app needs, behind small interfaces so a real one is a drop-in.
 * Only the demo implementations exist: they need no keys, and they say so in their names.
 */
export interface OtpProvider {
  /** Throws if the code isn't right for this phone number */
  verify(phone: string, code: string): void;
}

export interface PaymentProvider {
  /** Takes `amountInr` from a UPI or card payment. Throws a 402 if it is declined. */
  charge(input: { amountInr: number; method: 'upi' | 'card'; reference: string; simulateDecline: boolean }): { id: string };
  /** Returns money to the original method (the demo gateway keeps nothing, so this only gives an id) */
  refund(input: { amountInr: number; reference: string }): { id: string };
}

export const demoOtp: OtpProvider = {
  verify(_phone, code) {
    if (code !== config.demoOtp) throw new HttpError(401, `Wrong OTP (use ${config.demoOtp})`);
  },
};

export const demoPayments: PaymentProvider = {
  charge({ simulateDecline, reference }) {
    if (simulateDecline) throw new HttpError(402, 'Payment declined by the bank');
    return { id: `demo_pay_${reference}_${Date.now()}` };
  },
  refund({ reference }) {
    return { id: `demo_refund_${reference}_${Date.now()}` };
  },
};

/** Swap these two lines for real providers (Twilio/MSG91, Razorpay/Stripe) */
export const otp: OtpProvider = demoOtp;
export const payments: PaymentProvider = demoPayments;
