import type { UserRow } from '../db/rows';
import { karma, wallet } from '../repositories/money';
import { users } from '../repositories/users';
import { notify } from './notify';
import { POLICY } from './policy';
import { summaryOf } from './people';

/** A referral code someone typed, if it belongs to another person */
export const referrerFor = (code: string | undefined) => (code ? users.byReferralCode(code) : null);

/** The newcomer's bonus, right after signing up with a code */
export function rewardNewcomer(user: UserRow) {
  if (!user.referred_by) return;
  wallet.adjust(user.id, POLICY.referral.newcomer, 'referral', 'Referral bonus');
  notify(user.id, 'referral_bonus', { amount: POLICY.referral.newcomer, actor: summaryOf(user.referred_by) });
}

/** The referrer's reward, once the person they referred makes their first booking */
export function rewardReferrerIfFirstBooking(user: UserRow) {
  if (!user.referred_by || user.referral_rewarded) return;
  const referrer = users.byId(user.referred_by);
  users.markReferralRewarded(user.id);
  if (!referrer) return;
  wallet.adjust(referrer.id, POLICY.referral.referrer, 'referral', `${user.name} made their first booking`);
  karma.add(referrer.id, POLICY.karma.referrer, 'referral', `${user.name} made their first booking`, `referral:${user.id}`);
  notify(referrer.id, 'referral_reward', { amount: POLICY.referral.referrer, points: POLICY.karma.referrer, actor: summaryOf(user.id) });
}
