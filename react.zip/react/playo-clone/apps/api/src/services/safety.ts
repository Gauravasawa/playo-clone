/**
 * Message filtering: a small blocklist of abusive words is replaced with ***, in chat messages,
 * reviews and tickets. Whole words only, any capitalisation, so ordinary words aren't touched.
 */
const BLOCKED = ['idiot', 'stupid', 'moron', 'loser', 'jerk', 'dumb', 'shut up', 'trash', 'scum', 'bastard'];

const pattern = new RegExp(`\\b(${BLOCKED.map((w) => w.replace(/\s+/g, '\\s+')).join('|')})\\b`, 'gi');

export const filterText = (text: string) => text.replace(pattern, (m) => '*'.repeat(Math.max(3, m.length)));
export const hasBlockedWords = (text: string) => new RegExp(pattern.source, 'i').test(text);
