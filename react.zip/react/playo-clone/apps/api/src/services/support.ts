import { hub } from '../realtime/hub';
import { bookings } from '../repositories/bookings';
import { tickets } from '../repositories/tickets';
import { catalog } from './catalog';
import { isPlus } from './membership';
import { notify } from './notify';
import { hoursUntil, refundPercent } from './policy';

/**
 * The demo support agent: answers after a short pause, and mentions the booking the ticket is about.
 * It replies to the topic and to a few words in the user's message.
 */
function replyFor(ticketId: number, userMessage: string): string {
  const t = tickets.byId(ticketId)!;
  const b = t.booking_id ? bookings.byId(t.booking_id) : null;
  const venue = b ? catalog.find(b.venue_id)?.name : null;
  const text = userMessage.toLowerCase();

  if (b && venue && (t.topic === 'Refund' || /refund|cancel/.test(text))) {
    const hours = hoursUntil(b.starts_at);
    const pct = hours > 0 ? refundPercent(hours, isPlus(t.user_id)) : 0;
    return hours > 0
      ? `I can see booking #${b.id} at ${venue} on ${b.date}. If you cancel it now you get ${pct}% back (₹${Math.round((b.paid * pct) / 100)} of ₹${b.paid}) to your wallet. You can cancel from My bookings. Anything else?`
      : `Booking #${b.id} at ${venue} has already started, so it can no longer be cancelled. I'm sorry about that.`;
  }
  if (b && venue && t.topic === 'Payment') return `Thanks. For booking #${b.id} at ${venue} we took ₹${b.paid} (${b.method}). If you see a different amount on your statement, tell me the amount and I'll check it.`;
  if (/refund/.test(text) || t.topic === 'Refund') return 'Refunds go to your wallet straight away. You get 100% back if you cancel 24+ hours ahead, 50% from 24 to 2 hours, and nothing in the last 2 hours (Plus members: 100% up to 2 hours). Which booking is it about?';
  if (/login|otp|password/.test(text) || t.topic === 'Account') return 'For login problems: check the phone number, and remember the demo one-time password is 1234. If you still cannot get in, tell me your phone number and what you see.';
  if (/join|game|host/.test(text) || t.topic === 'Game') return 'Games can be full, started, private, or need a higher skill level. The message under the Join button says which. Which game are you trying to join?';
  if (/thank/.test(text)) return "You're welcome! I'll close this ticket if there's nothing else.";
  return `Thanks for writing in about "${t.subject}". I've read it and I'm looking into it. Can you tell me a bit more, like the date and what you expected to happen?`;
}

/** Schedules the agent's answer to the user's latest message */
export function agentWillReply(ticketId: number, userMessage: string, afterMs = 3000) {
  setTimeout(() => {
    try {
      const t = tickets.byId(ticketId);
      if (!t || t.status === 'closed') return;
      tickets.addMessage(ticketId, 'agent', replyFor(ticketId, userMessage));
      tickets.setStatus(ticketId, 'answered');
      notify(t.user_id, 'ticket_reply', { ticketId, subject: t.subject });
      hub.sendTo(t.user_id, { type: 'ticket', ticketId });
      hub.sendTo(t.user_id, { type: 'refresh', what: 'tickets' });
    } catch (e) {
      console.error('[support]', e);
    }
  }, afterMs);
}
