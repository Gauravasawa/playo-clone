import os from 'node:os';
import type { NextConfig } from 'next';

const API = process.env.API_URL ?? 'http://localhost:4000';

/**
 * Hosts you may open the dev site from besides `localhost`. Next 16 refuses to serve its dev
 * resources (including the scripts that make the page interactive) to any other host name, so
 * opening http://127.0.0.1:3000 or http://<this machine's IP>:3000 gave server-rendered HTML with
 * dead buttons and everything that loads in the browser stuck on "loading".
 * Add more with DEV_ORIGINS="my-host,192.168.0.20".
 */
const lanAddresses = Object.values(os.networkInterfaces())
  .flat()
  .filter((i): i is NonNullable<typeof i> => !!i && i.family === 'IPv4' && !i.internal)
  .map((i) => i.address);
const allowedDevOrigins = [
  '127.0.0.1',
  os.hostname(),
  ...lanAddresses,
  ...(process.env.DEV_ORIGINS?.split(',').map((s) => s.trim()).filter(Boolean) ?? []),
];

const config: NextConfig = {
  allowedDevOrigins,
  // A second build or dev server (e.g. with the store's logger switched on) needs its own folder
  distDir: process.env.NEXT_DIST_DIR ?? '.next',
  // On purpose: React renders every component twice in development, which would show up any
  // side effect in a store hook or action that isn't safe to repeat
  reactStrictMode: true,
  // The browser only talks to Next; Next forwards /api/* to the Bun backend (no CORS)
  async rewrites() {
    return [{ source: '/api/:path*', destination: `${API}/api/:path*` }];
  },
  images: { remotePatterns: [{ protocol: 'https', hostname: 'picsum.photos' }] },
};

export default config;
