/*
 * Runs before the first paint, as a normal script file (no inline script, so a strict Content-Security-Policy `script-src 'self'` works).
 * It puts the saved or system theme on <html> so a dark-mode visitor never sees a white flash. It reads the same localStorage entry the
 * store saves (`playo:state`, key `theme`). Keep this in step with src/lib/theme.ts `paint()`.
 */
(function () {
  try {
    var pref = 'system';
    try {
      var saved = JSON.parse(localStorage.getItem('playo:state') || 'null');
      var t = saved && saved.state && saved.state.theme;
      if (t === 'light' || t === 'dark' || t === 'system') pref = t;
    } catch (e) {}
    var dark = pref === 'dark' || (pref === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    var root = document.documentElement;
    root.dataset.theme = dark ? 'dark' : 'light';
    root.dataset.themePref = pref;
    root.style.colorScheme = dark ? 'dark' : 'light';
  } catch (e) {}
})();
