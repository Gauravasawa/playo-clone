// Copies the library under test (c:\react\.store\createStore.ts) into the app, so the library
// file stays the single source of truth and is never edited here. Runs before dev and build.
import { copyFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const from = resolve(import.meta.dir, '../../../../.store/createStore.ts');
const to = resolve(import.meta.dir, '../src/lib/store/createStore.ts');

if (!existsSync(from)) {
  console.error(`createStore.ts not found at ${from}`);
  process.exit(1);
}
mkdirSync(dirname(to), { recursive: true });
copyFileSync(from, to);
console.log(`synced createStore.ts -> ${to}`);
