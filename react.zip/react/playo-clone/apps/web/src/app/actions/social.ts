'use server';

import { api, type FriendsData } from '@/lib/api';
import { app } from '@/store';

/**
 * A Server Action: sends a friend request from the server, then loads the fresh friends list through
 * a store *scope* (the way to use the store outside a render: Server Actions and Route Handlers have
 * no request store). The browser puts what comes back straight into its own store.
 */
export async function sendFriendRequestAction(
  token: string,
  userId: number,
  simulateFailure: boolean
): Promise<{ id: number; friends: FriendsData }> {
  // The Lab's failure switch lives in the browser's store, so the browser passes it along
  if (simulateFailure) throw new Error('Simulated server failure');
  const created = await api.requestFriend(token, userId);
  const scope = app.createScope();
  const friends = (await scope.fetchQuery('friends', token, true)) as FriendsData;
  return { id: created.id, friends };
}
