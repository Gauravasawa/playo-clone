import { AdminReportsView } from '@/features/safety';

export default function Page() {
  return <AdminReportsView />;
}
