import { app, prefetch } from '@/store';
import { DEFAULT_CITY } from '@/config/cities';
import { ArticleView } from '@/features/help';

export const dynamic = 'force-dynamic';

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  await prefetch(app.fetchQuery('article', { slug, city: DEFAULT_CITY }));
  return (
    <app.Root>
      <ArticleView slug={slug} />
    </app.Root>
  );
}
