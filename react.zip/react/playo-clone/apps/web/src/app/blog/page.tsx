import { app, prefetch } from '@/store';
import { BlogView } from '@/features/help';

export const dynamic = 'force-dynamic';

export default async function Page() {
  await prefetch(app.fetchQuery('articles', { tag: '', q: '' }));
  return (
    <app.Root>
      <BlogView />
    </app.Root>
  );
}
