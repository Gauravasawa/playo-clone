import { BookingsView } from '@/features/bookings';

export default function Page() {
  return <BookingsView />;
}
