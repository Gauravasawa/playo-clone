import { ChatWindow } from '@/features/chat';

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  return <ChatWindow chatId={Number((await params).id)} />;
}
