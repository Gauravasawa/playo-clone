export default function Page() {
  return <p className="hidden rounded-2xl bg-white p-10 text-center text-ink/50 md:block">Pick a chat, or start a new one.</p>;
}
