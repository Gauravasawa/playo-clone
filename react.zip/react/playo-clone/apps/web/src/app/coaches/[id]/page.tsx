import { app, prefetch } from '@/store';
import { CoachProfileView } from '@/features/coaching';

export const dynamic = 'force-dynamic';

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const id = Number((await params).id);
  // The public part (profile, programs, reviews) is the same for everyone; "can I review" comes after login in the browser
  await prefetch(app.fetchQuery('sports'), app.fetchQuery('coach', { id, token: null }));
  return (
    <app.Root>
      <CoachProfileView id={id} />
    </app.Root>
  );
}
