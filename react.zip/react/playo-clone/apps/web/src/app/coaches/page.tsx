import { app, prefetch } from '@/store';
import { DEFAULT_COACH_PARAMS } from '@/config/constants';
import { CoachesView } from '@/features/community';

export const dynamic = 'force-dynamic';

export default async function Page() {
  // Same data the first client render shows: the sport chips and the default list
  await prefetch(app.fetchQuery('sports'), app.fetchQuery('coaches', DEFAULT_COACH_PARAMS));
  return (
    <app.Root>
      <CoachesView />
    </app.Root>
  );
}
