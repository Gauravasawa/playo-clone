import { app, prefetch } from '@/store';
import { EventDetailView } from '@/features/events';

export const dynamic = 'force-dynamic';

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const id = Number((await params).id);
  // Public details are rendered on the server; "am I going" arrives in the browser once logged in
  await prefetch(app.fetchQuery('event', { id, token: null }));
  return (
    <app.Root>
      <EventDetailView id={id} />
    </app.Root>
  );
}
