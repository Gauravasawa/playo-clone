import { app, prefetch } from '@/store';
import { DEFAULT_EVENT_PARAMS } from '@/config/constants';
import { EventsView } from '@/features/events';

export const dynamic = 'force-dynamic';

export default async function Page() {
  await prefetch(app.fetchQuery('sports'), app.fetchQuery('events', DEFAULT_EVENT_PARAMS));
  return (
    <app.Root>
      <EventsView />
    </app.Root>
  );
}
