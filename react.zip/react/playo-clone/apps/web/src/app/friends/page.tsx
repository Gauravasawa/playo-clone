import { FriendsView } from '@/features/friends';

export default function Page() {
  return <FriendsView />;
}
