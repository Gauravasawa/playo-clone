import { app } from '@/store';
import { GameByCodeView } from '@/features/games';

export const dynamic = 'force-dynamic';

export default async function Page({ params }: { params: Promise<{ code: string }> }) {
  const code = (await params).code;
  return (
    <app.Root>
      <GameByCodeView code={code} />
    </app.Root>
  );
}
