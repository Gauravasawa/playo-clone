import { app } from '@/store';
import { GameDetailView } from '@/features/games';

export const dynamic = 'force-dynamic';

/** Who can see a game depends on who's asking, so the browser loads it */
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const id = Number((await params).id);
  return (
    <app.Root>
      <GameDetailView id={id} />
    </app.Root>
  );
}
