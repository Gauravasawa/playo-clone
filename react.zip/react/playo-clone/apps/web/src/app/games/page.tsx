import { app, prefetch } from '@/store';
import { DEFAULT_GAMES_PARAMS } from '@/config/constants';
import { GamesView } from '@/features/games';

export const dynamic = 'force-dynamic';

export default async function Page() {
  await prefetch(app.fetchQuery('sports'), app.fetchQuery('games', DEFAULT_GAMES_PARAMS));
  return (
    <app.Root>
      <GamesView />
    </app.Root>
  );
}
