import { app, prefetch } from '@/store';
import { HelpView } from '@/features/help';

export const dynamic = 'force-dynamic';

export default async function Page() {
  await prefetch(app.fetchQuery('faq', ''));
  return (
    <app.Root>
      <HelpView />
    </app.Root>
  );
}
