import { TicketThreadView } from '@/features/help';

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  return <TicketThreadView id={Number((await params).id)} />;
}
