import { Suspense } from 'react';
import { TicketsView } from '@/features/help';

export default function Page() {
  return (
    <Suspense>
      <TicketsView />
    </Suspense>
  );
}
