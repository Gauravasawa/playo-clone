import { LabView } from '@/features/lab';

export default function Page() {
  return <LabView />;
}
