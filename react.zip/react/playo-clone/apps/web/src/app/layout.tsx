import type { Metadata } from 'next';
import './globals.css';
import './theme.css';
import { Shell } from '@/components/layout/Shell';
import { app } from '@/store';
import { ThemeScript } from '@/components/theme/ThemeScript';

export const metadata: Metadata = {
  title: 'Playo Clone – book venues, find games',
  description: 'A Playo-style sports app built to exercise createStore',
};

export const viewport = { colorScheme: 'light dark', themeColor: '#f5f7f6' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <ThemeScript />
      </head>
      <body className="min-h-screen font-sans antialiased">
        {/* Every Client Component below reads the store through a Root. This one carries no data
            (the header only needs the store to exist); pages add their own Root with data. */}
        <app.Root>
          <Shell>{children}</Shell>
        </app.Root>
      </body>
    </html>
  );
}
