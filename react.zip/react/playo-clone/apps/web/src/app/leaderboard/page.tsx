import { app, prefetch } from '@/store';
import { DEFAULT_LEADERBOARD_PARAMS } from '@/config/constants';
import { LeaderboardView } from '@/features/community';

export const dynamic = 'force-dynamic';

export default async function Page() {
  // Same data the first client render shows: the sport chips and the default list
  await prefetch(app.fetchQuery('sports'), app.fetchQuery('leaderboard', DEFAULT_LEADERBOARD_PARAMS));
  return (
    <app.Root>
      <LeaderboardView />
    </app.Root>
  );
}
