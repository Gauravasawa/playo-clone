import { app } from '@/store';
import { LearningView } from '@/features/coaching';

export default function Page() {
  return (
    <app.Root>
      <h1 className="mb-5 text-2xl font-extrabold">My learning</h1>
      <LearningView />
    </app.Root>
  );
}
