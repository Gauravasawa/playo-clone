import { OwnerDashboardView } from '@/features/owner';

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  return <OwnerDashboardView id={Number((await params).id)} />;
}
