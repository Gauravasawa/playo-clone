import { OwnerHome } from '@/features/owner';

export default function Page() {
  return <OwnerHome />;
}
