import { Suspense } from 'react';
import { app, prefetch } from '@/store';
import { DEFAULT_VENUE_FILTER } from '@/config/constants';
import { VenuesView } from '@/features/venues';
import { ReferralCapture } from '@/features/plus/ReferralCapture';

// Fetches from the backend on every request, so it can't be built ahead of time
export const dynamic = 'force-dynamic';

export default async function Page() {
  // Runs on the server, into this request's own store ...
  await prefetch(app.fetchQuery('sports'), app.fetchQuery('venues', DEFAULT_VENUE_FILTER));
  // ... and <Root> sends what was loaded to the browser, so the first paint already has the venues
  return (
    <app.Root>
      <Suspense fallback={null}>
        <ReferralCapture />
      </Suspense>
      <VenuesView />
    </app.Root>
  );
}
