import { PlusView } from '@/features/plus';

export default function Page() {
  return <PlusView />;
}
