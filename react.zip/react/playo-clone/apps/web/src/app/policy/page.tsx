import { app, prefetch } from '@/store';
import { PolicyView } from '@/features/help';

export const dynamic = 'force-dynamic';

export default async function Page() {
  await prefetch(app.fetchQuery('policy'));
  return (
    <app.Root>
      <PolicyView />
    </app.Root>
  );
}
