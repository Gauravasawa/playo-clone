import { ProfileEditor } from '@/features/profile';

export default function Page() {
  return <ProfileEditor />;
}
