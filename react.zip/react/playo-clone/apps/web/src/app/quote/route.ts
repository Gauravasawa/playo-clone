import { app } from '@/store';
import type { Slot } from '@/lib/api';

/**
 * GET /quote?venueId=3&date=2026-10-24&slots=18:00,19:00&extras=badminton:Racket&plus=1&karma=500&useKarma=1
 *
 * A price quote worked out on the server by the same `quote` computed value the checkout uses in the browser.
 * There is no request store in a Route Handler, so this makes its own `scope`, loads the venue and the day's
 * slot prices through it, sets the selection with key actions, and reads `quote`. It also toggles one slot and
 * undoes it, to show that `history` works inside a scope.
 */
export async function GET(req: Request) {
  const q = new URL(req.url).searchParams;
  const venueId = Number(q.get('venueId'));
  const date = q.get('date') ?? '';
  const wanted = (q.get('slots') ?? '').split(',').filter(Boolean);
  if (!venueId || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !wanted.length) {
    return Response.json({ error: 'venueId, date and slots are required' }, { status: 400 });
  }

  const scope = app.createScope();
  try {
    const venue = await scope.fetchQuery('venue', venueId);
    const slots: Slot[] = await scope.fetchQuery('slots', { venueId, date });
    const picked = slots.filter((s) => wanted.includes(s.time));
    if (picked.length !== wanted.length) return Response.json({ error: 'Some of those slots do not exist' }, { status: 400 });
    if (picked.some((s) => !s.available)) return Response.json({ error: 'Some of those slots are not available' }, { status: 409 });

    await scope.set.selection.start(venueId, date);
    for (const s of picked) await scope.set.selection.toggle({ time: s.time, price: s.price });
    const extras = (q.get('extras') ?? '').split(',').filter(Boolean);
    for (const id of extras) await scope.set.checkout.toggleExtra(id);
    await scope.set.checkout.setKarma(q.get('useKarma') === '1');
    await scope.set.pricing.set({
      equipment: venue.equipment ?? [],
      isPlus: q.get('plus') === '1',
      karmaBalance: Number(q.get('karma') ?? 0) || 0,
      passCoversSlots: false,
    });

    const quote = scope.getState('quote');
    const total = scope.getState('total');

    // history inside a scope: add a slot and undo it, the quote must come back to what it was
    const before = JSON.stringify(quote);
    const spare = slots.find((s) => s.available && !wanted.includes(s.time));
    let undoRestoresQuote: boolean | null = null;
    if (spare) {
      await scope.set.selection.toggle({ time: spare.time, price: spare.price });
      const changed = JSON.stringify(scope.getState('quote')) !== before;
      scope.undo();
      undoRestoresQuote = changed && JSON.stringify(scope.getState('quote')) === before;
    }
    return Response.json({ venueId, date, slots: wanted, extras, total, quote, undoRestoresQuote });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : 'Could not price that' }, { status: 502 });
  } finally {
    scope.destroy();
  }
}
