import { app } from '@/store';

/**
 * A Route Handler: no request store exists here (that's only for rendering), so it makes its own
 * `scope`, loads the profile through it, and answers with a small share card.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  const scope = app.createScope();
  const profile = await scope.fetchQuery('player', { username, token: null }).catch(() => null);
  if (!profile) return Response.json({ error: 'Player not found' }, { status: 404 });
  return Response.json({
    title: `${profile.name} (@${profile.username}) on Playo clone`,
    description: profile.restricted ? 'This profile is private.' : profile.bio || `${profile.stats.followers} followers`,
    url: `/p/${profile.username}`,
  });
}
