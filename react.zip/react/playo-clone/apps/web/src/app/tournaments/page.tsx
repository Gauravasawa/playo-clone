import { app, prefetch } from '@/store';
import { DEFAULT_TOURNAMENT_PARAMS } from '@/config/constants';
import { TournamentsView } from '@/features/community';

export const dynamic = 'force-dynamic';

export default async function Page() {
  // Same data the first client render shows: the sport chips and the default list
  await prefetch(app.fetchQuery('sports'), app.fetchQuery('tournaments', DEFAULT_TOURNAMENT_PARAMS));
  return (
    <app.Root>
      <TournamentsView />
    </app.Root>
  );
}
