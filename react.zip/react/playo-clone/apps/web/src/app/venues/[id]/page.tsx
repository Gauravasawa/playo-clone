import { app, prefetch } from '@/store';
import { VenueDetailView } from '@/features/booking';

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const id = Number((await params).id);
  // The venue is public and the same for everyone, so it's rendered on the server.
  // Slots depend on the day the visitor picks, so the browser loads those.
  await prefetch(app.fetchQuery('venue', id));
  return (
    <app.Root>
      <VenueDetailView id={id} />
    </app.Root>
  );
}
