import { Suspense } from 'react';
import { WalletView } from '@/features/wallet';

export default function Page() {
  // The tab comes from ?tab=, which needs a Suspense boundary
  return (
    <Suspense fallback={null}>
      <WalletView />
    </Suspense>
  );
}
