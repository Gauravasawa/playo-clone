'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef } from 'react';
import { app } from '@/store';
import { prefs } from '@/store/prefs.store';
import { SavingIndicator } from './SavingIndicator';
import { ThemeToggle } from '@/components/theme/ThemeToggle';
import { Avatar } from '@/components/ui/Avatar';
import { ApiError } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { money } from '@/lib/format';
import { CITIES } from '@/config/cities';
import { MENU_LINKS, MORE_LINKS, NAV_LINKS } from '@/config/nav';
import { signOut } from '@/store/session';

function Badge({ n, testId, what }: { n: number; testId: string; what: string }) {
  if (!n) return null;
  return <span data-testid={testId} data-tip={`${n} ${what}`} className="absolute -right-1.5 -top-1.5 min-w-4 rounded-full bg-red-600 px-1 text-center text-[10px] font-bold leading-4 text-white">{n > 99 ? '99+' : n}</span>;
}

export function Header() {
  const mounted = useMounted();
  const path = usePathname();
  const menu = useRef<HTMLDetailsElement>(null);
  const more = useRef<HTMLDetailsElement>(null);
  // the header stays mounted between pages, so close the menus when you go somewhere
  useEffect(() => { if (menu.current) menu.current.open = false; if (more.current) more.current.open = false; }, [path]);
  useEffect(() => {
    const away = (e: PointerEvent) => { for (const d of [menu.current, more.current]) if (d?.open && !d.contains(e.target as Node)) d.open = false; };
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') for (const d of [menu.current, more.current]) if (d?.open) d.open = false; };
    document.addEventListener('pointerdown', away);
    document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('pointerdown', away); document.removeEventListener('keydown', esc); };
  }, []);
  const [city, setCity] = app.useGlobalState('city');
  const [token] = app.useGlobalState('token');
  const [favoriteCount] = app.useGlobalState('favoriteCount');
  const [socket] = app.useGlobalState('socket');
  const [me, , meStatus] = app.useGlobalState('me', token ?? undefined);
  const [badges] = app.useGlobalState('badges', token ?? undefined);
  const [wallet] = app.useGlobalState('wallet', token ?? undefined);
  // session-only: forgotten when the tab is closed
  const [privacy, setPrivacy] = prefs.useGlobalState('privacyMode');

  // A token the server no longer knows (e.g. the database was reset): sign out
  useEffect(() => {
    if (meStatus.error instanceof ApiError && meStatus.error.status === 401) signOut();
  }, [meStatus.error]);

  const icon = 'relative rounded-full p-1 text-lg sm:p-2 hover:bg-black/5';
  return (
    <header className="sticky top-0 z-30 border-b bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-x-3 gap-y-2 px-3 py-3 sm:px-4">
        <Link href="/" className="inline-flex min-h-8 items-center text-xl font-extrabold tracking-tight text-brand">
          playo<span className="text-ink">·clone</span>
        </Link>
        <nav className="order-last flex w-full gap-1 overflow-x-auto text-sm md:order-none md:w-auto">
          {NAV_LINKS.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={`whitespace-nowrap rounded-full px-2.5 py-1.5 font-medium ${path === n.href ? 'bg-brand text-white' : 'text-ink/70 hover:bg-black/5'}`}
            >
              {n.label}
            </Link>
          ))}
          {MORE_LINKS.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={`whitespace-nowrap rounded-full px-2.5 py-1.5 font-medium md:hidden ${path === n.href ? 'bg-brand text-white' : 'text-ink/70 hover:bg-black/5'}`}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <details ref={more} className="relative hidden text-sm md:block">
          <summary data-testid="more-menu" className={`flex cursor-pointer list-none items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-1.5 font-medium hover:bg-black/5 ${MORE_LINKS.some((l) => l.href === path) ? 'bg-brand text-white' : 'text-ink/70'}`}>More <span aria-hidden className="text-xs">▾</span></summary>
          <div className="absolute left-0 mt-2 w-44 space-y-0.5 rounded-xl border bg-white p-2 shadow-lg">
            {MORE_LINKS.map((l) => <Link key={l.href} href={l.href} className="block rounded-lg px-3 py-1.5 hover:bg-black/5">{l.label}</Link>)}
          </div>
        </details>
        <div className="ml-auto flex items-center gap-0.5 text-sm sm:gap-1">
          <ThemeToggle />
          {mounted && (
            <>
              <select aria-label="City" data-tip="Choose your city" value={city} onChange={(e) => setCity(e.target.value)} className="max-w-[5.5rem] rounded-lg border bg-white px-2 py-1.5 sm:max-w-none">
                {CITIES.map((c) => <option key={c}>{c}</option>)}
              </select>
              <SavingIndicator />
              <span title="Favourite venues" className="hidden px-2 text-ink/70 sm:inline">♥ {favoriteCount}</span>
              {token ? (
                <>
                  <Link href="/wallet" data-tip="Wallet balance (tap to add money)" className="inline-flex min-h-8 items-center rounded-full border px-2 py-1 font-semibold sm:px-3 hover:bg-black/5" data-testid="wallet-chip">{privacy ? '₹ ••••' : wallet ? money(wallet.balance) : '₹…'}</Link>
                  <Link href="/chat" aria-label={`Chats${badges?.chats ? `, ${badges.chats} unread` : ''}`} className={icon}>💬<Badge n={badges?.chats ?? 0} testId="chat-badge" what="chats with new messages" /></Link>
                  <Link href="/notifications" aria-label={`Notifications${badges?.notifications ? `, ${badges.notifications} unread` : ''}`} className={icon}>🔔<Badge n={badges?.notifications ?? 0} testId="bell-badge" what="unread notifications" /></Link>
                  <span title={`Live updates: ${socket}`} aria-label={`Live updates ${socket}`} data-testid="socket-status" className={`hidden size-2 rounded-full sm:block ${socket === 'open' ? 'bg-green-500' : socket === 'connecting' ? 'bg-amber-400' : 'bg-gray-300'}`} />
                  <details ref={menu} className="relative">
                    <summary className="flex cursor-pointer list-none items-center gap-2 rounded-full p-1 hover:bg-black/5" data-testid="user-menu" data-tip="Your account" aria-label="Your account menu">
                      {me ? <Avatar player={{ ...me, online: true }} size={32} dot={false} /> : <span className="size-8 rounded-full bg-black/10" />}
                    </summary>
                    <div className="absolute right-0 mt-2 w-56 space-y-0.5 rounded-xl border bg-white p-2 shadow-lg">
                      {me && <p className="px-3 py-1 text-xs text-ink/50">@{me.username}{me.plus.active && ' ✨ Plus'} · {privacy ? '••' : me.karma} Karma</p>}
                      {MENU_LINKS.map((l) => <Link key={l.href} href={l.href} className="block rounded-lg px-3 py-1.5 hover:bg-black/5">{l.label}</Link>)}
                      <label className="flex cursor-pointer items-center gap-2 rounded-lg px-3 py-1.5 hover:bg-black/5"><input type="checkbox" data-testid="privacy-mode" checked={privacy} onChange={(e) => setPrivacy(e.target.checked)} /> Hide amounts <span className="text-xs text-ink/40">(this tab)</span></label>
                      <button onClick={signOut} className="block w-full rounded-lg px-3 py-1.5 text-left text-red-600 hover:bg-red-50">Log out</button>
                    </div>
                  </details>
                </>
              ) : (
                <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-4 py-1.5 font-semibold text-white hover:bg-brand-dark">Log in</button>
              )}
            </>
          )}
        </div>
      </div>
    </header>
  );
}
