'use client';

import { app } from '@/store';

/** "Saving…" while a key action's save is running (onSaveStart … onSaveSuccess/Error); a queued offline save keeps it up until the connection is back */
export function SavingIndicator() {
  const [pending] = app.useGlobalState('pendingSaves');
  if (!pending) return null;
  const offline = typeof navigator !== 'undefined' && !navigator.onLine;
  return (
    <span data-testid="saving" className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-800" aria-live="polite">
      {offline ? 'Saving when you are back online…' : `Saving${pending > 1 ? ` ${pending}` : ''}…`}
    </span>
  );
}
