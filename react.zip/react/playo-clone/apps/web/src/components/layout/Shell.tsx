import { LoginModal } from '@/features/auth';
import { RealtimeProvider } from '@/realtime/RealtimeProvider';
import { ThemeProvider } from '@/components/theme/ThemeProvider';
import { TooltipLayer } from '@/components/ui/Tooltip';
import { Header } from './Header';
import { Toasts } from './Toasts';

/** The frame around every page */
export function Shell({ children }: { children: React.ReactNode }) {
  return (
    <>
      <ThemeProvider />
      <Header />
      <main className="mx-auto max-w-5xl px-4 pb-24 pt-6">{children}</main>
      <Toasts />
      <TooltipLayer />
      <LoginModal />
      <RealtimeProvider />
    </>
  );
}
