'use client';

import { useEffect, useState } from 'react';
import { app, type Toast } from '@/store';

const SHOW_MS = 3500;

/** Shows what `app.emit('toast', ...)` sends, from anywhere in the app */
export function Toasts() {
  const [items, setItems] = useState<(Toast & { id: number })[]>([]);

  useEffect(() => {
    let n = 0;
    return app.on('toast', (t) => {
      const id = ++n;
      setItems((list) => [...list, { ...t, id }].slice(-4));
      setTimeout(() => setItems((list) => list.filter((x) => x.id !== id)), SHOW_MS);
    });
  }, []);

  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-50 flex w-80 flex-col gap-2">
      {items.map((t) => (
        <div key={t.id} role="status" className={`rounded-xl px-4 py-3 text-sm font-medium text-white shadow-lg ${t.kind === 'ok' ? 'bg-brand-dark' : 'bg-red-600'}`}>
          {t.text}
        </div>
      ))}
    </div>
  );
}
