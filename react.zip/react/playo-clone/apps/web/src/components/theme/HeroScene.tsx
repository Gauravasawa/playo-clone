'use client';

import { useEffect, useRef } from 'react';
import { reducedMotion } from '@/lib/theme';

/**
 * A small 3D scene for the home hero: a floodlit pitch seen at an angle with a ball hovering above it. It tilts with the pointer,
 * and the theme changes the light (sun and warm grass by day, moon, stars and floodlight cones at night). Pure CSS 3D, no library.
 */
export function HeroScene() {
  const scene = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scene.current;
    const host = el?.parentElement;
    if (!el || !host || reducedMotion()) return;
    let raf = 0;
    const set = (x: number, y: number) => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => { el.style.setProperty('--px', x.toFixed(3)); el.style.setProperty('--py', y.toFixed(3)); });
    };
    const move = (e: PointerEvent) => {
      const r = host.getBoundingClientRect();
      set((e.clientX - r.left) / r.width - 0.5, (e.clientY - r.top) / r.height - 0.5);
    };
    const leave = () => set(0, 0);
    host.addEventListener('pointermove', move);
    host.addEventListener('pointerleave', leave);
    return () => { cancelAnimationFrame(raf); host.removeEventListener('pointermove', move); host.removeEventListener('pointerleave', leave); };
  }, []);

  return (
    <div ref={scene} className="hero-scene" aria-hidden="true" data-testid="hero-scene">
      <div className="hs-sky">
        <span className="hs-sun" />
        <span className="hs-moon" />
        {Array.from({ length: 14 }, (_, i) => <i key={i} className="hs-star" style={{ ['--i' as string]: i }} />)}
      </div>
      <div className="hs-stage">
        <div className="hs-world">
          <div className="hs-court">
            <span className="hs-line hs-mid" />
            <span className="hs-line hs-circle" />
            <span className="hs-line hs-box hs-box-l" />
            <span className="hs-line hs-box hs-box-r" />
          </div>
          <span className="hs-light hs-light-l" />
          <span className="hs-light hs-light-r" />
        </div>
        <div className="hs-ball-wrap">
          <span className="hs-ball-shadow" />
          <span className="hs-ball"><span className="hs-ball-pattern" /></span>
        </div>
      </div>
    </div>
  );
}
