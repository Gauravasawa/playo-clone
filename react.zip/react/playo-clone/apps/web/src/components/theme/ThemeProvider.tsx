'use client';

import { useEffect, useState } from 'react';
import { app } from '@/store';
import { paint, resolveTheme } from '@/lib/theme';

/**
 * Keeps <html> in step with the stored choice: after the saved choice has loaded, when another tab changes it, and (for 'system')
 * when the operating system switches. Clicks in the toggle paint by themselves (with the animation) before this runs.
 */
export function ThemeProvider() {
  const [pref] = app.useGlobalState('theme');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    app.hydrated.then(() => alive && setReady(true));
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!ready) return; // until the saved choice is loaded `pref` is the default, and must not undo what the head script painted
    const apply = () => paint(resolveTheme(pref), pref);
    apply();
    if (pref !== 'system') return;
    const mq = matchMedia('(prefers-color-scheme: dark)');
    mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [pref, ready]);

  return null;
}
