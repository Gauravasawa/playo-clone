/**
 * Puts the saved or system theme on <html> before the first paint, so a dark-mode visitor never sees a white flash.
 * It is a plain script file (`public/theme-init.js`), not inline code: nothing is injected into the page as HTML, and a strict
 * Content-Security-Policy (`script-src 'self'`) can allow it. It is small, cached by the browser, and blocks only until it has run.
 */
export function ThemeScript() {
  return <script src="/theme-init.js" />;
}
