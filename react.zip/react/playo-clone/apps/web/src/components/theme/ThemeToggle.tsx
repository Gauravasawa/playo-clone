'use client';

import { useEffect, useRef, useState } from 'react';
import { app } from '@/store';
import { currentTheme, paint, resolveTheme, runThemeTransition, THEME_PREFS, type ThemePref } from '@/lib/theme';

const LABEL: Record<ThemePref, string> = { light: 'Light', dark: 'Dark', system: 'System' };
const ICON: Record<ThemePref, string> = { light: '☀️', dark: '🌙', system: '🖥️' };

/**
 * The theme button: a small 3D ball (a sun-lit football on one side, a moon on the other) that spins and bounces when the theme changes,
 * plus a menu for Light / Dark / System. Which side shows comes from <html data-theme> in CSS, so it is right on the first paint.
 */
export function ThemeToggle() {
  const [pref, setPref] = app.useGlobalState('theme');
  const [open, setOpen] = useState(false);
  const [hop, setHop] = useState(false);
  const ball = useRef<HTMLButtonElement>(null);
  const box = useRef<HTMLDivElement>(null);
  const spin = useRef(0); // the ball's rotation in degrees: 180 per theme, plus a full extra turn when it is clicked

  // keep the ball showing the right side when the theme changes some other way (system, another tab)
  useEffect(() => {
    const sync = () => {
      const want = currentTheme() === 'dark' ? 180 : 0;
      if (((spin.current % 360) + 360) % 360 !== want) {
        spin.current += 180;
        ball.current?.style.setProperty('--spin', `${spin.current}`);
      }
    };
    sync();
    const mo = new MutationObserver(sync);
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    return () => mo.disconnect();
  }, []);

  useEffect(() => {
    if (!open) return;
    const away = (e: PointerEvent) => {
      if (!box.current?.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
        ball.current?.focus();
      }
    };
    document.addEventListener('pointerdown', away);
    document.addEventListener('keydown', esc);
    return () => {
      document.removeEventListener('pointerdown', away);
      document.removeEventListener('keydown', esc);
    };
  }, [open]);

  const choose = (next: ThemePref, from?: HTMLElement | null) => {
    const resolved = resolveTheme(next);
    const rect = (from ?? ball.current)?.getBoundingClientRect();
    const origin = rect ? { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 } : undefined;
    if (resolved !== currentTheme()) {
      spin.current += 540; // a full spin and half a turn: lands on the other side
      ball.current?.style.setProperty('--spin', `${spin.current}`);
      setHop(true);
      setTimeout(() => setHop(false), 950);
    }
    setOpen(false);
    void runThemeTransition(() => {
      paint(resolved, next);
      setPref(next);
    }, origin);
  };

  return (
    <div ref={box} className="relative flex items-center" data-testid="theme-toggle-box">
      <button
        ref={ball}
        type="button"
        data-testid="theme-toggle"
        data-pref={pref}
        aria-label={`Switch theme (now ${LABEL[pref]})`}
        title="Switch light / dark"
        onClick={(e) => choose(currentTheme() === 'dark' ? 'light' : 'dark', e.currentTarget)}
        className={`theme-ball ${hop ? 'theme-ball-hop' : ''}`}
      >
        <span className="theme-ball-body">
          <span className="theme-ball-face theme-ball-day" />
          <span className="theme-ball-face theme-ball-night" />
        </span>
        <span className="theme-ball-shadow" />
      </button>
      <button
        type="button"
        data-testid="theme-menu-button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label="Choose theme: light, dark or system"
        onClick={() => setOpen((o) => !o)}
        className="ml-0.5 grid min-h-8 min-w-7 shrink-0 place-items-center rounded-full text-xs text-ink/60 hover:bg-black/5"
      >
        ▾
      </button>
      {open && (
        <div role="menu" data-testid="theme-menu" className="absolute left-0 top-full z-40 mt-2 w-40 sm:left-auto sm:right-0 space-y-0.5 rounded-xl border bg-white p-1.5 text-sm shadow-lg">
          {THEME_PREFS.map((p) => (
            <button
              key={p}
              role="menuitemradio"
              aria-checked={pref === p}
              data-testid={`theme-${p}`}
              onClick={(e) => choose(p, e.currentTarget)}
              className={`flex w-full items-center gap-2 rounded-lg px-3 py-1.5 text-left hover:bg-black/5 ${pref === p ? 'font-semibold text-brand-dark' : ''}`}
            >
              <span aria-hidden>{ICON[p]}</span>
              {LABEL[p]}
              {pref === p && <span aria-hidden className="ml-auto">✓</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
