'use client';

import { app } from '@/store';
import type { Player } from '@/lib/api';

type Who = Pick<Player, 'id' | 'name' | 'avatarEmoji' | 'avatarColor'> & { online?: boolean };

/** The player's emoji on their colour; a green dot when they're online (live over the WebSocket) */
export function Avatar({ player, size = 40, dot = true }: { player: Who; size?: number; dot?: boolean }) {
  const [presence] = app.useGlobalState('presence');
  const online = presence[player.id] ?? player.online ?? false;
  return (
    <span className="relative inline-block shrink-0" style={{ width: size, height: size }}>
      <span
        className="grid h-full w-full place-items-center rounded-full text-white"
        style={{ background: player.avatarColor, fontSize: size * 0.5 }}
        aria-label={player.name}
        role="img"
      >
        {player.avatarEmoji || player.name.slice(0, 1).toUpperCase()}
      </span>
      {dot && online && (
        <span data-testid={`online-${player.id}`} className="absolute bottom-0 right-0 size-3 rounded-full border-2 border-white bg-green-500" title="Online" />
      )}
    </span>
  );
}
