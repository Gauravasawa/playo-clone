export function EmptyState({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl bg-white p-10 text-center text-ink/60">{children}</div>;
}
