export function ErrorNotice({ children, onRetry }: { children: React.ReactNode; onRetry?: () => void }) {
  return (
    <p className="rounded-xl bg-red-50 p-4 text-red-700">
      {children}{' '}
      {onRetry && (
        <button className="underline" onClick={onRetry}>
          Try again
        </button>
      )}
    </p>
  );
}
