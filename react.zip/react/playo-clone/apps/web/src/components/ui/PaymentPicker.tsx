'use client';

import { useState } from 'react';
import { app } from '@/store';
import type { PayMethod } from '@/lib/api';
import { money } from '@/lib/format';

/** Wallet balance plus the choice of how to pay; the Lab can make UPI/card (mock) fail */
export function usePaymentChoice(amountInr: number) {
  const [token] = app.useGlobalState('token');
  const [wallet] = app.useGlobalState('wallet', token ?? undefined);
  const [method, setMethod] = useState<PayMethod>('wallet');
  const balance = wallet?.balance ?? 0;
  const enough = amountInr <= balance;
  return { method, setMethod, balance, enough, blocked: method === 'wallet' && !enough };
}

export function PaymentPicker({ choice, name = 'pay' }: { choice: ReturnType<typeof usePaymentChoice>; name?: string }) {
  const { method, setMethod, balance, enough } = choice;
  return (
    <fieldset className="space-y-1 text-sm">
      <legend className="mb-1 font-semibold">Pay with</legend>
      <label className="flex min-h-7 items-center gap-2"><input type="radio" name={name} checked={method === 'wallet'} onChange={() => setMethod('wallet')} /> Wallet <span className="text-ink/50">({money(balance)}){!enough && ' — not enough'}</span></label>
      <label className="flex min-h-7 items-center gap-2"><input type="radio" name={name} checked={method === 'upi'} onChange={() => setMethod('upi')} /> UPI (mock)</label>
      <label className="flex min-h-7 items-center gap-2"><input type="radio" name={name} checked={method === 'card'} onChange={() => setMethod('card')} /> Card (mock)</label>
    </fieldset>
  );
}
