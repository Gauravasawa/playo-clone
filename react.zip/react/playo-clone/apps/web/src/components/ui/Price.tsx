'use client';

import { formatLocal, formatPrice } from '@/config/cities';

/** A price held in rupees, shown in the city's currency (rupees in brackets for non-Indian cities) */
export function Price({ inr, city, brackets = true, className }: { inr: number; city: string; brackets?: boolean; className?: string }) {
  return <span className={className}>{brackets ? formatPrice(inr, city) : formatLocal(inr, city)}</span>;
}
