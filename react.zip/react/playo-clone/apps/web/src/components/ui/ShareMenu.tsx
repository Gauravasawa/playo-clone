'use client';

import { useState } from 'react';
import { app } from '@/store';

/** Share a link: the phone's share sheet when there is one, otherwise copy it */
export function ShareMenu({ path, title, text, label = 'Share' }: { path: string; title: string; text?: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const url = () => `${location.origin}${path}`;

  const share = async () => {
    try {
      if (navigator.share) {
        await navigator.share({ title, text, url: url() });
        return;
      }
      await navigator.clipboard.writeText(url());
      setCopied(true);
      app.emit('toast', { kind: 'ok', text: 'Link copied' });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* the share sheet was dismissed */
    }
  };
  return (
    <button onClick={share} data-testid="share-button" className="rounded-lg border px-3 py-1.5 text-sm font-semibold hover:bg-black/5">
      {copied ? '✓ Copied' : `🔗 ${label}`}
    </button>
  );
}
