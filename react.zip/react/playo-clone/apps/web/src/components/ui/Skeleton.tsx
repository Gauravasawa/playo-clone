/** Grey pulsing placeholders while data loads */
export function Skeleton({ count = 3, className = 'h-24' }: { count?: number; className?: string }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className={`animate-pulse rounded-2xl bg-black/10 ${className}`} />
      ))}
    </div>
  );
}
