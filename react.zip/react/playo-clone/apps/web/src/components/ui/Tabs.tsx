'use client';

export function Tabs<T extends string>({ tabs, value, onChange }: { tabs: { id: T; label: string; badge?: number }[]; value: T; onChange: (id: T) => void }) {
  return (
    <div role="tablist" className="flex gap-1 overflow-x-auto rounded-full bg-black/5 p-1 text-sm">
      {tabs.map((t) => (
        <button
          key={t.id}
          role="tab"
          aria-selected={value === t.id}
          onClick={() => onChange(t.id)}
          className={`whitespace-nowrap rounded-full px-4 py-1.5 font-medium ${value === t.id ? 'bg-white shadow' : 'text-ink/60 hover:text-ink'}`}
        >
          {t.label}
          {!!t.badge && <span data-tip={`${t.badge} waiting`} className="ml-1.5 rounded-full bg-red-600 px-1.5 text-xs text-white">{t.badge}</span>}
        </button>
      ))}
    </div>
  );
}
