'use client';

import { cloneElement, isValidElement, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

/**
 * Tooltips for the whole app, from one place.
 *
 *   <button data-tip="Add to favourites">♥</button>           an attribute is enough (use {...tip('text')} to spread it)
 *   <Tooltip text="Pick a slot first"><button disabled>Book</button></Tooltip>
 *   title="…" on any element also works (it is turned into the same tooltip, so the browser's slow native one doesn't show twice)
 *   text cut off with "…" (truncate / line-clamp) shows its full text on hover with no attribute at all
 *
 * One <TooltipLayer /> (mounted in the Shell) listens for the pointer and the keyboard:
 *   mouse     the tooltip appears after 250 ms over the element and goes away when the pointer leaves, scrolls or clicks
 *   keyboard  it appears when the element gets focus from the keyboard (:focus-visible); Escape closes it
 *   touch     press and hold (about half a second) shows it for a few seconds; a tap on a non-clickable thing (a dot, a badge) shows it too
 * It works on disabled controls (found with elementFromPoint, since disabled controls get no mouse events) and on native selects and inputs.
 * While it is shown the element gets aria-describedby -> the tooltip (role="tooltip"), so screen readers read it as the description.
 */
export const tip = (text: string) => ({ 'data-tip': text });

export function Tooltip({ text, children }: { text: string; children: React.ReactElement<Record<string, unknown>> }) {
  if (!isValidElement(children)) return children;
  return cloneElement(children, { 'data-tip': text });
}

const DELAY = 250;
const LONG_PRESS = 450;
const TOUCH_SHOW = 2800;
const ID = 'app-tooltip';
const INTERACTIVE = 'a[href], button, input, select, textarea, summary, [role=button], [role=tab], [role=menuitemradio], label';

const CONTROL = 'a[href], button, summary, [role=button], [role=tab], [role=menuitemradio]';

interface Target { el: HTMLElement; text: string }

/** Is this element's text cut off (ellipsis, or line-clamp)? */
function cutOff(el: HTMLElement): boolean {
  if (el.scrollWidth <= el.clientWidth + 1 && el.scrollHeight <= el.clientHeight + 1) return false;
  const cs = getComputedStyle(el);
  if (cs.textOverflow === 'ellipsis' && el.scrollWidth > el.clientWidth + 1) return true;
  const clamp = cs.getPropertyValue('-webkit-line-clamp');
  return !!clamp && clamp !== 'none' && el.scrollHeight > el.clientHeight + 1;
}

/** What to show for the element under the pointer: the nearest data-tip / title, or the full text of cut-off text */
function targetOf(start: Element | null): Target | null {
  let depth = 0;
  for (let e = start; e && e !== document.body && depth < 8; e = e.parentElement, depth++) {
    if (!(e instanceof HTMLElement)) continue;
    const t = e.getAttribute('data-tip') ?? e.getAttribute('title') ?? e.dataset.tipTitle;
    if (t && t.trim()) return { el: e, text: t.trim() };
    // a control that is only a symbol (♥ 🔔 × ▾ ★) shows its accessible name
    const name = e.getAttribute('aria-label');
    if (name && e.matches(CONTROL) && !/[\p{L}\p{N}]/u.test(e.textContent ?? '')) return { el: e, text: name.trim() };
    if (cutOff(e)) {
      const full = (e.getAttribute('aria-label') || e.textContent || '').replace(/\s+/g, ' ').trim();
      if (full) return { el: e, text: full };
    }
  }
  return null;
}

export function TooltipLayer() {
  const [shown, setShown] = useState<{ text: string; rect: DOMRect } | null>(null);
  const [pos, setPos] = useState<{ left: number; top: number; below: boolean } | null>(null);
  const bubble = useRef<HTMLDivElement>(null);
  const cur = useRef<Target | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const hideTimer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const restore = useRef<(() => void) | null>(null);

  useEffect(() => {
    const clear = () => { clearTimeout(timer.current); clearTimeout(hideTimer.current); };
    const hide = () => {
      clear();
      restore.current?.();
      restore.current = null;
      cur.current = null;
      setShown(null);
      setPos(null);
    };
    const show = (t: Target) => {
      restore.current?.();
      // title="…" becomes this tooltip: take it off while shown so the browser doesn't draw its own
      const title = t.el.getAttribute('title');
      const prevDescribed = t.el.getAttribute('aria-describedby');
      if (title && !t.el.getAttribute('data-tip')) { t.el.dataset.tipTitle = title; t.el.removeAttribute('title'); }
      t.el.setAttribute('aria-describedby', ID);
      restore.current = () => {
        if (t.el.dataset.tipTitle !== undefined) { t.el.setAttribute('title', t.el.dataset.tipTitle); delete t.el.dataset.tipTitle; }
        if (prevDescribed === null) t.el.removeAttribute('aria-describedby'); else t.el.setAttribute('aria-describedby', prevDescribed);
      };
      cur.current = t;
      setShown({ text: t.text, rect: t.el.getBoundingClientRect() });
    };
    const pending = { current: null as Target | null };
    let lastMove = 0;
    let touchStart: { x: number; y: number } | null = null;
    let longPressed = false;

    const onMove = (e: PointerEvent) => {
      if (e.pointerType === 'touch') return;
      const now = performance.now();
      if (now - lastMove < 40) return; // cheap enough, but there is no need to look on every pixel
      lastMove = now;
      // elementFromPoint also finds disabled controls, which get no mouse events of their own
      const t = targetOf(document.elementFromPoint(e.clientX, e.clientY));
      if (t && (pending.current?.el === t.el || cur.current?.el === t.el)) return;
      pending.current = t;
      if (!t) { hide(); return; }
      hide();
      timer.current = setTimeout(() => { if (pending.current?.el === t.el) show(t); }, DELAY);
    };
    const onLeave = (e: PointerEvent | MouseEvent) => { if (!(e as MouseEvent).relatedTarget) { pending.current = null; hide(); } };
    const onFocusIn = (e: FocusEvent) => {
      const el = e.target as HTMLElement;
      if (!el.matches?.(':focus-visible')) return;
      const t = targetOf(el);
      if (!t) return;
      hide();
      pending.current = t;
      timer.current = setTimeout(() => { if (pending.current?.el === t.el) show(t); }, DELAY);
    };
    const onFocusOut = () => { pending.current = null; hide(); };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape' && (cur.current || pending.current)) { pending.current = null; hide(); } };
    const onDown = (e: PointerEvent) => {
      if (e.pointerType !== 'touch') { pending.current = null; hide(); return; }
      touchStart = { x: e.clientX, y: e.clientY };
      longPressed = false;
      const t = targetOf(e.target as Element);
      clearTimeout(timer.current);
      if (!t) return;
      pending.current = t;
      timer.current = setTimeout(() => {
        longPressed = true;
        show(t);
        hideTimer.current = setTimeout(hide, TOUCH_SHOW);
      }, LONG_PRESS);
    };
    const onTouchMove = (e: PointerEvent) => {
      if (e.pointerType !== 'touch' || !touchStart) return;
      if (Math.hypot(e.clientX - touchStart.x, e.clientY - touchStart.y) > 10) { clearTimeout(timer.current); pending.current = null; }
    };
    const onUp = (e: PointerEvent) => {
      if (e.pointerType !== 'touch') return;
      clearTimeout(timer.current);
      if (longPressed) { clearTimeout(hideTimer.current); hideTimer.current = setTimeout(hide, TOUCH_SHOW); }
      touchStart = null;
    };
    const onClick = (e: MouseEvent) => {
      // a tap on something that is not clickable (a dot, a badge, a chip) shows its tooltip for a moment
      if ((e as PointerEvent).pointerType !== 'touch') return;
      const el = e.target as Element;
      if (el.closest(INTERACTIVE)) return;
      const t = targetOf(el);
      if (!t) return;
      show(t);
      hideTimer.current = setTimeout(hide, TOUCH_SHOW);
    };
    const onCtx = (e: Event) => { if (longPressed && cur.current) e.preventDefault(); }; // the long press must not also open the browser's menu
    const onScroll = () => { if (cur.current || pending.current) { pending.current = null; hide(); } };

    document.addEventListener('pointermove', onMove, { passive: true });
    document.documentElement.addEventListener('mouseleave', onLeave);
    document.addEventListener('focusin', onFocusIn);
    document.addEventListener('focusout', onFocusOut);
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('pointerdown', onDown, { passive: true });
    document.addEventListener('pointermove', onTouchMove, { passive: true });
    document.addEventListener('pointerup', onUp, { passive: true });
    document.addEventListener('pointercancel', onUp, { passive: true });
    document.addEventListener('click', onClick);
    document.addEventListener('contextmenu', onCtx);
    window.addEventListener('scroll', onScroll, { capture: true, passive: true });
    window.addEventListener('blur', hide);
    return () => {
      hide();
      document.removeEventListener('pointermove', onMove);
      document.documentElement.removeEventListener('mouseleave', onLeave);
      document.removeEventListener('focusin', onFocusIn);
      document.removeEventListener('focusout', onFocusOut);
      document.removeEventListener('keydown', onKey, true);
      document.removeEventListener('pointerdown', onDown);
      document.removeEventListener('pointermove', onTouchMove);
      document.removeEventListener('pointerup', onUp);
      document.removeEventListener('pointercancel', onUp);
      document.removeEventListener('click', onClick);
      document.removeEventListener('contextmenu', onCtx);
      window.removeEventListener('scroll', onScroll, { capture: true } as EventListenerOptions);
      window.removeEventListener('blur', hide);
    };
  }, []);

  // place it: above the element, flipped below when there is no room, and kept inside the screen sideways
  useLayoutEffect(() => {
    if (!shown || !bubble.current) return;
    const b = bubble.current.getBoundingClientRect();
    const r = shown.rect;
    const margin = 8;
    let below = false;
    let top = r.top - b.height - 8;
    if (top < margin) { below = true; top = r.bottom + 8; }
    if (below && top + b.height > innerHeight - margin) top = Math.max(margin, innerHeight - b.height - margin);
    const left = Math.min(Math.max(margin, r.left + r.width / 2 - b.width / 2), Math.max(margin, innerWidth - b.width - margin));
    setPos({ left, top, below });
  }, [shown]);

  if (!shown || typeof document === 'undefined') return null;
  return createPortal(
    <div
      ref={bubble}
      id={ID}
      role="tooltip"
      data-testid="tooltip"
      data-placement={pos ? (pos.below ? 'below' : 'above') : undefined}
      className="app-tooltip"
      style={{ left: pos?.left ?? 0, top: pos?.top ?? 0, visibility: pos ? 'visible' : 'hidden' }}
    >
      {shown.text}
    </div>,
    document.body
  );
}
