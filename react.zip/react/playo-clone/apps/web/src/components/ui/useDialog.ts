'use client';

import { useEffect, useRef } from 'react';

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type=hidden]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

/**
 * What a dialog should do for keyboard and screen-reader users: take focus when it opens (the first field, else the dialog itself),
 * keep Tab inside it, close on Escape, give focus back to what opened it, and stop the page behind from scrolling.
 * Put the returned ref on the element with role="dialog" (and tabIndex={-1}).
 */
export function useDialog<T extends HTMLElement>(onClose: () => void) {
  const ref = useRef<T>(null);
  const close = useRef(onClose);
  close.current = onClose;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const opener = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    // what Tab can actually reach: visible controls, and one radio per group (the checked one, else the first)
    const items = () => {
      const all = [...el.querySelectorAll<HTMLElement>(FOCUSABLE)].filter((n) => n.offsetParent !== null || n === document.activeElement);
      return all.filter((n) => {
        if (!(n instanceof HTMLInputElement) || n.type !== 'radio' || !n.name) return true;
        const group = all.filter((m): m is HTMLInputElement => m instanceof HTMLInputElement && m.type === 'radio' && m.name === n.name);
        return n === (group.find((m) => m.checked) ?? group[0]);
      });
    };
    (el.querySelector<HTMLElement>('[autofocus], input:not([type=hidden]):not([type=checkbox]):not([type=radio]), select, textarea') ?? el).focus({ preventScroll: true });

    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        close.current();
        return;
      }
      if (e.key !== 'Tab') return;
      const list = items();
      if (!list.length) { e.preventDefault(); el.focus(); return; }
      const first = list[0];
      const last = list[list.length - 1];
      const active = document.activeElement;
      if (!el.contains(active) || active === el) { e.preventDefault(); (e.shiftKey ? last : first).focus(); }
      else if (e.shiftKey && active === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && active === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', key, true);
    return () => {
      document.removeEventListener('keydown', key, true);
      document.body.style.overflow = overflow;
      if (opener && document.contains(opener)) opener.focus({ preventScroll: true });
    };
  }, []);

  return ref;
}
