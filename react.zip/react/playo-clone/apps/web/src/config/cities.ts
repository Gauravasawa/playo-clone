/**
 * Cities, their currency and centre. A mirror of apps/api/src/data/currency.ts: change both together.
 * Everything the server stores and charges is in rupees; other currencies are only shown.
 */
export type CurrencyCode = 'INR' | 'AED' | 'QAR' | 'AUD' | 'GBP';

export const CURRENCIES: Record<CurrencyCode, { symbol: string; inr: number; name: string }> = {
  INR: { symbol: '₹', inr: 1, name: 'Indian rupee' },
  AED: { symbol: 'AED ', inr: 22.5, name: 'UAE dirham' },
  QAR: { symbol: 'QAR ', inr: 23, name: 'Qatari riyal' },
  AUD: { symbol: 'A$', inr: 55, name: 'Australian dollar' },
  GBP: { symbol: '£', inr: 105, name: 'Pound sterling' },
};

export const CITY_INFO: Record<string, { currency: CurrencyCode; lat: number; lng: number; country: string }> = {
  Bengaluru: { currency: 'INR', lat: 12.9716, lng: 77.5946, country: 'India' },
  Mumbai: { currency: 'INR', lat: 19.076, lng: 72.8777, country: 'India' },
  Delhi: { currency: 'INR', lat: 28.6139, lng: 77.209, country: 'India' },
  Hyderabad: { currency: 'INR', lat: 17.385, lng: 78.4867, country: 'India' },
  Pune: { currency: 'INR', lat: 18.5204, lng: 73.8567, country: 'India' },
  Chennai: { currency: 'INR', lat: 13.0827, lng: 80.2707, country: 'India' },
  Kolkata: { currency: 'INR', lat: 22.5726, lng: 88.3639, country: 'India' },
  Ahmedabad: { currency: 'INR', lat: 23.0225, lng: 72.5714, country: 'India' },
  Jaipur: { currency: 'INR', lat: 26.9124, lng: 75.7873, country: 'India' },
  Dubai: { currency: 'AED', lat: 25.2048, lng: 55.2708, country: 'UAE' },
  Doha: { currency: 'QAR', lat: 25.2854, lng: 51.531, country: 'Qatar' },
  Sydney: { currency: 'AUD', lat: -33.8688, lng: 151.2093, country: 'Australia' },
  London: { currency: 'GBP', lat: 51.5072, lng: -0.1276, country: 'UK' },
};

export const CITIES = Object.keys(CITY_INFO) as [string, ...string[]];
export const DEFAULT_CITY = CITIES[0];
export const currencyOf = (city: string): CurrencyCode => CITY_INFO[city]?.currency ?? 'INR';
export const cityCentre = (city: string) => ({ lat: CITY_INFO[city]?.lat ?? 12.9716, lng: CITY_INFO[city]?.lng ?? 77.5946 });

const inr = (n: number) => `₹${Math.round(n).toLocaleString('en-IN')}`;

/**
 * A price in rupees as it should be shown in a city: in that city's currency with the rupees in brackets
 * (`AED 95 (₹2,140)`), or just rupees for Indian cities.
 */
export function formatPrice(amountInr: number, city: string): string {
  const c = currencyOf(city);
  if (c === 'INR') return inr(amountInr);
  const { symbol, inr: rate } = CURRENCIES[c];
  return `${symbol}${Math.round(amountInr / rate).toLocaleString('en')} (${inr(amountInr)})`;
}

/** Same, without the rupees in brackets */
export function formatLocal(amountInr: number, city: string): string {
  const c = currencyOf(city);
  return c === 'INR' ? inr(amountInr) : `${CURRENCIES[c].symbol}${Math.round(amountInr / CURRENCIES[c].inr).toLocaleString('en')}`;
}

export { inr as formatInr };
