import { CITIES, DEFAULT_CITY } from './cities';

export { CITIES, DEFAULT_CITY };

export const GAME_LEVELS = ['Beginner', 'Intermediate', 'Advanced'] as const;

/**
 * What the server renders (it doesn't know the visitor's saved city or sport). The browser
 * starts from these too, until it has mounted, so the first client render matches the server HTML.
 */
export const DEFAULT_VENUE_FILTER = {
  city: DEFAULT_CITY as string, sport: 'all', q: '', sort: 'rating' as 'rating' | 'price' | 'distance',
  amenities: [] as string[], maxPrice: null as number | null, near: null as { lat: number; lng: number } | null, maxKm: null as number | null,
};
export const DEFAULT_GAMES_PARAMS = { city: DEFAULT_CITY as string, sport: 'all', token: null as string | null };

/** What the server renders for the community pages (same idea as above: the browser matches it until mounted) */
export const DEFAULT_LEADERBOARD_PARAMS = { sport: 'all', city: 'all' };
export const DEFAULT_TOURNAMENT_PARAMS = { sport: 'all', city: DEFAULT_CITY as string, token: null as string | null };
export const DEFAULT_COACH_PARAMS = { sport: 'all', city: DEFAULT_CITY as string };
export const DEFAULT_EVENT_PARAMS = { type: 'all', city: DEFAULT_CITY as string, q: '', token: null as string | null };
