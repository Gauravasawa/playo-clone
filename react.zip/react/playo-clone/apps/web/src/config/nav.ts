/** Main navigation (the header); the rest lives in the user menu */
export const NAV_LINKS = [
  { href: '/', label: 'Venues' },
  { href: '/games', label: 'Play' },
  { href: '/events', label: 'Events' },
  { href: '/coaches', label: 'Coaching' },
  { href: '/help', label: 'Help' },
] as const;

/** Under "More" on wide screens (the header is full otherwise); on phones they sit in the scrolling row */
export const MORE_LINKS = [
  { href: '/tournaments', label: 'Tournaments' },
  { href: '/leaderboard', label: 'Leaderboard' },
] as const;

export const MENU_LINKS = [
  { href: '/profile', label: 'My profile' },
  { href: '/friends', label: 'Friends' },
  { href: '/bookings', label: 'My bookings' },
  { href: '/learning', label: 'My learning' },
  { href: '/wallet', label: 'Wallet & Karma' },
  { href: '/plus', label: 'Playo Plus' },
  { href: '/owner', label: 'Venue owner' },
  { href: '/blog', label: 'Blog' },
  { href: '/policy', label: 'Cancellation policy' },
  { href: '/lab', label: 'Store lab' },
] as const;
