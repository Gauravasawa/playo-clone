'use client';

import { useState } from 'react';
import { app } from '@/store';
import { useDialog } from '@/components/ui/useDialog';

export function LoginModal() {
  const [open, setOpen] = app.useGlobalState('loginOpen');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [otp, setOtp] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const close = () => setOpen(false);

  if (!open) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await app.actions.login(phone, name, otp);
      setOpen(false);
      setOtp('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setBusy(false);
    }
  };

  return <LoginForm onClose={close} submit={submit} busy={busy} error={error} name={name} setName={setName} phone={phone} setPhone={setPhone} otp={otp} setOtp={setOtp} />;
}

function LoginForm({ onClose, submit, busy, error, name, setName, phone, setPhone, otp, setOtp }: { onClose: () => void; submit: (e: React.FormEvent) => void; busy: boolean; error: string; name: string; setName: (v: string) => void; phone: string; setPhone: (v: string) => void; otp: string; setOtp: (v: string) => void }) {
  const ref = useDialog<HTMLFormElement>(onClose);
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-black/40 p-4" onClick={onClose}>
      <form ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-label="Log in" onSubmit={submit} onClick={(e) => e.stopPropagation()} className="w-full max-w-sm space-y-3 rounded-2xl bg-white p-6 shadow-xl outline-none">
        <h2 className="text-lg font-bold">Log in to play</h2>
        <p className="text-sm text-ink/60">Any 10 digit number works. The OTP is <b>1234</b>.</p>
        <input className="w-full rounded-lg border px-3 py-2" aria-label="Your name" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
        <input className="w-full rounded-lg border px-3 py-2" aria-label="Phone number (10 digits)" placeholder="Phone (10 digits)" inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))} />
        <input className="w-full rounded-lg border px-3 py-2" aria-label="One-time password (4 digits)" placeholder="OTP" inputMode="numeric" value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 4))} />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <div className="flex gap-2">
          <button type="button" onClick={onClose} className="flex-1 rounded-lg border py-2 font-medium">Cancel</button>
          <button disabled={busy || phone.length !== 10 || otp.length !== 4} data-tip={phone.length !== 10 ? 'Type your 10-digit phone number first' : otp.length !== 4 ? 'Type the 4-digit OTP (1234)' : undefined} className="flex-1 rounded-lg bg-brand py-2 font-semibold text-white hover:bg-brand-dark">
            {busy ? 'Logging in…' : 'Log in'}
          </button>
        </div>
      </form>
    </div>
  );
}
