'use client';

import { app } from '@/store';
import type { PickedSlot } from '@/store';
import { Price } from '@/components/ui/Price';
import { useMounted } from '@/lib/hooks';

interface Props {
  city: string;
  picked: PickedSlot[];
  total: number;
  onCheckout: () => void;
}

export function BookingSummary({ city, picked, total, onCheckout }: Props) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [canBook] = app.useGlobalState('canBook');

  return (
    <aside className="h-fit space-y-3 rounded-2xl border bg-white p-5 lg:sticky lg:top-24">
      <h2 className="font-bold">Your booking</h2>
      {picked.length === 0 ? (
        <p className="text-sm text-ink/50">Select one or more hourly slots.</p>
      ) : (
        <ul className="space-y-1 text-sm">
          {picked.map((s) => <li key={s.time} className="flex justify-between"><span>{s.time}</span><Price inr={s.price} city={city} brackets={false} /></li>)}
        </ul>
      )}
      <div className="flex justify-between border-t pt-3 font-bold">
        <span>Total</span>
        <span data-testid="total"><Price inr={picked.length ? total : 0} city={city} brackets={false} /></span>
      </div>
      <p className="text-xs text-ink/50">Rentals, passes, coupons and Karma come next at checkout.</p>
      <button onClick={onCheckout} data-testid="book-now" disabled={mounted && token ? !canBook : picked.length === 0} data-tip={(mounted && token ? !canBook : picked.length === 0) ? 'Pick at least one hourly slot first' : undefined} className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark disabled:opacity-50">
        {mounted && !token ? 'Log in to book' : 'Book now'}
      </button>
    </aside>
  );
}
