'use client';

import { useState } from 'react';
import { app } from '@/store';
import { Modal } from '@/components/ui/Modal';
import { PaymentPicker, usePaymentChoice } from '@/components/ui/PaymentPicker';
import { Price } from '@/components/ui/Price';
import { api, type VenueDetail } from '@/lib/api';
import { nextDays } from '@/lib/format';
import { useMounted } from '@/lib/hooks';

/** Buy a day pass (one day you choose) or a monthly membership for a venue */
export function BuyPassModal({ venue, kind, onClose }: { venue: VenueDetail; kind: 'daily' | 'monthly'; onClose: () => void }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const offer = venue.passes[kind];
  const days = mounted ? nextDays(14) : [];
  const [date, setDate] = useState('');
  const [busy, setBusy] = useState(false);
  const choice = usePaymentChoice(offer.priceInr);
  const day = date || days[0]?.value || '';

  const buy = async () => {
    if (!token) return;
    setBusy(true);
    try {
      await api.buyPass(token, { venueId: venue.id, kind, date: kind === 'daily' ? day : undefined, method: choice.method });
      app.emit('toast', { kind: 'ok', text: `${kind === 'daily' ? 'Day pass' : 'Monthly membership'} bought for ${venue.name}` });
      for (const k of ['passes', 'wallet', 'karma', 'me'] as const) app.invalidate(k);
      onClose();
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Payment failed' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={kind === 'daily' ? `Day pass · ${venue.name}` : `Monthly membership · ${venue.name}`} onClose={onClose}>
      <p className="text-sm text-ink/60">{offer.note}. Valid for {offer.hours} hours{kind === 'monthly' ? ' until the end of this month' : ''}. Use it at checkout.</p>
      {kind === 'daily' && (
        <label className="block text-sm font-semibold">
          Day
          <select value={day} onChange={(e) => setDate(e.target.value)} data-testid="pass-date" className="mt-1 block w-full rounded-lg border px-3 py-2 font-normal">
            {days.map((d) => <option key={d.value} value={d.value}>{d.day} {d.date} ({d.value})</option>)}
          </select>
        </label>
      )}
      <PaymentPicker choice={choice} name="passpay" />
      <button onClick={buy} disabled={busy || choice.blocked || (kind === 'daily' && !day)} data-testid="buy-pass-confirm" data-tip={busy ? 'Paying… one moment' : choice.blocked ? 'Not enough wallet balance: top up, or pay with UPI or card' : kind === 'daily' && !day ? 'Pick the day first' : undefined} className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark disabled:opacity-50">
        {busy ? 'Paying…' : <>Pay <Price inr={offer.priceInr} city={venue.city} brackets={false} /></>}
      </button>
    </Modal>
  );
}
