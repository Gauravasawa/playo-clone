'use client';

import { useEffect, useMemo, useState } from 'react';
import { app } from '@/store';
import { Modal } from '@/components/ui/Modal';
import { PaymentPicker, usePaymentChoice } from '@/components/ui/PaymentPicker';
import { Price } from '@/components/ui/Price';
import { api, type PayMethod, type Quote, type VenueDetail } from '@/lib/api';
import type { PickedSlot } from '@/store';

interface Props {
  venue: VenueDetail;
  date: string;
  picked: PickedSlot[];
  booking: boolean;
  onPay: (method: PayMethod) => Promise<boolean>;
  onClose: () => void;
}

/**
 * Pay for a booking: rentals, a venue pass, a coupon, Karma, the convenience fee and the payment method.
 * The total comes from the store's `quote` (worked out in the browser); the server's own quote is fetched
 * alongside and a notice shows if the two ever differ.
 */
export function CheckoutModal({ venue, date, picked, booking, onPay, onClose }: Props) {
  const [token] = app.useGlobalState('token');
  const [me] = app.useGlobalState('me', token ?? undefined);
  const [passes] = app.useGlobalState('passes', token ?? undefined);
  const [checkout, setCheckout] = app.useGlobalState('checkout');
  const [, setPricing] = app.useGlobalState('pricing');
  const [quote] = app.useGlobalState('quote');
  const [code, setCode] = useState('');
  const [couponError, setCouponError] = useState('');
  const [server, setServer] = useState<Quote | null>(null);
  const city = venue.city;

  // Only passes that can pay for exactly these slots
  const usable = useMemo(
    () => (passes ?? []).filter((p) => p.active && p.venueId === venue.id && (p.kind === 'daily' ? p.validDate === date : p.hoursLeft >= picked.length)),
    [passes, venue.id, date, picked.length]
  );
  const pass = usable.find((p) => p.id === checkout.passId) ?? null;

  // Tell the store what the quote needs: this venue's rentals, who is paying, whether the chosen pass covers the slots
  useEffect(() => {
    setPricing.set({ equipment: venue.equipment, isPlus: !!me?.plus.active, karmaBalance: me?.karma ?? 0, passCoversSlots: !!pass });
  }, [venue.equipment, me?.plus.active, me?.karma, pass]); // eslint-disable-line react-hooks/exhaustive-deps
  // A pass that no longer fits (another day, fewer hours left) is dropped
  useEffect(() => {
    if (checkout.passId && !pass) setCheckout.setPass(null);
  }, [checkout.passId, pass]); // eslint-disable-line react-hooks/exhaustive-deps
  // Leaving the checkout forgets the choices
  useEffect(() => () => { setCheckout.reset(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // A coupon's value depends on the amount, so it is checked again when the amount changes
  const coupon = checkout.coupon;
  useEffect(() => {
    if (!token || !coupon || quote.chargeableInr <= 0) return;
    api.validateCoupon(token, coupon.code, quote.chargeableInr)
      .then((r) => { if (r.discount !== coupon.discountInr) setCheckout.setCoupon({ code: r.code, discountInr: r.discount }); })
      .catch(() => setCheckout.setCoupon(null));
  }, [quote.chargeableInr]); // eslint-disable-line react-hooks/exhaustive-deps

  // The server's quote, for comparison
  const serverKey = JSON.stringify([checkout.extras, coupon?.code, quote.karmaPointsUsed, pass?.id, picked.map((s) => s.time)]);
  useEffect(() => {
    if (!token) return;
    const ctl = new AbortController();
    api.quote(token, {
      venueId: venue.id, date, slots: picked.map((s) => s.time), extras: checkout.extras, coupon: coupon?.code ?? null,
      karmaPoints: quote.karmaPointsUsed || undefined, passId: pass?.id ?? null,
    }, ctl.signal).then(setServer).catch(() => setServer(null));
    return () => ctl.abort();
  }, [serverKey]); // eslint-disable-line react-hooks/exhaustive-deps
  const mismatch = server && server.payableInr !== quote.payableInr;

  const choice = usePaymentChoice(quote.payableInr);
  const needsMethod = quote.payableInr > 0;

  const apply = async () => {
    if (!token || !code.trim()) return;
    setCouponError('');
    try {
      const r = await api.validateCoupon(token, code, quote.chargeableInr);
      setCheckout.setCoupon({ code: r.code, discountInr: r.discount });
    } catch (e) {
      setCheckout.setCoupon(null);
      setCouponError(e instanceof Error ? e.message : 'Invalid coupon');
    }
  };

  const pay = async () => {
    if (await onPay(needsMethod ? choice.method : 'wallet')) onClose();
  };

  const p = (inr: number) => <Price inr={inr} city={city} brackets={false} />;
  const karmaMax = Math.floor(Math.max(0, quote.chargeableInr - quote.couponDiscountInr) * 0.2);

  return (
    <Modal title="Checkout" onClose={onClose}>
      <p className="text-sm text-ink/60">{venue.name} · {date} · {picked.map((s) => s.time).join(', ')}</p>

      {venue.equipment.length > 0 && (
        <fieldset className="space-y-1 text-sm" data-testid="rentals">
          <legend className="mb-1 font-semibold">Rent equipment <span className="font-normal text-ink/50">(per hour)</span></legend>
          {venue.equipment.map((e) => (
            <label key={e.id} className="flex items-center gap-2">
              <input type="checkbox" data-testid={`rental-${e.id}`} checked={checkout.extras.includes(e.id)} onChange={() => setCheckout.toggleExtra(e.id)} />
              {e.name} <span className="text-ink/50">{p(e.priceInr)}/hr</span>
            </label>
          ))}
        </fieldset>
      )}

      {usable.length > 0 && (
        <fieldset className="space-y-1 text-sm" data-testid="passes">
          <legend className="mb-1 font-semibold">Use a pass</legend>
          <label className="flex min-h-7 items-center gap-2"><input type="radio" name="pass" checked={!pass} onChange={() => setCheckout.setPass(null)} /> No pass</label>
          {usable.map((x) => (
            <label key={x.id} className="flex items-center gap-2">
              <input type="radio" name="pass" data-testid={`use-pass-${x.id}`} checked={pass?.id === x.id} onChange={() => setCheckout.setPass(x.id)} />
              {x.kind === 'daily' ? `Day pass (${x.validDate})` : `Monthly membership (${x.hoursLeft}h left)`}
            </label>
          ))}
        </fieldset>
      )}

      <div className="flex gap-2">
        <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="Coupon code" aria-label="Coupon code" className="flex-1 rounded-lg border px-3 py-2" />
        <button onClick={apply} data-testid="apply-coupon" className="rounded-lg border px-4 font-semibold hover:bg-black/5">Apply</button>
      </div>
      {coupon && <p className="text-sm text-green-700" data-testid="coupon-ok">✓ {coupon.code} (−{p(coupon.discountInr)}) <button className="underline" onClick={() => setCheckout.setCoupon(null)}>remove</button></p>}
      {couponError && <p className="text-sm text-red-600" data-testid="coupon-error">{couponError}</p>}

      <label className="flex items-start gap-2 text-sm">
        <input type="checkbox" data-testid="use-karma" disabled={!me || me.karma < 10} checked={checkout.useKarma} onChange={(e) => setCheckout.setKarma(e.target.checked)} className="mt-1" />
        <span>Use Karma <span className="text-ink/50">({me?.karma ?? 0} points · 10 points = ₹1 · up to 20%, now max ₹{karmaMax})</span></span>
      </label>

      {needsMethod && <PaymentPicker choice={choice} />}

      <div className="space-y-1 border-t pt-3 text-sm" data-testid="breakdown">
        <div className="flex justify-between"><span>Slots</span><span>{p(quote.slotsInr)}</span></div>
        {quote.extrasInr > 0 && <div className="flex justify-between"><span>Rentals</span><span>{p(quote.extrasInr)}</span></div>}
        {quote.passCoveredInr > 0 && <div className="flex justify-between text-green-700"><span>Pass</span><span>−{p(quote.passCoveredInr)}</span></div>}
        {quote.couponDiscountInr > 0 && <div className="flex justify-between text-green-700"><span>Coupon</span><span>−{p(quote.couponDiscountInr)}</span></div>}
        {quote.karmaDiscountInr > 0 && <div className="flex justify-between text-green-700"><span>Karma ({quote.karmaPointsUsed} pts)</span><span>−{p(quote.karmaDiscountInr)}</span></div>}
        <div className="flex justify-between" data-testid="fee-line">
          <span>Convenience fee {me?.plus.active && <span className="text-green-700">(waived with Plus)</span>}</span>
          <span>{quote.feeInr > 0 ? p(quote.feeInr) : '₹0'}</span>
        </div>
        <div className="flex justify-between text-base font-bold"><span>To pay</span><span data-testid="payable">{p(quote.payableInr)}</span></div>
        {venue.currency !== 'INR' && <p className="text-xs text-ink/50">You are charged ₹{quote.payableInr.toLocaleString('en-IN')} from your wallet or card; the local price is for reference.</p>}
        <p className="text-xs text-ink/50">You earn {quote.earnKarma} Karma{me?.plus.active && ' (2x with Plus)'}.</p>
      </div>
      {mismatch && <p className="rounded-lg bg-amber-50 p-2 text-xs text-amber-800" data-testid="quote-mismatch">The server priced this at ₹{server.payableInr}. The server&apos;s price is the one charged.</p>}

      <button onClick={pay} data-testid="checkout-pay" disabled={booking || picked.length === 0 || (needsMethod && choice.blocked)} data-tip={booking ? 'Paying… one moment' : picked.length === 0 ? 'Pick at least one slot first' : needsMethod && choice.blocked ? 'Not enough wallet balance: top up, or pay with UPI or card' : undefined} className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark disabled:opacity-50">
        {booking ? 'Paying…' : needsMethod ? `Pay ₹${quote.payableInr.toLocaleString('en-IN')}` : 'Confirm booking'}
      </button>
    </Modal>
  );
}
