'use client';

import { useEffect, useMemo } from 'react';
import { app } from '@/store';
import type { Status } from '@/lib/store/createStore';
import { nextDays } from '@/lib/format';
import { Price } from '@/components/ui/Price';
import { useMounted } from '@/lib/hooks';

/** Day strip + hourly slots. The picked slots live in the store (`selection`), with undo/redo. */
export function SlotPicker({ venueId, venueStatus, date, city }: { venueId: number; venueStatus: Status; date: string; city: string }) {
  const mounted = useMounted();
  // "Today" depends on the visitor's clock and time zone, so the days appear after mounting
  const days = useMemo(() => (mounted ? nextDays(7) : []), [mounted]);
  const [selection, setSelection] = app.useGlobalState('selection');
  const history = app.useHistory();

  // start (or restart) a selection when the venue or day changes; the same venue + day keeps it
  useEffect(() => { setSelection.start(venueId, date); }, [venueId, date]); // eslint-disable-line react-hooks/exhaustive-deps

  // slots wait for the venue: if the venue fails to load, slots report why instead of firing
  const slotParams = useMemo(() => ({ venueId, date }), [venueId, date]);
  const [slots, , slotsStatus] = app.useGlobalState('slots', slotParams, { waitFor: venueStatus });
  const mine = selection.venueId === venueId ? selection.slots : [];

  return (
    <section className="space-y-3 rounded-2xl border bg-white p-4">
      <div className="flex items-center justify-between">
        <h2 className="font-bold">Pick a day and time</h2>
        <div className="flex gap-1 text-sm">
          <button disabled={!history.canUndo} data-tip={history.canUndo ? 'Undo your last slot choice' : 'Nothing to undo yet'} onClick={() => app.undo()} className="rounded-lg border px-2.5 py-1">↶ Undo</button>
          <button disabled={!history.canRedo} data-tip={history.canRedo ? 'Put your last slot choice back' : 'Nothing to redo yet'} onClick={() => app.redo()} className="rounded-lg border px-2.5 py-1">↷ Redo</button>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {days.map((d) => (
          <button key={d.value} onClick={() => setSelection.start(venueId, d.value)} className={`min-w-14 rounded-xl border px-3 py-2 text-center text-sm ${date === d.value ? 'border-brand bg-brand text-white' : 'bg-white'}`}>
            <div className="text-xs">{d.day}</div>
            <div className="font-bold">{d.date}</div>
          </button>
        ))}
      </div>

      {/* Slots aren't loaded on the server, but the browser may already have them saved (offline copy): show them only after mount so the first render matches */}
      {!mounted || slotsStatus.state === 'waiting' || slotsStatus.state === 'loading' ? (
        <p className="text-sm text-ink/50">Loading slots…</p>
      ) : slotsStatus.state === 'error' ? (
        <p className="text-sm text-red-600">Couldn&apos;t load slots. <button className="underline" onClick={() => slotsStatus.refetch()}>Retry</button></p>
      ) : (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {slots?.map((s) => {
            const picked = mounted && mine.some((m) => m.time === s.time);
            return (
              <button
                key={s.time}
                disabled={!s.available} data-testid={`slot-${s.time}`} title={s.reason ?? undefined}
                onClick={() => setSelection.toggle({ time: s.time, price: s.price })}
                className={`rounded-lg border px-2 py-2 text-sm ${picked ? 'border-brand bg-brand text-white' : s.available ? 'bg-white hover:border-brand' : 'bg-black/5 text-ink/30 line-through'}`}
              >
                {s.time}
                <div className="text-xs opacity-75" data-testid={s.available ? undefined : `slot-${s.reason}`}>{s.available ? <Price inr={s.price} city={city} brackets={false} /> : s.reason}</div>
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}
