'use client';

import { useMemo, useState } from 'react';
import { app } from '@/store';
import { nextDays } from '@/lib/format';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { BookingSummary } from './BookingSummary';
import { CheckoutModal } from './CheckoutModal';
import { SlotPicker } from './SlotPicker';
import { VenueInfo } from './VenueInfo';
import { VenuePasses } from './VenuePasses';
import { VenueReviews } from './VenueReviews';
import { useBookVenue } from './useBookVenue';

export function VenueDetailView({ id }: { id: number }) {
  const [venue, , venueStatus] = app.useGlobalState('venue', id);
  const [selection] = app.useGlobalState('selection');
  const [checkout, setCheckout] = useState(false);

  const today = useMemo(() => nextDays(1)[0].value, []);
  const date = selection.venueId === id && selection.date ? selection.date : today;
  const slotParams = useMemo(() => ({ venueId: id, date }), [id, date]);
  const { book, booking, picked, total } = useBookVenue(venue, date, slotParams);

  if (venueStatus.state === 'error') return <ErrorNotice onRetry={venueStatus.refetch}>Venue not found.</ErrorNotice>;
  if (!venue) return <div className="h-96 animate-pulse rounded-2xl bg-black/5" />;

  const startCheckout = () => {
    if (!app.getState('token')) app.setState('loginOpen', true);
    else setCheckout(true);
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
      <div className="space-y-6">
        <VenueInfo venue={venue} />
        <SlotPicker venueId={id} venueStatus={venueStatus} date={date} city={venue.city} />
        <VenuePasses venue={venue} />
        <VenueReviews venueId={id} />
      </div>
      <BookingSummary city={venue.city} picked={picked} total={total} onCheckout={startCheckout} />
      {checkout && <CheckoutModal venue={venue} date={date} picked={picked} booking={booking} onPay={book} onClose={() => setCheckout(false)} />}
    </div>
  );
}
