import type { Venue } from '@/lib/api';
import { Gallery } from '@/features/venues/Gallery';
import { Price } from '@/components/ui/Price';
import { ShareMenu } from '@/components/ui/ShareMenu';

export function VenueInfo({ venue }: { venue: Venue }) {
  const images = venue.images?.length ? venue.images : [venue.image];
  return (
    <>
      <Gallery images={images} name={venue.name} />
      <div>
        <div className="flex items-start justify-between gap-3">
          <h1 className="text-2xl font-extrabold">{venue.name}</h1>
          <ShareMenu path={`/venues/${venue.id}`} title={venue.name} text={`Play at ${venue.name}, ${venue.area}`} />
        </div>
        <p className="text-ink/60">{venue.address}</p>
        <p className="mt-1 text-sm">
          <span className="rounded bg-brand px-1.5 py-0.5 font-bold text-white">★ {venue.rating}</span>{' '}
          <span className="text-ink/50">({venue.reviews} reviews)</span>
          <span className="ml-3 font-semibold" data-testid="venue-hourly"><Price inr={venue.pricePerHour} city={venue.city} /> / hr</span>
          {venue.peakExtra > 0 && <span className="ml-2 text-xs text-ink/50">+<Price inr={venue.peakExtra} city={venue.city} brackets={false} /> at 18:00–21:00</span>}
        </p>
        <p className="mt-3 text-ink/80">{venue.description}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {venue.amenities.map((a) => <span key={a} className="rounded-full border bg-white px-2.5 py-1 text-xs">{a}</span>)}
        </div>
      </div>
    </>
  );
}
