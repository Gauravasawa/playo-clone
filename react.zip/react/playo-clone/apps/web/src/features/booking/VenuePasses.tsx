'use client';

import { useState } from 'react';
import { app } from '@/store';
import { Price } from '@/components/ui/Price';
import type { VenueDetail } from '@/lib/api';
import { BuyPassModal } from './BuyPassModal';

/** The passes a venue sells: pay once, then use them at checkout instead of paying per hour */
export function VenuePasses({ venue }: { venue: VenueDetail }) {
  const [open, setOpen] = useState<'daily' | 'monthly' | null>(null);
  const buy = (kind: 'daily' | 'monthly') => (app.getState('token') ? setOpen(kind) : app.setState('loginOpen', true));
  return (
    <section className="space-y-3 rounded-2xl border bg-white p-4" data-testid="venue-passes">
      <h2 className="font-bold">Passes</h2>
      <div className="grid gap-3 sm:grid-cols-2">
        {(['daily', 'monthly'] as const).map((k) => (
          <div key={k} className="space-y-1 rounded-xl border p-3 text-sm">
            <p className="font-semibold">{k === 'daily' ? 'Day pass' : 'Monthly membership'}</p>
            <p className="text-ink/60">{venue.passes[k].note}</p>
            <p className="font-bold"><Price inr={venue.passes[k].priceInr} city={venue.city} /></p>
            <button onClick={() => buy(k)} data-testid={`buy-pass-${k}`} className="rounded-lg border px-3 py-1.5 font-semibold hover:bg-black/5">Buy</button>
          </div>
        ))}
      </div>
      {open && <BuyPassModal venue={venue} kind={open} onClose={() => setOpen(null)} />}
    </section>
  );
}
