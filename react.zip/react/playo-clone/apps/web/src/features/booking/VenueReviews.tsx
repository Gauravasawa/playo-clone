'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { app } from '@/store';
import { api, type VenueReviews as Reviews } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { Stars } from '@/features/profile/ProfileParts';
import { ReportButton } from '@/features/safety/ReportButton';

/** Reviews of a venue. You can write one once you've attended a booking there (the Lab has a button for that). */
export function VenueReviews({ venueId }: { venueId: number }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [me] = app.useGlobalState('me', token ?? undefined);
  const params = useMemo(() => ({ venueId, token: mounted ? token : null }), [venueId, token, mounted]);
  const [loaded, setData] = app.useGlobalState('venueReviews', params);
  // Not loaded on the server, but the browser may have it saved (offline copy): show it after mount so the first render matches
  const data = mounted ? loaded : undefined;
  const [rating, setRating] = useState(5);
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !me) return;
    setBusy(true);
    try {
      // The review appears at once; if the server refuses it, it goes away again
      await setData(
        (prev) => ({
          ...(prev as Reviews),
          canReview: false,
          count: (prev?.count ?? 0) + 1,
          items: [{ id: -Date.now(), rating, body, createdAt: Date.now(), author: { id: me.id, username: me.username, name: me.name, avatarEmoji: me.avatarEmoji, avatarColor: me.avatarColor, city: me.city, isPrivate: me.isPrivate, online: true, plus: me.plus.active }, reply: null }, ...(prev?.items ?? [])],
        }),
        () => api.postVenueReview(token, venueId, { rating, body })
      );
      app.emit('toast', { kind: 'ok', text: 'Thanks for your review!' });
      setBody('');
    } catch (err) {
      app.emit('toast', { kind: 'err', text: `${err instanceof Error ? err.message : 'Could not post'} — review removed` });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="space-y-3 rounded-2xl border bg-white p-5" id="reviews" data-testid="venue-reviews">
      <h2 className="font-bold">Reviews {data && data.count > 0 && <span className="font-normal text-ink/60">· {data.avg} ★ ({data.count})</span>}</h2>

      {data?.canReview && (
        <form onSubmit={submit} className="space-y-2 rounded-xl bg-brand/5 p-3" aria-label="Write a review">
          <p className="text-sm font-semibold">You attended here. How was it?</p>
          <div className="flex gap-1" role="radiogroup" aria-label="Stars">
            {[1, 2, 3, 4, 5].map((n) => (
              <button type="button" key={n} role="radio" aria-checked={rating === n} aria-label={`${n} star${n > 1 ? 's' : ''}`} onClick={() => setRating(n)} className={`px-1 text-2xl ${n <= rating ? 'text-amber-600' : 'text-ink/20'}`}>★</button>
            ))}
          </div>
          <input value={body} onChange={(e) => setBody(e.target.value)} placeholder="Say a little about the courts, lights, staff…" maxLength={300} className="w-full rounded-lg border px-3 py-2" />
          <button disabled={busy} className="rounded-full bg-brand px-5 py-2 font-semibold text-white">Post review</button>
        </form>
      )}

      {!data ? <p className="text-sm text-ink/50">Loading reviews…</p> : data.items.length === 0 ? (
        <p className="text-sm text-ink/50">No reviews yet. Book and attend to be the first.</p>
      ) : (
        <ul className="space-y-2">
          {data.items.map((r) => (
            <li key={r.id} className="text-sm" data-testid="review-item"><Stars value={r.rating} />{' '}
              {r.author ? <Link href={`/p/${r.author.username}`} className="font-semibold hover:text-brand">{r.author.name}</Link> : <b>Someone</b>}
              {r.body && <span className="text-ink/70"> — {r.body}</span>}
              {r.id > 0 && token && r.author?.id !== me?.id && <span className="ml-2 align-middle"><ReportButton kind="review" targetId={r.id} label="Report" /></span>}
              {r.reply && (
                <div className="ml-6 mt-1 rounded-lg bg-black/5 px-3 py-2" data-testid="owner-reply">
                  <span className="text-xs font-semibold text-brand-dark">Reply from the venue</span>
                  <p className="text-ink/80">{r.reply.body}</p>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
