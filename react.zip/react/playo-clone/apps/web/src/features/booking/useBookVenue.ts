'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { app } from '@/store';
import { api, type Booking, type PayMethod, type VenueDetail } from '@/lib/api';

/**
 * Books the picked slots with what was chosen at checkout (rentals, pass, coupon, Karma).
 * The booking shows in "My bookings" at once and disappears if the server refuses.
 */
export function useBookVenue(venue: VenueDetail | undefined, date: string, slotParams: { venueId: number; date: string }) {
  const router = useRouter();
  const [token] = app.useGlobalState('token');
  const [selection, setSelection] = app.useGlobalState('selection');
  const [total] = app.useGlobalState('total');
  const [, setBookings] = app.useGlobalState('bookings', token ?? undefined);
  const [, setCheckout] = app.useGlobalState('checkout');
  const [, setPricing] = app.useGlobalState('pricing');
  const [booking, setBooking] = useState(false);

  const mine = venue && selection.venueId === venue.id ? selection.slots : [];

  /** Returns true if the booking went through (so the checkout can close) */
  const book = async (method: PayMethod) => {
    if (!token) {
      app.setState('loginOpen', true);
      return false;
    }
    if (!venue) return false;
    const checkout = app.getState('checkout');
    const quote = app.getState('quote');
    const pricing = app.getState('pricing');
    const body = {
      venueId: venue.id, date, slots: mine.map((s) => s.time), sport: venue.sports[0], method,
      extras: checkout.extras, coupon: checkout.coupon?.code ?? null, karmaPoints: quote.karmaPointsUsed || undefined,
      passId: checkout.passId && pricing.passCoversSlots ? checkout.passId : null,
    };
    const temp: Booking = {
      id: -Date.now(), venueId: venue.id, venueName: venue.name, area: venue.area, city: venue.city, currency: venue.currency, sport: body.sport,
      date, slots: body.slots, startsAt: Date.now(), total: quote.slotsInr + quote.extrasInr, slotsInr: quote.slotsInr,
      extras: venue.equipment.filter((e) => body.extras.includes(e.id)).map((e) => ({ id: e.id, name: e.name, hours: body.slots.length, priceInr: e.priceInr * body.slots.length })),
      extrasInr: quote.extrasInr, discount: quote.couponDiscountInr, coupon: body.coupon, passId: body.passId, passCovered: quote.passCoveredInr,
      fee: quote.feeInr, karmaUsed: quote.karmaPointsUsed, karmaDiscount: quote.karmaDiscountInr, paid: quote.payableInr, method,
      status: 'confirmed', createdAt: Date.now(), refundPercent: 100, canCancel: true, canReschedule: true,
    };
    setBooking(true);
    try {
      await setBookings((prev) => [temp, ...(prev ?? [])], () => api.book(token, body));
      setSelection.clear();
      setCheckout.reset();
      setPricing.reset();
      app.emit('toast', { kind: 'ok', text: `Booked ${venue.name} for ${body.slots.length} hour${body.slots.length > 1 ? 's' : ''}` });
      app.fetchQuery('slots', slotParams, true).catch(() => {});
      for (const k of ['wallet', 'karma', 'me', 'passes'] as const) app.invalidate(k);
      router.push('/bookings');
      return true;
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Booking failed' });
      app.fetchQuery('slots', slotParams, true).catch(() => {}); // someone may have taken a slot: show it
      return false;
    } finally {
      setBooking(false);
    }
  };

  return { book, booking, picked: mine, total };
}
