import Link from 'next/link';
import type { Booking } from '@/lib/api';
import { Price } from '@/components/ui/Price';

/** `booking.id < 0` is one still being saved (optimistic) */
export function BookingCard({ booking: b, onCancel, onReschedule }: { booking: Booking; onCancel: (b: Booking) => void; onReschedule: (b: Booking) => void }) {
  const saving = b.id < 0;
  const p = (inr: number) => <Price inr={inr} city={b.city} brackets={false} />;
  return (
    <li className={`flex flex-wrap items-center justify-between gap-4 rounded-2xl border bg-white p-4 ${saving ? 'opacity-60' : ''}`} data-testid={`booking-${b.id}`}>
      <div className="space-y-0.5">
        <Link href={`/venues/${b.venueId}`} className="font-bold hover:text-brand">{b.venueName}</Link>
        {b.status === 'attended' && <span className="ml-2 rounded-full bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-700">Attended</span>}
        <p className="text-sm text-ink/60">{b.area} · {b.date} · {b.slots.join(', ')}</p>
        <p className="text-sm font-semibold">
          {p(b.paid)}
          <span className="ml-2 font-normal text-ink/50">via {b.method}</span>
          {saving && <span className="ml-2 font-normal text-ink/50">saving…</span>}
        </p>
        <p className="text-xs text-ink/50" data-testid="booking-breakdown">
          Slots {p(b.slotsInr)}
          {b.extras.length > 0 && <> · Rentals: {b.extras.map((e) => e.name).join(', ')} ({p(b.extrasInr)})</>}
          {b.passCovered > 0 && <> · Pass −{p(b.passCovered)}</>}
          {b.discount > 0 && <> · {b.coupon ?? 'Coupon'} −{p(b.discount)}</>}
          {b.karmaDiscount > 0 && <> · Karma −{p(b.karmaDiscount)} ({b.karmaUsed} pts)</>}
          {b.fee > 0 && <> · Fee {p(b.fee)}</>}
        </p>
        {b.status === 'attended' && <Link href={`/venues/${b.venueId}#reviews`} className="text-sm text-brand underline">Write a review</Link>}
      </div>
      {b.status === 'confirmed' && (
        <div className="flex flex-col items-end gap-1.5">
          <div className="flex gap-2">
            {b.canReschedule && (
              <button onClick={() => onReschedule(b)} disabled={saving} data-testid="reschedule" className="rounded-lg border px-3 py-1.5 text-sm font-medium hover:bg-black/5">Reschedule</button>
            )}
            {b.canCancel && (
              <button onClick={() => onCancel(b)} disabled={saving} data-testid="cancel-booking" className="rounded-lg border border-red-200 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50">Cancel</button>
            )}
          </div>
          <p className="text-xs text-ink/50" data-testid="refund-percent">{b.canCancel ? `Cancel now: ${b.refundPercent}% back` : 'Too late to cancel'}</p>
        </div>
      )}
    </li>
  );
}
