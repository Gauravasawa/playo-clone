'use client';

import Link from 'next/link';
import { useState } from 'react';
import { app } from '@/store';
import { api, type Booking } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { BookingCard } from './BookingCard';
import { CancelModal } from './CancelModal';
import { RescheduleModal } from './RescheduleModal';

export function BookingsView() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [me, , meStatus] = app.useGlobalState('me', token ?? undefined);
  // Bookings wait until `me` has loaded: no request goes out while the user is unknown or failed to load
  const [bookings, setBookings, status] = app.useGlobalState('bookings', token ?? undefined, { waitFor: meStatus });
  const [cancelling, setCancelling] = useState<Booking | null>(null);
  const [moving, setMoving] = useState<Booking | null>(null);
  const [busy, setBusy] = useState(false);

  if (!mounted) return null;
  if (!token)
    return (
      <>
      <h1 className="mb-4 text-2xl font-extrabold">My bookings</h1>
      <EmptyState>
        <p className="mb-3">Log in to see your bookings.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
      </>
    );

  const cancel = async () => {
    if (!cancelling) return;
    const id = cancelling.id;
    setBusy(true);
    try {
      // The card disappears now; it comes back if the server refuses
      let result = { refunded: 0, percent: 0 };
      await setBookings((prev) => (prev ?? []).filter((b) => b.id !== id), async () => { result = await api.cancelBooking(token, id); });
      app.emit('toast', { kind: 'ok', text: `Booking cancelled: ₹${result.refunded} (${result.percent}%) refunded to your wallet` });
      for (const k of ['slots', 'wallet', 'karma', 'me', 'passes'] as const) app.invalidate(k);
      setCancelling(null);
    } catch (e) {
      app.emit('toast', { kind: 'err', text: `Couldn't cancel: ${e instanceof Error ? e.message : 'error'}. Restored.` });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-extrabold">My bookings {me && <span className="text-base font-normal text-ink/50">· {me.name}</span>}</h1>
      <p className="text-sm text-ink/60">Free cancellation up to 24 hours before, half back up to 2 hours before. <Link href="/policy" className="text-brand underline">Cancellation policy</Link></p>
      {status.state === 'waiting' || status.state === 'loading' ? (
        <Skeleton count={2} />
      ) : status.state === 'error' ? (
        <ErrorNotice onRetry={status.refetch}>{status.rootError ? `Couldn't load your profile (${status.blockedBy}).` : "Couldn't load bookings."}</ErrorNotice>
      ) : !bookings || bookings.length === 0 ? (
        <EmptyState>No bookings yet. <Link href="/" className="text-brand underline">Find a venue</Link></EmptyState>
      ) : (
        <ul className="space-y-3">{bookings.map((b) => <BookingCard key={b.id} booking={b} onCancel={setCancelling} onReschedule={setMoving} />)}</ul>
      )}
      {cancelling && <CancelModal booking={cancelling} busy={busy} onConfirm={cancel} onClose={() => setCancelling(null)} />}
      {moving && <RescheduleModal booking={moving} onClose={() => setMoving(null)} />}
    </div>
  );
}
