'use client';

import { Modal } from '@/components/ui/Modal';
import { Price } from '@/components/ui/Price';
import type { Booking } from '@/lib/api';

/** Shows what the cancellation policy gives back before the booking is cancelled */
export function CancelModal({ booking: b, busy, onConfirm, onClose }: { booking: Booking; busy: boolean; onConfirm: () => void; onClose: () => void }) {
  const refund = Math.round((b.paid * b.refundPercent) / 100);
  return (
    <Modal title="Cancel this booking?" onClose={onClose}>
      <p className="text-sm text-ink/70">{b.venueName} · {b.date} · {b.slots.join(', ')}</p>
      <p className="rounded-xl bg-amber-50 p-3 text-sm" data-testid="cancel-refund">
        You get <b>{b.refundPercent}%</b> back{b.paid > 0 && <> (about <Price inr={refund} city={b.city} brackets={false} />)</>} in your wallet.
        {b.refundPercent < 100 && <span className="block text-xs text-ink/60">100% back up to 24 hours before, 50% from 24 to 2 hours before, nothing after that. Plus members get 100% up to 2 hours before. See the cancellation policy.</span>}
      </p>
      <div className="flex gap-2">
        <button onClick={onClose} className="flex-1 rounded-xl border py-2.5 font-semibold hover:bg-black/5">Keep booking</button>
        <button onClick={onConfirm} disabled={busy} data-testid="confirm-cancel" className="flex-1 rounded-xl bg-red-600 py-2.5 font-semibold text-white hover:bg-red-700 disabled:opacity-50">{busy ? 'Cancelling…' : 'Yes, cancel'}</button>
      </div>
    </Modal>
  );
}
