'use client';

import { useMemo, useState } from 'react';
import { app } from '@/store';
import { Modal } from '@/components/ui/Modal';
import { Price } from '@/components/ui/Price';
import { api, type Booking } from '@/lib/api';
import { nextDays } from '@/lib/format';
import { useMounted } from '@/lib/hooks';

/** Move a booking to another day or hours. The server charges or refunds the difference in slot prices. */
export function RescheduleModal({ booking: b, onClose }: { booking: Booking; onClose: () => void }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [date, setDate] = useState(b.date);
  const [picked, setPicked] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const days = useMemo(() => (mounted ? nextDays(7) : []), [mounted]);
  const params = useMemo(() => ({ venueId: b.venueId, date }), [b.venueId, date]);
  const [slots, , status] = app.useGlobalState('slots', params);
  // The booking's own slots are free for it to keep (the server counts them as taken by you)
  const own = date === b.date ? b.slots : [];

  const toggle = (t: string) => setPicked((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]));
  const pick = (d: string) => { setDate(d); setPicked([]); };

  const move = async () => {
    if (!token || picked.length === 0) return;
    setBusy(true);
    try {
      await api.rescheduleBooking(token, b.id, { date, slots: picked });
      app.emit('toast', { kind: 'ok', text: `Booking moved to ${date}` });
      for (const k of ['bookings', 'wallet', 'slots'] as const) app.invalidate(k);
      onClose();
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not move the booking' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title="Reschedule" onClose={onClose}>
      <p className="text-sm text-ink/60">{b.venueName} · now {b.date} · {b.slots.join(', ')}. Pick the new day and hours; if they cost more or less you pay or get back the difference.</p>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {days.map((d) => (
          <button key={d.value} onClick={() => pick(d.value)} data-testid={`resched-day-${d.value}`} className={`min-w-14 rounded-xl border px-3 py-2 text-center text-sm ${date === d.value ? 'border-brand bg-brand text-white' : 'bg-white'}`}>
            <div className="text-xs">{d.day}</div>
            <div className="font-bold">{d.date}</div>
          </button>
        ))}
      </div>
      {!slots || status.state === 'loading' ? (
        <p className="text-sm text-ink/50">Loading slots…</p>
      ) : (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {slots.map((s) => {
            const mineAlready = own.includes(s.time);
            const free = s.available || mineAlready;
            return (
              <button key={s.time} disabled={!free} data-tip={!free ? 'Already booked or past: pick another time' : undefined} onClick={() => toggle(s.time)} data-testid={`resched-slot-${s.time}`}
                className={`rounded-lg border px-2 py-2 text-sm ${picked.includes(s.time) ? 'border-brand bg-brand text-white' : free ? 'bg-white hover:border-brand' : 'bg-black/5 text-ink/30 line-through'}`}>
                {s.time}
                <div className="text-xs opacity-75"><Price inr={s.price} city={b.city} brackets={false} /></div>
              </button>
            );
          })}
        </div>
      )}
      {b.passId && <p className="text-xs text-ink/50">This booking was paid with a pass, so it keeps the same number of hours ({b.slots.length}).</p>}
      <button onClick={move} disabled={busy || picked.length === 0} data-tip={busy ? 'Moving your booking… one moment' : picked.length === 0 ? 'Pick the new time first' : undefined} data-testid="reschedule-confirm" className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark disabled:opacity-50">
        {busy ? 'Moving…' : `Move to ${date}${picked.length ? ` (${picked.length}h)` : ''}`}
      </button>
    </Modal>
  );
}
