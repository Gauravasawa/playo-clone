'use client';

import Link from 'next/link';
import { useState } from 'react';
import { usePathname } from 'next/navigation';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import { Skeleton } from '@/components/ui/Skeleton';
import { chatFace, chatTitle, clock, kindLabel } from './chatUtils';
import { NewChatModal } from './NewChatModal';

export function ChatList() {
  const path = usePathname();
  const [token] = app.useGlobalState('token');
  const [me] = app.useGlobalState('me', token ?? undefined);
  const [chats, , status] = app.useGlobalState('chats', token ?? undefined);
  const [creating, setCreating] = useState(false);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold">Chats</h1>
        <button onClick={() => setCreating(true)} className="rounded-full bg-brand px-3 py-1.5 text-sm font-semibold text-white">+ New</button>
      </div>
      {(status.state === 'loading' || status.state === 'waiting') && <Skeleton count={4} className="h-16" />}
      {chats && chats.length === 0 && <p className="rounded-xl bg-white p-4 text-sm text-ink/60">No chats yet. Start one with a friend, or join a game to get its group chat.</p>}
      <ul className="space-y-1" data-testid="chat-list">
        {chats?.map((c) => {
          const face = chatFace(c, me?.id);
          const title = chatTitle(c, me?.id);
          return (
            <li key={c.id}>
              <Link href={`/chat/${c.id}`} className={`flex items-center gap-3 rounded-xl p-3 ${path === `/chat/${c.id}` ? 'bg-brand/10' : 'bg-white hover:bg-black/[0.03]'}`} data-testid={`chat-${c.id}`}>
                {face && <Avatar player={face} dot={c.kind === 'direct'} />}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span title={kindLabel(c) ? `${title} · ${kindLabel(c)}` : title} className="min-w-0 truncate font-semibold">{title}{kindLabel(c) && <span className="ml-1.5 text-xs font-normal text-ink/40">{kindLabel(c)}</span>}</span>
                    {c.lastMessage && <span className="shrink-0 text-xs text-ink/40">{clock(c.lastMessage.createdAt)}</span>}
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="min-w-0 truncate text-sm text-ink/60">{c.lastMessage ? (c.lastMessage.body || '📷 Picture') : 'No messages yet'}</span>
                    {c.unread > 0 && <span data-testid={`unread-${c.id}`} className="shrink-0 rounded-full bg-brand px-2 text-xs font-bold text-white">{c.unread}</span>}
                  </div>
                </div>
              </Link>
            </li>
          );
        })}
      </ul>
      {creating && <NewChatModal onClose={() => setCreating(false)} />}
    </div>
  );
}
