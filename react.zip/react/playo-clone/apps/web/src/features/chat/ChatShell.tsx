'use client';

import { usePathname } from 'next/navigation';
import { app } from '@/store';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ChatList } from './ChatList';

/** List of chats on the left, the open chat on the right; on a phone one at a time */
export function ChatShell({ children }: { children: React.ReactNode }) {
  const mounted = useMounted();
  const open = usePathname() !== '/chat';
  const [token] = app.useGlobalState('token');

  if (!mounted) return null;
  if (!token)
    return (
      <>
      <h1 className="mb-4 text-2xl font-extrabold">Chats</h1>
      <EmptyState>
        <p className="mb-3">Log in to chat with friends and game groups.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
      </>
    );

  return (
    <div className="grid gap-4 md:grid-cols-[320px_1fr]">
      <aside className={open ? 'hidden md:block' : ''}><ChatList /></aside>
      <section className={open ? '' : 'hidden md:block'}>{children}</section>
    </div>
  );
}
