'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { app } from '@/store';
import { chatStore } from '@/store/chat';
import { Avatar } from '@/components/ui/Avatar';
import { useMounted } from '@/lib/hooks';
import { chatFace, chatTitle } from './chatUtils';
import { Composer } from './Composer';
import { MembersModal } from './MembersModal';
import { MessageBubble } from './MessageBubble';

/** One conversation: messages (kept on the device), live typing and read receipts, and the message box */
export function ChatWindow({ chatId }: { chatId: number }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [me] = app.useGlobalState('me', token ?? undefined);
  const [chats, , chatsStatus] = app.useGlobalState('chats', token ?? undefined);
  const [socket] = app.useGlobalState('socket');
  const [allMessages] = chatStore.useGlobalState('messages');
  const [allReads] = chatStore.useGlobalState('reads');
  const [allTyping] = chatStore.useGlobalState('typing');
  const [hasMore] = chatStore.useGlobalState('hasMore');
  const [showMembers, setShowMembers] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const bottom = useRef<HTMLDivElement>(null);

  const chat = chats?.find((c) => c.id === chatId);
  const messages = allMessages[chatId] ?? [];
  const lastId = messages.at(-1)?.id;

  // This chat is the one on screen: new messages in it are read at once, and the list's unread count clears
  useEffect(() => {
    if (!token) return;
    chatStore.setState('activeChat', chatId);
    let cancelled = false;
    chatStore.actions.loadHistory(chatId).then(() => {
      if (cancelled) return;
      chatStore.actions.markSeen(chatId);
      app.setQueryData('chats', (prev: { id: number; unread: number }[] | undefined) => prev?.map((c) => (c.id === chatId ? { ...c, unread: 0 } : c)), token);
      app.fetchQuery('badges', token, true).catch(() => {});
    }).catch(() => {});
    return () => {
      cancelled = true;
      chatStore.setState('activeChat', null);
    };
  }, [chatId, token, socket]);

  // Mark as read when a message arrives while looking at the chat
  useEffect(() => {
    if (lastId && lastId > 0) chatStore.actions.markSeen(chatId);
  }, [lastId, chatId]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ block: 'end' });
  }, [lastId, chatId]);

  // "typing…" runs out by itself: look at the clock while someone is typing
  const typingIds = Object.entries(allTyping[chatId] ?? {}).filter(([id, until]) => until > now && Number(id) !== me?.id).map(([id]) => Number(id));
  useEffect(() => {
    if (typingIds.length === 0) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [typingIds.length]);
  useEffect(() => { setNow(Date.now()); }, [allTyping]);

  if (!mounted) return null;
  if (chatsStatus.state === 'ready' && !chat) return <p className="rounded-xl bg-white p-6 text-center text-ink/60">This chat doesn&apos;t exist, or you&apos;re no longer in it. <Link href="/chat" className="text-brand underline">Back to chats</Link></p>;
  if (!chat || !me) return <div className="h-96 animate-pulse rounded-2xl bg-black/5" />;

  const others = chat.members.filter((m) => m.id !== me.id);
  const reads = allReads[chatId] ?? chat.reads;
  const myNewest = [...messages].reverse().find((m) => m.senderId === me.id && m.id > 0);
  const seenBy = myNewest ? others.filter((o) => (reads[o.id] ?? 0) >= myNewest.id).length : 0;
  const receiptFor = (id: number) => {
    if (id !== myNewest?.id) return undefined;
    if (seenBy === 0) return 'Sent';
    return chat.kind === 'direct' ? 'Seen' : `Seen by ${seenBy}`;
  };
  const face = chatFace(chat, me.id);
  const typingNames = typingIds.map((id) => chat.members.find((m) => m.id === id)?.name.split(' ')[0] ?? 'Someone');

  return (
    <div className="flex h-[calc(100vh-9rem)] min-h-96 flex-col overflow-hidden rounded-2xl border bg-[#eef3f0]" data-testid="chat-window">
      <header className="flex items-center gap-3 border-b bg-white px-4 py-3">
        <Link href="/chat" className="text-ink/50 md:hidden" aria-label="Back">←</Link>
        {face && <Avatar player={face} dot={chat.kind === 'direct'} />}
        <div className="min-w-0 flex-1">
          <p className="truncate font-bold" data-testid="chat-title">{chatTitle(chat, me.id)}</p>
          <p className="h-4 text-xs text-ink/50" data-testid="typing">
            {typingNames.length > 0 ? `${typingNames.join(', ')} ${typingNames.length > 1 ? 'are' : 'is'} typing…` : chat.kind === 'direct' ? '' : `${chat.members.length} members`}
          </p>
        </div>
        <button onClick={() => setShowMembers(true)} className="rounded-full border px-3 py-1 text-sm hover:bg-black/5">{chat.kind === 'direct' ? 'Info' : 'Members'}</button>
      </header>

      <div className="flex-1 space-y-2 overflow-y-auto p-4" data-testid="messages">
        {hasMore[chatId] && (
          <div className="text-center"><button onClick={() => chatStore.actions.loadOlder(chatId)} className="rounded-full border bg-white px-4 py-1 text-sm">Load older messages</button></div>
        )}
        {messages.length === 0 && <p className="py-10 text-center text-sm text-ink/50">No messages yet. Say hello 👋</p>}
        {messages.map((m, i) => (
          <MessageBubble
            key={m.id}
            message={m}
            mine={m.senderId === me.id}
            sender={chat.members.find((x) => x.id === m.senderId)}
            showName={chat.kind !== 'direct' && messages[i - 1]?.senderId !== m.senderId}
            receipt={m.senderId === me.id ? receiptFor(m.id) : undefined}
          />
        ))}
        <div ref={bottom} />
      </div>

      <Composer chatId={chatId} />
      {showMembers && <MembersModal chat={chat} meId={me.id} onClose={() => setShowMembers(false)} />}
    </div>
  );
}
