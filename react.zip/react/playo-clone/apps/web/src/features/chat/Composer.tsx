'use client';

import { useRef, useState } from 'react';
import { app } from '@/store';
import { chatStore } from '@/store/chat';
import { shrinkImage } from '@/lib/image';
import { send as sendSocket } from '@/realtime/socket';

const TYPING_EVERY_MS = 2000;

/** The message box. What's typed is a draft kept on the device (so it survives leaving or reloading). */
export function Composer({ chatId }: { chatId: number }) {
  const [drafts, setDrafts] = chatStore.useGlobalState('drafts');
  const [socket] = app.useGlobalState('socket');
  const text = drafts[chatId] ?? '';
  const [image, setImage] = useState<string | null>(null);
  const [error, setError] = useState('');
  const lastTyping = useRef(0);
  const fileInput = useRef<HTMLInputElement>(null);

  const change = (value: string) => {
    setDrafts.set(chatId, value);
    // tell the others, at most every couple of seconds
    const now = Date.now();
    if (value && now - lastTyping.current > TYPING_EVERY_MS) {
      lastTyping.current = now;
      sendSocket({ type: 'typing', chatId });
    }
  };

  const submit = async () => {
    const body = text.trim();
    if (!body && !image) return;
    const picture = image;
    setImage(null);
    setError('');
    await chatStore.actions.send(chatId, body, picture);
  };

  const attach = async (file: File | undefined) => {
    if (!file) return;
    try {
      setImage(await shrinkImage(file));
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not use that picture');
    }
  };

  return (
    <div className="space-y-2 border-t bg-white p-3">
      {image && (
        <div className="relative inline-block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={image} alt="Picture to send" className="max-h-32 rounded-lg" data-testid="attachment-preview" />
          <button onClick={() => setImage(null)} aria-label="Remove picture" className="absolute -right-2 -top-2 size-6 rounded-full bg-ink text-white">×</button>
        </div>
      )}
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      <div className="flex items-end gap-2">
        <input ref={fileInput} type="file" accept="image/*" className="hidden" aria-label="Attach a picture" data-testid="file-input" onChange={(e) => { attach(e.target.files?.[0]); e.target.value = ''; }} />
        <button onClick={() => fileInput.current?.click()} aria-label="Attach picture" className="rounded-full border px-3 py-2 text-lg hover:bg-black/5">📷</button>
        <textarea
          value={text}
          onChange={(e) => change(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
          rows={1}
          placeholder="Type a message"
          aria-label="Message"
          className="max-h-32 min-h-10 flex-1 resize-none rounded-2xl border px-4 py-2 outline-none focus:border-brand"
        />
        <button onClick={submit} disabled={!text.trim() && !image} className="rounded-full bg-brand px-5 py-2 font-semibold text-white">Send</button>
      </div>
      {socket === 'closed' && <p className="text-xs text-amber-600">Offline: messages will be sent when you're back online.</p>}
    </div>
  );
}
