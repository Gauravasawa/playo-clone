'use client';

import { useState } from 'react';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import { Modal } from '@/components/ui/Modal';
import { api, type Chat } from '@/lib/api';

/** Who is in a chat; in a group, add friends or leave */
export function MembersModal({ chat, meId, onClose }: { chat: Chat; meId: number; onClose: () => void }) {
  const [token] = app.useGlobalState('token');
  const [friends] = app.useGlobalState('friends', token ?? undefined);
  const [picked, setPicked] = useState<number[]>([]);
  const [error, setError] = useState('');
  const inChat = new Set(chat.members.map((m) => m.id));
  const addable = (friends?.friends ?? []).filter((f) => !inChat.has(f.id));
  const isGroup = chat.kind === 'group';

  const run = async (task: (t: string) => Promise<unknown>, done?: () => void) => {
    if (!token) return;
    try {
      await task(token);
      app.invalidate('chats');
      done?.();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed');
    }
  };

  return (
    <Modal title={`${chat.title ?? 'Chat'} · ${chat.members.length} members`} onClose={onClose}>
      <ul className="space-y-1" data-testid="members">
        {chat.members.map((m) => (
          <li key={m.id} className="flex items-center justify-between gap-3 rounded-lg p-2">
            <span className="flex items-center gap-3"><Avatar player={m} size={32} /> {m.name}{m.id === meId && <span className="text-xs text-ink/40"> (you)</span>}</span>
            {isGroup && m.id !== meId && chat.createdBy === meId && (
              <button onClick={() => run((t) => api.removeMember(t, chat.id, m.id))} className="text-sm text-red-600 underline">Remove</button>
            )}
          </li>
        ))}
      </ul>
      {isGroup && addable.length > 0 && (
        <div className="space-y-2 border-t pt-3">
          <p className="text-sm font-semibold">Add friends</p>
          {addable.map((f) => (
            <label key={f.id} className="flex cursor-pointer items-center gap-3 rounded-lg p-1.5 hover:bg-black/5">
              <input type="checkbox" checked={picked.includes(f.id)} onChange={() => setPicked(picked.includes(f.id) ? picked.filter((x) => x !== f.id) : [...picked, f.id])} />
              <Avatar player={f} size={28} /> {f.name}
            </label>
          ))}
          <button disabled={picked.length === 0} onClick={() => run((t) => api.addMembers(t, chat.id, picked), () => setPicked([]))} className="rounded-full bg-brand px-4 py-1.5 text-sm font-semibold text-white">Add {picked.length || ''}</button>
        </div>
      )}
      {isGroup && (
        <button onClick={() => run((t) => api.removeMember(t, chat.id, meId), onClose)} className="text-sm text-red-600 underline">Leave group</button>
      )}
      {chat.kind === 'game' && <p className="text-xs text-ink/50">Everyone who joins the game is added to this chat; leave the game to leave the chat.</p>}
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
    </Modal>
  );
}
