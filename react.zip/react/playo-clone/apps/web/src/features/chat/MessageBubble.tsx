'use client';

import type { ChatMessage, Player } from '@/lib/api';
import { chatStore } from '@/store/chat';
import { ReportButton } from '@/features/safety/ReportButton';
import { clock } from './chatUtils';

interface Props {
  message: ChatMessage;
  mine: boolean;
  sender: Player | undefined;
  showName: boolean;
  /** Receipt line under my newest message: "Seen", "Seen by 2", or "Sent" */
  receipt?: string;
}

export function MessageBubble({ message: m, mine, sender, showName, receipt }: Props) {
  return (
    <div className={`flex ${mine ? 'justify-end' : 'justify-start'}`} data-testid={`msg-${m.id}`}>
      <div className={`max-w-[75%] space-y-1 rounded-2xl px-3 py-2 ${mine ? 'rounded-br-sm bg-brand text-white' : 'rounded-bl-sm bg-white'} ${m.pending ? 'opacity-60' : ''}`}>
        {showName && !mine && <p className="text-xs font-semibold text-brand-dark">{sender?.name ?? 'Someone'}</p>}
        {m.image && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={m.image} alt="Sent picture" className="max-h-64 rounded-lg" />
        )}
        {m.body && <p className="whitespace-pre-wrap break-words">{m.body}</p>}
        <p className={`flex items-center justify-end gap-2 text-[11px] ${mine ? 'text-white/90' : 'text-ink/40'}`}>
          {m.pending && <span>sending…</span>}
          {m.failed && (
            <>
              <span className="font-semibold text-red-200">Failed</span>
              <button className="underline" onClick={() => chatStore.actions.retry(m.chatId, m.id)}>Retry</button>
              <button className="underline" onClick={() => chatStore.messages.discard(m.chatId, m.id)}>Discard</button>
            </>
          )}
          {!m.pending && !m.failed && <span>{clock(m.createdAt)}</span>}
          {receipt && <span data-testid="receipt">{receipt}</span>}
          {!mine && m.id > 0 && !m.pending && <ReportButton kind="message" targetId={m.id} label="Report" className="text-[11px] text-ink/40 underline hover:text-red-600" />}
        </p>
      </div>
    </div>
  );
}
