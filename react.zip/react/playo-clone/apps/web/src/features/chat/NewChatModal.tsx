'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import { Modal } from '@/components/ui/Modal';
import { Tabs } from '@/components/ui/Tabs';
import { api } from '@/lib/api';

type Mode = 'direct' | 'group';

/** Start a 1:1 chat with a friend, or make a group of friends */
export function NewChatModal({ onClose }: { onClose: () => void }) {
  const router = useRouter();
  const [token] = app.useGlobalState('token');
  const [friends] = app.useGlobalState('friends', token ?? undefined);
  const [mode, setMode] = useState<Mode>('direct');
  const [title, setTitle] = useState('');
  const [picked, setPicked] = useState<number[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const list = friends?.friends ?? [];

  const open = async (create: () => Promise<{ id: number }>) => {
    setBusy(true);
    setError('');
    try {
      const chat = await create();
      app.invalidate('chats');
      onClose();
      router.push(`/chat/${chat.id}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not create the chat');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title="New chat" onClose={onClose}>
      <Tabs<Mode> value={mode} onChange={setMode} tabs={[{ id: 'direct', label: 'One to one' }, { id: 'group', label: 'Group' }]} />
      {list.length === 0 && <p className="text-sm text-ink/60">You can chat with friends. Add some from the Friends page first.</p>}
      {mode === 'group' && (
        <input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={40} placeholder="Group name" aria-label="Group name" className="w-full rounded-lg border px-3 py-2" />
      )}
      <ul className="max-h-64 space-y-1 overflow-y-auto">
        {list.map((f) => (
          <li key={f.id}>
            {mode === 'direct' ? (
              <button disabled={busy} onClick={() => token && open(() => api.openDirect(token, f.id))} className="flex w-full items-center gap-3 rounded-lg p-2 text-left hover:bg-black/5">
                <Avatar player={f} size={32} /> {f.name}
              </button>
            ) : (
              <label className="flex cursor-pointer items-center gap-3 rounded-lg p-2 hover:bg-black/5">
                <input type="checkbox" checked={picked.includes(f.id)} onChange={() => setPicked(picked.includes(f.id) ? picked.filter((x) => x !== f.id) : [...picked, f.id])} />
                <Avatar player={f} size={32} /> {f.name}
              </label>
            )}
          </li>
        ))}
      </ul>
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      {mode === 'group' && (
        <button disabled={busy || !title.trim() || picked.length === 0} onClick={() => token && open(() => api.createGroup(token, title.trim(), picked))} className="w-full rounded-full bg-brand py-2.5 font-semibold text-white">
          Create group ({picked.length})
        </button>
      )}
    </Modal>
  );
}
