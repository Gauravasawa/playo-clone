import type { Chat, Player } from '@/lib/api';

/** What to call a chat: the other person in a 1:1, otherwise its title */
export function chatTitle(chat: Chat, meId: number | undefined): string {
  if (chat.kind === 'direct') return chat.members.find((m) => m.id !== meId)?.name ?? 'Chat';
  return chat.title ?? 'Group';
}

/** The face for a chat: the other person in a 1:1, the first member otherwise */
export function chatFace(chat: Chat, meId: number | undefined): Player | undefined {
  return chat.kind === 'direct' ? chat.members.find((m) => m.id !== meId) : chat.members[0];
}

export const kindLabel = (chat: Chat) => (chat.kind === 'game' ? 'Game chat' : chat.kind === 'group' ? 'Group' : '');

export const clock = (ms: number) => new Date(ms).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
