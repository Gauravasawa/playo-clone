'use client';

import { useState } from 'react';
import { app } from '@/store';
import { Modal } from '@/components/ui/Modal';
import { PaymentPicker, usePaymentChoice } from '@/components/ui/PaymentPicker';
import { Price } from '@/components/ui/Price';
import { api, type Batch, type Coach, type Program } from '@/lib/api';
import { money, nextDays } from '@/lib/format';
import { useMounted } from '@/lib/hooks';

const errorText = (e: unknown, fallback: string) => (e instanceof Error ? e.message : fallback);

/** Pick a batch of a program and pay for the whole program */
export function EnrolModal({ coach, program, onClose }: { coach: Coach; program: Program; onClose: () => void }) {
  const [token] = app.useGlobalState('token');
  const [batchId, setBatchId] = useState<number | null>(program.batches.find((b) => b.seatsLeft > 0)?.id ?? null);
  const [busy, setBusy] = useState(false);
  const choice = usePaymentChoice(program.priceInr);

  const pay = async () => {
    if (!token || batchId == null) return;
    setBusy(true);
    try {
      await api.enrol(token, program.id, { batchId, method: choice.method });
      app.emit('toast', { kind: 'ok', text: `Enrolled in ${program.title}` });
      app.invalidate('learning');
      app.invalidate('wallet');
      onClose();
    } catch (e) {
      app.emit('toast', { kind: 'err', text: errorText(e, 'Could not enrol') });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={`Enrol: ${program.title}`} onClose={onClose}>
      <p className="text-sm text-ink/60">{program.sessions} sessions over {program.weeks} weeks with {coach.name}</p>
      <fieldset className="space-y-1 text-sm">
        <legend className="mb-1 font-semibold">Choose a batch</legend>
        {program.batches.map((b: Batch) => (
          <label key={b.id} className={`flex items-center gap-2 rounded-lg border p-2 ${b.seatsLeft <= 0 ? 'opacity-50' : ''}`}>
            <input type="radio" name="batch" data-testid={`batch-${b.id}`} disabled={b.seatsLeft <= 0} checked={batchId === b.id} onChange={() => setBatchId(b.id)} />
            <span>{b.days} · {b.time} · starts {b.startsOn}</span>
            <span className="ml-auto text-ink/50">{b.seatsLeft <= 0 ? 'Full' : `${b.seatsLeft} of ${b.seats} seats left`}</span>
          </label>
        ))}
      </fieldset>
      <PaymentPicker choice={choice} name="enrol-pay" />
      <button onClick={pay} disabled={busy || batchId == null || choice.blocked} data-tip={busy ? 'Working… one moment' : batchId == null ? 'Pick a batch first' : choice.blocked ? 'Not enough wallet balance: top up, or pay with UPI or card' : undefined} data-testid="enrol-pay" className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark disabled:opacity-50">
        {busy ? 'Paying…' : <>Pay <Price inr={program.priceInr} city={coach.city} brackets={false} /> and enrol</>}
      </button>
      <p className="text-xs text-ink/50">Charged in rupees ({money(program.priceInr)}). Cancel before the batch starts for a refund, see the cancellation policy.</p>
    </Modal>
  );
}

/** A single trial session: pick a day and a free slot, then pay */
export function SessionModal({ coach, onClose }: { coach: Coach; onClose: () => void }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const days = nextDays(7);
  const [date, setDate] = useState(days[0].value);
  const [time, setTime] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [slots, , status] = app.useGlobalState('coachSlots', { id: coach.id, date });
  const choice = usePaymentChoice(coach.pricePerSession);

  const book = async () => {
    if (!token || !time) return;
    setBusy(true);
    try {
      await api.bookSession(token, coach.id, { date, time, method: choice.method });
      app.emit('toast', { kind: 'ok', text: `Trial session booked for ${date} at ${time}` });
      app.invalidate('learning');
      app.invalidate('wallet');
      app.invalidate('coachSlots');
      onClose();
    } catch (e) {
      app.emit('toast', { kind: 'err', text: errorText(e, 'Could not book') });
      app.invalidate('coachSlots');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={`Trial session with ${coach.name}`} onClose={onClose}>
      <div className="flex gap-1 overflow-x-auto">
        {days.map((d) => (
          <button key={d.value} data-testid={`session-day-${d.value}`} onClick={() => { setDate(d.value); setTime(null); }} className={`rounded-lg border px-3 py-1.5 text-center text-sm ${date === d.value ? 'border-brand bg-brand text-white' : 'bg-white'}`}>
            <div className="text-xs">{d.day}</div><div className="font-bold">{d.date}</div>
          </button>
        ))}
      </div>
      {mounted && status.state === 'loading' ? <p className="text-sm text-ink/50">Loading slots…</p> : (
        <div className="flex flex-wrap gap-2" data-testid="session-slots">
          {(slots ?? []).map((s) => (
            <button key={s.time} disabled={!s.available} onClick={() => setTime(s.time)} title={s.reason ?? ''} data-testid={`session-slot-${s.time}`}
              className={`rounded-lg border px-3 py-1.5 text-sm ${time === s.time ? 'border-brand bg-brand text-white' : s.available ? 'bg-white hover:bg-black/5' : 'bg-black/5 text-ink/30 line-through'}`}>{s.time}</button>
          ))}
          {slots && slots.length === 0 && <p className="text-sm text-ink/50">No slots this day.</p>}
        </div>
      )}
      <PaymentPicker choice={choice} name="session-pay" />
      <button onClick={book} disabled={busy || !time || choice.blocked} data-tip={busy ? 'Working… one moment' : !time ? 'Pick a time first' : choice.blocked ? 'Not enough wallet balance: top up, or pay with UPI or card' : undefined} data-testid="session-pay" className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark disabled:opacity-50">
        {busy ? 'Paying…' : <>Pay <Price inr={coach.pricePerSession} city={coach.city} brackets={false} /> and book</>}
      </button>
    </Modal>
  );
}

/** A free-text enquiry to the coach (the original flow, kept next to booking) */
export function EnquiryModal({ coach, onClose }: { coach: Coach; onClose: () => void }) {
  const [token] = app.useGlobalState('token');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    if (!token) return;
    setBusy(true);
    try {
      await api.coachEnquiry(token, coach.id, message);
      app.emit('toast', { kind: 'ok', text: `Enquiry sent to ${coach.name}` });
      onClose();
    } catch (e) {
      app.emit('toast', { kind: 'err', text: errorText(e, 'Could not send') });
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={`Ask ${coach.name}`} onClose={onClose}>
      <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={4} placeholder="Tell the coach your level and when you're free" aria-label="Message to the coach" className="w-full rounded-lg border px-3 py-2" />
      <button disabled={busy || !message.trim()} data-tip={!message.trim() ? 'Write a short message first' : undefined} onClick={send} data-testid="enquiry-send" className="w-full rounded-full bg-brand py-2.5 font-semibold text-white">Send enquiry</button>
    </Modal>
  );
}
