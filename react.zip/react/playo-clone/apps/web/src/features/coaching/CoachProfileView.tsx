'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Price } from '@/components/ui/Price';
import { ShareMenu } from '@/components/ui/ShareMenu';
import { Skeleton } from '@/components/ui/Skeleton';
import { ReportButton } from '@/features/safety/ReportButton';
import { Stars } from '@/features/profile/ProfileParts';
import { api, type Program } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { EnquiryModal, EnrolModal, SessionModal } from './BookingModals';

type Dialog = { kind: 'enrol'; program: Program } | { kind: 'session' } | { kind: 'enquiry' } | null;

function ReviewForm({ coachId }: { coachId: number }) {
  const [token] = app.useGlobalState('token');
  const [rating, setRating] = useState(5);
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    if (!token) return;
    setBusy(true);
    try {
      await api.reviewCoach(token, coachId, { rating, body });
      app.emit('toast', { kind: 'ok', text: 'Thanks for your review' });
      setBody('');
      app.invalidate('coach');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not send review' });
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="space-y-2 rounded-xl border bg-white p-4" data-testid="coach-review-form">
      <p className="font-semibold">Rate your coach</p>
      <select value={rating} onChange={(e) => setRating(Number(e.target.value))} aria-label="Rating" className="rounded-lg border px-2 py-1">
        {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} ★</option>)}
      </select>
      <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={3} placeholder="How were the sessions?" aria-label="Review text" className="w-full rounded-lg border px-3 py-2" />
      <button onClick={send} disabled={busy || !body.trim()} data-testid="coach-review-send" className="rounded-full bg-brand px-5 py-2 font-semibold text-white disabled:opacity-50">Post review</button>
    </div>
  );
}

export function CoachProfileView({ id }: { id: number }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [sportsData] = app.useGlobalState('sports');
  const sports = sportsData ?? []; // the query is undefined until it loads
  const params = useMemo(() => ({ id, token: mounted ? token : null }), [id, mounted, token]);
  const [coach, , status] = app.useGlobalState('coach', params);
  const [dialog, setDialog] = useState<Dialog>(null);
  const needLogin = (open: () => void) => (token ? open() : app.setState('loginOpen', true));

  if (status.state === 'loading' || status.state === 'waiting') return <Skeleton count={3} className="h-32" />;
  if (status.state === 'error' || !coach) return <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load this coach.</ErrorNotice>;
  const sport = sports.find((s) => s.id === coach.sport);

  return (
    <div className="space-y-6" data-testid="coach-profile">
      <Link href="/coaches" className="inline-block py-1.5 text-sm text-ink/60 hover:text-brand">← All coaches</Link>
      <header className="space-y-2 rounded-2xl border bg-white p-6">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="text-2xl font-extrabold" data-testid="coach-name">{coach.name}</h1>
            <p className="text-sm text-ink/60">{sport?.emoji} {sport?.name ?? coach.sport} · {coach.area}, {coach.city} · {coach.experienceYears} yrs experience</p>
          </div>
          <ShareMenu path={`/coaches/${coach.id}`} title={coach.name} text={`Train with ${coach.name} on Playo clone`} />
        </div>
        <p className="text-sm"><Stars value={Math.round(coach.rating)} /> <b>{coach.rating}</b> ({coach.reviewCount} reviews) · <b><Price inr={coach.pricePerSession} city={coach.city} /></b> per trial session</p>
        <p className="text-ink/80">{coach.bio}</p>
        <dl className="grid gap-3 pt-2 text-sm md:grid-cols-3">
          <div><dt className="font-semibold">Certifications</dt><dd className="text-ink/70" data-testid="coach-certs">{coach.certifications.map((c) => <span key={c} className="mr-1 mt-1 inline-block rounded-full bg-green-50 px-2 py-0.5 text-green-800">🎓 {c}</span>)}</dd></div>
          <div><dt className="font-semibold">Specialties</dt><dd className="text-ink/70" data-testid="coach-specialties">{coach.specialties.map((c) => <span key={c} className="mr-1 mt-1 inline-block rounded-full bg-black/5 px-2 py-0.5">{c}</span>)}</dd></div>
          <div><dt className="font-semibold">Languages</dt><dd className="text-ink/70">{coach.languages.join(', ')}</dd></div>
        </dl>
        <div className="flex flex-wrap gap-2 pt-2">
          <button onClick={() => needLogin(() => setDialog({ kind: 'session' }))} data-testid="book-session" className="rounded-full bg-brand px-5 py-2 font-semibold text-white hover:bg-brand-dark">Book a trial session</button>
          <button onClick={() => needLogin(() => setDialog({ kind: 'enquiry' }))} data-testid="open-enquiry" className="rounded-full border px-5 py-2 font-semibold hover:bg-black/5">Enquire</button>
        </div>
      </header>

      <section className="space-y-3">
        <h2 className="text-lg font-bold">Programs</h2>
        {coach.programs.length === 0 ? <EmptyState>No programs yet. Book a trial session or send an enquiry.</EmptyState> : (
          <ul className="grid gap-4 md:grid-cols-2" data-testid="program-list">
            {coach.programs.map((p) => (
              <li key={p.id} className="space-y-2 rounded-2xl border bg-white p-5" data-testid={`program-${p.id}`}>
                <h3 className="font-bold">{p.title}</h3>
                <p className="text-sm text-ink/60">{p.level} · {p.sessions} sessions · {p.weeks} weeks</p>
                <p className="text-sm text-ink/70">{p.description}</p>
                <ul className="space-y-0.5 text-sm text-ink/70">
                  {p.batches.map((b) => <li key={b.id}>🗓 {b.days} · {b.time} · from {b.startsOn} · {b.seatsLeft > 0 ? `${b.seatsLeft} seats left` : 'full'}</li>)}
                </ul>
                <div className="flex items-center justify-between pt-1">
                  <b><Price inr={p.priceInr} city={coach.city} /></b>
                  <button disabled={p.batches.every((b) => b.seatsLeft <= 0)} onClick={() => needLogin(() => setDialog({ kind: 'enrol', program: p }))} data-testid={`enrol-${p.id}`} className="rounded-full bg-brand px-4 py-1.5 text-sm font-semibold text-white disabled:opacity-50">Enrol</button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="space-y-3" id="reviews">
        <h2 className="text-lg font-bold">Reviews</h2>
        {coach.canReview && <ReviewForm coachId={coach.id} />}
        {coach.reviews.length === 0 ? <EmptyState>No reviews yet. Students can review after a session or a program.</EmptyState> : (
          <ul className="space-y-3" data-testid="coach-reviews">
            {coach.reviews.map((r) => (
              <li key={r.id} className="flex gap-3 rounded-2xl border bg-white p-4">
                {r.author && <Avatar player={r.author} size={36} />}
                <div className="flex-1">
                  <p className="text-sm font-semibold">{r.author?.name ?? 'Player'} <Stars value={r.rating} /></p>
                  <p className="text-sm text-ink/80">{r.body}</p>
                </div>
                <ReportButton kind="review" targetId={r.id} label="Report" />
              </li>
            ))}
          </ul>
        )}
      </section>

      {dialog?.kind === 'enrol' && <EnrolModal coach={coach} program={dialog.program} onClose={() => setDialog(null)} />}
      {dialog?.kind === 'session' && <SessionModal coach={coach} onClose={() => setDialog(null)} />}
      {dialog?.kind === 'enquiry' && <EnquiryModal coach={coach} onClose={() => setDialog(null)} />}
    </div>
  );
}
