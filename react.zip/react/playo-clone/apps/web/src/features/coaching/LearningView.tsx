'use client';

import Link from 'next/link';
import { useState } from 'react';
import { app } from '@/store';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { api } from '@/lib/api';
import { formatInr } from '@/config/cities';
import { useMounted } from '@/lib/hooks';

const statusChip = (s: string) => `rounded-full px-2 py-0.5 text-xs font-semibold ${s === 'cancelled' ? 'bg-red-100 text-red-700' : s === 'active' || s === 'confirmed' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`;

/** What you've enrolled in and booked: programs and trial sessions */
export function LearningView() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [data, , status] = app.useGlobalState('learning', token ?? undefined, { enabled: mounted && !!token });
  const [busy, setBusy] = useState<string | null>(null);

  if (!mounted) return <Skeleton count={2} className="h-24" />;
  if (!token) return <><EmptyState>Log in to see your programs and sessions. <button className="font-semibold text-brand underline" onClick={() => app.setState('loginOpen', true)}>Log in</button></EmptyState></>;
  if (status.state === 'loading' || status.state === 'waiting') return <Skeleton count={3} className="h-24" />;
  if (status.state === 'error' || !data) return <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load your learning.</ErrorNotice>;

  const now = Date.now();
  const run = async (key: string, job: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    try {
      await job();
      app.emit('toast', { kind: 'ok', text: ok });
      app.invalidate('learning');
      app.invalidate('wallet');
      app.invalidate('coach');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Something went wrong' });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-8">
      <section className="space-y-3">
        <h2 className="text-lg font-bold">Programs</h2>
        {data.enrolments.length === 0 ? <EmptyState>No programs yet. <Link href="/coaches" className="font-semibold text-brand underline">Find a coach</Link></EmptyState> : (
          <ul className="space-y-3" data-testid="enrolment-list">
            {data.enrolments.map((e) => (
              <li key={e.id} className="space-y-1 rounded-2xl border bg-white p-5" data-testid={`enrolment-${e.id}`}>
                <div className="flex items-center justify-between">
                  <h3 className="font-bold">{e.program.title}</h3>
                  <span className={statusChip(e.status)} data-testid={`enrolment-status-${e.id}`}>{e.status}</span>
                </div>
                <p className="text-sm text-ink/60">with <Link href={`/coaches/${e.coach.id}`} className="text-brand hover:underline">{e.coach.name}</Link> · {e.batch.days} · {e.batch.time} · starts {e.batch.startsOn} · {e.program.sessions} sessions · paid {formatInr(e.paid)}</p>
                <div className="flex flex-wrap gap-2 pt-1">
                  {e.status === 'active' && e.startsAt > now && (
                    <button disabled={busy === `e${e.id}`} data-testid={`cancel-enrolment-${e.id}`} onClick={() => confirm(`Cancel? You get ${e.refundPercent}% back.`) && run(`e${e.id}`, () => api.cancelEnrolment(token, e.id), 'Enrolment cancelled, refund sent to your wallet')} className="rounded-full border px-4 py-1.5 text-sm font-semibold text-red-600 hover:bg-red-50">Cancel ({e.refundPercent}% refund)</button>
                  )}
                  {e.status === 'active' && (
                    <button disabled={busy === `a-e${e.id}`} data-testid={`attend-enrolment-${e.id}`} onClick={() => run(`a-e${e.id}`, () => api.attendLearning(token, 'enrolment', e.id), 'Marked completed (demo)')} className="rounded-full border px-4 py-1.5 text-sm hover:bg-black/5">Demo: mark completed</button>
                  )}
                  {e.status === 'completed' && <Link href={`/coaches/${e.coach.id}#reviews`} className="rounded-full bg-brand px-4 py-1.5 text-sm font-semibold text-white">Review your coach</Link>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="space-y-3">
        <h2 className="text-lg font-bold">Trial sessions</h2>
        {data.sessions.length === 0 ? <EmptyState>No trial sessions booked.</EmptyState> : (
          <ul className="space-y-3" data-testid="session-list">
            {data.sessions.map((s) => (
              <li key={s.id} className="space-y-1 rounded-2xl border bg-white p-5" data-testid={`session-${s.id}`}>
                <div className="flex items-center justify-between">
                  <h3 className="font-bold">Trial with {s.coach.name}</h3>
                  <span className={statusChip(s.status)} data-testid={`session-status-${s.id}`}>{s.status}</span>
                </div>
                <p className="text-sm text-ink/60">{s.date} at {s.time} · {s.coach.city} · paid {formatInr(s.paid)}</p>
                <div className="flex flex-wrap gap-2 pt-1">
                  {s.status === 'confirmed' && s.startsAt > now && (
                    <button disabled={busy === `s${s.id}`} data-testid={`cancel-session-${s.id}`} onClick={() => confirm(`Cancel? You get ${s.refundPercent}% back.`) && run(`s${s.id}`, () => api.cancelSession(token, s.id), 'Session cancelled, refund sent to your wallet')} className="rounded-full border px-4 py-1.5 text-sm font-semibold text-red-600 hover:bg-red-50">Cancel ({s.refundPercent}% refund)</button>
                  )}
                  {s.status === 'confirmed' && (
                    <button disabled={busy === `a-s${s.id}`} data-testid={`attend-session-${s.id}`} onClick={() => run(`a-s${s.id}`, () => api.attendLearning(token, 'session', s.id), 'Marked attended (demo)')} className="rounded-full border px-4 py-1.5 text-sm hover:bg-black/5">Demo: mark attended</button>
                  )}
                  {s.status === 'attended' && <Link href={`/coaches/${s.coach.id}#reviews`} className="rounded-full bg-brand px-4 py-1.5 text-sm font-semibold text-white">Review your coach</Link>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
