'use client';

import { useMemo, useState } from 'react';
import { app } from '@/store';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Modal } from '@/components/ui/Modal';
import { Skeleton } from '@/components/ui/Skeleton';
import { api, type Coach } from '@/lib/api';
import Link from 'next/link';
import { Price } from '@/components/ui/Price';
import { useMounted } from '@/lib/hooks';
import { Stars } from '@/features/profile/ProfileParts';
import { Filters } from './Filters';

export function CoachesView() {
  const mounted = useMounted();
  const [sport] = app.useGlobalState('sport');
  const [city, setCity] = app.useGlobalState('city');
  const [token] = app.useGlobalState('token');
  const [sportsData] = app.useGlobalState('sports');
  const sports = sportsData ?? []; // the query is undefined until it loads
  const params = useMemo(() => ({ sport: mounted ? sport : 'all', city: mounted ? city : 'Bengaluru' }), [mounted, sport, city]);
  const [pages, , status] = app.useGlobalState('coaches', params);
  const coaches = pages.flatMap((p) => p.items);
  const [asking, setAsking] = useState<Coach | null>(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  const send = async () => {
    if (!token || !asking) return;
    setBusy(true);
    try {
      await api.coachEnquiry(token, asking.id, message);
      app.emit('toast', { kind: 'ok', text: `Enquiry sent to ${asking.name}` });
      setAsking(null);
      setMessage('');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not send' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-extrabold">Coaches</h1>
      <Filters city={city} onCity={setCity} />
      {status.state === 'loading' || status.state === 'waiting' ? <Skeleton count={3} className="h-28" /> : status.state === 'error' ? (
        <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load coaches.</ErrorNotice>
      ) : coaches.length === 0 ? (
        <EmptyState>No coaches for this sport in this city.</EmptyState>
      ) : (
        <>
          <ul className="grid gap-4 md:grid-cols-2" data-testid="coach-list">
            {coaches.map((c) => (
              <li key={c.id} className="space-y-1 rounded-2xl border bg-white p-5">
                <h2 className="font-bold"><Link href={`/coaches/${c.id}`} className="inline-block py-1 hover:text-brand" data-testid={`coach-link-${c.id}`}>{c.name}</Link></h2>
                <p className="text-sm text-ink/60">{sports.find((s) => s.id === c.sport)?.emoji} {sports.find((s) => s.id === c.sport)?.name} · {c.area} {c.city} · {c.experienceYears} yrs</p>
                <p className="text-sm text-ink/70">{c.bio}</p>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-sm"><Stars value={Math.round(c.rating)} /> {c.rating} ({c.reviewCount}) · <b><Price inr={c.pricePerSession} city={c.city} /></b>/session</span>
                  <div className="flex gap-2"><Link href={`/coaches/${c.id}`} className="rounded-full bg-brand px-4 py-1.5 text-sm font-semibold text-white">View profile</Link><button data-testid={`enquire-${c.id}`} onClick={() => (token ? setAsking(c) : app.setState('loginOpen', true))} className="rounded-full border px-4 py-1.5 text-sm font-semibold hover:bg-black/5">Enquire</button></div>
                </div>
              </li>
            ))}
          </ul>
          {status.hasNextPage && (
            <div className="text-center"><button onClick={() => status.fetchNextPage()} disabled={status.isFetchingNextPage} className="rounded-full border bg-white px-6 py-2 font-semibold">{status.isFetchingNextPage ? 'Loading…' : 'Load more'}</button></div>
          )}
        </>
      )}
      {asking && (
        <Modal title={`Ask ${asking.name}`} onClose={() => setAsking(null)}>
          <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={4} placeholder="Tell the coach your level and when you're free" aria-label="Message to the coach" className="w-full rounded-lg border px-3 py-2" />
          <button disabled={busy || !message.trim()} onClick={send} className="w-full rounded-full bg-brand py-2.5 font-semibold text-white">Send enquiry</button>
        </Modal>
      )}
    </div>
  );
}
