'use client';

import { app } from '@/store';
import { CITIES } from '@/config/constants';
import { useMounted } from '@/lib/hooks';
import { SportChips } from '@/features/venues/VenueFilters';

/** Sport chips (the same global `sport` as the rest of the app) and a city picker */
export function Filters({ allCities, city, onCity }: { allCities?: boolean; city: string; onCity: (c: string) => void }) {
  const mounted = useMounted();
  return (
    <div className="flex flex-wrap items-center gap-2">
      <SportChips allLabel="All sports" />
      <select aria-label="City filter" value={mounted ? city : ''} onChange={(e) => onCity(e.target.value)} className="ml-auto rounded-lg border bg-white px-2 py-1.5 text-sm">
        {allCities && <option value="all">All cities</option>}
        {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
      </select>
    </div>
  );
}
