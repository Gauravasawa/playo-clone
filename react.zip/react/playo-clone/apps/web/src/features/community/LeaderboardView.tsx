'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { useMounted } from '@/lib/hooks';
import { Filters } from './Filters';

/** Players ranked by points (3 per win + 1 per game played), from the games hosts have ended */
export function LeaderboardView() {
  const mounted = useMounted();
  const [sport] = app.useGlobalState('sport');
  const [token] = app.useGlobalState('token');
  const [me] = app.useGlobalState('me', token ?? undefined);
  const [city, setCity] = useState('all');
  const params = useMemo(() => ({ sport: mounted ? sport : 'all', city }), [mounted, sport, city]);
  const [rows, , status] = app.useGlobalState('leaderboard', params);

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-extrabold">Leaderboard</h1>
      <Filters allCities city={city} onCity={setCity} />
      {status.state === 'loading' || status.state === 'waiting' ? <Skeleton count={5} className="h-14" /> : status.state === 'error' ? (
        <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load the leaderboard.</ErrorNotice>
      ) : !rows?.length ? (
        <EmptyState>No finished games for this filter yet.</EmptyState>
      ) : (
        <ol className="space-y-2" data-testid="leaderboard">
          {rows.map((r) => (
            <li key={r.player.id} className={`flex flex-wrap items-center gap-x-4 gap-y-1 rounded-2xl border p-3 ${me?.id === r.player.id ? 'border-brand bg-brand/5' : 'bg-white'}`} data-testid={`rank-${r.rank}`}>
              <span className="w-8 text-center text-lg font-extrabold text-ink/40">{r.rank <= 3 ? ['🥇', '🥈', '🥉'][r.rank - 1] : r.rank}</span>
              <Avatar player={r.player} size={36} />
              <Link href={`/p/${r.player.username}`} className="min-w-[8rem] flex-1 break-words py-1 font-semibold hover:text-brand">{r.player.name}<span className="ml-2 break-all text-sm font-normal text-ink/50">@{r.player.username}</span></Link>
              <span className="text-sm text-ink/60">{r.games} games · {r.wins} wins</span>
              <span className="w-16 text-right font-bold">{r.points} pts</span>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
