'use client';

import { useMemo, useState } from 'react';
import { app } from '@/store';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Modal } from '@/components/ui/Modal';
import { Skeleton } from '@/components/ui/Skeleton';
import { api, type Tournament } from '@/lib/api';
import { formatGameTime, money } from '@/lib/format';
import { Price } from '@/components/ui/Price';
import { useMounted } from '@/lib/hooks';
import { Filters } from './Filters';

export function TournamentsView() {
  const mounted = useMounted();
  const [sport] = app.useGlobalState('sport');
  const [globalCity, setGlobalCity] = app.useGlobalState('city');
  const [token] = app.useGlobalState('token');
  const [wallet] = app.useGlobalState('wallet', token ?? undefined);
  const params = useMemo(() => ({ sport: mounted ? sport : 'all', city: mounted ? globalCity : 'Bengaluru', token: mounted ? token : null }), [mounted, sport, globalCity, token]);
  const [list, setList, status] = app.useGlobalState('tournaments', params);
  const [joining, setJoining] = useState<Tournament | null>(null);
  const [busy, setBusy] = useState(false);

  const register = async (t: Tournament) => {
    if (!token) return;
    setBusy(true);
    try {
      // "Registered" and one spot less show now; if the wallet can't pay, they go back
      await setList((prev) => (prev ?? []).map((x) => (x.id === t.id ? { ...x, registered: true, spotsLeft: x.spotsLeft - 1 } : x)), () => api.registerTournament(token, t.id));
      app.emit('toast', { kind: 'ok', text: `Registered for ${t.name}` });
      app.invalidate('wallet');
      setJoining(null);
    } catch (e) {
      app.emit('toast', { kind: 'err', text: `${e instanceof Error ? e.message : 'Could not register'} — not registered` });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-extrabold">Tournaments</h1>
      <Filters city={globalCity} onCity={setGlobalCity} />
      {status.state === 'loading' || status.state === 'waiting' ? <Skeleton count={3} className="h-32" /> : status.state === 'error' ? (
        <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load tournaments.</ErrorNotice>
      ) : !list?.length ? (
        <EmptyState>No tournaments for this sport in this city.</EmptyState>
      ) : (
        <ul className="grid gap-4 md:grid-cols-2">
          {list.map((t) => (
            <li key={t.id} className="space-y-2 rounded-2xl border bg-white p-5" data-testid={`tournament-${t.id}`}>
              <h2 className="font-bold">{t.name}</h2>
              <p className="text-sm text-ink/60">{t.format} · {formatGameTime(t.startsAt)}</p>
              <p className="text-sm">Entry <b><Price inr={t.fee} city={t.city} /></b> · Prize pool <b><Price inr={t.prize} city={t.city} /></b></p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-ink/60" data-testid={`spots-${t.id}`}>{t.spotsLeft} of {t.capacity} spots left</span>
                {t.registered ? <span className="rounded-full bg-green-100 px-3 py-1 text-sm font-semibold text-green-700">Registered ✓</span> : (
                  <button disabled={t.spotsLeft <= 0} onClick={() => (token ? setJoining(t) : app.setState('loginOpen', true))} className="rounded-full bg-brand px-4 py-1.5 text-sm font-semibold text-white">{t.spotsLeft <= 0 ? 'Full' : 'Register'}</button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
      {joining && (
        <Modal title="Register" onClose={() => setJoining(null)}>
          <p className="text-sm">{joining.name}</p>
          <p className="text-sm text-ink/60">The entry fee of {money(joining.fee)} is paid from your wallet ({money(wallet?.balance ?? 0)}).</p>
          <button disabled={busy} onClick={() => register(joining)} className="w-full rounded-full bg-brand py-2.5 font-semibold text-white">{busy ? 'Paying…' : `Pay ${money(joining.fee)} and register`}</button>
        </Modal>
      )}
    </div>
  );
}
