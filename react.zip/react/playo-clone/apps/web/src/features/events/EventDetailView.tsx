'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Modal } from '@/components/ui/Modal';
import { PaymentPicker, usePaymentChoice } from '@/components/ui/PaymentPicker';
import { Price } from '@/components/ui/Price';
import { ShareMenu } from '@/components/ui/ShareMenu';
import { Skeleton } from '@/components/ui/Skeleton';
import { api, type SportEvent } from '@/lib/api';
import { formatGameTime } from '@/lib/format';
import { useMounted } from '@/lib/hooks';
import { EVENT_EMOJI, EVENT_LABEL } from './EventsView';

const errorText = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong');

/** Marathons pick a distance, treks and paid meet-ups just pay; everyone sees what they'll pay before confirming */
function RegisterModal({ event, answer, onClose }: { event: SportEvent; answer: 'going' | 'maybe'; onClose: () => void }) {
  const [token] = app.useGlobalState('token');
  const [category, setCategory] = useState(event.categories?.[0]?.id ?? '');
  const [busy, setBusy] = useState(false);
  const fee = event.categories?.length ? (event.categories.find((c) => c.id === category)?.feeInr ?? 0) : event.feeInr;
  const pays = answer === 'going' && fee > 0;
  const choice = usePaymentChoice(pays ? fee : 0);

  const go = async () => {
    if (!token) return;
    setBusy(true);
    try {
      await api.registerEvent(token, event.id, { category: category || undefined, answer, method: pays ? choice.method : undefined });
      app.emit('toast', { kind: 'ok', text: answer === 'maybe' ? 'Saved as maybe' : `You're going to ${event.title}` });
      app.invalidate('event');
      app.invalidate('events');
      app.invalidate('wallet');
      onClose();
    } catch (e) {
      app.emit('toast', { kind: 'err', text: errorText(e) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={event.type === 'meetup' ? 'RSVP' : 'Register'} onClose={onClose}>
      <p className="text-sm text-ink/60">{event.title} · {formatGameTime(event.startsAt)}</p>
      {event.categories && event.categories.length > 0 && (
        <fieldset className="space-y-1 text-sm">
          <legend className="mb-1 font-semibold">Distance</legend>
          {event.categories.map((c) => (
            <label key={c.id} className="flex items-center gap-2 rounded-lg border p-2">
              <input type="radio" name="category" data-testid={`category-${c.id}`} checked={category === c.id} onChange={() => setCategory(c.id)} />
              {c.label}<span className="ml-auto font-semibold"><Price inr={c.feeInr} city={event.city} /></span>
            </label>
          ))}
        </fieldset>
      )}
      {pays && <PaymentPicker choice={choice} name="event-pay" />}
      <button onClick={go} disabled={busy || (pays && choice.blocked) || (!!event.categories?.length && !category)} data-tip={busy ? 'Working… one moment' : !!event.categories?.length && !category ? 'Pick a distance first' : pays && choice.blocked ? 'Not enough wallet balance: top up, or pay with UPI or card' : undefined} data-testid="event-confirm" className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark disabled:opacity-50">
        {busy ? 'Saving…' : pays ? <>Pay <Price inr={fee} city={event.city} brackets={false} /> and confirm</> : answer === 'maybe' ? 'Save as maybe' : 'Confirm'}
      </button>
    </Modal>
  );
}

export function EventDetailView({ id }: { id: number }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const params = useMemo(() => ({ id, token: mounted ? token : null }), [id, mounted, token]);
  const [event, , status] = app.useGlobalState('event', params);
  const [dialog, setDialog] = useState<'going' | 'maybe' | null>(null);
  const [busy, setBusy] = useState(false);
  const needLogin = (open: () => void) => (token ? open() : app.setState('loginOpen', true));

  if (status.state === 'loading' || status.state === 'waiting') return <Skeleton count={3} className="h-32" />;
  if (status.state === 'error' || !event) return <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load this event.</ErrorNotice>;

  const cancel = async () => {
    if (!token || !event.mine) return;
    if (event.mine.paid > 0 && !confirm(`Cancel your spot? You get ${event.mine.refundPercent}% back.`)) return;
    setBusy(true);
    try {
      await api.cancelEvent(token, event.id);
      app.emit('toast', { kind: 'ok', text: event.mine.paid > 0 ? 'Cancelled, refund sent to your wallet' : 'You are no longer going' });
      app.invalidate('event');
      app.invalidate('events');
      app.invalidate('wallet');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: errorText(e) });
    } finally {
      setBusy(false);
    }
  };

  const mine = event.mine;
  const category = event.categories?.find((c) => c.id === mine?.category);
  const full = event.spotsLeft <= 0;

  return (
    <div className="space-y-6" data-testid="event-detail">
      <Link href="/events" className="inline-block py-1.5 text-sm text-ink/60 hover:text-brand">← All events</Link>
      <header className="space-y-2 rounded-2xl border bg-white p-6">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <p className="text-sm font-semibold text-brand">{EVENT_EMOJI[event.type]} {EVENT_LABEL[event.type]}{event.difficulty && ` · ${event.difficulty}`}</p>
            <h1 className="text-2xl font-extrabold" data-testid="event-title">{event.title}</h1>
            <p className="text-sm text-ink/60">{formatGameTime(event.startsAt)} · {event.place}, {event.city} · hosted by {event.hostName}</p>
          </div>
          <ShareMenu path={`/events/${event.id}`} title={event.title} text={`Join me at ${event.title}`} />
        </div>
        <p className="text-ink/80">{event.description}</p>
        <p className="text-sm text-ink/60" data-testid="event-counts">{event.going} going · {event.spotsLeft} of {event.capacity} spots left</p>
        {event.categories && event.categories.length > 0 && (
          <ul className="flex flex-wrap gap-2 text-sm">{event.categories.map((c) => <li key={c.id} className="rounded-full bg-black/5 px-3 py-1">{c.label} · <Price inr={c.feeInr} city={event.city} /></li>)}</ul>
        )}
        {event.type !== 'marathon' && <p className="text-sm font-semibold">{event.feeInr > 0 ? <>Fee <Price inr={event.feeInr} city={event.city} /></> : 'Free'}</p>}
        {event.itinerary && event.itinerary.length > 0 && (
          <div>
            <h2 className="pt-2 font-semibold">Itinerary</h2>
            <ol className="list-decimal space-y-0.5 pl-5 text-sm text-ink/70" data-testid="event-itinerary">{event.itinerary.map((s) => <li key={s}>{s}</li>)}</ol>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2 pt-3">
          {event.past ? <span className="rounded-full bg-black/5 px-4 py-1.5 text-sm">This event is over</span>
            : event.isHost ? <span className="rounded-full bg-black/5 px-4 py-1.5 text-sm" data-testid="event-host-note">You&apos;re hosting this</span>
            : mine ? (
              <>
                <span className="rounded-full bg-green-100 px-4 py-1.5 text-sm font-semibold text-green-700" data-testid="event-status">
                  {mine.status === 'maybe' ? 'Maybe ✓' : 'Going ✓'}{category && ` · ${category.label}`}{mine.bib != null && <> · bib <b data-testid="event-bib">{mine.bib}</b></>}
                </span>
                {mine.status === 'maybe' && !full && <button onClick={() => needLogin(() => setDialog('going'))} data-testid="event-going" className="rounded-full bg-brand px-4 py-1.5 text-sm font-semibold text-white">I&apos;m going</button>}
                <button onClick={cancel} disabled={busy} data-testid="event-cancel" className="rounded-full border px-4 py-1.5 text-sm font-semibold text-red-600 hover:bg-red-50">{mine.paid > 0 ? `Cancel (${mine.refundPercent}% refund)` : 'Not going'}</button>
              </>
            ) : (
              <>
                <button disabled={full} onClick={() => needLogin(() => setDialog('going'))} data-testid={event.type === 'meetup' ? 'event-going' : 'event-register'} className="rounded-full bg-brand px-5 py-2 font-semibold text-white hover:bg-brand-dark disabled:opacity-50">{full ? 'Full' : event.type === 'meetup' ? "I'm going" : 'Register'}</button>
                {event.type === 'meetup' && !full && <button onClick={() => needLogin(() => setDialog('maybe'))} data-testid="event-maybe" className="rounded-full border px-5 py-2 font-semibold hover:bg-black/5">Maybe</button>}
              </>
            )}
        </div>
      </header>

      <section className="space-y-2">
        <h2 className="text-lg font-bold">Who&apos;s going</h2>
        {!event.participants?.length ? <p className="text-sm text-ink/50">Nobody yet. Be the first!</p> : (
          <ul className="flex flex-wrap gap-3" data-testid="participants">
            {event.participants.map((p) => (
              <li key={p.id}><Link href={`/p/${p.username}`} className="flex items-center gap-2 rounded-full border bg-white py-1 pl-1 pr-3 text-sm hover:bg-black/5">
                <Avatar player={{ ...p, online: false }} size={28} dot={false} />{p.name}{p.status === 'maybe' && <span className="text-ink/40"> (maybe)</span>}{p.bib != null && <span className="text-ink/40"> #{p.bib}</span>}
              </Link></li>
            ))}
          </ul>
        )}
      </section>
      {dialog && <RegisterModal event={event} answer={dialog} onClose={() => setDialog(null)} />}
    </div>
  );
}
