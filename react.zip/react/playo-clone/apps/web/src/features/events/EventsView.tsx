'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { app } from '@/store';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Price } from '@/components/ui/Price';
import { Skeleton } from '@/components/ui/Skeleton';
import { Tabs } from '@/components/ui/Tabs';
import { CITIES } from '@/config/constants';
import { formatGameTime } from '@/lib/format';
import { useDebounced, useMounted } from '@/lib/hooks';
import { HostMeetupModal } from './HostMeetupModal';

export const EVENT_EMOJI: Record<string, string> = { marathon: '🏃', trek: '🥾', meetup: '🤝' };
export const EVENT_LABEL: Record<string, string> = { marathon: 'Marathon', trek: 'Trek', meetup: 'Meet-up / workshop' };

type Filter = 'all' | 'marathon' | 'trek' | 'meetup';

export function EventsView() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [city, setCity] = app.useGlobalState('city');
  const [type, setType] = useState<Filter>('all');
  const [q, setQ] = useState('');
  const text = useDebounced(q, 300);
  const [hosting, setHosting] = useState(false);
  const params = useMemo(() => ({ type, city: mounted ? city : 'Bengaluru', q: text.trim(), token: mounted ? token : null }), [type, mounted, city, text, token]);
  const [events, , status] = app.useGlobalState('events', params);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-2xl font-extrabold">Events</h1>
        <button data-testid="host-meetup" onClick={() => (token ? setHosting(true) : app.setState('loginOpen', true))} className="rounded-full bg-brand px-5 py-2 font-semibold text-white hover:bg-brand-dark">+ Host a meet-up</button>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Tabs<Filter> value={type} onChange={setType} tabs={[{ id: 'all', label: 'All' }, { id: 'marathon', label: '🏃 Marathons' }, { id: 'trek', label: '🥾 Treks' }, { id: 'meetup', label: '🤝 Meet-ups & workshops' }]} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search events" aria-label="Search events" data-testid="event-search" className="ml-auto rounded-lg border px-3 py-1.5 text-sm" />
        <select aria-label="City filter" value={mounted ? city : ''} onChange={(e) => setCity(e.target.value)} className="rounded-lg border bg-white px-2 py-1.5 text-sm">
          {CITIES.map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>

      {status.state === 'loading' || status.state === 'waiting' ? <Skeleton count={3} className="h-32" /> : status.state === 'error' ? (
        <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load events.</ErrorNotice>
      ) : !events?.length ? (
        <EmptyState>No events here yet. Host a meet-up!</EmptyState>
      ) : (
        <ul className="grid gap-4 md:grid-cols-2" data-testid="event-list">
          {events.map((e) => (
            <li key={e.id} className="space-y-2 rounded-2xl border bg-white p-5" data-testid={`event-${e.id}`}>
              <div className="flex items-start justify-between gap-2">
                <h2 className="font-bold"><Link href={`/events/${e.id}`} className="inline-block py-1 hover:text-brand" data-testid={`event-link-${e.id}`}>{EVENT_EMOJI[e.type]} {e.title}</Link></h2>
                {e.mine && <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-700">{e.mine.status === 'maybe' ? 'Maybe' : 'Going'} ✓</span>}
              </div>
              <p className="text-sm text-ink/60">{EVENT_LABEL[e.type]} · {formatGameTime(e.startsAt)} · {e.place}, {e.city}</p>
              <p className="text-sm">{e.categories?.length ? <>From <b><Price inr={Math.min(...e.categories.map((c) => c.feeInr))} city={e.city} /></b></> : e.feeInr > 0 ? <b><Price inr={e.feeInr} city={e.city} /></b> : <b>Free</b>}
                <span className="text-ink/60"> · {e.going} going · {e.spotsLeft} spots left</span></p>
              <Link href={`/events/${e.id}`} className="inline-block rounded-full border px-4 py-1.5 text-sm font-semibold hover:bg-black/5">View</Link>
            </li>
          ))}
        </ul>
      )}
      {hosting && <HostMeetupModal onClose={() => setHosting(false)} />}
    </div>
  );
}
