'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { app } from '@/store';
import { Modal } from '@/components/ui/Modal';
import { CITIES } from '@/config/constants';
import { api } from '@/lib/api';

const inOneWeek = () => {
  const d = new Date(Date.now() + 7 * 864e5);
  d.setHours(18, 0, 0, 0);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

/** Host a meet-up or workshop: a title, when and where, a fee (0 = free) and a limit on guests */
export function HostMeetupModal({ onClose }: { onClose: () => void }) {
  const router = useRouter();
  const [token] = app.useGlobalState('token');
  const [city] = app.useGlobalState('city');
  const [sportsData] = app.useGlobalState('sports');
  const sports = sportsData ?? []; // the query is undefined until it loads
  const [f, setF] = useState({ title: '', city, startsAt: inOneWeek(), place: '', description: '', feeInr: 0, capacity: 20, sport: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((x) => ({ ...x, [k]: v }));

  const submit = async () => {
    if (!token) return;
    setBusy(true);
    setError('');
    try {
      const created = await api.createMeetup(token, { ...f, startsAt: new Date(f.startsAt).toISOString(), sport: f.sport || undefined });
      app.invalidate('events');
      app.emit('toast', { kind: 'ok', text: 'Meet-up created' });
      onClose();
      router.push(`/events/${created.id}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not create');
    } finally {
      setBusy(false);
    }
  };

  const field = 'w-full rounded-lg border px-3 py-2';
  return (
    <Modal title="Host a meet-up or workshop" onClose={onClose}>
      <input value={f.title} onChange={(e) => set('title', e.target.value)} placeholder="Title, e.g. Sunday pickup games" aria-label="Title" data-testid="meetup-title" className={field} />
      <div className="flex gap-2">
        <select aria-label="City" value={f.city} onChange={(e) => set('city', e.target.value)} className={field}>{CITIES.map((c) => <option key={c}>{c}</option>)}</select>
        <select aria-label="Sport" value={f.sport} onChange={(e) => set('sport', e.target.value)} className={field}>
          <option value="">Any sport</option>
          {sports.map((s) => <option key={s.id} value={s.id}>{s.emoji} {s.name}</option>)}
        </select>
      </div>
      <input type="datetime-local" value={f.startsAt} onChange={(e) => set('startsAt', e.target.value)} aria-label="Starts at" className={field} />
      <input value={f.place} onChange={(e) => set('place', e.target.value)} placeholder="Place" aria-label="Place" data-testid="meetup-place" className={field} />
      <textarea value={f.description} onChange={(e) => set('description', e.target.value)} rows={3} placeholder="What's the plan?" aria-label="Description" className={field} />
      <div className="flex gap-2">
        <label className="flex-1 text-sm">Fee (₹, 0 = free)<input type="number" min={0} value={f.feeInr} onChange={(e) => set('feeInr', Number(e.target.value))} data-testid="meetup-fee" className={field} /></label>
        <label className="flex-1 text-sm">Guests<input type="number" min={2} value={f.capacity} onChange={(e) => set('capacity', Number(e.target.value))} data-testid="meetup-capacity" className={field} /></label>
      </div>
      {error && <p className="text-sm text-red-600" data-testid="meetup-error">{error}</p>}
      <button onClick={submit} disabled={busy || !f.title.trim() || !f.place.trim()} data-tip={!f.title.trim() ? 'Give the meet-up a title first' : !f.place.trim() ? 'Say where it is first' : undefined} data-testid="meetup-create" className="w-full rounded-full bg-brand py-2.5 font-semibold text-white disabled:opacity-50">{busy ? 'Creating…' : 'Create meet-up'}</button>
    </Modal>
  );
}
