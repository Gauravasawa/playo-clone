'use client';

import { useState } from 'react';
import { app } from '@/store';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { Tabs } from '@/components/ui/Tabs';
import { PlayerCard } from './PlayerCard';
import { PlayerSearch } from './PlayerSearch';
import { SuggestedPlayers } from './SuggestedPlayers';
import { RelationshipActions } from './RelationshipActions';
import { useSocialActions } from './useSocialActions';

type Tab = 'friends' | 'requests' | 'suggested' | 'played' | 'find';

export function FriendsView() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [tab, setTab] = useState<Tab>('friends');
  const [friends, , friendsStatus] = app.useGlobalState('friends', token ?? undefined);
  const [followRequests] = app.useGlobalState('followRequests', token ?? undefined);

  if (!mounted) return null;
  if (!token)
    return (
      <>
      <h1 className="mb-4 text-2xl font-extrabold">Friends</h1>
      <EmptyState>
        <p className="mb-3">Log in to see your friends and the players you've played with.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
      </>
    );

  const pending = (friends?.incoming.length ?? 0) + (followRequests?.length ?? 0);

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-extrabold">Friends</h1>
      <Tabs<Tab>
        value={tab}
        onChange={setTab}
        tabs={[
          { id: 'friends', label: `Friends${friends ? ` (${friends.friends.length})` : ''}` },
          { id: 'requests', label: 'Requests', badge: pending },
          { id: 'suggested', label: 'Players for you' },
          { id: 'played', label: 'Played with' },
          { id: 'find', label: 'Find players' },
        ]}
      />
      {friendsStatus.state === 'error' && <ErrorNotice onRetry={friendsStatus.refetch}>Couldn&apos;t load your friends.</ErrorNotice>}
      {tab === 'friends' && <FriendList />}
      {tab === 'requests' && <Requests />}
      {tab === 'suggested' && <SuggestedPlayers />}
      {tab === 'played' && <PlayedWith />}
      {tab === 'find' && <PlayerSearch />}
    </div>
  );
}

function FriendList() {
  const [token] = app.useGlobalState('token');
  const [friends, , status] = app.useGlobalState('friends', token ?? undefined);
  const social = useSocialActions();
  if (status.state === 'loading' || status.state === 'waiting') return <Skeleton count={3} />;
  if (!friends?.friends.length) return <EmptyState>No friends yet. Find players you&apos;ve played with in the “Played with” tab.</EmptyState>;
  return (
    <ul className="space-y-3">
      {friends.friends.map((p) => (
        <PlayerCard key={p.id} player={p}>
          <div className="flex gap-2">
            <button onClick={() => social.openChat(p)} className="rounded-full bg-brand px-3 py-1.5 text-sm font-semibold text-white">Message</button>
            <button onClick={() => social.unfriend(p)} className="rounded-full border px-3 py-1.5 text-sm font-semibold hover:bg-black/5">Unfriend</button>
          </div>
        </PlayerCard>
      ))}
    </ul>
  );
}

function Requests() {
  const [token] = app.useGlobalState('token');
  const [friends] = app.useGlobalState('friends', token ?? undefined);
  const [followRequests] = app.useGlobalState('followRequests', token ?? undefined);
  const social = useSocialActions();
  const none = !friends?.incoming.length && !friends?.outgoing.length && !followRequests?.length;
  if (none) return <EmptyState>No pending requests.</EmptyState>;
  const btn = 'rounded-full px-3 py-1.5 text-sm font-semibold';
  return (
    <div className="space-y-5">
      {!!friends?.incoming.length && (
        <section className="space-y-2"><h2 className="font-bold">Friend requests</h2>
          <ul className="space-y-3">
            {friends.incoming.map((r) => (
              <PlayerCard key={r.id} player={r.player}>
                <div className="flex gap-2">
                  <button className={`${btn} bg-brand text-white`} onClick={() => social.acceptFriend(r.id, r.player)}>Accept</button>
                  <button className={`${btn} border`} onClick={() => social.declineFriend(r.id)}>Decline</button>
                </div>
              </PlayerCard>
            ))}
          </ul>
        </section>
      )}
      {!!followRequests?.length && (
        <section className="space-y-2"><h2 className="font-bold">Follow requests (your profile is private)</h2>
          <ul className="space-y-3">
            {followRequests.map((r) => (
              <PlayerCard key={r.player.id} player={r.player}>
                <div className="flex gap-2">
                  <button className={`${btn} bg-brand text-white`} onClick={() => social.acceptFollow(r.player)}>Accept</button>
                  <button className={`${btn} border`} onClick={() => social.declineFollow(r.player)}>Decline</button>
                </div>
              </PlayerCard>
            ))}
          </ul>
        </section>
      )}
      {!!friends?.outgoing.length && (
        <section className="space-y-2"><h2 className="font-bold">Sent by you</h2>
          <ul className="space-y-3">
            {friends.outgoing.map((r) => (
              <PlayerCard key={r.id} player={r.player} note="Waiting for them to accept">
                <button className={`${btn} border`} onClick={() => social.cancelFriendRequest(r.id)}>Cancel</button>
              </PlayerCard>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

function PlayedWith() {
  const [token] = app.useGlobalState('token');
  const [list, , status] = app.useGlobalState('playedWith', token ?? undefined);
  if (status.state === 'loading' || status.state === 'waiting') return <Skeleton count={3} />;
  if (!list?.length) return <EmptyState>Nobody yet. Join a game and, once the host ends it, its players show up here.</EmptyState>;
  return (
    <ul className="space-y-3">
      {list.map((r) => (
        <PlayerCard key={r.player.id} player={r.player} note={`${r.games} game${r.games > 1 ? 's' : ''} together · last ${new Date(r.lastAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`}>
          <RelationshipActions player={r.player} relationship={r.relationship} />
        </PlayerCard>
      ))}
    </ul>
  );
}
