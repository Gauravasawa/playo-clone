import Link from 'next/link';
import { Avatar } from '@/components/ui/Avatar';
import type { Player } from '@/lib/api';

/** Avatar, name and @username (a link to their page), with room for buttons */
export function PlayerCard({ player, note, children }: { player: Player; note?: React.ReactNode; children?: React.ReactNode }) {
  return (
    <li className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-white p-4" data-testid={`player-${player.username}`}>
      <div className="flex items-center gap-3">
        <Avatar player={player} />
        <div>
          <Link href={`/p/${player.username}`} className="font-bold hover:text-brand">{player.name}</Link>
          {player.plus && <span className="ml-1.5 rounded-full bg-amber-100 px-1.5 text-xs font-semibold text-amber-700" title="Playo Plus member" data-testid={`plus-${player.username}`}>✨ Plus</span>}
          {player.isPrivate && <span className="ml-1.5 text-xs text-ink/40" title="Private profile">🔒</span>}
          <p className="text-sm text-ink/60">@{player.username} · {player.city}</p>
          {note && <p className="text-xs text-ink/50">{note}</p>}
        </div>
      </div>
      {children}
    </li>
  );
}
