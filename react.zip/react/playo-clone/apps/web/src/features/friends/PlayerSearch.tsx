'use client';

import { useEffect, useMemo } from 'react';
import { useState } from 'react';
import { app } from '@/store';
import { useDebounced } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { PlayerCard } from './PlayerCard';
import { RelationshipActions } from './RelationshipActions';

/** Find any player by name or @username. Requests still need a shared game: the buttons say so. */
export function PlayerSearch() {
  const [token] = app.useGlobalState('token');
  const [recent, setRecent] = app.useGlobalState('recentSearches');
  const [text, setText] = useState('');
  const q = useDebounced(text.trim(), 300);

  // The text changed: the request for the old text is cancelled, not left running
  useEffect(() => {
    app.abort('searchPlayers');
  }, [text]);

  const params = useMemo(() => (token && q.length >= 2 ? { token, q } : undefined), [token, q]);
  const [results, , status] = app.useGlobalState('searchPlayers', params);

  // Remember a search once it found something
  useEffect(() => {
    if (params && status.state === 'ready' && results && results.length > 0) setRecent.add(params.q);
  }, [params, status.state, results]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="space-y-3">
      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Search players by name or @username"
        aria-label="Search players"
        className="w-full rounded-full border bg-white px-5 py-3 outline-none focus:border-brand"
      />
      {recent.length > 0 && text === '' && (
        <div className="flex flex-wrap items-center gap-2 text-sm" data-testid="recent-searches">
          <span className="text-ink/50">Recent:</span>
          {recent.map((r) => (
            <button key={r} onClick={() => setText(r)} className="rounded-full border bg-white px-3 py-1 hover:bg-black/5">{r}</button>
          ))}
          <button onClick={() => setRecent.clear()} className="text-ink/40 underline">clear</button>
        </div>
      )}
      {text.trim().length > 0 && text.trim().length < 2 && <p className="text-sm text-ink/50">Type at least 2 letters.</p>}
      {status.state === 'error' && <ErrorNotice onRetry={status.refetch}>Search failed.</ErrorNotice>}
      {params && status.state === 'loading' && <p className="text-sm text-ink/50">Searching…</p>}
      {params && status.state === 'ready' && results && results.length === 0 && <EmptyState>No players match “{q}”.</EmptyState>}
      {results && results.length > 0 && params && (
        <ul className="space-y-3">
          {results.map((p) => (
            <PlayerCard key={p.id} player={p} note={p.relationship.playedWith ? 'You have played together' : 'Not played together yet'}>
              <RelationshipActions player={p} relationship={p.relationship} />
            </PlayerCard>
          ))}
        </ul>
      )}
    </div>
  );
}
