'use client';

import type { Player, Relationship } from '@/lib/api';
import { useSocialActions } from './useSocialActions';

const NOT_PLAYED = 'You can send requests to players you have played a game with. Join one of their games first.';

/**
 * The friend and follow buttons for one player. `relationship` says what already exists; the rules
 * (who may be asked, and private profiles needing approval) are enforced by the server, and mirrored here.
 */
export function RelationshipActions({ player, relationship: rel }: { player: Player; relationship: Relationship | null }) {
  const social = useSocialActions();
  if (!rel) return null; // your own profile
  const btn = 'rounded-full px-3 py-1.5 text-sm font-semibold disabled:opacity-50';
  const solid = `${btn} bg-brand text-white hover:bg-brand-dark`;
  const outline = `${btn} border hover:bg-black/5`;
  const blocked = !rel.playedWith && rel.friend === 'none';

  return (
    <div className="flex flex-wrap items-center gap-2" data-testid={`actions-${player.username}`}>
      {rel.friend === 'none' && (
        <button className={solid} disabled={blocked} title={blocked ? NOT_PLAYED : undefined} onClick={() => social.requestFriend(player)}>
          Add friend
        </button>
      )}
      {rel.friend === 'pending_out' && (
        <button className={outline} onClick={() => rel.friendshipId && social.cancelFriendRequest(rel.friendshipId)}>Requested · Cancel</button>
      )}
      {rel.friend === 'pending_in' && rel.friendshipId && (
        <>
          <button className={solid} onClick={() => social.acceptFriend(rel.friendshipId!, player)}>Accept friend</button>
          <button className={outline} onClick={() => social.declineFriend(rel.friendshipId!)}>Decline</button>
        </>
      )}
      {rel.friend === 'friends' && (
        <>
          <button className={solid} onClick={() => social.openChat(player)}>Message</button>
          <button className={outline} onClick={() => social.unfriend(player)}>Friends ✓ · Unfriend</button>
        </>
      )}

      {rel.follow === 'none' && (
        <button className={outline} disabled={!rel.playedWith} title={!rel.playedWith ? NOT_PLAYED : undefined} onClick={() => social.follow(player)}>
          {player.isPrivate ? 'Request to follow' : 'Follow'}
        </button>
      )}
      {rel.follow === 'pending' && <button className={outline} onClick={() => social.unfollow(player)}>Follow requested · Cancel</button>}
      {rel.follow === 'following' && <button className={outline} onClick={() => social.unfollow(player)}>Following · Unfollow</button>}
      {rel.followsMe && <span className="text-xs text-ink/50">follows you</span>}
    </div>
  );
}
