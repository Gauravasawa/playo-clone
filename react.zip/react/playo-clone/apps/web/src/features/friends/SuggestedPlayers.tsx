'use client';

import Link from 'next/link';
import { app } from '@/store';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { PlayerCard } from './PlayerCard';
import { RelationshipActions } from './RelationshipActions';

/** "Players for you": people who share your sports, level, city and play times, best match first */
export function SuggestedPlayers() {
  const [token] = app.useGlobalState('token');
  const [list, , status] = app.useGlobalState('suggested', token ?? undefined);
  if (status.state === 'loading' || status.state === 'waiting') return <Skeleton count={3} />;
  if (status.state === 'error') return <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load suggestions.</ErrorNotice>;
  if (!list?.length) return <EmptyState>No suggestions yet. Add sports and play times to your profile to get matches.</EmptyState>;
  return (
    <ul className="space-y-3" data-testid="suggested-list">
      {list.map((s) => (
        <PlayerCard key={s.player.id} player={s.player} note={s.sharedSports.map((x) => `${x.sport} (${x.mine} / ${x.theirs})`).join(' · ')}>
          <div className="w-full space-y-2">
            <p className="flex flex-wrap items-center gap-2 text-sm">
              <span className="rounded-full bg-brand/10 px-2 py-0.5 font-bold text-brand-dark" data-testid={`match-${s.player.username}`}>{s.matchPercent}% match</span>
              {s.reasons.map((r) => <span key={r} className="rounded-full bg-black/5 px-2 py-0.5 text-xs">{r}</span>)}
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <RelationshipActions player={s.player} relationship={s.relationship} />
              <Link href={`/games?with=${s.player.username}`} data-testid={`join-together-${s.player.username}`} className="rounded-full border border-brand px-3 py-1.5 text-sm font-semibold text-brand hover:bg-brand/5">
                Join a game together
              </Link>
            </div>
            {s.relationship.friend === 'none' && !s.relationship.playedWith && (
              <p className="text-xs text-ink/50">You need to play a game together before sending requests.</p>
            )}
          </div>
        </PlayerCard>
      ))}
    </ul>
  );
}
