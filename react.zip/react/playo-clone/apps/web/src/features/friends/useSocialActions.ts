'use client';

import { useRouter } from 'next/navigation';
import { app } from '@/store';
import { sendFriendRequestAction } from '@/app/actions/social';
import { api, type FriendsData, type Player } from '@/lib/api';

const EMPTY: FriendsData = { friends: [], incoming: [], outgoing: [] };
const reason = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong');

/**
 * Every friend and follow button goes through here. Friend changes show at once in the `friends`
 * entry and are undone if the server refuses; everything that shows a relationship (profiles,
 * search results, "played with") is refreshed afterwards.
 */
export function useSocialActions() {
  const router = useRouter();
  const [token] = app.useGlobalState('token');
  const [, setFriends] = app.useGlobalState('friends', token ?? undefined);
  const [, setFollowRequests] = app.useGlobalState('followRequests', token ?? undefined);

  const refreshPeople = () => {
    app.invalidate('player');
    app.invalidate('searchPlayers');
    app.invalidate('playedWith');
  };
  const ok = (text: string) => app.emit('toast', { kind: 'ok', text });
  const fail = (e: unknown) => app.emit('toast', { kind: 'err', text: `${reason(e)}. Change undone.` });
  /** Runs `task`; false if nobody is logged in (the login box opens) or it failed */
  const guarded = async (task: (token: string) => Promise<unknown>, success: string) => {
    if (!token) {
      app.setState('loginOpen', true);
      return false;
    }
    try {
      await task(token);
      ok(success);
      return true;
    } catch (e) {
      fail(e);
      return false;
    } finally {
      refreshPeople();
    }
  };
  const friendsList = (prev: FriendsData | undefined) => prev ?? EMPTY;

  return {
    requestFriend: (player: Player) =>
      guarded(
        (t) =>
          setFriends(
            (prev) => ({ ...friendsList(prev), outgoing: [{ id: -Date.now(), player, createdAt: Date.now() }, ...friendsList(prev).outgoing] }),
            // the request is sent by a Server Action, which hands back the fresh list
            async () => {
              const result = await sendFriendRequestAction(t, player.id, app.getState('simulateFailure'));
              app.setQueryData('friends', result.friends, t);
            }
          ),
        `Friend request sent to ${player.name}`
      ),

    acceptFriend: (requestId: number, player: Player) =>
      guarded(
        (t) =>
          setFriends(
            (prev) => ({ ...friendsList(prev), friends: [player, ...friendsList(prev).friends], incoming: friendsList(prev).incoming.filter((r) => r.id !== requestId) }),
            () => api.acceptFriend(t, requestId)
          ),
        `You and ${player.name} are friends`
      ),

    declineFriend: (requestId: number) =>
      guarded((t) => setFriends((prev) => ({ ...friendsList(prev), incoming: friendsList(prev).incoming.filter((r) => r.id !== requestId) }), () => api.declineFriend(t, requestId)), 'Request declined'),

    cancelFriendRequest: (requestId: number) =>
      guarded((t) => setFriends((prev) => ({ ...friendsList(prev), outgoing: friendsList(prev).outgoing.filter((r) => r.id !== requestId) }), () => api.cancelFriendRequest(t, requestId)), 'Request cancelled'),

    unfriend: (player: Player) =>
      guarded((t) => setFriends((prev) => ({ ...friendsList(prev), friends: friendsList(prev).friends.filter((f) => f.id !== player.id) }), () => api.unfriend(t, player.id)), `${player.name} removed from friends`),

    follow: (player: Player) =>
      guarded(async (t) => {
        const { status } = await api.follow(t, player.id);
        if (status === 'pending') ok(`Follow request sent to ${player.name}`);
      }, `Following ${player.name}`),

    unfollow: (player: Player) => guarded((t) => api.unfollow(t, player.id), `Unfollowed ${player.name}`),

    acceptFollow: (player: Player) =>
      guarded((t) => setFollowRequests((prev) => (prev ?? []).filter((r) => r.player.id !== player.id), () => api.acceptFollow(t, player.id)), `${player.name} now follows you`),

    declineFollow: (player: Player) =>
      guarded((t) => setFollowRequests((prev) => (prev ?? []).filter((r) => r.player.id !== player.id), () => api.declineFollow(t, player.id)), 'Request declined'),

    /** Opens (or creates) the 1:1 chat with a friend */
    async openChat(player: Player) {
      if (!token) return app.setState('loginOpen', true);
      try {
        const chat = await api.openDirect(token, player.id);
        app.invalidate('chats');
        router.push(`/chat/${chat.id}`);
      } catch (e) {
        app.emit('toast', { kind: 'err', text: reason(e) });
      }
    },
  };
}
