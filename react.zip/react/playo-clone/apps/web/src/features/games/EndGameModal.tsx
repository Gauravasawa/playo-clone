'use client';

import { useState } from 'react';
import { Modal } from '@/components/ui/Modal';
import type { Game } from '@/lib/api';

/** The host marks who turned up and who won; no-shows earn no Karma and are counted as absent */
export function EndGameModal({ game, onEnd, onClose }: { game: Game; onEnd: (winnerIds: number[], attendedIds: number[]) => Promise<boolean>; onClose: () => void }) {
  const [attended, setAttended] = useState<number[]>(game.players.map((p) => p.id));
  const [winners, setWinners] = useState<number[]>([]);
  const [busy, setBusy] = useState(false);
  const flip = (list: number[], set: (v: number[]) => void, id: number) => set(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);
  return (
    <Modal title={`End “${game.title}”`} onClose={onClose}>
      <p className="text-sm text-ink/60">Mark who came and who won. Winners count towards the leaderboard; everyone who came becomes someone you&apos;ve played with.</p>
      <table className="w-full text-sm">
        <thead><tr className="text-left text-xs text-ink/50"><th scope="col">Player</th><th scope="col">Came</th><th scope="col">Won</th></tr></thead>
        <tbody>
          {game.players.map((p) => (
            <tr key={p.id} className="border-t">
              <td className="py-1.5">{p.name}</td>
              <td><input type="checkbox" aria-label={`${p.name} came`} data-testid={`attended-${p.id}`} checked={attended.includes(p.id)} onChange={() => { flip(attended, setAttended, p.id); setWinners(winners.filter((w) => w !== p.id)); }} /></td>
              <td><input type="checkbox" aria-label={`${p.name} won`} data-testid={`won-${p.id}`} disabled={!attended.includes(p.id)} checked={winners.includes(p.id)} onChange={() => flip(winners, setWinners, p.id)} /></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button
        data-testid="end-game-confirm"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          if (await onEnd(winners, attended)) onClose();
          setBusy(false);
        }}
        className="w-full rounded-full bg-brand py-2.5 font-semibold text-white"
      >
        {busy ? 'Ending…' : 'End game'}
      </button>
      {game.priceInr > 0 && <p className="text-xs text-ink/50">The players&apos; payments are credited to your wallet when the game ends.</p>}
    </Modal>
  );
}
