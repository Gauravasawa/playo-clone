import Link from 'next/link';
import type { Game } from '@/lib/api';
import { formatGameTime } from '@/lib/format';
import { Price } from '@/components/ui/Price';
import { GameJoinButton } from './GameJoinButton';

export const levelRule = (g: Game) => (g.minLevel ? `${g.minLevel}+ only` : g.level);

/** A game in a list: the summary, the host-set rules as chips, and the right join button */
export function GameCard({ game: g, city, onEnd }: { game: Game; city: string; onEnd?: (game: Game) => void }) {
  const chip = 'rounded-full bg-black/5 px-2 py-0.5 text-xs';
  return (
    <li className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-white p-4" data-testid={`game-${g.id}`}>
      <div className="min-w-0">
        <Link href={`/games/${g.id}`} className="font-bold hover:text-brand" data-testid={`game-link-${g.id}`}>{g.title}</Link>
        <p className="text-sm text-ink/60">{g.venue?.name}, {g.venue?.area} · {formatGameTime(g.startsAt)}</p>
        <p className="text-sm text-ink/60">Hosted by {g.hostName}</p>
        <p className="mt-1 flex flex-wrap gap-1.5">
          <span className={chip} data-tip={g.minLevel ? `Only ${g.minLevel} players and above can join` : `Skill level of this game: ${g.level}`}>{levelRule(g)}</span>
          <span className={chip} data-tip={g.priceInr > 0 ? 'Price per player' : 'Free to join'} data-testid={`price-${g.id}`}>{g.priceInr > 0 ? <Price inr={g.priceInr} city={city} brackets={false} /> : 'Free'}</span>
          {g.joinMode === 'approval' && <span className={chip} data-tip="The host approves each request before you can play">🔒 Host approves</span>}
          {g.visibility === 'private' && <span className={chip}>🕵️ Invite only</span>}
          {g.status === 'ended' && <span className={chip}>Ended</span>}
          {g.me.invited && !g.me.isPlayer && <span className={`${chip} bg-amber-100`}>💌 You&apos;re invited</span>}
          {g.me.isHost && !!g.requests?.length && <span className={`${chip} bg-red-100 text-red-700`}>{g.requests.length} request(s)</span>}
        </p>
        <p className="mt-1 flex flex-wrap gap-x-2 text-xs text-ink/50">
          {g.players.map((p) => <Link key={p.id} href={`/p/${p.username}`} className="inline-block min-w-6 px-0.5 py-1 text-center hover:text-brand">{p.name.split(' ')[0]}</Link>)}
        </p>
        {g.me.isPlayer && g.chatId && <Link href={`/chat/${g.chatId}`} className="inline-block py-1 text-sm text-brand underline">💬 Game chat</Link>}
      </div>
      <div className="flex items-center gap-3">
        <span className="text-sm font-semibold" data-testid={`players-${g.id}`}>{g.players.length}/{g.capacity} players</span>
        {g.me.isHost && g.status === 'open' && onEnd && <button data-testid={`end-${g.id}`} onClick={() => onEnd(g)} className="rounded-full border px-4 py-2 text-sm font-semibold hover:bg-black/5">End game</button>}
        <GameJoinButton game={g} />
      </div>
    </li>
  );
}
