'use client';

import Link from 'next/link';
import { useState } from 'react';
import { app } from '@/store';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Price } from '@/components/ui/Price';
import { ShareMenu } from '@/components/ui/ShareMenu';
import { Skeleton } from '@/components/ui/Skeleton';
import { ApiError, type Game } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { formatGameTime } from '@/lib/format';
import { ReportButton } from '@/features/safety/ReportButton';
import { EndGameModal } from './EndGameModal';
import { GameJoinButton } from './GameJoinButton';
import { InviteModal } from './InviteModal';
import { levelRule } from './GameCard';
import { useGameActions } from './useGameActions';

const RSVP = [['going', '✅ Going'], ['maybe', '🤔 Maybe'], ['no', '❌ Can’t'] ] as const;

function GameDetail({ game: g, code }: { game: Game; code?: string }) {
  const [token] = app.useGlobalState('token');
  const [city] = app.useGlobalState('city');
  const { decide, invite, rsvp, end } = useGameActions(token);
  const [inviting, setInviting] = useState(false);
  const [ending, setEnding] = useState(false);
  const started = new Date(g.startsAt).getTime() <= Date.now();
  const sharePath = g.inviteCode ? `/g/${g.inviteCode}` : `/games/${g.id}`;

  return (
    <div className="space-y-5" data-testid="game-detail">
      <div className="flex flex-wrap items-start gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">{g.title}</h1>
          <p className="text-ink/60">{g.venue ? <Link href={`/venues/${g.venue.id}`} className="hover:text-brand">{g.venue.name}, {g.venue.area}</Link> : null} · {formatGameTime(g.startsAt)}</p>
          <p className="text-sm text-ink/60">Hosted by {g.hostName} · {g.sport}</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <ShareMenu path={sharePath} title={g.title} text={`Join my game “${g.title}”`} />
          {g.me.isPlayer || g.me.isHost ? null : <ReportButton kind="game" targetId={g.id} label="Report" />}
        </div>
      </div>

      <div className="flex flex-wrap gap-2 text-sm">
        <span className="rounded-full bg-black/5 px-3 py-1" data-testid="detail-level">{levelRule(g)}</span>
        <span className="rounded-full bg-black/5 px-3 py-1" data-testid="detail-price">{g.priceInr > 0 ? <>Price: <Price inr={g.priceInr} city={city} /></> : 'Free'}</span>
        <span className="rounded-full bg-black/5 px-3 py-1">{g.joinMode === 'approval' ? '🔒 Host approves players' : 'Open to join'}</span>
        <span className="rounded-full bg-black/5 px-3 py-1">{g.visibility === 'private' ? '🕵️ Invite only' : 'Public'}</span>
        <span className="rounded-full bg-black/5 px-3 py-1" data-testid="detail-players">{g.players.length}/{g.capacity} players</span>
        {g.status === 'ended' && <span className="rounded-full bg-black/10 px-3 py-1">Ended</span>}
      </div>

      {g.me.invited && !g.me.isPlayer && g.status === 'open' && <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-800">💌 You were invited to this game.</p>}
      {g.me.request === 'declined' && <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700" data-testid="request-declined">The host declined your request. Any payment was refunded.</p>}
      {g.me.request === 'approved' && !g.me.isPlayer && <p className="text-sm text-green-700">Your request was approved.</p>}

      <div className="flex flex-wrap items-center gap-3">
        <GameJoinButton game={g} code={code ?? (g.viaCode ? g.inviteCode ?? undefined : undefined)} />
        {g.me.isPlayer && g.chatId && <Link href={`/chat/${g.chatId}`} className="inline-block py-1 text-sm text-brand underline">💬 Game chat</Link>}
        {g.me.isHost && g.status === 'open' && (
          <>
            <button data-testid="invite-open" onClick={() => setInviting(true)} className="rounded-full border px-4 py-2 text-sm font-semibold hover:bg-black/5">Invite players</button>
            <button data-testid="end-open" onClick={() => setEnding(true)} className="rounded-full border px-4 py-2 text-sm font-semibold hover:bg-black/5">End game</button>
          </>
        )}
      </div>
      {g.me.isPlayer && !g.me.isHost && g.status === 'open' && g.priceInr > 0 && <p className="text-xs text-ink/50">Leaving at least 3 hours before the start refunds your payment.</p>}

      {g.me.isHost && !!g.requests?.length && (
        <section className="space-y-2 rounded-2xl border bg-white p-4" data-testid="requests-panel">
          <h2 className="font-bold">Join requests ({g.requests.length})</h2>
          <ul className="space-y-2">
            {g.requests.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center gap-3 text-sm" data-testid={`request-${r.player?.id}`}>
                <span className="font-semibold">{r.player?.name ?? 'Player'}</span>
                <span className="text-ink/50">{r.level}{r.paidInr > 0 && ` · paid ₹${r.paidInr} (held)`}</span>
                <span className="ml-auto flex gap-2">
                  <button data-testid={`approve-${r.player?.id}`} onClick={() => r.player && decide(g, r.player.id, true)} className="rounded-full bg-brand px-4 py-1.5 font-semibold text-white">Approve</button>
                  <button data-testid={`decline-${r.player?.id}`} onClick={() => r.player && decide(g, r.player.id, false)} className="rounded-full border px-4 py-1.5 font-semibold">Decline</button>
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="space-y-2 rounded-2xl border bg-white p-4">
        <h2 className="font-bold">Players</h2>
        <ul className="space-y-1 text-sm">
          {g.players.map((p) => (
            <li key={p.id} className="flex items-center gap-2" data-testid={`player-${p.id}`}>
              <Link href={`/p/${p.username}`} className="inline-block py-1 hover:text-brand">{p.name}</Link>
              {p.id === g.hostId && <span className="rounded-full bg-black/5 px-2 text-xs">host</span>}
              {g.status === 'ended' && p.won && <span title="Won">🏆</span>}
              {g.status === 'ended' && p.attended === false && <span className="rounded-full bg-red-100 px-2 text-xs text-red-700">absent</span>}
            </li>
          ))}
        </ul>
      </section>

      <section className="space-y-2 rounded-2xl border bg-white p-4" data-testid="rsvp">
        <h2 className="font-bold">{g.status === 'ended' ? 'Who said they were coming' : 'Are you coming?'}</h2>
        <p className="text-sm text-ink/60" data-testid="rsvp-counts">{g.rsvp.going} going · {g.rsvp.maybe} maybe · {g.rsvp.no} can&apos;t</p>
        {g.me.isPlayer && g.status === 'open' && !started && (
          <div className="flex gap-2">
            {RSVP.map(([a, label]) => (
              <button key={a} data-testid={`rsvp-${a}`} aria-pressed={g.rsvp.mine === a} onClick={() => rsvp(g, a)} className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${g.rsvp.mine === a ? 'border-brand bg-brand text-white' : 'hover:bg-black/5'}`}>{label}</button>
            ))}
          </div>
        )}
      </section>

      {inviting && <InviteModal game={g} onInvite={(ids) => invite(g, ids)} onClose={() => setInviting(false)} />}
      {ending && <EndGameModal game={g} onEnd={(w, a) => end(g, w, a)} onClose={() => setEnding(false)} />}
    </div>
  );
}

function Frame({ game, status, code }: { game: Game | undefined; status: { state: string; error?: unknown; refetch: () => void }; code?: string }) {
  const mounted = useMounted();
  if (!mounted || status.state === 'loading' || status.state === 'waiting') return <Skeleton count={3} />;
  if (status.state === 'error') {
    const notFound = status.error instanceof ApiError && (status.error.status === 404 || status.error.status === 403);
    return notFound ? <EmptyState>This game doesn&apos;t exist, or it&apos;s private and you haven&apos;t been invited.</EmptyState> : <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load the game.</ErrorNotice>;
  }
  return game ? <GameDetail game={game} code={code} /> : null;
}

export function GameDetailView({ id }: { id: number }) {
  const [token] = app.useGlobalState('token');
  const [game, , status] = app.useGlobalState('game', { id, token });
  return <Frame game={game} status={status} />;
}

/** What a shared invite link opens; it works for private games too, and logging in is only needed to join */
export function GameByCodeView({ code }: { code: string }) {
  const [token] = app.useGlobalState('token');
  const [game, , status] = app.useGlobalState('gameByCode', { code, token });
  return <Frame game={game} status={status} code={code} />;
}
