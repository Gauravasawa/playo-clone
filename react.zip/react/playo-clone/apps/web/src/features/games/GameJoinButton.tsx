'use client';

import { useState } from 'react';
import { app } from '@/store';
import { JoinModal } from './JoinModal';
import { useGameActions } from './useGameActions';
import type { Game } from '@/lib/api';

/** Join / Ask to join / Withdraw request / Leave, depending on who you are in this game */
export function GameJoinButton({ game: g, code }: { game: Game; code?: string }) {
  const [token] = app.useGlobalState('token');
  const [city] = app.useGlobalState('city');
  const { join, leave, cancelRequest } = useGameActions(token);
  const [paying, setPaying] = useState(false);
  const [busy, setBusy] = useState(false);
  const run = async (fn: () => Promise<boolean>) => { setBusy(true); await fn(); setBusy(false); };
  const base = 'rounded-full px-5 py-2 text-sm font-semibold disabled:opacity-50';
  const id = `join-${g.id}`;

  if (g.me.isHost) return <span className="text-sm font-semibold text-brand" data-testid={`host-badge-${g.id}`}>You host this</span>;
  if (g.status === 'ended') return null;
  if (g.me.isPlayer) {
    return <button data-testid={`leave-${g.id}`} disabled={busy} onClick={() => run(() => leave(g))} className={`${base} border border-brand text-brand`}>Leave</button>;
  }
  if (g.me.request === 'pending') {
    return <button data-testid={`withdraw-${g.id}`} disabled={busy} onClick={() => run(() => cancelRequest(g))} className={`${base} border`}>Request sent · Withdraw</button>;
  }
  if (g.players.length >= g.capacity) return <button disabled className={`${base} border`}>Full</button>;

  const label = g.joinMode === 'approval' ? 'Ask to join' : 'Join';
  const start = () => {
    if (!token) return app.setState('loginOpen', true);
    if (g.priceInr > 0) return setPaying(true);
    return run(() => join(g, { code }));
  };
  return (
    <>
      <button data-testid={id} disabled={busy} onClick={start} className={`${base} bg-brand text-white`}>{busy ? '…' : label}</button>
      {paying && <JoinModal game={g} city={city} onJoin={(method) => join(g, { method, code })} onClose={() => setPaying(false)} />}
    </>
  );
}
