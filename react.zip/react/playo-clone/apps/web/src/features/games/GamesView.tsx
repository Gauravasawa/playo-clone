'use client';

import { useEffect, useMemo, useState } from 'react';
import { app } from '@/store';
import { useMounted } from '@/lib/hooks';
import { DEFAULT_GAMES_PARAMS, GAME_LEVELS } from '@/config/constants';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { Tabs } from '@/components/ui/Tabs';
import { SportChips } from '@/features/venues/VenueFilters';
import type { Game } from '@/lib/api';
import { EndGameModal } from './EndGameModal';
import { GameCard } from './GameCard';
import { HostGameForm } from './HostGameForm';
import { MyGames } from './MyGames';
import { useGameActions } from './useGameActions';

type Tab = 'all' | 'mine';

export function GamesView() {
  const mounted = useMounted();
  const [city] = app.useGlobalState('city');
  const [sport] = app.useGlobalState('sport');
  const [token] = app.useGlobalState('token');
  const [me] = app.useGlobalState('me', token ?? undefined);
  // Until mounted, the params the server rendered (see VenuesView)
  const params = useMemo(() => (mounted ? { city, sport, token } : DEFAULT_GAMES_PARAMS), [mounted, city, sport, token]);
  const [games, , status] = app.useGlobalState('games', params);
  const { host, end } = useGameActions(token);
  const [tab, setTab] = useState<Tab>('all');
  const [level, setLevel] = useState('all');
  const [ending, setEnding] = useState<Game | null>(null);
  const [hosting, setHosting] = useState(false);

  // "Join a game together" from a suggested player lands here as /games?with=username
  const [withUser, setWithUser] = useState<string | null>(null);
  useEffect(() => { setWithUser(new URLSearchParams(location.search).get('with')); }, []);

  const shown = (games ?? []).filter((g) => (level === 'all' || g.level === level || g.minLevel === level) && (!withUser || g.players.some((p) => p.username === withUser)));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-extrabold">Games in {mounted ? city : '…'}</h1>
        <button data-testid="host-toggle" onClick={() => (token ? setHosting((h) => !h) : app.setState('loginOpen', true))} className="ml-auto rounded-full bg-brand px-5 py-2 font-semibold text-white hover:bg-brand-dark">
          {hosting ? 'Close' : '+ Host a game'}
        </button>
      </div>

      {withUser && <p data-testid="with-banner" className="rounded-lg bg-brand/10 px-3 py-2 text-sm">Showing games @{withUser} is in. <a href="/games" className="font-semibold underline">Show all</a> or host one and invite them.</p>}

      {hosting && token && <HostGameForm onHost={host} onDone={() => setHosting(false)} />}

      {mounted && token && <Tabs tabs={[{ id: 'all', label: 'Find games' }, { id: 'mine', label: 'My games' }]} value={tab} onChange={setTab} />}

      {tab === 'mine' && mounted && token ? (
        <MyGames token={token} city={city} onEnd={setEnding} />
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <SportChips allLabel="All" />
            <select aria-label="Level" data-testid="games-level" value={level} onChange={(e) => setLevel(e.target.value)} className="ml-auto rounded-lg border bg-white px-2 py-1.5 text-sm">
              <option value="all">Any level</option>
              {GAME_LEVELS.map((l) => <option key={l}>{l}</option>)}
            </select>
          </div>
          {status.state === 'loading' || status.state === 'waiting' ? (
            <Skeleton count={3} />
          ) : status.state === 'error' ? (
            <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load games.</ErrorNotice>
          ) : !shown.length ? (
            <EmptyState>No games here yet. Host the first one!</EmptyState>
          ) : (
            <ul className="space-y-3">{shown.map((g) => <GameCard key={g.id} game={g} city={city} onEnd={setEnding} />)}</ul>
          )}
        </>
      )}

      {ending && <EndGameModal game={ending} onEnd={(w, a) => end(ending, w, a)} onClose={() => setEnding(null)} />}
    </div>
  );
}
