'use client';

import { useState } from 'react';
import { app } from '@/store';
import { DEFAULT_VENUE_FILTER, GAME_LEVELS } from '@/config/constants';
import { formatLocal } from '@/config/cities';
import type { NewGame, SkillLevel } from '@/lib/api';

/** Host options: who can join (open / host approves), who can see it (public / invite only), the lowest level, and a price per player */
export function HostGameForm({ onHost, onDone }: { onHost: (body: NewGame) => Promise<boolean>; onDone: () => void }) {
  const [city] = app.useGlobalState('city');
  const [sportsData] = app.useGlobalState('sports');
  const sports = sportsData ?? []; // the query is undefined until it loads
  const [venues] = app.useGlobalState('venues', { ...DEFAULT_VENUE_FILTER, city });
  const venueList = venues.flatMap((p) => p.items);

  const [title, setTitle] = useState('');
  const [sport, setSport] = useState('badminton');
  const [venueId, setVenueId] = useState(0);
  const [startsAt, setStartsAt] = useState('');
  const [capacity, setCapacity] = useState(6);
  const [level, setLevel] = useState<string>(GAME_LEVELS[1]);
  const [joinMode, setJoinMode] = useState<'open' | 'approval'>('open');
  const [visibility, setVisibility] = useState<'public' | 'private'>('public');
  const [minLevel, setMinLevel] = useState<SkillLevel | ''>('');
  const [price, setPrice] = useState(0);
  const [busy, setBusy] = useState(false);
  const chosen = venueId || venueList[0]?.id || 0;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chosen) return;
    setBusy(true);
    const ok = await onHost({ title, sport, venueId: chosen, startsAt: new Date(startsAt).toISOString(), capacity, level, joinMode, visibility, minLevel: minLevel || null, priceInr: price });
    setBusy(false);
    if (ok) onDone();
  };
  const f = 'rounded-lg border px-3 py-2';
  return (
    <form onSubmit={submit} className="grid gap-3 rounded-2xl border bg-white p-5 sm:grid-cols-2" data-testid="host-form">
      <input required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title, e.g. Friday night doubles" aria-label="Title" className={`${f} sm:col-span-2`} />
      <select aria-label="Sport" value={sport} onChange={(e) => setSport(e.target.value)} className={f}>{sports.map((s) => <option key={s.id} value={s.id}>{s.emoji} {s.name}</option>)}</select>
      <select aria-label="Venue" value={chosen} onChange={(e) => setVenueId(Number(e.target.value))} className={f}>{venueList.map((v) => <option key={v.id} value={v.id}>{v.name} · {v.area}</option>)}</select>
      <input required type="datetime-local" aria-label="Starts at" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} className={f} />
      <div className="flex gap-2">
        <input type="number" min={2} max={30} value={capacity} onChange={(e) => setCapacity(Number(e.target.value))} className={`w-24 ${f}`} aria-label="Players" />
        <select aria-label="Level" value={level} onChange={(e) => setLevel(e.target.value)} className={`flex-1 ${f}`}>{GAME_LEVELS.map((l) => <option key={l}>{l}</option>)}</select>
      </div>

      <label className="text-sm">Who can join
        <select data-testid="host-joinmode" value={joinMode} onChange={(e) => setJoinMode(e.target.value as 'open' | 'approval')} className={`mt-1 w-full ${f}`}>
          <option value="open">Anyone, right away</option>
          <option value="approval">I approve each player</option>
        </select>
      </label>
      <label className="text-sm">Who can see it
        <select data-testid="host-visibility" value={visibility} onChange={(e) => setVisibility(e.target.value as 'public' | 'private')} className={`mt-1 w-full ${f}`}>
          <option value="public">Everyone</option>
          <option value="private">Invite only (link or invite)</option>
        </select>
      </label>
      <label className="text-sm">Lowest level allowed
        <select data-testid="host-minlevel" value={minLevel} onChange={(e) => setMinLevel(e.target.value as SkillLevel | '')} className={`mt-1 w-full ${f}`}>
          <option value="">Any level</option>
          {GAME_LEVELS.map((l) => <option key={l}>{l}</option>)}
        </select>
      </label>
      <label className="text-sm">Price per player (₹, 0 = free)
        <input data-testid="host-price" type="number" min={0} max={5000} value={price} onChange={(e) => setPrice(Math.max(0, Number(e.target.value)))} className={`mt-1 w-full ${f}`} />
        {price > 0 && <span className="text-xs text-ink/50">Players in {city} see {formatLocal(price, city)}</span>}
      </label>
      <p className="text-xs text-ink/50 sm:col-span-2">Players who leave at least 3 hours before the start get their payment back; you receive the money when you end the game.</p>
      <button disabled={busy || !chosen} data-testid="host-submit" className="rounded-lg bg-brand py-2.5 font-semibold text-white sm:col-span-2">{busy ? 'Creating…' : 'Create game'}</button>
    </form>
  );
}
