'use client';

import { useState } from 'react';
import { app } from '@/store';
import { Modal } from '@/components/ui/Modal';
import type { Game } from '@/lib/api';

/** Invite friends and people you've played with (private games are only visible to invited people) */
export function InviteModal({ game, onInvite, onClose }: { game: Game; onInvite: (ids: number[]) => Promise<boolean>; onClose: () => void }) {
  const [token] = app.useGlobalState('token');
  const [friends] = app.useGlobalState('friends', token ?? undefined);
  const [played] = app.useGlobalState('playedWith', token ?? undefined);
  const [picked, setPicked] = useState<number[]>([]);
  const inGame = new Set(game.players.map((p) => p.id));
  const people = new Map<number, { id: number; name: string; username: string }>();
  for (const p of friends?.friends ?? []) people.set(p.id, p);
  for (const w of played ?? []) people.set(w.player.id, w.player);
  const list = [...people.values()].filter((p) => !inGame.has(p.id));
  return (
    <Modal title="Invite players" onClose={onClose}>
      {!list.length ? <p className="text-sm text-ink/60">No friends or players to invite yet.</p> : (
        <ul className="max-h-64 space-y-1 overflow-y-auto">
          {list.map((p) => (
            <li key={p.id}>
              <label className="flex cursor-pointer items-center gap-3 rounded-lg p-2 hover:bg-black/5">
                <input type="checkbox" data-testid={`invite-${p.id}`} checked={picked.includes(p.id)} onChange={() => setPicked(picked.includes(p.id) ? picked.filter((x) => x !== p.id) : [...picked, p.id])} />
                {p.name} <span className="text-xs text-ink/50">@{p.username}</span>
              </label>
            </li>
          ))}
        </ul>
      )}
      <button data-testid="invite-send" disabled={!picked.length} data-tip={!picked.length ? 'Pick at least one player first' : undefined} onClick={async () => { if (await onInvite(picked)) onClose(); }} className="w-full rounded-full bg-brand py-2.5 font-semibold text-white disabled:opacity-50">
        Invite {picked.length || ''}
      </button>
    </Modal>
  );
}
