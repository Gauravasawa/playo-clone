'use client';

import { useState } from 'react';
import { Modal } from '@/components/ui/Modal';
import { PaymentPicker, usePaymentChoice } from '@/components/ui/PaymentPicker';
import { Price } from '@/components/ui/Price';
import type { Game, PayMethod } from '@/lib/api';

/** Priced games: choose how to pay. Approval games hold the payment until the host decides (refunded if declined). */
export function JoinModal({ game, city, onJoin, onClose }: { game: Game; city: string; onJoin: (method: PayMethod) => Promise<boolean>; onClose: () => void }) {
  const choice = usePaymentChoice(game.priceInr);
  const [busy, setBusy] = useState(false);
  const approval = game.joinMode === 'approval';
  return (
    <Modal title={approval ? 'Ask to join' : 'Join game'} onClose={onClose}>
      <p className="text-sm text-ink/60">{game.title} · {game.venue?.name}</p>
      <p className="text-lg font-bold">Price: <Price inr={game.priceInr} city={city} /></p>
      {approval && <p className="rounded-lg bg-amber-50 p-2 text-sm text-amber-800">The host approves players. Your payment is held now and refunded in full if the request is declined.</p>}
      <PaymentPicker choice={choice} name="joinpay" />
      <p className="text-xs text-ink/50">Leave at least 3 hours before the start for a full refund.</p>
      <button
        data-testid="join-pay"
        disabled={busy || choice.blocked}
        onClick={async () => { setBusy(true); const ok = await onJoin(choice.method); setBusy(false); if (ok) onClose(); }}
        className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark disabled:opacity-50"
      >
        {busy ? 'Paying…' : approval ? 'Pay & send request' : 'Pay & join'}
      </button>
    </Modal>
  );
}
