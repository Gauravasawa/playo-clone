'use client';

import { useState } from 'react';
import { app } from '@/store';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { Tabs } from '@/components/ui/Tabs';
import type { Game } from '@/lib/api';
import { GameCard } from './GameCard';

/** Games you host or joined: coming up, or finished */
export function MyGames({ token, city, onEnd }: { token: string; city: string; onEnd: (g: Game) => void }) {
  const [status, setStatus] = useState<'open' | 'ended'>('open');
  const [games, , s] = app.useGlobalState('myGames', { token, status });
  return (
    <div className="space-y-3" data-testid="my-games">
      <Tabs tabs={[{ id: 'open', label: 'Upcoming' }, { id: 'ended', label: 'Finished' }]} value={status} onChange={setStatus} />
      {s.state === 'loading' || s.state === 'waiting' ? <Skeleton count={2} />
        : s.state === 'error' ? <ErrorNotice onRetry={s.refetch}>Couldn&apos;t load your games.</ErrorNotice>
        : !games?.length ? <EmptyState>{status === 'open' ? 'You have no upcoming games.' : 'No finished games yet.'}</EmptyState>
        : <ul className="space-y-3">{games.map((g) => <GameCard key={g.id} game={g} city={city} onEnd={onEnd} />)}</ul>}
    </div>
  );
}
