'use client';

import { app } from '@/store';
import { api, type Game, type NewGame, type PayMethod } from '@/lib/api';

const reason = (e: unknown) => (e instanceof Error ? e.message : 'Failed');
const toast = (kind: 'ok' | 'err', text: string) => app.emit('toast', { kind, text });

/** Everything a game changes: lists, the game itself, the wallet (payments/refunds), Karma and chats */
function refresh() {
  for (const name of ['games', 'myGames', 'game', 'gameByCode', 'wallet', 'karma', 'chats', 'me'] as const) app.invalidate(name);
}

/** Host, join, leave, decide on requests, invite, RSVP and end. Every one returns true when the server accepted it. */
export function useGameActions(token: string | null) {
  const guard = async (fn: (t: string) => Promise<string | void>, failure: string) => {
    if (!token) {
      app.setState('loginOpen', true);
      return false;
    }
    try {
      const ok = await fn(token);
      if (ok) toast('ok', ok);
      refresh();
      return true;
    } catch (e) {
      toast('err', `${failure}: ${reason(e)}`);
      return false;
    }
  };

  const host = (body: NewGame) =>
    guard(async (t) => {
      await api.hostGame(t, body);
      return 'Game created. Its chat is ready.';
    }, "Couldn't create the game");

  const join = (g: Game, opts: { method?: PayMethod; code?: string } = {}) =>
    guard(async (t) => {
      const r = await api.joinGame(t, g.id, opts);
      return r.pending ? 'Request sent. The host will decide.' : `You joined ${g.title}`;
    }, "Couldn't join");

  const leave = (g: Game) =>
    guard(async (t) => {
      const r = await api.leaveGame(t, g.id);
      return r.refunded > 0 ? `You left ${g.title}. ₹${r.refunded} went back to your wallet.` : `You left ${g.title}`;
    }, "Couldn't leave");

  const cancelRequest = (g: Game) => guard(async (t) => { await api.cancelJoinRequest(t, g.id); return 'Request withdrawn'; }, "Couldn't withdraw");
  const decide = (g: Game, userId: number, approve: boolean) =>
    guard(async (t) => { await api.decideRequest(t, g.id, userId, approve); return approve ? 'Player approved' : 'Request declined'; }, "Couldn't update the request");
  const invite = (g: Game, userIds: number[]) =>
    guard(async (t) => { const r = await api.invite(t, g.id, userIds); return `${r.invited} invited`; }, "Couldn't invite");
  const rsvp = (g: Game, answer: 'going' | 'maybe' | 'no') => guard(async (t) => { await api.rsvp(t, g.id, answer); return 'Answer saved'; }, "Couldn't save your answer");

  /** The host ends the game, picks winners and who actually came; players now count as "played with" */
  const end = (g: Game, winnerIds: number[], attendedIds: number[]) =>
    guard(async (t) => {
      await api.endGame(t, g.id, { winnerIds, attendedIds });
      for (const name of ['playedWith', 'leaderboard', 'player', 'friends'] as const) app.invalidate(name);
      return `“${g.title}” ended. Rate the players from their profiles.`;
    }, "Couldn't end the game");

  return { host, join, leave, cancelRequest, decide, invite, rsvp, end };
}
