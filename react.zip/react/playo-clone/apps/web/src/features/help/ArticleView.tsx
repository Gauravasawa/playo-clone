'use client';

import Link from 'next/link';
import { app } from '@/store';
import { DEFAULT_CITY, formatLocal } from '@/config/cities';
import { useMounted } from '@/lib/hooks';
import { ShareMenu } from '@/components/ui/ShareMenu';
import { EmptyState } from '@/components/ui/EmptyState';
import { Skeleton } from '@/components/ui/Skeleton';

export function ArticleView({ slug }: { slug: string }) {
  const mounted = useMounted();
  const [city] = app.useGlobalState('city');
  // The server renders with the default city; the visitor's own city is used after mount (suggested venues follow it)
  const [a, , status] = app.useGlobalState('article', { slug, city: mounted ? city : DEFAULT_CITY });

  if (!a) {
    if (status.state === 'error') return <EmptyState>That article doesn&apos;t exist. <Link href="/blog" className="text-brand underline">Back to the blog</Link></EmptyState>;
    return <Skeleton count={3} />;
  }
  return (
    <article className="mx-auto max-w-2xl space-y-4" data-testid="article">
      <Link href="/blog" className="inline-block py-1.5 text-sm text-brand underline">← Blog</Link>
      <h1 className="text-3xl font-extrabold" data-testid="article-title">{a.title}</h1>
      <p className="text-sm text-ink/50">{a.readMinutes} min read · {a.publishedAt}</p>
      <ShareMenu path={`/blog/${a.slug}`} title={a.title} text={a.summary} />
      <div className="space-y-3 leading-relaxed">{a.body.map((p, i) => <p key={i}>{p}</p>)}</div>
      {a.relatedVenues.length > 0 && (
        <section className="space-y-2 border-t pt-4" data-testid="related-venues">
          <h2 className="font-bold">Try it at</h2>
          <ul className="grid gap-2 sm:grid-cols-3">
            {a.relatedVenues.map((v) => (
              <li key={v.id}><Link href={`/venues/${v.id}`} className="block rounded-xl border bg-white p-3 text-sm hover:shadow"><b>{v.name}</b><br /><span className="text-ink/60">{v.area} · {formatLocal(v.pricePerHour, v.city)}/hr</span></Link></li>
            ))}
          </ul>
        </section>
      )}
    </article>
  );
}
