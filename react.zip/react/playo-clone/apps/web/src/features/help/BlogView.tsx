'use client';

import Link from 'next/link';
import { useState } from 'react';
import { app } from '@/store';
import { useDebounced } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';

export function BlogView() {
  const [tag, setTag] = useState('');
  const [text, setText] = useState('');
  const q = useDebounced(text.trim(), 300);
  const [data, , status] = app.useGlobalState('articles', { tag, q });
  const [all] = app.useGlobalState('articles', { tag: '', q: '' });
  const tags = all?.tags ?? data?.tags ?? [];

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-extrabold">Playo blog</h1>
      <input type="search" value={text} onChange={(e) => setText(e.target.value)} placeholder="Search articles" aria-label="Search articles" data-testid="blog-search" className="w-full rounded-xl border bg-white px-4 py-2.5" />
      <div className="flex flex-wrap gap-1.5 text-sm">
        {['', ...tags].map((t) => (
          <button key={t || 'all'} onClick={() => setTag(t)} aria-pressed={tag === t} data-testid={`tag-${t || 'all'}`} className={`rounded-full border px-3 py-1 ${tag === t ? 'border-brand bg-brand text-white' : 'bg-white hover:bg-black/5'}`}>{t || 'All'}</button>
        ))}
      </div>
      {!data ? (status.state === 'error' ? <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load articles.</ErrorNotice> : <Skeleton count={3} />) : data.items.length === 0 ? (
        <EmptyState>No articles match.</EmptyState>
      ) : (
        <ul className="grid gap-4 md:grid-cols-2" data-testid="article-list">
          {data.items.map((a) => (
            <li key={a.slug}>
              <Link href={`/blog/${a.slug}`} data-testid={`article-${a.slug}`} className="block h-full space-y-2 rounded-2xl border bg-white p-5 hover:shadow">
                <h2 className="font-bold">{a.title}</h2>
                <p className="text-sm text-ink/70">{a.summary}</p>
                <p className="text-xs text-ink/50">{a.readMinutes} min read · {a.publishedAt} · {a.tags.join(', ')}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
