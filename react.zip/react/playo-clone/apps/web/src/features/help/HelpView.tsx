'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { app } from '@/store';
import type { Faq } from '@/lib/api';
import { useDebounced } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';

/** FAQ with search. The text is debounced; each typed character cancels the request still in flight (`app.abort('faq')`) */
export function HelpView() {
  const [text, setText] = useState('');
  const q = useDebounced(text.trim(), 300);
  const [category, setCategory] = useState('all');
  const [cancelled, setCancelled] = useState(0);
  const first = useRef(true);
  const [data, , status] = app.useGlobalState('faq', q);
  const last = useRef(data);
  if (data) last.current = data;
  const shown = data ?? last.current; // while a search is loading (or was cancelled) keep showing the previous answers

  useEffect(() => {
    if (first.current) { first.current = false; return; }
    app.abort('faq'); // the old search is no longer wanted
    setCancelled((n) => n + 1);
  }, [text]);

  const items = (shown?.items ?? []).filter((f) => category === 'all' || f.category === category);
  const grouped = items.reduce<Record<string, Faq[]>>((m, f) => ((m[f.category] ??= []).push(f), m), {});
  const failed = status.state === 'error' && !shown;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-extrabold">Help centre</h1>
        <Link href="/help/tickets" className="ml-auto rounded-full border px-4 py-1.5 text-sm font-semibold hover:bg-black/5" data-testid="my-tickets-link">My support tickets</Link>
      </div>
      <input type="search" value={text} onChange={(e) => setText(e.target.value)} placeholder="Search the help centre: refund, reschedule, Karma…" aria-label="Search help" data-testid="faq-search" className="w-full rounded-xl border bg-white px-4 py-3" />
      <div className="flex flex-wrap items-center gap-1.5 text-sm">
        {['all', ...(shown?.categories ?? [])].map((c) => (
          <button key={c} onClick={() => setCategory(c)} aria-pressed={category === c} data-testid={`faq-cat-${c}`} className={`rounded-full border px-3 py-1 ${category === c ? 'border-brand bg-brand text-white' : 'bg-white hover:bg-black/5'}`}>{c === 'all' ? 'All' : c}</button>
        ))}
        <span className="ml-auto text-xs text-ink/50" data-testid="faq-meta" data-cancelled={cancelled}>
          {text.trim() !== q || status.state === 'loading' ? 'Searching…' : `${items.length} answer${items.length === 1 ? '' : 's'}`}
        </span>
      </div>

      {!shown && !failed ? <Skeleton count={4} className="h-14" /> : failed ? (
        <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load the help centre.</ErrorNotice>
      ) : items.length === 0 ? (
        <EmptyState>
          <p className="mb-3">No answer found for “{q}”.</p>
          <Link href="/help/tickets?new=1" className="rounded-full bg-brand px-5 py-2 font-semibold text-white" data-testid="ask-support">Ask support</Link>
        </EmptyState>
      ) : (
        <div className="space-y-5" data-testid="faq-list">
          {Object.entries(grouped).map(([cat, list]) => (
            <section key={cat} className="space-y-2">
              <h2 className="font-bold text-ink/70">{cat}</h2>
              {list.map((f) => (
                <details key={f.id} className="rounded-xl border bg-white p-4" data-testid={`faq-${f.id}`}>
                  <summary className="min-h-8 cursor-pointer py-1 font-semibold">{f.question}</summary>
                  <p className="mt-2 text-sm text-ink/70">{f.answer}</p>
                </details>
              ))}
            </section>
          ))}
          <p className="text-sm text-ink/60">Didn&apos;t find it? <Link href="/help/tickets?new=1" className="text-brand underline">Ask support</Link> · <Link href="/policy" className="text-brand underline">Cancellation policy</Link> · <Link href="/blog" className="text-brand underline">Blog</Link></p>
        </div>
      )}
    </div>
  );
}
