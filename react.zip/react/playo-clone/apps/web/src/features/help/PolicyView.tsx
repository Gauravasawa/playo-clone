'use client';

import Link from 'next/link';
import { app } from '@/store';
import { formatInr } from '@/config/cities';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';

type Rows = { hoursBefore: number; percent: number }[];

/** What a Plus member gets when cancelling at the start of a standard window */
const percentAt = (rows: Rows, hoursBefore: number) => rows.find((r) => hoursBefore >= r.hoursBefore)?.percent ?? 0;

/** The rules the server enforces, shown from the same `policy` query the checkout uses */
export function PolicyView() {
  const [p, , status] = app.useGlobalState('policy');
  if (!p) return status.state === 'error' ? <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load the policy.</ErrorNotice> : <Skeleton count={3} />;

  const rows = p.refund.standard.map((r, i, all) => {
    const upper = all[i - 1]?.hoursBefore;
    const when = r.hoursBefore === 0 ? `less than ${upper} hours before` : upper ? `${r.hoursBefore} to ${upper} hours before` : `${r.hoursBefore} or more hours before`;
    return { when, standard: r.percent, plus: percentAt(p.refund.plus, r.hoursBefore) };
  });

  const card = 'space-y-2 rounded-2xl border bg-white p-5';
  return (
    <div className="mx-auto max-w-2xl space-y-5" data-testid="policy">
      <h1 className="text-2xl font-extrabold">Cancellation &amp; refund policy</h1>
      <section className={card}>
        <h2 className="font-bold">Cancelling a booking</h2>
        <table className="w-full text-sm" data-testid="refund-table">
          <thead><tr className="text-left text-ink/50"><th scope="col">Cancel…</th><th scope="col">Everyone</th><th scope="col">Playo Plus ✨</th></tr></thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-t"><td className="py-1.5">{r.when}</td><td data-testid={`refund-std-${i}`}>{r.standard}%</td><td data-testid={`refund-plus-${i}`}>{r.plus}%</td></tr>
            ))}
          </tbody>
        </table>
        <p className="text-sm text-ink/60">Refunds go to your wallet straight away. Plus members get a full refund up to {p.refund.plus[0].hoursBefore} hours before.</p>
      </section>
      <section className={card}>
        <h2 className="font-bold">Changing plans</h2>
        <ul className="list-disc space-y-1 pl-5 text-sm">
          <li>Reschedule a booking up to <b>{p.rescheduleUntilHoursBefore} hours</b> before it starts, for free.</li>
          <li>Leave a game up to <b>{p.gameLeaveRefundHoursBefore} hours</b> before it starts to get your price back.</li>
        </ul>
      </section>
      <section className={card}>
        <h2 className="font-bold">Fees</h2>
        <p className="text-sm">A convenience fee of <b>{p.convenienceFee.percent}%</b> ({formatInr(p.convenienceFee.min)} to {formatInr(p.convenienceFee.max)}) is added to bookings. It is waived for Plus members and for bookings paid by a pass.</p>
      </section>
      <section className={card}>
        <h2 className="font-bold">Karma, Plus and gifts</h2>
        <ul className="list-disc space-y-1 pl-5 text-sm">
          <li>10 Karma points = {formatInr(1)}; Karma can cover up to {Math.round(p.karma.maxShareOfPayable * 100)}% of a booking. Plus earns {p.plus.karmaMultiplier}x.</li>
          <li>Playo Plus costs {formatInr(p.plus.monthly)}/month or {formatInr(p.plus.yearly)}/year.</li>
          <li>Gift cards are {formatInr(p.giftCard.min)} to {formatInr(p.giftCard.max)} and valid for {Math.round(p.giftCard.validMs / (365 * 86_400_000))} year.</li>
          <li>Referrals: {formatInr(p.referral.newcomer)} for the newcomer, {formatInr(p.referral.referrer)} and Karma for you after their first booking.</li>
        </ul>
      </section>
      <p className="text-sm text-ink/60">Something went wrong? <Link href="/help/tickets?new=1" className="text-brand underline">Contact support</Link> or read the <Link href="/help" className="text-brand underline">help centre</Link>.</p>
    </div>
  );
}
