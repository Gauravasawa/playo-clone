'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { app } from '@/store';
import { api } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';

/** A ticket conversation. The demo agent's replies arrive over the WebSocket ('ticket' event), which invalidates this query */
export function TicketThreadView({ id }: { id: number }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [ticket, , status] = app.useGlobalState('ticket', token ? { token, id } : undefined);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const count = ticket?.messages?.length ?? 0;
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [count]);

  if (!mounted) return null;
  if (!token) return <EmptyState>Log in to see this ticket.</EmptyState>;
  if (!ticket) return status.state === 'error' ? <ErrorNotice onRetry={status.refetch}>{status.error instanceof Error ? status.error.message : "Couldn't load the ticket."}</ErrorNotice> : <Skeleton count={3} className="h-16" />;

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    setBusy(true);
    try {
      await api.replyTicket(token, id, body);
      setText('');
      app.invalidate('ticket');
      app.invalidate('tickets');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not send' });
    } finally {
      setBusy(false);
    }
  };
  const close = async () => {
    try {
      await api.closeTicket(token, id);
      app.invalidate('ticket');
      app.invalidate('tickets');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not close' });
    }
  };

  const waiting = ticket.status === 'open' && ticket.messages?.at(-1)?.sender === 'user';
  return (
    <div className="space-y-4" data-testid="ticket-thread">
      <div className="flex items-start gap-3">
        <div>
          <Link href="/help/tickets" className="text-sm text-brand underline">← All tickets</Link>
          <h1 className="text-xl font-extrabold" data-testid="ticket-subject">{ticket.subject}</h1>
          <p className="text-sm text-ink/60">{ticket.topic}{ticket.bookingId ? ` · booking #${ticket.bookingId}` : ''} · <span data-testid="thread-status">{ticket.status}</span></p>
        </div>
        {ticket.status !== 'closed' && <button onClick={close} data-testid="close-ticket" className="ml-auto rounded-full border px-4 py-1.5 text-sm font-semibold hover:bg-black/5">Close ticket</button>}
      </div>
      <ul className="space-y-2">
        {(ticket.messages ?? []).map((m) => (
          <li key={m.id} data-testid={`msg-${m.sender}`} className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm ${m.sender === 'user' ? 'ml-auto bg-brand text-white' : 'bg-white shadow-sm'}`}>
            {m.sender === 'agent' && <b className="block text-xs text-ink/50">Support</b>}
            {m.body}
          </li>
        ))}
      </ul>
      {waiting && <p className="text-sm text-ink/50" data-testid="agent-typing">Support is typing…</p>}
      <div ref={end} />
      {ticket.status === 'closed' ? <p className="text-sm text-ink/50">This ticket is closed.</p> : (
        <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2">
          <input aria-label="Reply" placeholder="Write a reply" value={text} onChange={(e) => setText(e.target.value)} className="flex-1 rounded-xl border bg-white px-3 py-2" />
          <button disabled={busy || !text.trim()} data-testid="ticket-reply" className="rounded-xl bg-brand px-5 font-semibold text-white disabled:opacity-40">Send</button>
        </form>
      )}
    </div>
  );
}
