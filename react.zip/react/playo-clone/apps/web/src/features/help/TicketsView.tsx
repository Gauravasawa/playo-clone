'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { app } from '@/store';
import { api, type Ticket } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Modal } from '@/components/ui/Modal';
import { Skeleton } from '@/components/ui/Skeleton';

const TOPICS = ['Booking', 'Payment', 'Refund', 'Game', 'Account', 'Other'];
const BADGE: Record<Ticket['status'], string> = { open: 'bg-amber-100 text-amber-800', answered: 'bg-green-100 text-green-800', closed: 'bg-gray-100 text-gray-600' };

export function TicketsView() {
  const mounted = useMounted();
  const params = useSearchParams();
  const [token] = app.useGlobalState('token');
  const [tickets, , status] = app.useGlobalState('tickets', token ?? undefined);
  const [creating, setCreating] = useState(params?.get('new') === '1');

  if (!mounted) return null;
  if (!token)
    return (
      <>
      <h1 className="mb-4 text-2xl font-extrabold">Support tickets</h1>
      <EmptyState>
        <p className="mb-3">Log in to contact support.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
      </>
    );

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div>
          <Link href="/help" className="inline-block py-1.5 text-sm text-brand underline">← Help centre</Link>
          <h1 className="text-2xl font-extrabold">Support tickets</h1>
        </div>
        <button onClick={() => setCreating(true)} data-testid="new-ticket" className="ml-auto rounded-full bg-brand px-4 py-2 text-sm font-semibold text-white hover:bg-brand-dark">New ticket</button>
      </div>
      {status.state === 'loading' || status.state === 'waiting' ? <Skeleton count={2} className="h-16" /> : status.state === 'error' ? (
        <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load your tickets.</ErrorNotice>
      ) : !tickets?.length ? (
        <EmptyState>No tickets yet. Answers to common questions are in the <Link href="/help" className="text-brand underline">help centre</Link>.</EmptyState>
      ) : (
        <ul className="space-y-2" data-testid="ticket-list">
          {tickets.map((t) => (
            <li key={t.id}>
              <Link href={`/help/tickets/${t.id}`} data-testid={`ticket-${t.id}`} className="block rounded-xl border bg-white p-4 hover:shadow">
                <div className="flex items-center gap-2"><b className="truncate">{t.subject}</b><span className={`ml-auto rounded-full px-2 py-0.5 text-xs font-semibold ${BADGE[t.status]}`} data-testid={`ticket-status-${t.id}`}>{t.status}</span></div>
                <p className="truncate text-sm text-ink/60">{t.topic} · {t.lastMessage ? `${t.lastMessage.sender === 'agent' ? 'Support: ' : 'You: '}${t.lastMessage.body}` : ''}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
      {creating && <NewTicketModal token={token} onClose={() => setCreating(false)} />}
    </div>
  );
}

function NewTicketModal({ token, onClose }: { token: string; onClose: () => void }) {
  const router = useRouter();
  const [bookings] = app.useGlobalState('bookings', token);
  const [form, setForm] = useState({ topic: 'Booking', subject: '', message: '', bookingId: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    setBusy(true);
    setError('');
    try {
      const t = await api.createTicket(token, { topic: form.topic, subject: form.subject, message: form.message, bookingId: form.bookingId ? Number(form.bookingId) : null });
      app.invalidate('tickets');
      router.push(`/help/tickets/${t.id}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not send');
      setBusy(false);
    }
  };
  const input = 'w-full rounded-lg border px-3 py-2';
  return (
    <Modal title="New support ticket" onClose={onClose}>
      <form data-testid="ticket-form" onSubmit={(e) => { e.preventDefault(); submit(); }} className="space-y-3 text-sm">
        <select aria-label="Topic" value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} className={input}>{TOPICS.map((t) => <option key={t}>{t}</option>)}</select>
        {!!bookings?.length && (
          <select aria-label="Related booking" value={form.bookingId} onChange={(e) => setForm({ ...form, bookingId: e.target.value })} className={input}>
            <option value="">No booking</option>
            {bookings.map((b) => <option key={b.id} value={b.id}>#{b.id} {b.venueName} · {b.date}</option>)}
          </select>
        )}
        <input aria-label="Subject" placeholder="Subject" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className={input} />
        <textarea aria-label="Message" placeholder="What happened?" rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className={input} />
        {error && <p className="text-red-600" data-testid="ticket-error">{error}</p>}
        <button disabled={busy} data-testid="ticket-submit" className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark">{busy ? 'Sending…' : 'Send to support'}</button>
      </form>
    </Modal>
  );
}
