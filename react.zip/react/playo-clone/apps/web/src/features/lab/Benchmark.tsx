'use client';

import { useState } from 'react';
import { createStore, query } from '@/lib/store/createStore';
import { Card } from './ui';

interface Row { name: string; ops: number; ms: number }

const nextFrame = () => new Promise((r) => setTimeout(r, 0));

/** Each benchmark gets a throwaway store, so the app's own state is never touched */
const benchmarks: [name: string, ops: number, run: (ops: number) => Promise<void> | void][] = [
  ['setState on a number (no listeners)', 20000, async (n) => {
    const s = createStore({ n: 0 });
    for (let i = 0; i < n; i++) await s.setState('n', i);
  }],
  ['setState with 500 subscribers listening', 5000, async (n) => {
    const s = createStore({ a: 0 });
    for (let i = 0; i < 500; i++) s.subscribe(() => {});
    for (let i = 0; i < n; i++) await s.setState('a', i);
  }],
  ['setState with a 2-layer computed value', 5000, async (n) => {
    const s = createStore({ n: 0 }, { computed: [{ double: (get) => get('n') * 2 }, { quad: (get) => get('double') * 2 }] });
    for (let i = 0; i < n; i++) {
      await s.setState('n', i);
      s.getState('quad');
    }
  }],
  ['batch of 1,000 setState calls (one notification)', 200, async (n) => {
    const s = createStore({ n: 0 });
    for (let r = 0; r < n; r++) s.batch(() => { for (let i = 0; i < 1000; i++) s.setState('n', i); });
  }],
  ['key action on a 1,000-item list', 2000, async (n) => {
    const s = createStore({ list: Array.from({ length: 1000 }, (_, i) => i) }, { keyActions: { list: { push: (l: number[], x: number) => [...l, x] } } });
    for (let i = 0; i < n; i++) await s.set.list.push(i);
  }],
  ['fetchQuery cache hits', 20000, async (n) => {
    const q = query(async (id: number) => id, { staleTime: 60_000 });
    const s = createStore({ q });
    await s.fetchQuery('q', 1);
    for (let i = 0; i < n; i++) await s.fetchQuery('q', 1);
  }],
  ['fetchQuery, 2,000 different params', 2000, async (n) => {
    const q = query(async (id: number) => ({ id }));
    const s = createStore({ q });
    await Promise.all(Array.from({ length: n }, (_, i) => s.fetchQuery('q', i)));
  }],
  ['history: 1,000 changes then undo all (limit 50)', 1000, async (n) => {
    const s = createStore({ n: 0 }, { history: { limit: 50 } });
    for (let i = 0; i < n; i++) await s.setState('n', i);
    for (let i = 0; i < 60; i++) s.undo();
  }],
  ['snapshot of 5,000 cached entries', 20, async (n) => {
    const q = query(async (id: number) => ({ id, text: 'x'.repeat(40) }));
    const s = createStore({ q });
    await Promise.all(Array.from({ length: 5000 }, (_, i) => s.fetchQuery('q', i)));
    for (let i = 0; i < n; i++) JSON.stringify(s.snapshot());
  }],
];

export function Benchmark() {
  const [rows, setRows] = useState<Row[]>([]);
  const [running, setRunning] = useState(false);

  const run = async () => {
    setRows([]);
    setRunning(true);
    for (const [name, ops, fn] of benchmarks) {
      await nextFrame();
      const t = performance.now();
      try {
        await fn(ops);
        setRows((r) => [...r, { name, ops, ms: performance.now() - t }]);
      } catch (e) {
        setRows((r) => [...r, { name: `${name}: ${e instanceof Error ? e.message : e}`, ops, ms: -1 }]);
      }
    }
    setRunning(false);
  };

  return (
    <Card title="Performance benchmark">
      <p className="text-sm text-ink/60">Times the library on throwaway stores (never the app&apos;s own). Numbers depend on your machine and on dev vs production builds.</p>
      <button data-testid="bench-run" onClick={run} disabled={running} className="rounded-lg bg-brand px-4 py-2 font-semibold text-white">{running ? 'Running…' : 'Run benchmark'}</button>
      {rows.length > 0 && (
        <table className="w-full text-sm" data-testid="bench-table">
          <thead><tr className="text-left text-ink/50"><th>Case</th><th className="text-right">Operations</th><th className="text-right">Total ms</th><th className="text-right">µs / op</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.name} className="border-t">
                <td className="py-1">{r.name}</td>
                <td className="text-right">{r.ops.toLocaleString('en')}</td>
                <td className="text-right">{r.ms < 0 ? 'failed' : r.ms.toFixed(1)}</td>
                <td className="text-right" data-testid="bench-us">{r.ms < 0 ? '–' : ((r.ms * 1000) / r.ops).toFixed(1)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Card>
  );
}
