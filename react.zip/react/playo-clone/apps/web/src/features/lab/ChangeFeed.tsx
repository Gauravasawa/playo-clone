'use client';

import { useEffect, useState } from 'react';
import { app } from '@/store';
import type { ChangeEvent } from '@/lib/store/createStore';
import { Card } from './ui';

/** Every change the store makes, as `store.subscribe` reports it */
export function ChangeFeed() {
  const [events, setEvents] = useState<ChangeEvent[]>([]);
  useEffect(() => app.subscribe((e) => setEvents((l) => [e, ...l].slice(0, 12))), []);

  return (
    <Card title="Change feed (store.subscribe)">
      {events.length === 0 ? (
        <p className="text-sm text-ink/50">Change something to see it here.</p>
      ) : (
        <ul className="space-y-1 font-mono text-xs">
          {events.map((e, i) => (
            <li key={`${e.time}-${i}`}>
              <span className="rounded bg-black/5 px-1.5 py-0.5">{e.source}</span> <b>{e.key.replace(/\u0000/g, '·')}</b> → {JSON.stringify(e.next)?.slice(0, 90)}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
