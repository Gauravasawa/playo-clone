'use client';

import { app } from '@/store';
import { Card, Row } from './ui';

export function Controls() {
  const [fail, setFail] = app.useGlobalState('simulateFailure');
  const [sportsData, , sportsStatus] = app.useGlobalState('sports');
  const sports = sportsData ?? [];
  return (
    <Card title="Controls">
      <label className="flex items-center gap-3 rounded-xl bg-amber-50 p-3 text-sm">
        <input type="checkbox" checked={fail} onChange={(e) => setFail(e.target.checked)} className="size-4" />
        <span><b>Simulate server failures.</b> Every write (favourite, book, cancel, join) returns 503, so you can watch optimistic updates roll back.</span>
      </label>
      <div className="grid grid-cols-2 gap-2 text-sm">
        <button className="rounded-lg border py-2" onClick={() => app.emit('toast', { kind: 'ok', text: 'Hello from emit()' })}>emit toast here</button>
        <button className="rounded-lg border py-2" onClick={() => app.emit('toast', { kind: 'ok', text: 'Broadcast from another tab' }, { broadcast: true })}>emit to all tabs</button>
        <button className="rounded-lg border py-2" onClick={() => app.fetchQuery('sports', undefined, true)}>refetch sports</button>
        <button className="rounded-lg border py-2" onClick={() => app.invalidate('venues')}>invalidate venues</button>
        <button className="rounded-lg border py-2" onClick={() => app.batch(() => { app.setState('city', 'Mumbai'); app.setState('sport', 'football'); })}>batch: Mumbai + football</button>
        <button className="rounded-lg border border-red-200 py-2 text-red-600" onClick={() => app.reset()}>reset() store</button>
      </div>
      <Row k="sports query" v={`${sportsStatus.state}${sportsStatus.fetching ? ' (fetching)' : ''} · ${sports.length} items`} />
      <p className="text-xs text-ink/50">Open this app in two tabs: logging in, favouriting, or changing the city in one follows in the other (syncTabs).</p>
    </Card>
  );
}
