'use client';

import { useState } from 'react';
import { app } from '@/store';
import { api } from '@/lib/api';
import { Card } from './ui';

const STATE_KEY = 'playo:state';

/** Buttons that set up situations that are hard to reach by hand, each tied to a store feature */
export function DemoTools() {
  const [token] = app.useGlobalState('token');
  const [me] = app.useGlobalState('me', token ?? undefined);
  const [payFail, setPayFail] = app.useGlobalState('simulatePaymentFailure');
  const [bookings, setBookings] = app.useGlobalState('bookings', token ?? undefined);
  const [routeResult, setRouteResult] = useState('');
  const toast = (kind: 'ok' | 'err', text: string) => app.emit('toast', { kind, text });

  const makeNotifications = async () => {
    if (!token) return toast('err', 'Log in first');
    await api.devNotifications(token, 40);
    app.invalidate('notifications');
    toast('ok', '40 notifications created. Open Notifications and press Load more: the list keeps only the latest 3 pages (pages.max).');
  };

  const attend = async (id: number) => {
    if (!token) return;
    try {
      await setBookings((prev) => (prev ?? []).map((b) => (b.id === id ? { ...b, status: 'attended' as const } : b)), () => api.attendBooking(token, id));
      // A forced reload (not just `invalidate`) so the offline copy of "can I review?" is replaced too
      const venueId = (bookings ?? []).find((b) => b.id === id)?.venueId;
      if (venueId) await app.fetchQuery('venueReviews', { venueId, token }, true).catch(() => {});
      toast('ok', 'Marked as attended: you can now review that venue.');
    } catch (e) {
      toast('err', e instanceof Error ? e.message : 'Failed');
    }
  };

  const checkRouteHandler = async () => {
    if (!me) return toast('err', 'Log in first');
    const res = await fetch(`/share/${me.username}`);
    setRouteResult(`${res.status} ${JSON.stringify(await res.json())}`);
  };

  /** Writes what an older version of the app would have saved, then reloads: persist.migrate has to upgrade it */
  const oldShape = () => {
    localStorage.setItem(STATE_KEY, JSON.stringify({ $version: 1, state: { city: 'Pune', sport: 'tennis', sort: 'price', token, favorites: [1, 2] } }));
    location.reload();
  };
  /** Writes saved values that make no sense: `validate` must ignore them */
  const badValues = () => {
    localStorage.setItem(STATE_KEY, JSON.stringify({ $version: 2, state: { city: 'Atlantis', sport: 'tennis', sort: 'rating', token: 'definitely-not-a-token', favorites: 'oops', recentSearches: [] } }));
    location.reload();
  };

  const confirmed = (bookings ?? []).filter((b) => b.status === 'confirmed' && b.id > 0);
  const btn = 'rounded-lg border px-3 py-2 text-left text-sm hover:bg-black/5';

  return (
    <Card title="Demo tools">
      <label className="flex items-center gap-3 rounded-xl bg-amber-50 p-3 text-sm">
        <input type="checkbox" checked={payFail} onChange={(e) => setPayFail(e.target.checked)} className="size-4" />
        <span><b>Decline UPI and card payments.</b> Checkout and wallet top-ups then fail, and the optimistic booking or balance goes back.</span>
      </label>

      <div className="grid gap-2 sm:grid-cols-2">
        <button className={btn} onClick={makeNotifications}><b>Make 40 notifications</b><br /><span className="text-ink/50">tries the paged query with <code>max: 3</code></span></button>
        <button className={btn} onClick={checkRouteHandler}><b>Call the Route Handler</b><br /><span className="text-ink/50">/share/&lt;you&gt; loads your profile through a scope</span></button>
        <button className={btn} onClick={oldShape}><b>Save an old (v1) state and reload</b><br /><span className="text-ink/50"><code>persist.migrate</code> upgrades it</span></button>
        <button className={btn} onClick={badValues}><b>Save invalid values and reload</b><br /><span className="text-ink/50"><code>validate</code> ignores them (see the console)</span></button>
      </div>
      {routeResult && <pre data-testid="route-result" className="overflow-x-auto rounded-lg bg-black/5 p-2 text-xs">{routeResult}</pre>}

      <div>
        <p className="mb-1 text-sm font-semibold">Mark a booking as attended (unlocks its venue review)</p>
        {confirmed.length === 0 ? <p className="text-sm text-ink/50">No confirmed bookings.</p> : (
          <ul className="space-y-1 text-sm">
            {confirmed.map((b) => (
              <li key={b.id} className="flex items-center justify-between gap-2 rounded-lg bg-black/[0.03] px-3 py-1.5">
                <span>{b.venueName} · {b.date}</span>
                <button onClick={() => attend(b.id)} className="rounded-full border bg-white px-3 py-0.5 text-xs font-semibold">Mark attended</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <p className="text-xs text-ink/50">Offline: switch the network off in your browser's DevTools. Pages keep showing what was loaded (<code>offline</code>), favourites and messages queue and go out when it's back.</p>
    </Card>
  );
}
