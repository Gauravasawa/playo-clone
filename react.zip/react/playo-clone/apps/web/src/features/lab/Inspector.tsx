'use client';

import { app } from '@/store';
import { chatStore } from '@/store/chat';
import { money } from '@/lib/format';
import { Card, Row } from './ui';

/** Live view of state, computed values, a selector and the undo/redo history */
export function Inspector() {
  const [city] = app.useGlobalState('city');
  const [sport] = app.useGlobalState('sport');
  const [token] = app.useGlobalState('token');
  const [favorites] = app.useGlobalState('favorites');
  const [selection] = app.useGlobalState('selection');
  const [loggedIn] = app.useGlobalState('loggedIn');
  const [slotCount] = app.useGlobalState('slotCount');
  const [total] = app.useGlobalState('total');
  const [canBook] = app.useGlobalState('canBook');
  const [socket] = app.useGlobalState('socket');
  const [recent] = app.useGlobalState('recentSearches');
  const [cachedMessages] = chatStore.useGlobalState('messages');
  const [drafts] = chatStore.useGlobalState('drafts');
  const h = app.useHistory();
  // a selector: this component re-renders only when the selected value changes
  const favoritesHint = app.useGlobalState((s) => (s('favorites').length > 3 ? 'many favourites' : 'few favourites'));

  return (
    <Card title="Live state">
      <Row k="city / sport" v={`${city} / ${sport}`} />
      <Row k="token" v={token ? `${token.slice(0, 8)}…` : 'null'} />
      <Row k="favorites" v={JSON.stringify(favorites)} />
      <Row k="selection" v={selection.venueId ? `venue ${selection.venueId} · ${selection.date} · ${selection.slots.map((s) => s.time).join(', ') || 'none'}` : 'none'} />
      <Row k="WebSocket" v={socket} />
      <Row k="recentSearches" v={JSON.stringify(recent)} />
      <Row k="chat store (IndexedDB)" v={`${Object.values(cachedMessages).reduce((n, l) => n + l.length, 0)} messages in ${Object.keys(cachedMessages).length} chats, ${Object.keys(drafts).length} drafts`} />
      <hr />
      <p className="text-xs font-semibold uppercase text-ink/40">Computed</p>
      <Row k="loggedIn" v={String(loggedIn)} />
      <Row k="slotCount" v={slotCount} />
      <Row k="total" v={money(total)} />
      <Row k="canBook (layer 2)" v={String(canBook)} />
      <Row k="selector" v={favoritesHint} />
      <hr />
      <p className="text-xs font-semibold uppercase text-ink/40">History (selection)</p>
      <Row k="position / length" v={`${h.position} / ${h.length}`} />
      <div className="flex gap-2">
        <button disabled={!h.canUndo} data-tip={h.canUndo ? 'Undo the last slot choice' : 'Nothing to undo yet'} onClick={() => app.undo()} className="rounded-lg border px-3 py-1 text-sm">Undo</button>
        <button disabled={!h.canRedo} data-tip={h.canRedo ? 'Redo the slot choice' : 'Nothing to redo yet'} onClick={() => app.redo()} className="rounded-lg border px-3 py-1 text-sm">Redo</button>
      </div>
    </Card>
  );
}
