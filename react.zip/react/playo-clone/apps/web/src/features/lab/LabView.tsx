'use client';

import { useMounted } from '@/lib/hooks';
import { ChangeFeed } from './ChangeFeed';
import { Controls } from './Controls';
import { DemoTools } from './DemoTools';
import { Benchmark } from './Benchmark';
import { Inspector } from './Inspector';
import { SelfTests } from './SelfTests';

export function LabView() {
  const mounted = useMounted();
  if (!mounted) return null;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-extrabold">Store lab</h1>
      <p className="text-ink/60">Watch <code>createStore</code> work live, flip it into failure mode, and run its self-tests.</p>
      <div className="grid gap-6 md:grid-cols-2">
        <Inspector />
        <Controls />
      </div>
      <DemoTools />
      <ChangeFeed />
      <SelfTests />
      <Benchmark />
    </div>
  );
}
