'use client';

import { useState } from 'react';
import { runSelfTests, testCount, type TestResult } from './selftest';
import { Card } from './ui';

export function SelfTests() {
  const [results, setResults] = useState<TestResult[]>([]);
  const [running, setRunning] = useState(false);

  const run = async () => {
    setResults([]);
    setRunning(true);
    await runSelfTests((r) => setResults((l) => [...l, r]));
    setRunning(false);
  };
  const failed = results.filter((r) => !r.ok).length;

  return (
    <Card title={`Self-tests (${testCount})`}>
      <div className="flex items-center gap-3">
        <button onClick={run} disabled={running} className="rounded-lg bg-brand px-4 py-2 font-semibold text-white">{running ? 'Running…' : 'Run all'}</button>
        {results.length > 0 && !running && (
          <span data-testid="selftest-summary" className={`text-sm font-semibold ${failed ? 'text-red-600' : 'text-brand-dark'}`}>
            {results.length - failed} passed, {failed} failed
          </span>
        )}
      </div>
      <ul className="space-y-1 text-sm">
        {results.map((r) => (
          <li key={r.name} className="flex gap-2">
            <span>{r.ok ? '✅' : '❌'}</span>
            <span>
              <span className="font-medium">{r.name}</span> <span className="text-ink/40">{r.ms}ms</span>
              {r.detail && <span className={`block text-xs ${r.ok ? 'text-ink/50' : 'text-red-600'}`}>{r.detail}</span>}
            </span>
          </li>
        ))}
      </ul>
    </Card>
  );
}
