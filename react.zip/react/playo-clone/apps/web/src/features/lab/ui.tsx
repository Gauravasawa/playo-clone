export function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-3 rounded-2xl border bg-white p-5">
      <h2 className="font-bold">{title}</h2>
      {children}
    </section>
  );
}

export function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between gap-4 text-sm">
      <span className="text-ink/60">{k}</span>
      <span className="break-all text-right font-mono">{v}</span>
    </div>
  );
}
