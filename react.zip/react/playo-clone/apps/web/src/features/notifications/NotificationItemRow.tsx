'use client';

import Link from 'next/link';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import type { NotificationItem } from '@/lib/api';
import { useSocialActions } from '@/features/friends/useSocialActions';
import { describe } from './describe';

const ago = (ms: number) => {
  const s = Math.max(1, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86_400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86_400)}d ago`;
};

export function NotificationItemRow({ item, onOpen }: { item: NotificationItem; onOpen: (n: NotificationItem) => void }) {
  const social = useSocialActions();
  const [token] = app.useGlobalState('token');
  const [friends] = app.useGlobalState('friends', token ?? undefined);
  const [followRequests] = app.useGlobalState('followRequests', token ?? undefined);
  const d = describe(item);
  const actor = item.data.actor;

  // A request can be answered right here, while it's still waiting
  const friendRequestPending = item.type === 'friend_request' && actor && friends?.incoming.find((r) => r.id === item.data.requestId);
  const followRequestPending = item.type === 'follow_request' && actor && followRequests?.some((r) => r.player.id === actor.id);
  const btn = 'rounded-full px-3 py-1 text-sm font-semibold';

  return (
    <li className={`flex flex-wrap items-center gap-3 rounded-2xl border p-4 ${item.read ? 'bg-white' : 'border-brand/40 bg-brand/5'}`} data-testid={`notification-${item.id}`} data-read={item.read}>
      {actor ? <Avatar player={actor} /> : <span className="grid size-10 place-items-center rounded-full bg-black/5 text-xl">{d.emoji}</span>}
      <div className="min-w-0 flex-1">
        <p className="text-sm">{d.href ? <Link href={d.href} onClick={() => onOpen(item)} className="inline-block py-1 hover:text-brand">{d.emoji} {d.text}</Link> : <span>{d.emoji} {d.text}</span>}</p>
        <p className="text-xs text-ink/40">{ago(item.createdAt)}{!item.read && ' · new'}</p>
      </div>
      {friendRequestPending && actor && (
        <div className="flex gap-2">
          <button className={`${btn} bg-brand text-white`} onClick={() => social.acceptFriend(friendRequestPending.id, actor)}>Accept</button>
          <button className={`${btn} border`} onClick={() => social.declineFriend(friendRequestPending.id)}>Decline</button>
        </div>
      )}
      {followRequestPending && actor && (
        <div className="flex gap-2">
          <button className={`${btn} bg-brand text-white`} onClick={() => social.acceptFollow(actor)}>Accept</button>
          <button className={`${btn} border`} onClick={() => social.declineFollow(actor)}>Decline</button>
        </div>
      )}
    </li>
  );
}
