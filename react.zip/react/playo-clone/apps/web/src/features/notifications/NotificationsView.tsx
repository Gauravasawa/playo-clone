'use client';

import { app } from '@/store';
import { api, type NotificationItem } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { NotificationItemRow } from './NotificationItemRow';
import { PushToggle } from './PushToggle';

const KEPT_PAGES = 3; // the `max` of the notifications query

export function NotificationsView() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [pages, , status] = app.useGlobalState('notifications', token ?? undefined);

  if (!mounted) return null;
  if (!token)
    return (
      <>
      <h1 className="mb-4 text-2xl font-extrabold">Notifications</h1>
      <EmptyState>
        <p className="mb-3">Log in to see your notifications.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
      </>
    );

  const items = pages.flatMap((p) => p.items);
  const unread = pages[0]?.unread ?? 0;

  /** Marks some (or all) notifications read, here and in every other open tab */
  const markRead = async (ids?: number[]) => {
    try {
      await api.markRead(token, ids);
      app.emit('notifications-read', { ids: ids ?? 'all' }, { broadcast: true });
      app.fetchQuery('badges', token, true).catch(() => {});
      app.invalidate('notifications');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not mark as read' });
    }
  };
  const open = (n: NotificationItem) => { if (!n.read) markRead([n.id]); };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-extrabold">Notifications</h1>
        {unread > 0 && <span data-testid="unread-count" data-tip={`${unread} unread`} className="rounded-full bg-red-600 px-2 text-sm font-bold text-white">{unread}</span>}
        <button disabled={unread === 0} onClick={() => markRead()} className="ml-auto rounded-full border px-4 py-1.5 text-sm font-semibold hover:bg-black/5">Mark all read</button>
      </div>

      <PushToggle />

      {status.state === 'loading' || status.state === 'waiting' ? (
        <Skeleton count={4} className="h-16" />
      ) : status.state === 'error' ? (
        <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load notifications.</ErrorNotice>
      ) : items.length === 0 ? (
        <EmptyState>Nothing yet. Friend requests, follows, games and bookings show up here.</EmptyState>
      ) : (
        <>
          <ul className="space-y-2" data-testid="notification-list">{items.map((n) => <NotificationItemRow key={n.id} item={n} onOpen={open} />)}</ul>
          {pages.length >= KEPT_PAGES && (
            <p className="text-center text-xs text-ink/40" data-testid="kept-pages-note">Showing {items.length} notifications: the list keeps the latest {KEPT_PAGES} pages loaded and drops the oldest from memory.</p>
          )}
          {status.hasNextPage && (
            <div className="text-center">
              <button onClick={() => status.fetchNextPage()} disabled={status.isFetchingNextPage} className="rounded-full border bg-white px-6 py-2 font-semibold hover:bg-black/5">
                {status.isFetchingNextPage ? 'Loading…' : 'Load more'}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
