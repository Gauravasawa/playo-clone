'use client';

import { app } from '@/store';
import { askForPush, pushPermission } from '@/lib/push';

/** Browser notifications for when this tab is in the background; the browser asks permission when it is switched on */
export function PushToggle() {
  const [enabled, setEnabled] = app.useGlobalState('pushEnabled');
  const permission = pushPermission();

  const toggle = async () => {
    if (enabled) return setEnabled(false);
    if (await askForPush()) {
      setEnabled(true);
      app.emit('toast', { kind: 'ok', text: 'Browser notifications on' });
    } else {
      app.emit('toast', { kind: 'err', text: permission === 'unsupported' ? 'This browser does not support notifications' : 'Notifications are blocked in your browser settings' });
    }
  };

  return (
    <label className="flex items-center gap-3 rounded-xl bg-black/[0.03] p-3 text-sm" data-testid="push-toggle">
      <input type="checkbox" className="size-4" checked={enabled && permission === 'granted'} onChange={toggle} disabled={permission === 'unsupported'} />
      <span><b>Browser notifications.</b> Get a pop-up for new messages and requests while this tab is in the background.{permission === 'denied' && ' (Blocked in your browser settings.)'}</span>
    </label>
  );
}
