import type { NotificationItem } from '@/lib/api';
import { formatInr } from '@/config/cities';

export interface Described { emoji: string; text: string; href?: string }

/** One line for a notification, shared by the list, the live toast and the browser notification */
export function describe(n: NotificationItem): Described {
  const d = n.data;
  const who = d.actor?.name ?? 'Someone';
  const profile = d.actor ? `/p/${d.actor.username}` : undefined;
  const game = d.gameId ? `/games/${d.gameId}` : '/games';
  switch (n.type) {
    // people
    case 'friend_request': return { emoji: '🤝', text: `${who} sent you a friend request`, href: '/friends' };
    case 'friend_accepted': return { emoji: '✅', text: `${who} accepted your friend request`, href: profile };
    case 'friend_declined': return { emoji: '🚫', text: `${who} declined your friend request`, href: profile };
    case 'follow_request': return { emoji: '👤', text: `${who} wants to follow you`, href: '/friends' };
    case 'follow_accepted': return { emoji: '✅', text: `${who} accepted your follow request`, href: profile };
    case 'new_follower': return { emoji: '👀', text: `${who} started following you`, href: profile };
    case 'added_to_group': return { emoji: '👥', text: `${who} added you to “${d.title}”`, href: `/chat/${d.chatId}` };
    // games
    case 'game_joined': return { emoji: '🎮', text: `${who} joined your game “${d.title}”`, href: game };
    case 'game_join_request': return { emoji: '🙋', text: `${who} (${d.level}) asked to join “${d.title}”`, href: game };
    case 'game_request_approved': return { emoji: '✅', text: `${who} approved your request to join “${d.title}”`, href: game };
    case 'game_request_declined': return { emoji: '🚫', text: `Your request to join “${d.title}” was declined${d.refunded ? ` and ${formatInr(Number(d.refunded))} refunded` : ''}`, href: '/games' };
    case 'game_invite': return { emoji: '💌', text: `${who} invited you to “${d.title}”`, href: game };
    case 'game_ended': return { emoji: '🏁', text: `“${d.title}” ended${d.won ? ' — you won!' : ''}${d.attended === false ? ' (marked absent)' : '. Rate the players you played with.'}`, href: '/friends' };
    // money
    case 'booking_confirmed': return { emoji: '📅', text: `Booking confirmed at ${d.venue} on ${d.date} (${formatInr(Number(d.paid))})`, href: '/bookings' };
    case 'booking_cancelled': return { emoji: '↩️', text: `Booking cancelled, ${formatInr(Number(d.refunded))} (${d.percent}%) refunded to your wallet`, href: '/wallet' };
    case 'booking_rescheduled': return { emoji: '🔁', text: `Booking at ${d.venue} moved to ${d.date}`, href: '/bookings' };
    case 'gift_card_received': return { emoji: '🎁', text: `${who} sent you a ${formatInr(Number(d.amount))} gift card: ${d.code}`, href: '/wallet?tab=gift' };
    case 'gift_card_redeemed': return { emoji: '🎁', text: `${who} used your ${formatInr(Number(d.amount))} gift card`, href: '/wallet?tab=gift' };
    case 'plus_started': return { emoji: '✨', text: 'You are a Playo Plus member now. Enjoy 2x Karma and no booking fees.', href: '/plus' };
    case 'pass_bought': return { emoji: '🎟️', text: `${d.kind === 'daily' ? 'Day pass' : 'Monthly membership'} bought for ${d.venue}`, href: '/wallet?tab=passes' };
    case 'referral_bonus': return { emoji: '🎉', text: `${formatInr(Number(d.amount))} referral bonus added to your wallet`, href: '/wallet?tab=referrals' };
    case 'referral_reward': return { emoji: '🎉', text: `${who} made their first booking: you got ${formatInr(Number(d.amount))} and ${d.points} Karma`, href: '/wallet?tab=referrals' };
    case 'tournament_registered': return { emoji: '🏆', text: `You're registered for ${d.name}`, href: '/tournaments' };
    // learning and events
    case 'coach_enquiry_sent': return { emoji: '📨', text: `Your enquiry was sent to ${d.name}` };
    case 'program_enrolled': return { emoji: '🎓', text: `You're enrolled in ${d.title}, starting ${d.startsOn}`, href: '/learning' };
    case 'session_booked': return { emoji: '🧑‍🏫', text: `Trial session with ${d.coach} booked for ${d.date} at ${d.time}`, href: '/learning' };
    case 'event_registered': return { emoji: '🎽', text: `You're going to ${d.title}${d.bib ? ` (bib ${d.bib})` : ''}`, href: `/events/${d.eventId}` };
    case 'event_rsvp': return { emoji: '🙌', text: `Someone is ${d.answer === 'maybe' ? 'maybe coming to' : 'coming to'} ${d.title}`, href: `/events/${d.eventId}` };
    // venue owners
    case 'owner_booking': return { emoji: '💼', text: `${who} booked ${d.venue} on ${d.date} (${formatInr(Number(d.paid))})`, href: `/owner/${d.venueId}` };
    case 'venue_claimed': return { emoji: '🏟️', text: `You now run ${d.name}`, href: '/owner' };
    case 'review_reply': return { emoji: '💬', text: 'A venue owner replied to your review', href: `/venues/${d.venueId}#reviews` };
    // help and safety
    case 'ticket_reply': return { emoji: '🛟', text: `Support replied: “${d.subject}”`, href: `/help/tickets/${d.ticketId}` };
    case 'report_filed': return { emoji: '🚩', text: `New ${d.kind} report: ${d.reason}`, href: '/admin/reports' };
    case 'report_update': return { emoji: '🚩', text: `Your report was ${d.status}` };
    case 'welcome': return { emoji: '🎉', text: String(d.text ?? 'Welcome!') };
    default: return { emoji: '🔔', text: String(d.text ?? n.type) };
  }
}
