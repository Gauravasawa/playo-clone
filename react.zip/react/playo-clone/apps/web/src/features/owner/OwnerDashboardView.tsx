'use client';

import Link from 'next/link';
import { useEffect, useMemo, useRef, useState } from 'react';
import { app } from '@/store';
import { api, type OwnerDashboard } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { formatInr, formatLocal } from '@/config/cities';
import { nextDays } from '@/lib/format';
import { describe } from '@/features/notifications/describe';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { Tabs } from '@/components/ui/Tabs';
import { PricePreview, type PriceField } from './PricePreview';

type Tab = 'bookings' | 'blocks' | 'pricing' | 'revenue' | 'reviews' | 'alerts';
const HOURS = Array.from({ length: 17 }, (_, i) => `${String(6 + i).padStart(2, '0')}:00`);
const errorText = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong');

export function OwnerDashboardView({ id }: { id: number }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const days = useMemo(() => nextDays(7), []);
  const [date, setDate] = useState(() => days[0].value);
  const [tab, setTab] = useState<Tab>('bookings');
  const params = token && mounted ? { token, id, date } : undefined;
  const [data, , status] = app.useGlobalState('ownerVenue', params);

  if (!mounted) return null;
  if (!token)
    return (
      <EmptyState>
        <p className="mb-3">Log in to manage your venue.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
    );
  if (!data) {
    if (status.state === 'error') return <ErrorNotice onRetry={status.refetch}>{status.error instanceof Error ? status.error.message : "Couldn't load this venue."} <Link href="/owner" className="underline">Back to my venues</Link></ErrorNotice>;
    return <Skeleton count={3} />;
  }
  const v = data.venue;

  return (
    <div className="space-y-5" data-testid="owner-dashboard">
      <div>
        <Link href="/owner" className="inline-block py-1.5 text-sm text-brand underline">← My venues</Link>
        <h1 className="text-2xl font-extrabold" data-testid="owner-venue-name">{v.name}</h1>
        <p className="text-sm text-ink/60">{v.area}, {v.city} · {formatLocal(data.pricing.pricePerHour, v.city)}/hr · peak +{formatLocal(data.pricing.peakExtra, v.city)}</p>
      </div>
      <div className="grid grid-cols-3 gap-3 text-center">
        <Stat label="Bookings" value={v.stats.bookings} testId="stat-bookings" />
        <Stat label="Upcoming" value={v.stats.upcoming} testId="stat-upcoming" />
        <Stat label="Earned" value={formatInr(v.stats.revenueInr)} testId="stat-revenue" />
      </div>
      <Tabs<Tab>
        value={tab}
        onChange={setTab}
        tabs={[
          { id: 'bookings', label: 'Bookings', badge: data.bookings.length || undefined },
          { id: 'blocks', label: 'Block slots' },
          { id: 'pricing', label: 'Pricing' },
          { id: 'revenue', label: 'Revenue' },
          { id: 'reviews', label: 'Reviews' },
          { id: 'alerts', label: 'Notifications' },
        ]}
      />
      {tab === 'bookings' && <Bookings data={data} />}
      {tab === 'blocks' && <Blocks token={token} id={id} data={data} days={days} date={date} onDate={setDate} />}
      {tab === 'pricing' && <Pricing token={token} id={id} data={data} />}
      {tab === 'revenue' && <Revenue data={data} />}
      {tab === 'reviews' && <Reviews token={token} data={data} />}
      {tab === 'alerts' && <Alerts token={token} venueId={id} />}
    </div>
  );
}

function Stat({ label, value, testId }: { label: string; value: string | number; testId: string }) {
  return <div className="rounded-xl border bg-white p-3"><p className="text-xs text-ink/50">{label}</p><p className="text-lg font-bold" data-testid={testId}>{value}</p></div>;
}

function Bookings({ data }: { data: OwnerDashboard }) {
  if (!data.bookings.length) return <EmptyState>No upcoming bookings.</EmptyState>;
  return (
    <ul className="space-y-2" data-testid="owner-bookings">
      {data.bookings.map((b) => (
        <li key={b.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded-xl border bg-white p-3 text-sm" data-testid={`owner-booking-${b.id}`}>
          <b>{b.date}</b><span>{b.slots.join(', ')}</span>
          <span className="text-ink/60">{b.player ? `${b.player.name} (@${b.player.username})` : 'Player'}</span>
          <span className="ml-auto font-semibold">{formatInr(b.paid)}</span>
        </li>
      ))}
    </ul>
  );
}

function Blocks({ token, id, data, days, date, onDate }: { token: string; id: number; data: OwnerDashboard; days: { value: string; day: string; date: string }[]; date: string; onDate: (d: string) => void }) {
  const [picked, setPicked] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const blocked = data.blocked.times;
  useEffect(() => { setPicked([]); }, [date]);

  const run = async (kind: 'block' | 'unblock') => {
    setBusy(true);
    try {
      await (kind === 'block' ? api.blockHours : api.unblockHours)(token, id, { date, times: picked });
      app.emit('toast', { kind: 'ok', text: `${picked.length} hour${picked.length > 1 ? 's' : ''} ${kind === 'block' ? 'blocked' : 'open again'}` });
      setPicked([]);
      app.invalidate('ownerVenue');
      app.invalidate('slots');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: errorText(e) });
    } finally {
      setBusy(false);
    }
  };
  const taken = new Set(data.bookings.filter((b) => b.date === date).flatMap((b) => b.slots));

  return (
    <div className="space-y-3">
      <div className="flex gap-2 overflow-x-auto">
        {days.map((d) => (
          <button key={d.value} onClick={() => onDate(d.value)} aria-pressed={date === d.value} data-testid={`block-day-${d.value}`} className={`rounded-xl border px-3 py-1.5 text-sm ${date === d.value ? 'border-brand bg-brand text-white' : 'bg-white hover:bg-black/5'}`}>{d.day} {d.date}</button>
        ))}
      </div>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-6" data-testid="block-grid">
        {HOURS.map((t) => {
          const isBlocked = blocked.includes(t);
          const isBooked = taken.has(t);
          const isPicked = picked.includes(t);
          return (
            <button key={t} disabled={isBooked} onClick={() => setPicked(isPicked ? picked.filter((x) => x !== t) : [...picked, t])} aria-pressed={isPicked} data-testid={`block-${t}`}
              className={`rounded-lg border px-2 py-2 text-sm ${isBooked ? 'cursor-not-allowed bg-gray-100 text-ink/30' : isBlocked ? 'bg-red-50 text-red-700' : 'bg-white'} ${isPicked ? 'ring-2 ring-brand' : ''}`}>
              {t}<span className="block text-[10px]">{isBooked ? 'booked' : isBlocked ? 'blocked' : 'open'}</span>
            </button>
          );
        })}
      </div>
      <div className="flex gap-2">
        <button disabled={busy || !picked.length || picked.every((t) => blocked.includes(t))} onClick={() => run('block')} data-testid="block-hours" className="rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-40">Block selected</button>
        <button disabled={busy || !picked.length || !picked.some((t) => blocked.includes(t))} onClick={() => run('unblock')} data-testid="unblock-hours" className="rounded-full border px-4 py-2 text-sm font-semibold disabled:opacity-40">Open selected</button>
      </div>
    </div>
  );
}

function Pricing({ token, id, data }: { token: string; id: number; data: OwnerDashboard }) {
  const [hourly, setHourly] = useState(String(data.pricing.pricePerHour));
  const [peak, setPeak] = useState(String(data.pricing.peakExtra));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  // the editor and its preview point at each other: `hot` is the field being hovered, focused or picked
  const [hot, setHot] = useState<PriceField | null>(null);
  const [flash, setFlash] = useState<PriceField | null>(null);
  const fields = { hourly: useRef<HTMLInputElement>(null), peak: useRef<HTMLInputElement>(null) };
  const pick = (f: PriceField) => {
    const el = fields[f].current;
    if (!el) return;
    el.scrollIntoView({ block: 'nearest', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    el.focus({ preventScroll: true });
    el.select();
    setFlash(f);
    setTimeout(() => setFlash((cur) => (cur === f ? null : cur)), 1400);
  };
  const h = Number(hourly) || 0;
  const p = Number(peak) || 0;
  const dirty = h !== data.pricing.pricePerHour || p !== data.pricing.peakExtra;
  const city = data.venue.city;

  const save = async () => {
    setBusy(true);
    setError('');
    try {
      await api.setPricing(token, id, { pricePerHour: h, peakExtra: p });
      app.emit('toast', { kind: 'ok', text: 'Prices updated' });
      app.invalidate('ownerVenue');
      app.invalidate('venue');
      app.invalidate('venues');
      app.invalidate('slots');
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  };

  const input = 'w-28 rounded-lg border px-3 py-1.5';
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="space-y-3 rounded-2xl border bg-white p-5 text-sm">
        <p className="text-ink/60">Prices are held in rupees. {city} shows them in the city&apos;s currency.</p>
        <label data-testid="field-hourly" data-lit={hot === 'hourly' || flash === 'hourly'} onMouseEnter={() => setHot('hourly')} onMouseLeave={() => setHot(null)} title="The price of one hour. It also sets every row in the preview." className={`flex items-center justify-between rounded-lg px-2 py-1 transition ${hot === 'hourly' || flash === 'hourly' ? 'bg-brand/10 ring-2 ring-brand' : ''}`}>Price per hour (₹)<input ref={fields.hourly} data-testid="price-hourly" type="number" min={50} value={hourly} onChange={(e) => setHourly(e.target.value)} onFocus={() => setHot('hourly')} onBlur={() => setHot(null)} className={input} /></label>
        <label data-testid="field-peak" data-lit={hot === 'peak' || flash === 'peak'} onMouseEnter={() => setHot('peak')} onMouseLeave={() => setHot(null)} title="Added on top of the hourly price for 18:00–21:00 only. It changes the peak rows in the preview." className={`flex items-center justify-between rounded-lg px-2 py-1 transition ${hot === 'peak' || flash === 'peak' ? 'bg-brand/10 ring-2 ring-brand' : ''}`}>Peak extra, 18:00–21:00 (₹)<input ref={fields.peak} data-testid="price-peak" type="number" min={0} value={peak} onChange={(e) => setPeak(e.target.value)} onFocus={() => setHot('peak')} onBlur={() => setHot(null)} className={input} /></label>
        {error && <p className="text-red-600" data-testid="pricing-error">{error}</p>}
        <button disabled={busy || !dirty} onClick={save} data-testid="save-pricing" className="w-full rounded-xl bg-brand py-2.5 font-bold text-white disabled:opacity-40">{busy ? 'Saving…' : 'Save prices'}</button>
      </div>
      <PricePreview hourly={h} peak={p} city={city} equipment={data.venue.equipment} hot={hot} onHot={setHot} onPick={pick} />
    </div>
  );
}

function Revenue({ data }: { data: OwnerDashboard }) {
  const rows = data.revenue;
  const max = Math.max(1, ...rows.map((r) => r.revenue));
  const total = rows.reduce((s, r) => s + r.revenue, 0);
  if (!rows.length) return <EmptyState>No paid bookings in the last 30 days.</EmptyState>;
  return (
    <div className="space-y-3 rounded-2xl border bg-white p-5" data-testid="revenue">
      <p className="text-sm">Last 30 days: <b data-testid="revenue-total">{formatInr(total)}</b> from {rows.reduce((s, r) => s + r.bookings, 0)} bookings</p>
      <ul className="space-y-1">
        {rows.map((r) => (
          <li key={r.date} className="flex items-center gap-2 text-xs">
            <span className="w-20 shrink-0 text-ink/60">{r.date}</span>
            <span className="h-4 rounded bg-brand" style={{ width: `${Math.max(2, (r.revenue / max) * 100)}%` }} />
            <span className="shrink-0">{formatInr(r.revenue)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Reviews({ token, data }: { token: string; data: OwnerDashboard }) {
  const [drafts, setDrafts] = useState<Record<number, string>>({});
  const [busy, setBusy] = useState<number | null>(null);
  if (!data.reviews.length) return <EmptyState>No reviews yet.</EmptyState>;

  const reply = async (reviewId: number) => {
    setBusy(reviewId);
    try {
      await api.replyToReview(token, reviewId, drafts[reviewId] ?? '');
      setDrafts((d) => ({ ...d, [reviewId]: '' }));
      app.emit('toast', { kind: 'ok', text: 'Reply posted' });
      app.invalidate('ownerVenue');
      app.invalidate('venueReviews');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: errorText(e) });
    } finally {
      setBusy(null);
    }
  };

  return (
    <ul className="space-y-3" data-testid="owner-reviews">
      {data.reviews.map((r) => (
        <li key={r.id} className="space-y-2 rounded-xl border bg-white p-4 text-sm" data-testid={`owner-review-${r.id}`}>
          <p><b>{'★'.repeat(r.rating)}</b> <span className="text-ink/60">by {r.author?.name ?? 'a player'}</span></p>
          {r.body && <p>{r.body}</p>}
          {r.reply ? (
            <p className="rounded-lg bg-brand/5 p-2" data-testid={`reply-${r.id}`}><b>Your reply:</b> {r.reply.body}</p>
          ) : (
            <div className="flex gap-2">
              <input aria-label="Reply" placeholder="Reply to this review" value={drafts[r.id] ?? ''} onChange={(e) => setDrafts({ ...drafts, [r.id]: e.target.value })} className="flex-1 rounded-lg border px-3 py-1.5" />
              <button disabled={busy === r.id || !(drafts[r.id] ?? '').trim()} onClick={() => reply(r.id)} data-testid={`reply-send-${r.id}`} className="rounded-lg bg-brand px-4 text-white disabled:opacity-40">Reply</button>
            </div>
          )}
        </li>
      ))}
    </ul>
  );
}

/** The owner's own notifications (new bookings, claims), from the same notifications query the bell uses */
function Alerts({ token, venueId }: { token: string; venueId: number }) {
  const [pages, , status] = app.useGlobalState('notifications', token);
  const items = pages.flatMap((p) => p.items).filter((n) => n.type === 'owner_booking' || n.type === 'venue_claimed').filter((n) => n.type === 'venue_claimed' || n.data.venueId === venueId);
  if (status.state === 'loading' && !items.length) return <Skeleton count={2} className="h-12" />;
  if (!items.length) return <EmptyState>No booking alerts yet. New bookings show up here live.</EmptyState>;
  return (
    <ul className="space-y-2" data-testid="owner-alerts">
      {items.map((n) => { const d = describe(n); return <li key={n.id} className="rounded-xl border bg-white p-3 text-sm">{d.emoji} {d.text}</li>; })}
    </ul>
  );
}
