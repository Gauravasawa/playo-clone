'use client';

import Link from 'next/link';
import { useState } from 'react';
import { app } from '@/store';
import { api, type OwnerVenue } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { CITIES, formatInr, formatLocal, currencyOf, CURRENCIES } from '@/config/cities';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Modal } from '@/components/ui/Modal';
import { Skeleton } from '@/components/ui/Skeleton';

const AMENITIES = ['Parking', 'Washroom', 'Changing room', 'Floodlights', 'Drinking water', 'Cafe', 'Equipment rental', 'First aid'];

const errorText = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong');

export function OwnerHome() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [city, setCity] = app.useGlobalState('city');
  const [venues, , status] = app.useGlobalState('ownerVenues', token ?? undefined);
  const [claimable, , claimStatus] = app.useGlobalState('claimable', token ? { token, city } : undefined);
  const [creating, setCreating] = useState(false);
  const [claiming, setClaiming] = useState<number | null>(null);

  if (!mounted) return null;
  if (!token)
    return (
      <>
      <h1 className="mb-4 text-2xl font-extrabold">Venue owner</h1>
      <EmptyState>
        <p className="mb-3">Log in to list or claim a venue.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
      </>
    );

  const claim = async (id: number) => {
    setClaiming(id);
    try {
      await api.claimVenue(token, id);
      app.emit('toast', { kind: 'ok', text: 'Venue claimed. It is yours to manage now.' });
      app.invalidate('ownerVenues');
      app.invalidate('claimable');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: `Couldn't claim: ${errorText(e)}` });
    } finally {
      setClaiming(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-extrabold">Venue owner</h1>
        <button onClick={() => setCreating(true)} data-testid="new-venue" className="ml-auto rounded-full bg-brand px-4 py-2 text-sm font-semibold text-white hover:bg-brand-dark">+ List a new venue</button>
      </div>

      <section className="space-y-3">
        <h2 className="font-bold">My venues</h2>
        {status.state === 'loading' || status.state === 'waiting' ? <Skeleton count={2} /> : status.state === 'error' ? (
          <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load your venues.</ErrorNotice>
        ) : !venues?.length ? (
          <EmptyState>You don&apos;t run any venue yet. Claim one below or list a new one.</EmptyState>
        ) : (
          <ul className="grid gap-3 md:grid-cols-2">
            {venues.map((v) => <MyVenue key={v.id} v={v} />)}
          </ul>
        )}
      </section>

      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <h2 className="font-bold">Claim an existing venue in</h2>
          <select aria-label="City" value={city} onChange={(e) => setCity(e.target.value)} className="rounded-lg border bg-white px-2 py-1 text-sm">
            {CITIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        {claimStatus.state === 'loading' || claimStatus.state === 'waiting' ? <Skeleton count={2} className="h-16" /> : !claimable?.length ? (
          <EmptyState>Nothing left to claim in {city}.</EmptyState>
        ) : (
          <ul className="grid gap-2 md:grid-cols-2">
            {claimable.map((v) => (
              <li key={v.id} className="flex items-center gap-3 rounded-xl border bg-white p-3" data-testid={`claimable-${v.id}`}>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{v.name}</p>
                  <p className="text-xs text-ink/60">{v.area} · {formatLocal(v.pricePerHour, v.city)}/hr</p>
                </div>
                <button disabled={claiming === v.id} onClick={() => claim(v.id)} data-testid={`claim-${v.id}`} className="rounded-full border px-3 py-1 text-sm font-semibold hover:bg-black/5">{claiming === v.id ? 'Claiming…' : 'Claim'}</button>
              </li>
            ))}
          </ul>
        )}
      </section>

      {creating && <NewVenueModal token={token} defaultCity={city} onClose={() => setCreating(false)} />}
    </div>
  );
}

function MyVenue({ v }: { v: OwnerVenue }) {
  return (
    <li data-testid={`owner-venue-${v.id}`}>
      <Link href={`/owner/${v.id}`} className="block space-y-1 rounded-2xl border bg-white p-4 hover:shadow">
        <p className="font-bold">{v.name}{v.custom && <span className="ml-2 rounded-full bg-brand/10 px-2 py-0.5 text-xs font-semibold text-brand">your listing</span>}</p>
        <p className="text-sm text-ink/60">{v.area}, {v.city} · {formatLocal(v.pricePerHour, v.city)}/hr</p>
        <p className="text-sm">{v.stats.upcoming} upcoming · {v.stats.bookings} bookings · <b>{formatInr(v.stats.revenueInr)}</b> earned</p>
      </Link>
    </li>
  );
}

function NewVenueModal({ token, defaultCity, onClose }: { token: string; defaultCity: string; onClose: () => void }) {
  const [sportsData] = app.useGlobalState('sports');
  const sports = sportsData ?? []; // the query is undefined until it loads
  const [form, setForm] = useState({ name: '', city: defaultCity, area: '', price: '600', address: '', description: '' });
  const [picked, setPicked] = useState<string[]>([]);
  const [amenities, setAmenities] = useState<string[]>(['Parking']);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const symbol = CURRENCIES[currencyOf(form.city)].symbol.trim();
  const toggle = (list: string[], set: (v: string[]) => void, x: string) => set(list.includes(x) ? list.filter((y) => y !== x) : [...list, x]);

  const submit = async () => {
    setBusy(true);
    setError('');
    try {
      await api.createVenue(token, {
        name: form.name, city: form.city, area: form.area, sports: picked, pricePerHourLocal: Number(form.price),
        amenities, address: form.address, description: form.description,
      });
      app.emit('toast', { kind: 'ok', text: `${form.name} is listed` });
      app.invalidate('ownerVenues');
      app.invalidate('venues');
      onClose();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  };

  const input = 'w-full rounded-lg border px-3 py-2';
  return (
    <Modal title="List a new venue" onClose={onClose}>
      <form data-testid="venue-form" onSubmit={(e) => { e.preventDefault(); submit(); }} className="space-y-3 text-sm">
        <input aria-label="Venue name" placeholder="Venue name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={input} />
        <div className="flex gap-2">
          <select aria-label="Venue city" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className={`${input} flex-1`}>{CITIES.map((c) => <option key={c}>{c}</option>)}</select>
          <input aria-label="Area" placeholder="Area" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} className={`${input} flex-1`} />
        </div>
        <input aria-label="Address" placeholder="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className={input} />
        <textarea aria-label="Description" placeholder="Describe the venue" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className={input} rows={2} />
        <label className="flex items-center gap-2">Price per hour ({symbol}) <input aria-label="Price per hour" type="number" min={1} value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="w-28 rounded-lg border px-3 py-1.5" /></label>
        <fieldset><legend className="mb-1 font-semibold">Sports</legend>
          <div className="flex flex-wrap gap-1.5">{(sports ?? []).map((s) => (
            <button type="button" key={s.id} aria-pressed={picked.includes(s.id)} onClick={() => toggle(picked, setPicked, s.id)} className={`rounded-full border px-3 py-1 ${picked.includes(s.id) ? 'border-brand bg-brand text-white' : 'hover:bg-black/5'}`}>{s.emoji} {s.name}</button>
          ))}</div>
        </fieldset>
        <fieldset><legend className="mb-1 font-semibold">Amenities</legend>
          <div className="flex flex-wrap gap-1.5">{AMENITIES.map((a) => (
            <button type="button" key={a} aria-pressed={amenities.includes(a)} onClick={() => toggle(amenities, setAmenities, a)} className={`rounded-full border px-3 py-1 ${amenities.includes(a) ? 'border-brand bg-brand/10 text-brand' : 'hover:bg-black/5'}`}>{a}</button>
          ))}</div>
        </fieldset>
        {error && <p className="text-red-600" data-testid="venue-error">{error}</p>}
        <button disabled={busy} data-testid="venue-submit" className="w-full rounded-xl bg-brand py-3 font-bold text-white hover:bg-brand-dark">{busy ? 'Listing…' : 'List venue'}</button>
      </form>
    </Modal>
  );
}
