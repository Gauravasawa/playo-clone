'use client';

import { useEffect, useState } from 'react';
import { app } from '@/store';
import type { Equipment } from '@/lib/api';
import { formatPrice } from '@/config/cities';

/** The editable fields on the left of the pricing editor; the preview points at them */
export type PriceField = 'hourly' | 'peak';

interface Props {
  hourly: number;
  peak: number;
  city: string;
  equipment: Equipment[];
  /** the field being hovered or focused on the left (or the one a preview row maps to): its preview rows light up */
  hot: PriceField | null;
  onHot: (field: PriceField | null) => void;
  /** a click in the preview: the editor focuses and selects that field */
  onPick: (field: PriceField) => void;
}

const SAMPLE_HOURS = ['17:00', '18:00', '19:00']; // 18:00 and 19:00 are peak hours

/**
 * What a player would pay at these prices. It runs in its own <app.Root scope={...}>: a scope of the
 * app store made with `app.createScope()`, nested inside the page's Root. The slots, rentals, Plus switch
 * and the `quote` computed value below live only in that scope; the owner's typing never touches the
 * real `selection` / `checkout` of the app store (the second line shows that).
 */
export function PricePreview(props: Props) {
  // one scope per mount; `pricing` is seeded, everything else starts from the store's initial state
  const [scope] = useState(() =>
    app.createScope({ pricing: { equipment: props.equipment, isPlus: false, karmaBalance: 400, passCoversSlots: false } })
  );
  return (
    <app.Root scope={scope}>
      <PreviewBody {...props} />
    </app.Root>
  );
}

function PreviewBody({ hourly, peak, city, equipment, hot, onHot, onPick }: Props) {
  // These three hooks are the preview scope's, because the nearest Root is the nested one
  const [selection, setSelection] = app.useGlobalState('selection');
  const [checkout, setCheckout] = app.useGlobalState('checkout');
  const [pricing, setPricing] = app.useGlobalState('pricing');
  const [quote] = app.useGlobalState('quote');
  const [slotCount] = app.useGlobalState('slotCount');

  useEffect(() => {
    setSelection({
      venueId: 0,
      date: 'preview',
      slots: SAMPLE_HOURS.map((time) => ({ time, price: hourly + (time >= '18:00' ? peak : 0) })),
    });
  }, [hourly, peak, setSelection]);

  const rental = equipment[0];
  return (
    <div className="space-y-2 rounded-xl border border-dashed bg-brand/5 p-4 text-sm" data-testid="price-preview">
      <p className="font-semibold">What players will see ({slotCount} sample hours)</p>
      <p className="text-xs text-ink/60">Click a price to edit it on the left.</p>
      <ul className="space-y-0.5">
        {selection.slots.map((s) => {
          const isPeak = s.time >= '18:00';
          const field: PriceField = isPeak ? 'peak' : 'hourly';
          // the price per hour changes every row; the peak extra only the peak rows
          const lit = hot === 'hourly' || (hot === 'peak' && isPeak);
          const what = isPeak ? 'the peak extra' : 'the price per hour';
          return (
            <li key={s.time}>
              <button
                type="button"
                data-testid={`preview-row-${s.time}`}
                data-lit={lit}
                onClick={() => onPick(field)}
                onMouseEnter={() => onHot(field)}
                onMouseLeave={() => onHot(null)}
                onFocus={() => onHot(field)}
                onBlur={() => onHot(null)}
                title={`Click to edit ${what}`}
                aria-label={`${s.time}${isPeak ? ' peak' : ''}, ${formatPrice(s.price, city)}. Edit ${what}`}
                className={`flex w-full justify-between rounded-md px-2 py-1 text-left transition hover:bg-black/5 ${lit ? 'bg-brand/15 ring-1 ring-brand' : ''}`}
              >
                <span>{s.time}{isPeak && ' · peak'}</span><span data-testid={`preview-slot-${s.time}`}>{formatPrice(s.price, city)}</span>
              </button>
            </li>
          );
        })}
      </ul>
      <div className="flex flex-wrap gap-3 border-t pt-2">
        <label className="flex min-h-7 items-center gap-1"><input type="checkbox" checked={pricing.isPlus} onChange={(e) => setPricing({ ...pricing, isPlus: e.target.checked })} /> Player has Plus</label>
        <label className="flex min-h-7 items-center gap-1"><input type="checkbox" checked={checkout.useKarma} onChange={(e) => setCheckout({ ...checkout, useKarma: e.target.checked })} /> Uses Karma</label>
        {rental && (
          <label className="flex min-h-7 items-center gap-1"><input type="checkbox" checked={checkout.extras.includes(rental.id)} onChange={() => setCheckout({ ...checkout, extras: checkout.extras.includes(rental.id) ? [] : [rental.id] })} /> Rents {rental.name}</label>
        )}
      </div>
      <dl className="space-y-0.5">
        <div className="flex justify-between"><dt>Slots</dt><dd data-testid="preview-slots">{formatPrice(quote.slotsInr, city)}</dd></div>
        {quote.extrasInr > 0 && <div className="flex justify-between"><dt>Rentals</dt><dd>{formatPrice(quote.extrasInr, city)}</dd></div>}
        {quote.karmaDiscountInr > 0 && <div className="flex justify-between text-green-700"><dt>Karma</dt><dd>−{formatPrice(quote.karmaDiscountInr, city)}</dd></div>}
        <div className="flex justify-between" title="Set by Playo, not by you: 3% of what the player pays (at least ₹10, at most ₹100), waived for Plus members"><dt>Convenience fee</dt><dd>{formatPrice(quote.feeInr, city)}</dd></div>
        <div className="flex justify-between font-bold"><dt>Player pays</dt><dd data-testid="preview-payable">{formatPrice(quote.payableInr, city)}</dd></div>
      </dl>
      <GlobalCheck />
    </div>
  );
}

/** `app.getState` always talks to the app's own store, never the nested scope: the preview must not change it */
function GlobalCheck() {
  const [n, setN] = useState<{ slots: number; extras: number } | null>(null);
  useEffect(() => {
    const read = () => setN({ slots: app.getState('selection').slots.length, extras: app.getState('checkout').extras.length });
    read();
    const t = setInterval(read, 300);
    return () => clearInterval(t);
  }, []);
  return (
    <p className="text-xs text-ink/50" data-testid="preview-global-check" data-slots={n?.slots} data-extras={n?.extras}>
      App store: {n ? `${n.slots} slots picked, ${n.extras} rentals (not changed by this preview)` : '…'}
    </p>
  );
}
