'use client';

import { useState } from 'react';
import { app } from '@/store';
import { api } from '@/lib/api';
import { money } from '@/lib/format';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { PaymentPicker, usePaymentChoice } from '@/components/ui/PaymentPicker';
import { Skeleton } from '@/components/ui/Skeleton';

const BENEFITS = [
  ['✨', '2x Karma', 'Every point you earn counts double'],
  ['🧾', 'No convenience fee', 'Skip the 3% fee on every booking'],
  ['↩️', 'Free cancellation to 2 hours', 'Full refund until 2 hours before, not 24'],
  ['🏅', 'Plus badge', 'A badge next to your name for other players'],
  ['🎯', 'Priority in suggestions', 'You show up first in "Players for you"'],
] as const;

export function PlusView() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [plus, , status] = app.useGlobalState('plus', token ?? undefined);
  const [plan, setPlan] = useState<'monthly' | 'yearly'>('yearly');
  const [busy, setBusy] = useState(false);
  const price = plan === 'yearly' ? (plus?.priceYearly ?? 0) : (plus?.priceMonthly ?? 0);
  const choice = usePaymentChoice(price);

  if (!mounted) return null;

  const refresh = () => { for (const k of ['plus', 'me', 'wallet', 'karma'] as const) app.invalidate(k); };

  const subscribe = async () => {
    if (!token) return app.setState('loginOpen', true);
    setBusy(true);
    try {
      await api.subscribePlus(token, { plan, method: choice.method });
      app.emit('toast', { kind: 'ok', text: '✨ Welcome to Playo Plus' });
      refresh();
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Payment failed' });
    } finally {
      setBusy(false);
    }
  };

  const cancel = async () => {
    if (!token) return;
    setBusy(true);
    try {
      await api.cancelPlus(token);
      app.emit('toast', { kind: 'ok', text: 'Plus will not renew. You keep the benefits until the end of the period.' });
      refresh();
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not cancel' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <section className="rounded-3xl bg-gradient-to-br from-violet-700 to-fuchsia-700 p-8 text-white">
        <h1 className="text-3xl font-extrabold">Playo Plus ✨</h1>
        <p className="mt-1 text-white">Play more, pay less.</p>
      </section>

      <ul className="grid gap-3 sm:grid-cols-2" data-testid="plus-benefits">
        {BENEFITS.map(([emoji, title, text]) => (
          <li key={title} className="rounded-2xl border bg-white p-4"><span className="text-2xl">{emoji}</span><p className="font-bold">{title}</p><p className="text-sm text-ink/60">{text}</p></li>
        ))}
      </ul>

      {!token ? (
        <EmptyState>
          <p className="mb-3">Log in to join Plus.</p>
          <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
        </EmptyState>
      ) : !plus ? (
        status.state === 'error' ? <p className="text-red-600">Couldn&apos;t load your membership.</p> : <Skeleton count={1} className="h-40" />
      ) : plus.active ? (
        <section className="space-y-3 rounded-2xl border bg-white p-5" data-testid="plus-active">
          <p className="font-bold text-violet-700">You are a Plus member ✨ ({plus.plan})</p>
          <p className="text-sm text-ink/70">
            {plus.cancelled ? 'Cancelled: ends on ' : 'Renews on '}
            {plus.renewsAt ? new Date(plus.renewsAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : '—'}.
          </p>
          {!plus.cancelled && (
            <button onClick={cancel} disabled={busy} data-testid="cancel-plus" className="rounded-lg border border-red-200 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50">Cancel membership</button>
          )}
        </section>
      ) : (
        <section className="space-y-4 rounded-2xl border bg-white p-5" data-testid="plus-plans">
          <div className="grid gap-3 sm:grid-cols-2">
            {(['monthly', 'yearly'] as const).map((p) => (
              <button key={p} onClick={() => setPlan(p)} data-testid={`plan-${p}`} className={`rounded-2xl border-2 p-4 text-left ${plan === p ? 'border-violet-600 bg-violet-50' : 'border-black/10'}`}>
                <p className="font-bold capitalize">{p}</p>
                <p className="text-2xl font-extrabold">{money(p === 'yearly' ? plus.priceYearly : plus.priceMonthly)}</p>
                {p === 'yearly' && <p className="text-xs text-green-700">Save {money(plus.priceMonthly * 12 - plus.priceYearly)} a year</p>}
              </button>
            ))}
          </div>
          <PaymentPicker choice={choice} name="pluspay" />
          <button onClick={subscribe} disabled={busy || choice.blocked} data-testid="subscribe-plus" data-tip={choice.blocked ? 'Not enough wallet balance: top up, or pay with UPI or card' : busy ? 'Working…' : undefined} className="w-full rounded-xl bg-violet-600 py-3 font-bold text-white hover:bg-violet-700 disabled:opacity-50">
            {busy ? 'Paying…' : `Join Plus for ${money(price)}`}
          </button>
        </section>
      )}
    </div>
  );
}
