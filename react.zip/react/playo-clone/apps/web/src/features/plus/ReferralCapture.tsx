'use client';

import { useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { app } from '@/store';
import { useMounted } from '@/lib/hooks';

/** `/?ref=CODE`: keeps the code (saved in the browser) until this device signs up, and says what it is worth */
export function ReferralCapture() {
  const mounted = useMounted();
  const code = useSearchParams()?.get('ref')?.trim().toUpperCase() ?? '';
  const [token] = app.useGlobalState('token');
  const [pending, setPending] = app.useGlobalState('pendingReferral');

  useEffect(() => {
    if (code && code !== pending) setPending(code);
  }, [code]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!mounted || token || !pending) return null;
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl bg-violet-50 p-4 text-sm" data-testid="referral-banner">
      <span>🎁 Referral code <b>{pending}</b> applied: you get a welcome bonus when you sign up.</span>
      <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-4 py-1.5 font-semibold text-white">Sign up</button>
    </div>
  );
}
