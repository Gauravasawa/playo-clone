'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import { EmptyState } from '@/components/ui/EmptyState';
import { CITIES } from '@/config/constants';
import { api, type Me, type ProfileUpdate, type SkillLevel } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { BlockedList } from '@/features/safety/BlockedList';
import { BadgeList, StatsGrid } from './ProfileParts';

const EMOJIS = ['🙂', '😎', '🏸', '⚽', '🏏', '🎾', '🏀', '🏊', '🏓', '🥒', '🏃', '🔥', '⚡', '🦁', '🐯', '🦅', '🚀', '🎯', '🌟', '💪'];
const COLORS = ['#00b259', '#2563eb', '#7c3aed', '#db2777', '#ea580c', '#ca8a04', '#0891b2', '#4338ca', '#b91c1c', '#16a34a'];
const LEVELS: SkillLevel[] = ['Beginner', 'Intermediate', 'Advanced'];

const DAYS = [['weekday', 'Weekdays'], ['weekend', 'Weekends']] as const;
const TIMES = [['morning', 'Mornings'], ['evening', 'Evenings']] as const;
const toggle = <T,>(list: T[], v: T) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);

const toDraft = (me: Me): ProfileUpdate => ({
  name: me.name, username: me.username, bio: me.bio, city: me.city, avatarEmoji: me.avatarEmoji,
  avatarColor: me.avatarColor, isPrivate: me.isPrivate, sports: me.sports, plays: me.plays,
});

/** Your own profile: change how you look to others, which sports you play, and whether you're private */
export function ProfileEditor() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [sportsCatalogData] = app.useGlobalState('sports');
  const sportsCatalog = sportsCatalogData ?? [];
  const [me, setMe, meStatus] = app.useGlobalState('me', token ?? undefined);
  const [draft, setDraft] = useState<ProfileUpdate | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const profileParams = me ? { username: me.username, token } : undefined;
  const [profile] = app.useGlobalState('player', profileParams);

  useEffect(() => {
    if (me && !draft) setDraft(toDraft(me));
  }, [me, draft]);

  if (!mounted) return null;
  if (!token)
    return (
      <>
      <h1 className="mb-4 text-2xl font-extrabold">My profile</h1>
      <EmptyState>
        <p className="mb-3">Log in to see and edit your profile.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
      </>
    );
  if (!me || !draft) return <div className="h-96 animate-pulse rounded-2xl bg-black/5" aria-busy={meStatus.loading} />;

  const set = <K extends keyof ProfileUpdate>(k: K, v: ProfileUpdate[K]) => setDraft({ ...draft, [k]: v });
  const levelOf = (sport: string) => draft.sports.find((s) => s.sport === sport)?.level;
  const toggleSport = (sport: string) =>
    set('sports', levelOf(sport) ? draft.sports.filter((s) => s.sport !== sport) : [...draft.sports, { sport, level: 'Beginner' }]);
  const setLevel = (sport: string, level: SkillLevel) => set('sports', draft.sports.map((s) => (s.sport === sport ? { ...s, level } : s)));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      // Your profile changes on screen now; the server's answer (e.g. "username taken") undoes it
      await setMe((prev) => ({ ...(prev as Me), ...draft }), () => api.updateProfile(token, draft));
      app.emit('toast', { kind: 'ok', text: 'Profile saved' });
      app.invalidate('player');
      app.invalidate('playedWith');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save');
      setDraft(toDraft(me));
    } finally {
      setBusy(false);
    }
  };

  const field = 'w-full rounded-lg border px-3 py-2';
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-extrabold">Your profile</h1>
        <Link href={`/p/${me.username}`} className="ml-auto inline-block py-1.5 text-sm text-brand underline">View public page</Link>
      </div>

      {profile && (
        <section className="space-y-3 rounded-2xl border bg-white p-5">
          <StatsGrid stats={profile.stats} />
          <BadgeList badges={profile.badges} />
        </section>
      )}

      <form onSubmit={save} className="space-y-5 rounded-2xl border bg-white p-6" aria-label="Edit profile">
        <div className="flex items-center gap-4">
          <Avatar player={{ id: me.id, name: draft.name, avatarEmoji: draft.avatarEmoji, avatarColor: draft.avatarColor, online: true }} size={72} dot={false} />
          <div className="space-y-2">
            <div className="flex flex-wrap gap-1" aria-label="Pick an emoji">
              {EMOJIS.map((em) => (
                <button type="button" key={em} onClick={() => set('avatarEmoji', em)} aria-label={`Emoji ${em}`} className={`rounded-lg px-1.5 py-0.5 text-xl ${draft.avatarEmoji === em ? 'bg-brand/20 ring-2 ring-brand' : 'hover:bg-black/5'}`}>{em}</button>
              ))}
            </div>
            <div className="flex flex-wrap gap-1.5" aria-label="Pick a colour">
              {COLORS.map((c) => (
                <button type="button" key={c} onClick={() => set('avatarColor', c)} aria-label={`Colour ${c}`} className={`size-7 rounded-full ${draft.avatarColor === c ? 'ring-2 ring-offset-2 ring-ink' : ''}`} style={{ background: c }} />
              ))}
            </div>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <label className="space-y-1 text-sm"><span className="text-ink/60">Name</span><input className={field} value={draft.name} onChange={(e) => set('name', e.target.value)} /></label>
          <label className="space-y-1 text-sm"><span className="text-ink/60">Username</span><input aria-label="Username" className={field} value={draft.username} onChange={(e) => set('username', e.target.value.toLowerCase())} /></label>
          <label className="space-y-1 text-sm"><span className="text-ink/60">City</span>
            <select className={field} value={draft.city} onChange={(e) => set('city', e.target.value)}>{CITIES.map((c) => <option key={c}>{c}</option>)}</select>
          </label>
          <label className="space-y-1 text-sm sm:col-span-2"><span className="text-ink/60">Bio</span><textarea className={field} rows={2} maxLength={160} value={draft.bio} onChange={(e) => set('bio', e.target.value)} /></label>
        </div>

        <fieldset className="space-y-2">
          <legend className="font-bold">Sports you play</legend>
          <div className="grid gap-2 sm:grid-cols-2">
            {sportsCatalog.map((s) => (
              <div key={s.id} className={`flex items-center justify-between gap-2 rounded-xl border px-3 py-2 ${levelOf(s.id) ? 'border-brand bg-brand/5' : ''}`}>
                <label className="flex min-h-7 items-center gap-2"><input type="checkbox" checked={!!levelOf(s.id)} onChange={() => toggleSport(s.id)} /> {s.emoji} {s.name}</label>
                {levelOf(s.id) && (
                  <select aria-label={`${s.name} level`} value={levelOf(s.id)} onChange={(e) => setLevel(s.id, e.target.value as SkillLevel)} className="rounded-lg border px-2 py-1 text-sm">
                    {LEVELS.map((l) => <option key={l}>{l}</option>)}
                  </select>
                )}
              </div>
            ))}
          </div>
        </fieldset>

        <fieldset className="space-y-2" data-testid="plays-editor">
          <legend className="font-bold">When you play</legend>
          <p className="text-xs text-ink/50">Used to suggest players with the same free time.</p>
          <div className="flex flex-wrap gap-2">
            {DAYS.map(([id, label]) => (
              <label key={id} className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm ${draft.plays.days.includes(id) ? 'border-brand bg-brand/5' : ''}`}>
                <input type="checkbox" checked={draft.plays.days.includes(id)} onChange={() => set('plays', { ...draft.plays, days: toggle(draft.plays.days, id) })} data-testid={`plays-${id}`} /> {label}
              </label>
            ))}
            {TIMES.map(([id, label]) => (
              <label key={id} className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm ${draft.plays.times.includes(id) ? 'border-brand bg-brand/5' : ''}`}>
                <input type="checkbox" checked={draft.plays.times.includes(id)} onChange={() => set('plays', { ...draft.plays, times: toggle(draft.plays.times, id) })} data-testid={`plays-${id}`} /> {label}
              </label>
            ))}
          </div>
        </fieldset>

        <label className="flex items-start gap-3 rounded-xl bg-black/[0.03] p-3 text-sm">
          <input type="checkbox" className="mt-1 size-4" checked={draft.isPrivate} onChange={(e) => set('isPrivate', e.target.checked)} />
          <span><b>Private profile.</b> People you have played with can ask to follow you and you approve each request. Only friends and followers see your sports, stats and badges.</span>
        </label>

        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        <button disabled={busy} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white hover:bg-brand-dark">{busy ? 'Saving…' : 'Save profile'}</button>
      </form>

      <BlockedList />
    </div>
  );
}
