import { money } from '@/lib/format';
import type { Badge, PlayerStats, SportLevel, Sport } from '@/lib/api';

export function StatBox({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-xl bg-black/[0.03] px-4 py-3 text-center">
      <div className="text-xl font-extrabold" data-testid={`stat-${label.toLowerCase().replace(/\s/g, '-')}`}>{value}</div>
      <div className="text-xs text-ink/50">{label}</div>
    </div>
  );
}

export function StatsGrid({ stats }: { stats: Partial<PlayerStats> & { followers: number; following: number; friends: number } }) {
  return (
    <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
      {stats.gamesPlayed !== undefined && <StatBox label="Games" value={stats.gamesPlayed} />}
      {stats.wins !== undefined && <StatBox label="Wins" value={stats.wins} />}
      <StatBox label="Friends" value={stats.friends} />
      <StatBox label="Followers" value={stats.followers} />
      <StatBox label="Following" value={stats.following} />
      {stats.bookings !== undefined && <StatBox label="Bookings" value={stats.bookings} />}
    </div>
  );
}

export function BadgeList({ badges }: { badges: Badge[] }) {
  if (badges.length === 0) return <p className="text-sm text-ink/50">No badges yet.</p>;
  return (
    <div className="flex flex-wrap gap-2" data-testid="badges">
      {badges.map((b) => (
        <span key={b.id} className="rounded-full border bg-white px-3 py-1 text-sm">{b.emoji} {b.label}</span>
      ))}
    </div>
  );
}

export function SportLevels({ sports, catalog }: { sports: SportLevel[]; catalog: Sport[] }) {
  if (sports.length === 0) return <p className="text-sm text-ink/50">No sports added.</p>;
  return (
    <div className="flex flex-wrap gap-2">
      {sports.map((s) => {
        const meta = catalog.find((c) => c.id === s.sport);
        return (
          <span key={s.sport} className="rounded-full bg-brand/10 px-3 py-1 text-sm font-medium text-brand-dark">
            {meta?.emoji} {meta?.name ?? s.sport} · {s.level}
          </span>
        );
      })}
    </div>
  );
}

export const Stars = ({ value }: { value: number }) => (
  <span aria-label={`${value} out of 5`} className="text-amber-600">{'★'.repeat(value)}<span className="text-ink/20">{'★'.repeat(5 - value)}</span></span>
);

export { money };
