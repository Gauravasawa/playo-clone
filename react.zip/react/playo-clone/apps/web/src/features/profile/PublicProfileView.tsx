'use client';

import Link from 'next/link';
import { useMemo } from 'react';
import { app } from '@/store';
import { Avatar } from '@/components/ui/Avatar';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { RelationshipActions } from '@/features/friends/RelationshipActions';
import { useMounted } from '@/lib/hooks';
import { RatingForm } from './RatingForm';
import { BlockButton } from '@/features/safety/BlockButton';
import { ReportButton } from '@/features/safety/ReportButton';
import { ShareButton } from './ShareButton';
import { BadgeList, SportLevels, Stars, StatsGrid } from './ProfileParts';

/**
 * Someone's page. Before mount it shows what the server rendered (no viewer: `token: null`); after
 * mount it asks again with the viewer's token, which adds the friend/follow state and what they can rate.
 */
export function PublicProfileView({ username }: { username: string }) {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [sportsData] = app.useGlobalState('sports');
  const sports = sportsData ?? []; // the query is undefined until it loads
  const params = useMemo(() => ({ username, token: mounted ? token : null }), [username, token, mounted]);
  const [profile, , status] = app.useGlobalState('player', params);

  if (status.state === 'error') return <ErrorNotice onRetry={status.refetch}>That player doesn&apos;t exist.</ErrorNotice>;
  if (!profile) return <div className="h-64 animate-pulse rounded-2xl bg-black/5" />;
  const p = profile;

  return (
    <div className="space-y-5" data-testid="public-profile">
      <section className="space-y-4 rounded-3xl border bg-white p-6">
        <div className="flex flex-wrap items-start gap-4">
          <Avatar player={p} size={84} />
          <div className="min-w-0 flex-1">
            <h1 className="text-2xl font-extrabold">{p.name} {p.plus && <span className="rounded-full bg-amber-100 px-2 py-0.5 align-middle text-xs font-semibold text-amber-700" data-testid="plus-badge">✨ Plus</span>} {p.isPrivate && <span title="Private profile" className="text-base">🔒</span>}</h1>
            <p className="text-ink/60">@{p.username} · {p.city}</p>
            {p.bio && <p className="mt-2 text-ink/80">{p.bio}</p>}
            {p.rating.count > 0 && <p className="mt-1 text-sm"><Stars value={Math.round(p.rating.avg)} /> {p.rating.avg} <span className="text-ink/50">({p.rating.count} rating{p.rating.count > 1 ? 's' : ''})</span></p>}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {p.isMe ? <Link href="/profile" className="rounded-full bg-brand px-4 py-1.5 text-sm font-semibold text-white">Edit profile</Link> : mounted && <RelationshipActions player={p} relationship={p.relationship} />}
          <ShareButton username={p.username} />
          {mounted && token && !p.isMe && (
            <>
              <BlockButton player={p} blocked={p.blockedByMe} />
              <ReportButton kind="player" targetId={p.id} />
            </>
          )}
        </div>
        <StatsGrid stats={p.stats} />
      </section>

      {p.restricted ? (
        <p className="rounded-2xl bg-white p-6 text-center text-ink/60" data-testid="restricted">🔒 This profile is private. Follow or be friends with {p.name.split(' ')[0]} to see their sports, stats and badges.</p>
      ) : (
        <>
          <section className="space-y-2 rounded-2xl border bg-white p-5"><h2 className="font-bold">Sports</h2><SportLevels sports={p.sports} catalog={sports} /></section>
          <section className="space-y-2 rounded-2xl border bg-white p-5"><h2 className="font-bold">Badges</h2><BadgeList badges={p.badges} /></section>
          {mounted && p.ratable.length > 0 && <RatingForm player={p} games={p.ratable} />}
          {p.ratings.length > 0 && (
            <section className="space-y-2 rounded-2xl border bg-white p-5"><h2 className="font-bold">What players say</h2>
              <ul className="space-y-2">
                {p.ratings.map((r) => (
                  <li key={r.id} className="text-sm"><Stars value={r.rating} /> <b>{r.author?.name ?? 'Someone'}</b>{r.body && <span className="text-ink/70"> — {r.body}</span>}</li>
                ))}
              </ul>
            </section>
          )}
        </>
      )}
    </div>
  );
}
