'use client';

import { useState } from 'react';
import { app } from '@/store';
import { api, type Player } from '@/lib/api';

/** Rate a player for a game you both played; each game can be rated once */
export function RatingForm({ player, games }: { player: Player; games: { id: number; title: string }[] }) {
  const [token] = app.useGlobalState('token');
  const [gameId, setGameId] = useState(games[0]?.id ?? 0);
  const [rating, setRating] = useState(5);
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  if (!token || games.length === 0) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.ratePlayer(token, player.id, { gameId, rating, body });
      app.emit('toast', { kind: 'ok', text: `You rated ${player.name}` });
      setBody('');
      app.invalidate('player');
    } catch (err) {
      app.emit('toast', { kind: 'err', text: err instanceof Error ? err.message : 'Could not save the rating' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-2 rounded-2xl border bg-white p-4" aria-label="Rate this player">
      <h3 className="font-bold">Rate {player.name}</h3>
      <select aria-label="The game you played together" value={gameId} onChange={(e) => setGameId(Number(e.target.value))} className="w-full rounded-lg border px-3 py-2">
        {games.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
      </select>
      <div className="flex gap-1" role="radiogroup" aria-label="Stars">
        {[1, 2, 3, 4, 5].map((n) => (
          <button type="button" key={n} role="radio" aria-checked={rating === n} aria-label={`${n} star${n > 1 ? 's' : ''}`} onClick={() => setRating(n)} className={`px-1 text-2xl ${n <= rating ? 'text-amber-600' : 'text-ink/20'}`}>★</button>
        ))}
      </div>
      <input aria-label="A few words about playing with them (optional)" value={body} onChange={(e) => setBody(e.target.value)} placeholder="A few words (optional)" maxLength={300} className="w-full rounded-lg border px-3 py-2" />
      <button disabled={busy} className="rounded-full bg-brand px-5 py-2 font-semibold text-white">{busy ? 'Saving…' : 'Submit rating'}</button>
    </form>
  );
}
