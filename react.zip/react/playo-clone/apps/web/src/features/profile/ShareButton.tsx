'use client';

import { useState } from 'react';
import { app } from '@/store';

/**
 * Calls the Route Handler at /share/<username> (which loads the profile through a store scope) and
 * copies the page link. The card it returns is shown so the handler's output can be seen.
 */
export function ShareButton({ username }: { username: string }) {
  const [card, setCard] = useState<{ title: string; description: string; url: string } | null>(null);

  const share = async () => {
    try {
      const res = await fetch(`/share/${username}`);
      if (!res.ok) throw new Error('Profile not found');
      const data = (await res.json()) as { title: string; description: string; url: string };
      setCard(data);
      await navigator.clipboard?.writeText(`${location.origin}${data.url}`).catch(() => {});
      app.emit('toast', { kind: 'ok', text: 'Profile link copied' });
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not share' });
    }
  };

  return (
    <>
      <button onClick={share} className="rounded-full border px-3 py-1.5 text-sm font-semibold hover:bg-black/5">Share</button>
      {card && (
        <div data-testid="share-card" className="w-full rounded-xl bg-black/[0.04] p-3 text-sm">
          <b>{card.title}</b><br />{card.description}<br /><span className="text-ink/50">{card.url}</span>
        </div>
      )}
    </>
  );
}
