'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { app } from '@/store';
import { api } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { Skeleton } from '@/components/ui/Skeleton';
import { Tabs } from '@/components/ui/Tabs';

type Status = 'open' | 'resolved' | 'dismissed';

/** Reports from players; only the admin account (phone 9000000000) can open this */
export function AdminReportsView() {
  const mounted = useMounted();
  const [token] = app.useGlobalState('token');
  const [me] = app.useGlobalState('me', token ?? undefined);
  const [status, setStatus] = useState<Status>('open');
  const params = useMemo(() => (token && me?.isAdmin ? { token, status } : undefined), [token, me?.isAdmin, status]);
  const [reports, , st] = app.useGlobalState('adminReports', params);

  if (!mounted) return null;
  const title = <h1 className="mb-4 text-2xl font-extrabold">Reports</h1>;
  if (!token) return <>{title}<EmptyState>Log in as the admin (phone 9000000000, OTP 1234) to see reports.</EmptyState></>;
  if (me && !me.isAdmin) return <>{title}<EmptyState><span data-testid="not-admin">Only the admin account can see reports.</span></EmptyState></>;

  const decide = async (id: number, decision: 'resolve' | 'dismiss') => {
    try {
      await api.decideReport(token, id, decision);
      app.emit('toast', { kind: 'ok', text: decision === 'resolve' ? 'Report resolved' : 'Report dismissed' });
      app.invalidate('adminReports');
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not update the report' });
    }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-extrabold">Reports</h1>
      <Tabs<Status> value={status} onChange={setStatus} tabs={[{ id: 'open', label: 'Open' }, { id: 'resolved', label: 'Resolved' }, { id: 'dismissed', label: 'Dismissed' }]} />
      {st.state === 'error' ? (
        <ErrorNotice onRetry={st.refetch}>Couldn&apos;t load reports.</ErrorNotice>
      ) : st.state === 'loading' || st.state === 'waiting' ? (
        <Skeleton count={3} />
      ) : !reports?.length ? (
        <EmptyState>No {status} reports.</EmptyState>
      ) : (
        <ul className="space-y-3" data-testid="report-list">
          {reports.map((r) => (
            <li key={r.id} className="space-y-1 rounded-2xl border bg-white p-4" data-testid={`report-${r.id}`}>
              <p className="text-sm"><span className="rounded-full bg-black/5 px-2 py-0.5 font-semibold">{r.kind}</span> <b>{r.reason}</b></p>
              <p className="text-sm text-ink/70">“{r.target}”</p>
              {r.details && <p className="text-sm text-ink/60">{r.details}</p>}
              <p className="text-xs text-ink/40">
                by {r.reporter ? <Link href={`/p/${r.reporter.username}`} className="hover:text-brand">@{r.reporter.username}</Link> : 'someone'} · {new Date(r.createdAt).toLocaleString('en-IN')}
              </p>
              {r.status === 'open' && (
                <div className="flex gap-2 pt-1">
                  <button onClick={() => decide(r.id, 'resolve')} data-testid={`resolve-${r.id}`} className="rounded-full bg-brand px-3 py-1 text-sm font-semibold text-white">Resolve</button>
                  <button onClick={() => decide(r.id, 'dismiss')} data-testid={`dismiss-${r.id}`} className="rounded-full border px-3 py-1 text-sm font-semibold">Dismiss</button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
