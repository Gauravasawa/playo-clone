'use client';

import { app } from '@/store';
import { api, type Player } from '@/lib/api';

/** Block or unblock a player: they can't find, message or ask you for anything while blocked */
export function BlockButton({ player, blocked, className }: { player: Pick<Player, 'id' | 'name' | 'username'>; blocked: boolean; className?: string }) {
  const [token] = app.useGlobalState('token');
  const toggle = async () => {
    if (!token) return app.setState('loginOpen', true);
    if (!blocked && !confirm(`Block ${player.name}? They can't find you, message you or send requests, and any friendship or follow between you ends.`)) return;
    try {
      if (blocked) await api.unblockPlayer(token, player.id);
      else await api.blockPlayer(token, player.id);
      app.emit('toast', { kind: 'ok', text: blocked ? `${player.name} unblocked` : `${player.name} blocked` });
      for (const n of ['blocks', 'player', 'friends', 'followRequests', 'playedWith', 'suggested', 'chats', 'searchPlayers'] as const) app.invalidate(n);
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Something went wrong' });
    }
  };
  return (
    <button onClick={toggle} data-testid={`block-${player.username}`} className={className ?? 'rounded-full border px-3 py-1.5 text-sm font-semibold hover:bg-black/5'}>
      {blocked ? '✋ Unblock' : '🚫 Block'}
    </button>
  );
}
