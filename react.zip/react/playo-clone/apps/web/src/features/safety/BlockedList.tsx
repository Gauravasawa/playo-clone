'use client';

import { app } from '@/store';
import { PlayerCard } from '@/features/friends/PlayerCard';
import { BlockButton } from './BlockButton';

/** Players you blocked, with a way to unblock them */
export function BlockedList() {
  const [token] = app.useGlobalState('token');
  const [blocked, , status] = app.useGlobalState('blocks', token ?? undefined);
  return (
    <section className="space-y-3 rounded-2xl border bg-white p-5" data-testid="blocked-list">
      <h2 className="font-bold">Blocked players</h2>
      {status.state === 'loading' || status.state === 'waiting' ? (
        <p className="text-sm text-ink/50">Loading…</p>
      ) : !blocked?.length ? (
        <p className="text-sm text-ink/60">You haven&apos;t blocked anyone.</p>
      ) : (
        <ul className="space-y-2">
          {blocked.map((p) => (
            <PlayerCard key={p.id} player={p}>
              <BlockButton player={p} blocked />
            </PlayerCard>
          ))}
        </ul>
      )}
    </section>
  );
}
