'use client';

import { useState } from 'react';
import { app } from '@/store';
import { Modal } from '@/components/ui/Modal';
import { api } from '@/lib/api';

interface Props {
  kind: 'review' | 'player' | 'message' | 'game';
  targetId: number;
  label?: string;
  className?: string;
}

/** "Report" button + a box to choose a reason; reports go to the admin page */
export function ReportButton({ kind, targetId, label = 'Report', className }: Props) {
  const [open, setOpen] = useState(false);
  const [token] = app.useGlobalState('token');
  const start = () => (token ? setOpen(true) : app.setState('loginOpen', true));
  return (
    <>
      <button onClick={start} data-testid={`report-${kind}-${targetId}`} className={className ?? 'rounded-full border px-3 py-1.5 text-sm font-semibold text-red-600 hover:bg-red-50'}>
        🚩 {label}
      </button>
      {open && token && <ReportModal token={token} kind={kind} targetId={targetId} onClose={() => setOpen(false)} />}
    </>
  );
}

function ReportModal({ token, kind, targetId, onClose }: { token: string; kind: Props['kind']; targetId: number; onClose: () => void }) {
  const [reasons] = app.useGlobalState('reportReasons');
  const [reason, setReason] = useState('');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const send = async () => {
    setBusy(true);
    setError('');
    try {
      await api.report(token, { kind, targetId, reason, details: details.trim() || undefined });
      app.emit('toast', { kind: 'ok', text: 'Thanks, we will look into it' });
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not send the report');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={`Report this ${kind}`} onClose={onClose}>
      <fieldset className="space-y-1 text-sm">
        <legend className="mb-1 font-semibold">What is wrong?</legend>
        {(reasons ?? []).map((r) => (
          <label key={r} className="flex min-h-7 items-center gap-2"><input type="radio" name="reason" checked={reason === r} onChange={() => setReason(r)} /> {r}</label>
        ))}
      </fieldset>
      <textarea value={details} onChange={(e) => setDetails(e.target.value)} maxLength={300} rows={3} placeholder="More details (optional)" aria-label="Report details" className="w-full rounded-lg border px-3 py-2 text-sm" />
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      <button onClick={send} disabled={!reason || busy} data-tip={!reason ? 'Pick a reason first' : undefined} data-testid="report-submit" className="w-full rounded-xl bg-red-600 py-2.5 font-bold text-white disabled:opacity-50">
        {busy ? 'Sending…' : 'Send report'}
      </button>
    </Modal>
  );
}
