'use client';

import { useState } from 'react';

/** A big photo with a strip of thumbnails; arrows and thumbnails switch photos */
export function Gallery({ images, name = 'Venue' }: { images: string[]; name?: string }) {
  const [i, setI] = useState(0);
  if (images.length === 0) return null;
  const at = Math.min(i, images.length - 1);
  const step = (d: number) => setI((at + d + images.length) % images.length);
  return (
    <div className="space-y-2" data-testid="gallery">
      <div className="relative">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={images[at]} alt={`${name} photo ${at + 1}`} data-testid="gallery-main" className="h-64 w-full rounded-2xl object-cover sm:h-80" />
        {images.length > 1 && (
          <>
            <button onClick={() => step(-1)} aria-label="Previous photo" data-testid="gallery-prev" className="absolute left-2 top-1/2 grid size-9 -translate-y-1/2 place-items-center rounded-full bg-black/50 text-white">‹</button>
            <button onClick={() => step(1)} aria-label="Next photo" data-testid="gallery-next" className="absolute right-2 top-1/2 grid size-9 -translate-y-1/2 place-items-center rounded-full bg-black/50 text-white">›</button>
            <span className="absolute bottom-2 right-3 rounded-full bg-black/70 px-2 py-0.5 text-xs text-white" data-testid="gallery-count">{at + 1} / {images.length}</span>
          </>
        )}
      </div>
      {images.length > 1 && (
        <div className="flex gap-2 overflow-x-auto">
          {images.map((src, n) => (
            <button key={src + n} onClick={() => setI(n)} aria-label={`Show photo ${n + 1}`} data-testid="gallery-thumb" className={`shrink-0 overflow-hidden rounded-lg border-2 ${n === at ? 'border-brand' : 'border-transparent'}`}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt="" loading="lazy" className="h-14 w-20 object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
