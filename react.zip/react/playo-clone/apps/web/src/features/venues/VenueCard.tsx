'use client';

import Link from 'next/link';
import { app } from '@/store';
import { Price } from '@/components/ui/Price';
import { useMounted } from '@/lib/hooks';
import type { Venue } from '@/lib/api';

export function VenueCard({ venue }: { venue: Venue }) {
  const mounted = useMounted();
  const [favorites, setFavorites] = app.useGlobalState('favorites');
  const [token] = app.useGlobalState('token');
  const [sportsData] = app.useGlobalState('sports');
  const sports = sportsData ?? []; // the query is undefined until it loads
  const liked = mounted && favorites.includes(venue.id);

  const toggle = async () => {
    if (!token) return app.setState('loginOpen', true);
    // Shows at once; if the server refuses, the store undoes it and onSaveError toasts
    await setFavorites.toggle(venue.id).catch(() => {});
  };

  return (
    <article data-testid="venue-card" className="overflow-hidden rounded-2xl border bg-white shadow-sm transition hover:shadow-md">
      <Link href={`/venues/${venue.id}`} className="block">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={venue.image} alt={venue.name} loading="lazy" className="h-40 w-full object-cover" />
      </Link>
      <div className="space-y-2 p-4">
        <div className="flex items-start justify-between gap-2">
          <Link href={`/venues/${venue.id}`} className="-my-1 inline-block py-1 font-bold leading-tight hover:text-brand">{venue.name}</Link>
          <button onClick={toggle} aria-label={liked ? 'Remove from favourites' : 'Add to favourites'} className={`-m-2 p-2 text-xl leading-none ${liked ? 'text-red-500' : 'text-ink/30'}`}>♥</button>
        </div>
        <p className="text-sm text-ink/60">
          {venue.area}, {venue.city}
          {venue.distanceKm != null && <span data-testid="venue-distance" className="ml-2 rounded bg-black/5 px-1.5 py-0.5 text-xs font-medium">{venue.distanceKm} km</span>}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {venue.sports.map((id) => {
            const s = sports.find((x) => x.id === id);
            return <span key={id} className="rounded-full bg-brand/10 px-2 py-0.5 text-xs font-medium text-brand-dark">{s?.emoji} {s?.name ?? id}</span>;
          })}
        </div>
        <div className="flex items-center justify-between pt-1 text-sm">
          <span data-tip={`Rated ${venue.rating} out of 5`} aria-label={`Rated ${venue.rating} out of 5`} role="img" className="rounded bg-brand px-1.5 py-0.5 text-xs font-bold text-white">★ {venue.rating}</span>
          <span className="font-semibold" data-testid="venue-price"><Price inr={venue.pricePerHour} city={venue.city} /><span className="font-normal text-ink/50"> / hr</span></span>
        </div>
      </div>
    </article>
  );
}
