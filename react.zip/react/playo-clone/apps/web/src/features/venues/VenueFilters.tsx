'use client';

import { useState } from 'react';
import { app } from '@/store';
import { cityCentre, formatLocal } from '@/config/cities';
import type { VenueFilter } from '@/lib/api';
import { useMounted } from '@/lib/hooks';
import { HeroScene } from '@/components/theme/HeroScene';

/** Search box, sport chips and sort: all of it is global state, so Play and Venues share the sport */
export function VenueHero() {
  const mounted = useMounted();
  const [city] = app.useGlobalState('city');
  const [search, setSearch] = app.useGlobalState('search');
  return (
    <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand to-emerald-700 p-8 text-white">
      <HeroScene />
      <h1 className="relative text-3xl font-extrabold">Book venues. Find players. Play.</h1>
      <p className="relative mt-1 text-white">Courts, turfs and pools in {mounted ? city : '…'}</p>
      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search venues or areas"
        aria-label="Search venues or areas" className="hero-input relative mt-4 w-full max-w-md rounded-full bg-white px-5 py-3 text-ink shadow-sm"
      />
    </section>
  );
}

export function SportChips({ allLabel = 'All sports' }: { allLabel?: string }) {
  const mounted = useMounted();
  const [sport, setSport] = app.useGlobalState('sport');
  const [sportsData, , status] = app.useGlobalState('sports');
  const sports = sportsData ?? [];
  return (
    <>
      {[{ id: 'all', name: allLabel, emoji: '🏆' }, ...sports].map((s) => (
        <button
          key={s.id}
          onClick={() => setSport(s.id)}
          className={`rounded-full border px-3 py-1.5 text-sm font-medium ${mounted && sport === s.id ? 'border-brand bg-brand text-white' : 'bg-white hover:bg-black/5'}`}
        >
          {s.emoji} {s.name}
        </button>
      ))}
      {status.state === 'loading' && <span className="text-sm text-ink/50">loading sports…</span>}
    </>
  );
}


export const AMENITY_OPTIONS = ['Parking', 'Washroom', 'Changing room', 'Floodlights', 'Drinking water', 'Cafe', 'Equipment rental', 'First aid'];
const PRICE_STEPS = [500, 800, 1200, 2000];

/** Asks the browser where we are; when that is refused or unavailable, falls back to the middle of the chosen city */
export function useLocate() {
  const [city] = app.useGlobalState('city');
  const [location, setLocation] = app.useGlobalState('location');
  const locate = () =>
    new Promise<void>((resolve) => {
      const fallback = () => {
        const c = cityCentre(city);
        setLocation({ ...c, source: 'city' });
        resolve();
      };
      if (typeof navigator === 'undefined' || !navigator.geolocation) return fallback();
      navigator.geolocation.getCurrentPosition(
        (p) => {
          setLocation({ lat: p.coords.latitude, lng: p.coords.longitude, source: 'gps' });
          resolve();
        },
        fallback,
        { timeout: 5000, maximumAge: 60_000 }
      );
    });
  return { location, locate, clear: () => setLocation(null) };
}

export function SortSelect() {
  const mounted = useMounted();
  const [sort, setSort] = app.useGlobalState('sort');
  const { location, locate } = useLocate();
  const change = async (v: VenueFilter['sort']) => {
    if (v === 'distance' && !location) await locate();
    setSort(v);
  };
  return (
    <select aria-label="Sort venues" data-testid="sort-select" value={mounted ? sort : 'rating'} onChange={(e) => change(e.target.value as VenueFilter['sort'])} className="rounded-lg border bg-white px-2 py-1.5 text-sm">
      <option value="rating">Top rated</option>
      <option value="price">Lowest price</option>
      <option value="distance">Nearest</option>
    </select>
  );
}

export function NearMeButton({ maxKm, onMaxKm }: { maxKm: number | null; onMaxKm: (km: number | null) => void }) {
  const mounted = useMounted();
  const { location, locate, clear } = useLocate();
  const [busy, setBusy] = useState(false);
  const [sort, setSort] = app.useGlobalState('sort');
  const on = mounted && !!location;
  const toggle = async () => {
    if (on) {
      clear();
      onMaxKm(null);
      if (sort === 'distance') setSort('rating');
      return;
    }
    setBusy(true);
    await locate();
    setSort('distance');
    setBusy(false);
  };
  return (
    <span className="flex items-center gap-2">
      <button onClick={toggle} disabled={busy} data-testid="near-me" aria-pressed={on} className={`rounded-full border px-3 py-1.5 text-sm font-medium ${on ? 'border-brand bg-brand text-white' : 'bg-white hover:bg-black/5'}`}>
        📍 {busy ? 'Locating…' : 'Near me'}
      </button>
      {on && (
        <>
          <select aria-label="Within" data-testid="max-km" value={maxKm ?? ''} onChange={(e) => onMaxKm(e.target.value ? Number(e.target.value) : null)} className="rounded-lg border bg-white px-2 py-1.5 text-sm">
            <option value="">Any distance</option>
            {[2, 5, 10, 25].map((k) => <option key={k} value={k}>Within {k} km</option>)}
          </select>
          <span className="text-xs text-ink/50" data-testid="location-source">{location!.source === 'gps' ? 'using your location' : 'using the city centre'}</span>
        </>
      )}
    </span>
  );
}

export function AmenityFilter({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5" role="group" aria-label="Amenities">
      {AMENITY_OPTIONS.map((a) => {
        const on = value.includes(a);
        return (
          <button key={a} onClick={() => onChange(on ? value.filter((x) => x !== a) : [...value, a])} aria-pressed={on} data-testid={`filter-amenity-${a.toLowerCase().replace(/\s+/g, '-')}`} className={`rounded-full border px-2.5 py-1 text-xs ${on ? 'border-brand bg-brand/10 font-semibold text-brand-dark' : 'bg-white hover:bg-black/5'}`}>
            {on ? '✓ ' : ''}{a}
          </button>
        );
      })}
    </div>
  );
}

export function PriceFilter({ city, value, onChange }: { city: string; value: number | null; onChange: (v: number | null) => void }) {
  return (
    <select aria-label="Maximum price per hour" data-testid="filter-max-price" value={value ?? ''} onChange={(e) => onChange(e.target.value ? Number(e.target.value) : null)} className="rounded-lg border bg-white px-2 py-1.5 text-sm">
      <option value="">Any price</option>
      {PRICE_STEPS.map((p) => <option key={p} value={p}>Up to {formatLocal(p, city)} / hr</option>)}
    </select>
  );
}
