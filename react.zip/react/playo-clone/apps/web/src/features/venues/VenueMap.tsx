'use client';
import 'leaflet/dist/leaflet.css';

import { useEffect, useRef } from 'react';
import type { Venue } from '@/lib/api';
import { formatLocal } from '@/config/cities';

/** OpenStreetMap through Leaflet. Leaflet needs `window`, so it is imported inside the effect (browser only). */
export function VenueMap({ venues, centre, you }: { venues: Venue[]; centre: { lat: number; lng: number }; you: { lat: number; lng: number } | null }) {
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let map: import('leaflet').Map | undefined;
    let dead = false;
    (async () => {
      const L = (await import('leaflet')).default;
      if (dead || !box.current) return;
      map = L.map(box.current).setView([centre.lat, centre.lng], 12);
      // One tile source for both themes: in dark mode the tile layer is darkened with a CSS filter (theme.css), so there is no second map service to depend on
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
      const pin = (cls: string, text: string) => {
        const el = document.createElement('div'); // an element, not an HTML string
        el.className = cls;
        el.textContent = text;
        return L.divIcon({ className: '', html: el, iconSize: [0, 0] });
      };
      const points: [number, number][] = [];
      for (const v of venues) {
        const m = L.marker([v.lat, v.lng], { icon: pin('venue-pin', '📍'), title: v.name }).addTo(map);
        const pop = document.createElement('div');
        // built with DOM calls and textContent: venue names are never parsed as HTML
        const title = document.createElement('b');
        title.textContent = v.name;
        const meta = document.createElement('span');
        meta.textContent = `★ ${v.rating} · ${formatLocal(v.pricePerHour, v.city)}/hr`;
        const a = document.createElement('a');
        a.dataset.testid = 'map-popup-link';
        a.style.cssText = 'color:#00703a;font-weight:600';
        a.textContent = 'View venue';
        a.setAttribute('href', `/venues/${v.id}`);
        pop.append(title, document.createElement('br'), meta, document.createElement('br'), a);
        m.bindPopup(pop);
        points.push([v.lat, v.lng]);
      }
      if (you) L.marker([you.lat, you.lng], { icon: pin('you-pin', '🔵'), title: 'You' }).addTo(map);
      if (points.length > 1) map.fitBounds(points, { padding: [30, 30] });
    })();
    return () => {
      dead = true;
      map?.remove();
    };
  }, [venues, centre.lat, centre.lng, you]);

  return <div ref={box} data-testid="venue-map" className="z-0 h-[28rem] w-full overflow-hidden rounded-2xl border" />;
}
