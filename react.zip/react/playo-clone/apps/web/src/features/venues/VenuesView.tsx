'use client';

import dynamic from 'next/dynamic';
import { useEffect, useMemo, useState } from 'react';
import { app } from '@/store';
import { useDebounced, useMounted } from '@/lib/hooks';
import { DEFAULT_VENUE_FILTER } from '@/config/constants';
import { cityCentre } from '@/config/cities';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { EmptyState } from '@/components/ui/EmptyState';
import { AmenityFilter, NearMeButton, PriceFilter, SportChips, SortSelect, VenueHero } from './VenueFilters';
import { VenueCard } from './VenueCard';

// Leaflet needs the browser, so the map is never rendered on the server
const VenueMap = dynamic(() => import('./VenueMap').then((m) => m.VenueMap), { ssr: false, loading: () => <div className="h-[28rem] animate-pulse rounded-2xl bg-black/5" /> });

export function VenuesView() {
  const mounted = useMounted();
  const [city] = app.useGlobalState('city');
  const [sport] = app.useGlobalState('sport');
  const [sort] = app.useGlobalState('sort');
  const [search] = app.useGlobalState('search');
  const [location, setLocation] = app.useGlobalState('location');
  const q = useDebounced(search);
  const [amenities, setAmenities] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState<number | null>(null);
  const [maxKm, setMaxKm] = useState<number | null>(null);
  const [view, setView] = useState<'list' | 'map'>('list');

  // A "city centre" position belongs to the city it was made for
  useEffect(() => {
    if (location?.source === 'city') setLocation({ ...cityCentre(city), source: 'city' });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [city]);

  // Each distinct filter is its own cache entry: going back to a filter you saw shows it instantly.
  // Until mounted, use the filter the server rendered (the saved city isn't known there), so
  // hydration matches; then switch to the visitor's own.
  const near = mounted && location ? { lat: location.lat, lng: location.lng } : null;
  const filter = useMemo(
    () => (mounted ? { city, sport, q, sort: sort === 'distance' && !near ? ('rating' as const) : sort, amenities, maxPrice, near, maxKm: near ? maxKm : null } : DEFAULT_VENUE_FILTER),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [mounted, city, sport, q, sort, amenities, maxPrice, near?.lat, near?.lng, maxKm]
  );
  const [pages, , status] = app.useGlobalState('venues', filter);
  const [mapItems, , mapStatus] = app.useGlobalState('mapVenues', filter, { enabled: view === 'map' });
  const venues = pages.flatMap((p) => p.items);
  const total = pages[0]?.total ?? 0;
  const centre = useMemo(() => cityCentre(city), [city]);
  const mapList = useMemo(() => mapItems ?? [], [mapItems]);

  return (
    <div className="space-y-6">
      <VenueHero />
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <SportChips />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <NearMeButton maxKm={maxKm} onMaxKm={setMaxKm} />
          <PriceFilter city={city} value={maxPrice} onChange={setMaxPrice} />
          <SortSelect />
          <div className="ml-auto flex rounded-full bg-black/5 p-1 text-sm" role="group" aria-label="View">
            <button onClick={() => setView('list')} aria-pressed={view === 'list'} data-testid="view-list" className={`rounded-full px-3 py-1 ${view === 'list' ? 'bg-white shadow' : 'text-ink/60'}`}>☰ List</button>
            <button onClick={() => setView('map')} aria-pressed={view === 'map'} data-testid="view-map" className={`rounded-full px-3 py-1 ${view === 'map' ? 'bg-white shadow' : 'text-ink/60'}`}>🗺️ Map</button>
          </div>
        </div>
        <AmenityFilter value={amenities} onChange={setAmenities} />
      </div>

      {view === 'map' ? (
        mapStatus.state === 'error' ? (
          <ErrorNotice onRetry={mapStatus.refetch}>Couldn&apos;t load the map.</ErrorNotice>
        ) : (
          <>
            <p className="text-sm text-ink/60" data-testid="venue-count">{mapList.length} venues on the map</p>
            <VenueMap venues={mapList} centre={centre} you={near} />
          </>
        )
      ) : status.state === 'error' ? (
        <ErrorNotice onRetry={status.refetch}>Couldn&apos;t load venues.</ErrorNotice>
      ) : status.state === 'loading' || status.state === 'waiting' ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }, (_, i) => <div key={i} className="h-64 animate-pulse rounded-2xl bg-black/5" />)}
        </div>
      ) : (
        <>
          <p className="text-sm text-ink/60" data-testid="venue-count">{total} venues{status.fetching ? ' · updating…' : ''}</p>
          {venues.length === 0 ? (
            <EmptyState>No venues match. Try another sport, fewer amenities or a higher price.</EmptyState>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {venues.map((v) => <VenueCard key={v.id} venue={v} />)}
            </div>
          )}
          {status.hasNextPage && (
            <div className="text-center">
              <button onClick={() => status.fetchNextPage()} disabled={status.isFetchingNextPage} className="rounded-full border bg-white px-6 py-2.5 font-semibold hover:bg-black/5">
                {status.isFetchingNextPage ? 'Loading…' : 'Load more'}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
