'use client';

import { useState } from 'react';
import { app } from '@/store';
import { api, type GiftCard } from '@/lib/api';
import { money } from '@/lib/format';
import { PaymentPicker, usePaymentChoice } from '@/components/ui/PaymentPicker';
import { ShareMenu } from '@/components/ui/ShareMenu';

const PRESETS = [500, 1000, 2000];
const date = (t: number) => new Date(t).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

function Card({ c, kind }: { c: GiftCard; kind: 'bought' | 'received' }) {
  const who = kind === 'bought' ? (c.recipient ? `to ${c.recipient.name}` : 'for yourself or sharing') : `from ${c.buyer?.name ?? 'someone'}`;
  const state = c.redeemed ? `Used ${c.redeemedAt ? date(c.redeemedAt) : ''}` : c.expired ? 'Expired' : `Valid until ${date(c.expiresAt)}`;
  return (
    <li className="space-y-1 rounded-xl border p-3 text-sm" data-testid={`gift-${c.code}`}>
      <div className="flex items-center justify-between">
        <span className="text-lg font-extrabold">{money(c.amount)}</span>
        <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${c.redeemed || c.expired ? 'bg-black/10 text-ink/60' : 'bg-green-100 text-green-700'}`}>{state}</span>
      </div>
      <p className="text-ink/60">{who}</p>
      <p><code className="rounded bg-black/5 px-1.5 py-0.5 font-semibold">{c.code}</code></p>
      {c.message && <p className="italic text-ink/70">“{c.message}”</p>}
    </li>
  );
}

export function GiftCardsTab({ token }: { token: string }) {
  const [cards, , status] = app.useGlobalState('giftCards', token);
  const [friends] = app.useGlobalState('friends', token);
  const [policy] = app.useGlobalState('policy');
  const min = policy?.giftCard.min ?? 100;
  const max = policy?.giftCard.max ?? 10000;

  const [preset, setPreset] = useState<number | 'custom'>(500);
  const [custom, setCustom] = useState('');
  const [to, setTo] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [code, setCode] = useState('');
  const [redeeming, setRedeeming] = useState(false);
  const [bought, setBought] = useState<GiftCard | null>(null);

  const amount = preset === 'custom' ? Math.floor(Number(custom) || 0) : preset;
  const valid = amount >= min && amount <= max;
  const choice = usePaymentChoice(amount);

  const buy = async () => {
    setBusy(true);
    try {
      const card = await api.buyGiftCard(token, { amount, recipientId: to ? Number(to) : null, message: message.trim() || undefined, method: choice.method });
      setBought(card);
      setMessage('');
      app.emit('toast', { kind: 'ok', text: `Gift card ${card.code} bought` });
      for (const k of ['giftCards', 'wallet', 'karma', 'me'] as const) app.invalidate(k);
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Payment failed' });
    } finally {
      setBusy(false);
    }
  };

  const redeem = async () => {
    setRedeeming(true);
    try {
      const r = await api.redeemGiftCard(token, code.trim());
      app.emit('toast', { kind: 'ok', text: `${money(r.amount)} added to your wallet` });
      setCode('');
      for (const k of ['giftCards', 'wallet'] as const) app.invalidate(k);
    } catch (e) {
      app.emit('toast', { kind: 'err', text: e instanceof Error ? e.message : 'Could not redeem' });
    } finally {
      setRedeeming(false);
    }
  };

  return (
    <div className="space-y-5">
      <section className="space-y-3 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Redeem a gift card</h2>
        <div className="flex gap-2">
          <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="PLAYO-XXXX-XXXX" aria-label="Gift card code" data-testid="redeem-code" className="flex-1 rounded-lg border px-3 py-2" />
          <button onClick={redeem} disabled={redeeming || !code.trim()} data-testid="redeem-gift-card" data-tip={!code.trim() ? 'Type the gift card code first' : redeeming ? 'Redeeming…' : undefined} className="rounded-lg bg-brand px-5 font-semibold text-white disabled:opacity-50">{redeeming ? '…' : 'Redeem'}</button>
        </div>
      </section>

      <section className="space-y-3 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Send a gift card</h2>
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((a) => (
            <button key={a} onClick={() => setPreset(a)} data-testid={`gift-amount-${a}`} className={`rounded-full border px-4 py-1.5 font-semibold ${preset === a ? 'border-brand bg-brand text-white' : 'hover:bg-black/5'}`}>{money(a)}</button>
          ))}
          <button onClick={() => setPreset('custom')} data-testid="gift-amount-custom" className={`rounded-full border px-4 py-1.5 font-semibold ${preset === 'custom' ? 'border-brand bg-brand text-white' : 'hover:bg-black/5'}`}>Custom</button>
        </div>
        {preset === 'custom' && (
          <label className="block text-sm">Amount (₹{min}–₹{max})
            <input type="number" value={custom} onChange={(e) => setCustom(e.target.value)} data-testid="gift-custom-amount" className="mt-1 block w-40 rounded-lg border px-3 py-2" />
          </label>
        )}
        {!valid && <p className="text-xs text-red-600">Pick an amount between ₹{min} and ₹{max}.</p>}
        <label className="block text-sm">Send to a friend (optional)
          <select value={to} onChange={(e) => setTo(e.target.value)} data-testid="gift-recipient" className="mt-1 block w-full rounded-lg border px-3 py-2">
            <option value="">Just give me the code</option>
            {friends?.friends.map((f) => <option key={f.id} value={f.id}>{f.avatarEmoji} {f.name} (@{f.username})</option>)}
          </select>
        </label>
        <label className="block text-sm">Message (optional)
          <input value={message} maxLength={140} onChange={(e) => setMessage(e.target.value)} data-testid="gift-message" className="mt-1 block w-full rounded-lg border px-3 py-2" />
        </label>
        <PaymentPicker choice={choice} name="giftpay" />
        <button onClick={buy} disabled={busy || !valid || choice.blocked} data-testid="buy-gift-card" data-tip={!valid ? `Pick an amount between ₹${min} and ₹${max}` : choice.blocked ? 'Not enough wallet balance: top up, or pay with UPI or card' : busy ? 'Working…' : undefined} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white hover:bg-brand-dark disabled:opacity-50">
          {busy ? 'Paying…' : `Buy for ${money(amount)}`}
        </button>
        {bought && (
          <div className="space-y-2 rounded-xl bg-green-50 p-3 text-sm" data-testid="gift-bought">
            Gift card ready: <code className="font-bold" data-testid="gift-code">{bought.code}</code> ({money(bought.amount)}).
            {bought.recipient ? ` ${bought.recipient.name} was notified.` : ' Share the code with a friend.'}
            <div><ShareMenu path="/wallet?tab=gift" title="Playo gift card" text={`I sent you a Playo gift card! Code: ${bought.code}`} label="Share the code" /></div>
          </div>
        )}
      </section>

      <section className="space-y-2 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Received</h2>
        {!cards ? <p className="text-sm text-ink/50">{status.state === 'error' ? 'Couldn’t load gift cards.' : 'Loading…'}</p>
          : cards.received.length === 0 ? <p className="text-sm text-ink/50">Nothing yet.</p>
          : <ul className="grid gap-2 sm:grid-cols-2">{cards.received.map((c) => <Card key={c.code} c={c} kind="received" />)}</ul>}
        <h2 className="pt-2 font-bold">Bought</h2>
        {!cards ? null : cards.bought.length === 0 ? <p className="text-sm text-ink/50">Nothing yet.</p>
          : <ul className="grid gap-2 sm:grid-cols-2">{cards.bought.map((c) => <Card key={c.code} c={c} kind="bought" />)}</ul>}
      </section>
    </div>
  );
}
