'use client';

import Link from 'next/link';
import { app } from '@/store';
import { Skeleton } from '@/components/ui/Skeleton';

/** Karma: points earned for playing and paying, spent at checkout (10 points = ₹1) */
export function KarmaTab({ token }: { token: string }) {
  const [karma, , status] = app.useGlobalState('karma', token);
  if (!karma) return status.state === 'error' ? <p className="text-red-600">Couldn&apos;t load Karma.</p> : <Skeleton count={2} className="h-32" />;
  return (
    <div className="space-y-5">
      <section className="rounded-3xl bg-gradient-to-br from-amber-700 to-orange-700 p-6 text-white">
        <p className="text-sm text-white">Karma points {karma.multiplier > 1 && <span className="ml-1 rounded-full bg-white/20 px-2 py-0.5 text-xs">{karma.multiplier}x with Plus ✨</span>}</p>
        <p className="text-4xl font-extrabold" data-testid="karma-balance">{karma.balance}</p>
        <p className="text-sm text-white">Worth ₹{Math.floor(karma.balance / 10)} at checkout (up to 20% of a booking)</p>
      </section>
      <section className="space-y-1 rounded-2xl border bg-white p-5 text-sm">
        <h2 className="font-bold">How to earn</h2>
        <ul className="list-disc space-y-0.5 pl-5 text-ink/70">
          <li>1 point for every ₹10 you pay</li>
          <li>+20 for each game you attend</li>
          <li>+10 for each review you write</li>
          <li>+5 for your first login of the day</li>
          {karma.multiplier === 1 && <li><Link href="/plus" className="text-brand underline">Playo Plus</Link> doubles all of it</li>}
        </ul>
      </section>
      <section className="space-y-2 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">History</h2>
        {karma.history.length === 0 ? <p className="text-sm text-ink/50">No Karma yet. Book a venue or log in tomorrow.</p> : (
          <ul className="divide-y text-sm" data-testid="karma-history">
            {karma.history.map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-3 py-2">
                <span>{t.note}<span className="block text-xs text-ink/40">{t.kind} · {new Date(t.createdAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}</span></span>
                <span className={`font-semibold ${t.points < 0 ? 'text-red-600' : 'text-green-700'}`}>{t.points < 0 ? '−' : '+'}{Math.abs(t.points)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
