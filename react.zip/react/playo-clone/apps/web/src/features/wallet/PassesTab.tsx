'use client';

import Link from 'next/link';
import { useState } from 'react';
import { app } from '@/store';
import { DEFAULT_VENUE_FILTER } from '@/config/constants';
import { BuyPassModal } from '@/features/booking';
import type { Pass } from '@/lib/api';
import { Price } from '@/components/ui/Price';

const until = (t: number) => new Date(t).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });

function PassCard({ p }: { p: Pass }) {
  return (
    <li className={`space-y-0.5 rounded-xl border p-3 text-sm ${p.active ? '' : 'opacity-60'}`} data-testid={`pass-${p.id}`}>
      <Link href={`/venues/${p.venueId}`} className="font-bold hover:text-brand">{p.venueName}</Link>
      <p>{p.kind === 'daily' ? `Day pass for ${p.validDate}` : `Monthly membership · ${p.hoursLeft} of ${p.hoursTotal} hours left`}</p>
      <p className="text-xs text-ink/50">{p.active ? `Valid until ${until(p.validUntil)}` : 'Expired or used up'} · paid ₹{p.paid}</p>
    </li>
  );
}

/** Day passes and monthly memberships, bought per venue and used at checkout */
export function PassesTab({ token }: { token: string }) {
  const [passes, , status] = app.useGlobalState('passes', token);
  const [me] = app.useGlobalState('me', token);
  const city = me?.city ?? DEFAULT_VENUE_FILTER.city;
  const [venues] = app.useGlobalState('mapVenues', { ...DEFAULT_VENUE_FILTER, city, sport: '', sort: 'rating' as const });
  const [venueId, setVenueId] = useState(0);
  const [kind, setKind] = useState<'daily' | 'monthly' | null>(null);
  const [venue] = app.useGlobalState('venue', venueId, { enabled: venueId > 0 });

  return (
    <div className="space-y-5">
      <section className="space-y-3 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Buy a pass</h2>
        <p className="text-sm text-ink/60">Pay once, then pick the pass at checkout instead of paying per hour. Passes work at one venue.</p>
        <select value={venueId} onChange={(e) => setVenueId(Number(e.target.value))} aria-label="Venue" data-testid="pass-venue" className="block w-full rounded-lg border px-3 py-2 text-sm">
          <option value={0}>Choose a venue in {city}…</option>
          {venues?.map((v) => <option key={v.id} value={v.id}>{v.name} · {v.area}</option>)}
        </select>
        {venue && (
          <div className="grid gap-3 sm:grid-cols-2">
            {(['daily', 'monthly'] as const).map((k) => (
              <div key={k} className="space-y-1 rounded-xl border p-3 text-sm">
                <p className="font-semibold">{k === 'daily' ? 'Day pass' : 'Monthly membership'}</p>
                <p className="text-ink/60">{venue.passes[k].note}</p>
                <p className="font-bold"><Price inr={venue.passes[k].priceInr} city={venue.city} /></p>
                <button onClick={() => setKind(k)} data-testid={`wallet-buy-pass-${k}`} className="rounded-lg border px-3 py-1.5 font-semibold hover:bg-black/5">Buy</button>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-2 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">My passes</h2>
        {!passes ? <p className="text-sm text-ink/50">{status.state === 'error' ? 'Couldn’t load passes.' : 'Loading…'}</p>
          : passes.length === 0 ? <p className="text-sm text-ink/50">No passes yet.</p>
          : <ul className="grid gap-2 sm:grid-cols-2" data-testid="my-passes">{passes.map((p) => <PassCard key={p.id} p={p} />)}</ul>}
      </section>
      {kind && venue && <BuyPassModal venue={venue} kind={kind} onClose={() => setKind(null)} />}
    </div>
  );
}
