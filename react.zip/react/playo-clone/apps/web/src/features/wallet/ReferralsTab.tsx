'use client';

import { app } from '@/store';
import { ShareMenu } from '@/components/ui/ShareMenu';
import { Skeleton } from '@/components/ui/Skeleton';

/** Your referral code, and who joined with it */
export function ReferralsTab({ token }: { token: string }) {
  const [r, , status] = app.useGlobalState('referrals', token);
  if (!r) return status.state === 'error' ? <p className="text-red-600">Couldn&apos;t load referrals.</p> : <Skeleton count={2} className="h-32" />;
  const rewarded = r.referred.filter((x) => x.rewarded).length;
  const path = `/?ref=${r.code}`;
  return (
    <div className="space-y-5">
      <section className="space-y-3 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Invite friends, get ₹{r.referrerBonus}</h2>
        <p className="text-sm text-ink/70">
          A friend who signs up with your code gets ₹{r.newcomerBonus}. After their first booking you get ₹{r.referrerBonus} and {r.referrerKarma} Karma.
        </p>
        <p>Your code: <code className="rounded bg-black/5 px-2 py-1 text-lg font-extrabold" data-testid="referral-code">{r.code}</code></p>
        <ShareMenu path={path} title="Join me on Playo clone" text={`Sign up with my code ${r.code} and get ₹${r.newcomerBonus}`} label="Share invite link" />
      </section>
      <section className="space-y-2 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Your referrals <span className="text-sm font-normal text-ink/50">({r.referred.length} joined, {rewarded} rewarded)</span></h2>
        {r.referred.length === 0 ? <p className="text-sm text-ink/50">Nobody yet.</p> : (
          <ul className="divide-y text-sm" data-testid="referred">
            {r.referred.map((x, i) => (
              <li key={i} className="flex items-center justify-between py-2">
                <span>{x.player ? `${x.player.avatarEmoji} ${x.player.name}` : 'A new player'}</span>
                <span className={x.rewarded ? 'text-green-700' : 'text-ink/50'}>{x.rewarded ? `Booked: you earned ₹${r.referrerBonus}` : 'Waiting for first booking'}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
