'use client';

import { useState } from 'react';
import { app } from '@/store';
import { api, type Wallet } from '@/lib/api';
import { money } from '@/lib/format';
import { Skeleton } from '@/components/ui/Skeleton';

const AMOUNTS = [200, 500, 1000, 2000];

export function WalletTab({ token }: { token: string }) {
  const [wallet, setWallet, status] = app.useGlobalState('wallet', token);
  const [amount, setAmount] = useState(500);
  const [method, setMethod] = useState<'upi' | 'card'>('upi');
  const [busy, setBusy] = useState(false);

  if (!wallet) return <Skeleton count={2} className="h-32" />;

  const topUp = async () => {
    setBusy(true);
    try {
      // The balance goes up now; if the payment is declined it goes back
      await setWallet(
        (prev) => ({ ...(prev as Wallet), balance: (prev?.balance ?? 0) + amount }),
        () => api.topUp(token, amount, method)
      );
      app.emit('toast', { kind: 'ok', text: `₹${amount} added to your wallet` });
    } catch (e) {
      app.emit('toast', { kind: 'err', text: `${e instanceof Error ? e.message : 'Payment failed'} — nothing was added` });
    } finally {
      setBusy(false);
      app.invalidate('wallet');
    }
  };

  return (
    <div className="space-y-6">
      <section className="rounded-3xl bg-gradient-to-br from-brand to-emerald-700 p-6 text-white">
        <p className="text-sm text-white">Balance</p>
        <p className="text-4xl font-extrabold" data-testid="wallet-balance">{money(wallet.balance)}</p>
        {status.fetching && <p className="text-xs text-white/70">updating…</p>}
      </section>

      <section className="space-y-3 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Add money</h2>
        <div className="flex flex-wrap gap-2">
          {AMOUNTS.map((a) => (
            <button key={a} onClick={() => setAmount(a)} className={`rounded-full border px-4 py-1.5 font-semibold ${amount === a ? 'border-brand bg-brand text-white' : 'hover:bg-black/5'}`}>{money(a)}</button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-4 text-sm">
          {(['upi', 'card'] as const).map((m) => (
            <label key={m} className="flex min-h-7 items-center gap-2"><input type="radio" name="method" checked={method === m} onChange={() => setMethod(m)} /> {m.toUpperCase()} (mock)</label>
          ))}
        </div>
        <button disabled={busy} onClick={topUp} data-testid="topup" className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white hover:bg-brand-dark">{busy ? 'Paying…' : `Pay ${money(amount)}`}</button>
      </section>

      <section className="space-y-2 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Coupons</h2>
        <ul className="text-sm">{wallet.coupons.map((c) => <li key={c.code}><code className="rounded bg-black/5 px-1.5 py-0.5 font-semibold">{c.code}</code> {c.label}</li>)}</ul>
      </section>

      <section className="space-y-2 rounded-2xl border bg-white p-5">
        <h2 className="font-bold">Transactions</h2>
        {wallet.transactions.length === 0 ? <p className="text-sm text-ink/50">No transactions yet.</p> : (
          <ul className="divide-y text-sm" data-testid="transactions">
            {wallet.transactions.map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-3 py-2">
                <span>{t.note}<span className="block text-xs text-ink/40">{t.kind} · {new Date(t.createdAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}</span></span>
                <span className={`font-semibold ${t.amount < 0 ? 'text-red-600' : 'text-green-700'}`}>{t.amount < 0 ? '−' : '+'}{money(Math.abs(t.amount))}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
