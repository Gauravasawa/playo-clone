'use client';

import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { app } from '@/store';
import { useMounted } from '@/lib/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { Tabs } from '@/components/ui/Tabs';
import { GiftCardsTab } from './GiftCardsTab';
import { KarmaTab } from './KarmaTab';
import { PassesTab } from './PassesTab';
import { ReferralsTab } from './ReferralsTab';
import { WalletTab } from './WalletTab';

const TABS = [
  { id: 'wallet', label: 'Wallet' },
  { id: 'karma', label: 'Karma' },
  { id: 'gift', label: 'Gift cards' },
  { id: 'passes', label: 'Passes' },
  { id: 'referrals', label: 'Refer & earn' },
] as const;
type TabId = (typeof TABS)[number]['id'];

export function WalletView() {
  const mounted = useMounted();
  const router = useRouter();
  const path = usePathname() ?? '/wallet';
  const params = useSearchParams();
  const [token] = app.useGlobalState('token');
  const asked = params?.get('tab') ?? null;
  const tab: TabId = TABS.some((t) => t.id === asked) ? (asked as TabId) : 'wallet';

  if (!mounted) return null;
  if (!token)
    return (
      <>
      <h1 className="mb-4 text-2xl font-extrabold">Wallet &amp; Karma</h1>
      <EmptyState>
        <p className="mb-3">Log in to use your wallet.</p>
        <button onClick={() => app.setState('loginOpen', true)} className="rounded-full bg-brand px-6 py-2.5 font-semibold text-white">Log in</button>
      </EmptyState>
      </>
    );

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-extrabold">Wallet &amp; Karma</h1>
      <Tabs tabs={[...TABS]} value={tab} onChange={(id) => router.replace(id === 'wallet' ? path : `${path}?tab=${id}`, { scroll: false })} />
      {tab === 'wallet' && <WalletTab token={token} />}
      {tab === 'karma' && <KarmaTab token={token} />}
      {tab === 'gift' && <GiftCardsTab token={token} />}
      {tab === 'passes' && <PassesTab token={token} />}
      {tab === 'referrals' && <ReferralsTab token={token} />}
    </div>
  );
}
