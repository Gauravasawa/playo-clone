export { WalletView } from './WalletView';
