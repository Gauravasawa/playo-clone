export class ApiError extends Error {
  constructor(public status: number, message: string, public retryAfter?: number) {
    super(message);
  }
}

/**
 * In the browser requests go to the same origin (`/api/...`, which Next forwards to the backend).
 * On the server there is no origin to be relative to, so they go to the backend directly.
 */
const BASE = typeof window === 'undefined' ? (process.env.API_URL ?? 'http://localhost:4000') : '';

/**
 * The Lab's "simulate failures" switches live in the store, but the client can't import the store
 * (the store imports the api), so the store registers readers here.
 */
let failing: () => boolean = () => false;
let payFailing: () => boolean = () => false;
export const setFailureReader = (fn: () => boolean) => { failing = fn; };
export const setPaymentFailureReader = (fn: () => boolean) => { payFailing = fn; };

/** Called when the server says "slow down" (HTTP 429), so the app can tell the person once, whatever they were doing */
let onRateLimited: (message: string, retryAfter: number) => void = () => {};
export const setRateLimitHandler = (fn: typeof onRateLimited) => { onRateLimited = fn; };

export interface CallOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  token?: string | null;
  body?: unknown;
  signal?: AbortSignal;
}

/** Every request goes through here: JSON in, JSON out, errors as ApiError */
export async function call<T>(path: string, opts: CallOptions = {}): Promise<T> {
  const isWrite = !!opts.method && opts.method !== 'GET';
  const res = await fetch(`${BASE}/api${path}`, {
    method: opts.method ?? 'GET',
    signal: opts.signal,
    cache: 'no-store',
    headers: {
      ...(opts.body !== undefined && { 'content-type': 'application/json' }),
      ...(opts.token && { authorization: `Bearer ${opts.token}` }),
      ...(isWrite && failing() && { 'x-simulate-failure': '1' }),
      ...(isWrite && payFailing() && { 'x-simulate-payment-failure': '1' }),
    },
    body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const body = data as { error?: string; retryAfter?: number };
    if (res.status === 429) onRateLimited(body.error ?? 'Too many requests', body.retryAfter ?? 5);
    throw new ApiError(res.status, body.error ?? `Request failed (${res.status})`, body.retryAfter);
  }
  return data as T;
}

/** A query string from an object; empty values are left out */
export const qs = (o: Record<string, string | number | undefined | null>) =>
  new URLSearchParams(
    Object.entries(o)
      .filter(([, v]) => v !== undefined && v !== null && v !== '')
      .map(([k, v]) => [k, String(v)])
  ).toString();
