import { call } from '../client';
import type { Badges, Me, ProfileUpdate } from '../types';

export const authApi = {
  login: (body: { phone: string; name: string; otp: string; referral?: string }) => call<{ token: string }>('/auth/login', { method: 'POST', body }),
  me: (token: string, signal?: AbortSignal) => call<Me>('/me', { token, signal }),
  updateProfile: (token: string, body: ProfileUpdate) => call<Me>('/me/profile', { method: 'PUT', token, body }),
  saveFavorites: (token: string, favorites: number[]) => call('/favorites', { method: 'PUT', token, body: { favorites } }),
  badges: (token: string, signal?: AbortSignal) => call<Badges>('/badges', { token, signal }),
};
