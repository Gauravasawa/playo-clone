import { call } from '../client';
import type { Booking, BookingRequest, NewBooking, Quote } from '../types';

export const bookingsApi = {
  bookings: (token: string, signal?: AbortSignal) => call<Booking[]>('/bookings', { token, signal }),
  /** The server's price for a booking: the checkout compares it with its own calculation */
  quote: (token: string, body: BookingRequest, signal?: AbortSignal) => call<Quote>('/bookings/quote', { method: 'POST', token, body, signal }),
  book: (token: string, body: NewBooking) => call<Booking>('/bookings', { method: 'POST', token, body }),
  cancelBooking: (token: string, id: number) => call<{ refunded: number; percent: number; karmaRefunded: number }>(`/bookings/${id}`, { method: 'DELETE', token }),
  rescheduleBooking: (token: string, id: number, body: { date: string; slots: string[] }) => call<Booking>(`/bookings/${id}/reschedule`, { method: 'POST', token, body }),
  /** Demo: marks a booking as attended, which unlocks the venue review */
  attendBooking: (token: string, id: number) => call<Booking>(`/bookings/${id}/attend`, { method: 'POST', token }),
};
