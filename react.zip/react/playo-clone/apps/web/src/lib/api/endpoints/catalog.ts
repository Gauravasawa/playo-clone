import { call, qs } from '../client';
import type { Slot, Sport, Venue, VenueDetail, VenueFilter, VenuePage } from '../types';

/** The filter as the query string the server reads */
const filterQuery = (f: VenueFilter) => ({
  city: f.city, sport: f.sport, q: f.q, sort: f.sort,
  amenities: f.amenities.join(','), maxPrice: f.maxPrice, maxKm: f.maxKm,
  lat: f.near?.lat, lng: f.near?.lng,
});

export const catalogApi = {
  sports: (signal?: AbortSignal) => call<Sport[]>('/sports', { signal }),
  venues: (page: number, f: VenueFilter, signal?: AbortSignal) => call<VenuePage>(`/venues?${qs({ page, limit: 6, ...filterQuery(f) })}`, { signal }),
  /** Everything that matches, in one go: what the map needs */
  venuesAll: (f: VenueFilter, signal?: AbortSignal) => call<VenuePage>(`/venues?${qs({ page: 1, limit: 60, ...filterQuery(f) })}`, { signal }).then((p) => p.items as Venue[]),
  venue: (id: number, signal?: AbortSignal) => call<VenueDetail>(`/venues/${id}`, { signal }),
  slots: (venueId: number, date: string, signal?: AbortSignal) => call<Slot[]>(`/venues/${venueId}/slots?date=${date}`, { signal }),
};
