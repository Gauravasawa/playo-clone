import { call } from '../client';
import type { Chat, ChatMessage, MessagesPage } from '../types';

export const chatsApi = {
  chats: (token: string, signal?: AbortSignal) => call<Chat[]>('/chats', { token, signal }),
  openDirect: (token: string, userId: number) => call<Chat>('/chats', { method: 'POST', token, body: { kind: 'direct', userId } }),
  createGroup: (token: string, title: string, memberIds: number[]) => call<Chat>('/chats', { method: 'POST', token, body: { kind: 'group', title, memberIds } }),
  messages: (token: string, chatId: number, before: number | null, signal?: AbortSignal) =>
    call<MessagesPage>(`/chats/${chatId}/messages?limit=30${before ? `&before=${before}` : ''}`, { token, signal }),
  sendMessage: (token: string, chatId: number, body: { body: string; image: string | null }) =>
    call<ChatMessage>(`/chats/${chatId}/messages`, { method: 'POST', token, body }),
  markChatRead: (token: string, chatId: number, upTo: number) => call(`/chats/${chatId}/read`, { method: 'POST', token, body: { upTo } }),
  addMembers: (token: string, chatId: number, userIds: number[]) => call<Chat>(`/chats/${chatId}/members`, { method: 'POST', token, body: { userIds } }),
  removeMember: (token: string, chatId: number, userId: number) => call(`/chats/${chatId}/members/${userId}`, { method: 'DELETE', token }),
};
