import { call, qs } from '../client';
import type { CoachDetail, CoachPage, CoachSlot, Enrolment, Learning, PayMethod } from '../types';

export const coachingApi = {
  coaches: (page: number, city: string, sport: string, signal?: AbortSignal) => call<CoachPage>(`/coaches?${qs({ page, limit: 6, city, sport })}`, { signal }),
  coach: (id: number, token: string | null, signal?: AbortSignal) => call<CoachDetail>(`/coaches/${id}`, { token, signal }),
  coachSlots: (id: number, date: string, signal?: AbortSignal) => call<CoachSlot[]>(`/coaches/${id}/slots?date=${date}`, { signal }),
  bookSession: (token: string, coachId: number, body: { date: string; time: string; method: PayMethod; karmaPoints?: number }) =>
    call(`/coaches/${coachId}/sessions`, { method: 'POST', token, body }),
  cancelSession: (token: string, id: number) => call<{ percent: number; refunded: number }>(`/coach-sessions/${id}`, { method: 'DELETE', token }),
  enrol: (token: string, programId: number, body: { batchId: number; method: PayMethod; karmaPoints?: number }) => call<Enrolment>(`/programs/${programId}/enrol`, { method: 'POST', token, body }),
  cancelEnrolment: (token: string, id: number) => call<{ percent: number; refunded: number }>(`/enrolments/${id}`, { method: 'DELETE', token }),
  learning: (token: string, signal?: AbortSignal) => call<Learning>('/learning', { token, signal }),
  reviewCoach: (token: string, coachId: number, body: { rating: number; body: string }) => call(`/coaches/${coachId}/reviews`, { method: 'POST', token, body }),
  coachEnquiry: (token: string, id: number, message: string) => call(`/coaches/${id}/enquiries`, { method: 'POST', token, body: { message } }),
  /** Demo: marks a trial session attended, or a program completed, which unlocks reviewing the coach */
  attendLearning: (token: string, kind: 'session' | 'enrolment', id: number) => call('/dev/attend', { method: 'POST', token, body: { kind, id } }),
};
