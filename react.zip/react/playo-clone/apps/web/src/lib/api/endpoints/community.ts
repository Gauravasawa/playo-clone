import { call, qs } from '../client';
import type { LeaderboardRow, Tournament, VenueReviews } from '../types';

export const communityApi = {
  venueReviews: (venueId: number, token: string | null, signal?: AbortSignal) => call<VenueReviews>(`/venues/${venueId}/reviews`, { token, signal }),
  postVenueReview: (token: string, venueId: number, body: { rating: number; body: string }) => call(`/venues/${venueId}/reviews`, { method: 'POST', token, body }),

  leaderboard: (sport: string, city: string, signal?: AbortSignal) => call<LeaderboardRow[]>(`/leaderboard?${qs({ sport, city })}`, { signal }),

  tournaments: (city: string, sport: string, token: string | null, signal?: AbortSignal) => call<Tournament[]>(`/tournaments?${qs({ city, sport })}`, { token, signal }),
  registerTournament: (token: string, id: number) => call(`/tournaments/${id}/register`, { method: 'POST', token }),
};
