import { call, qs } from '../client';
import type { NewMeetup, PayMethod, SportEvent } from '../types';

export const eventsApi = {
  events: (p: { type: string; city: string; q: string }, token: string | null, signal?: AbortSignal) => call<SportEvent[]>(`/events?${qs(p)}`, { token, signal }),
  event: (id: number, token: string | null, signal?: AbortSignal) => call<SportEvent>(`/events/${id}`, { token, signal }),
  registerEvent: (token: string, id: number, body: { category?: string; answer?: 'going' | 'maybe'; method?: PayMethod; karmaPoints?: number }) =>
    call<SportEvent>(`/events/${id}/register`, { method: 'POST', token, body }),
  cancelEvent: (token: string, id: number) => call<{ percent: number; refunded: number }>(`/events/${id}/register`, { method: 'DELETE', token }),
  createMeetup: (token: string, body: NewMeetup) => call<SportEvent>('/events', { method: 'POST', token, body }),
};
