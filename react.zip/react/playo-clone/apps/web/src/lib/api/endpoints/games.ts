import { call, qs } from '../client';
import type { Game, JoinResult, NewGame, PayMethod } from '../types';

export const gamesApi = {
  /** With a token, private games you can see (hosted, joined or invited to) are included */
  games: (city: string, sport: string, token: string | null, signal?: AbortSignal) => call<Game[]>(`/games?${qs({ city, sport })}`, { token, signal }),
  myGames: (token: string, status: 'open' | 'ended', signal?: AbortSignal) => call<Game[]>(`/games?${qs({ mine: 1, status })}`, { token, signal }),
  game: (id: number, token: string | null, signal?: AbortSignal) => call<Game>(`/games/${id}`, { token, signal }),
  /** What an invite link opens: works without a login */
  gameByCode: (code: string, token: string | null, signal?: AbortSignal) => call<Game>(`/games/by-code/${code}`, { token, signal }),
  hostGame: (token: string, body: NewGame) => call<Game>('/games', { method: 'POST', token, body }),
  joinGame: (token: string, id: number, body: { method?: PayMethod; karmaPoints?: number; code?: string } = {}) =>
    call<JoinResult>(`/games/${id}/join`, { method: 'POST', token, body }),
  leaveGame: (token: string, id: number) => call<{ refunded: number; early: boolean; game: Game }>(`/games/${id}/leave`, { method: 'POST', token }),
  cancelJoinRequest: (token: string, id: number) => call(`/games/${id}/requests`, { method: 'DELETE', token }),
  decideRequest: (token: string, id: number, userId: number, approve: boolean) =>
    call<Game>(`/games/${id}/requests/${userId}/${approve ? 'approve' : 'decline'}`, { method: 'POST', token }),
  invite: (token: string, id: number, userIds: number[]) => call<{ invited: number }>(`/games/${id}/invites`, { method: 'POST', token, body: { userIds } }),
  rsvp: (token: string, id: number, answer: 'going' | 'maybe' | 'no') => call<Game>(`/games/${id}/rsvp`, { method: 'POST', token, body: { answer } }),
  endGame: (token: string, id: number, body: { winnerIds: number[]; attendedIds?: number[] }) => call<Game>(`/games/${id}/end`, { method: 'POST', token, body }),
};
