import { call, qs } from '../client';
import type { Article, ArticleList, FaqResponse, Ticket, TicketMessage } from '../types';

export const helpApi = {
  faq: (q: string, signal?: AbortSignal) => call<FaqResponse>(`/faq?${qs({ q })}`, { signal }),
  articles: (p: { tag: string; q: string }, signal?: AbortSignal) => call<ArticleList>(`/articles?${qs(p)}`, { signal }),
  article: (slug: string, city: string, signal?: AbortSignal) => call<Article>(`/articles/${slug}?${qs({ city })}`, { signal }),
  tickets: (token: string, signal?: AbortSignal) => call<Ticket[]>('/tickets', { token, signal }),
  ticket: (token: string, id: number, signal?: AbortSignal) => call<Ticket>(`/tickets/${id}`, { token, signal }),
  createTicket: (token: string, body: { topic: string; subject: string; message: string; bookingId?: number | null }) => call<Ticket>('/tickets', { method: 'POST', token, body }),
  replyTicket: (token: string, id: number, body: string) => call<TicketMessage>(`/tickets/${id}/messages`, { method: 'POST', token, body: { body } }),
  closeTicket: (token: string, id: number) => call<Ticket>(`/tickets/${id}/close`, { method: 'POST', token }),
};
