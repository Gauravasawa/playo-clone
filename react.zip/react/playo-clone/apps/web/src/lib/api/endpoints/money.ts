import { call } from '../client';
import type { CouponResult, GiftCard, GiftCards, KarmaInfo, PayMethod, Pass, PlusStatus, Policy, Referrals, Wallet } from '../types';

export const moneyApi = {
  wallet: (token: string, signal?: AbortSignal) => call<Wallet>('/wallet', { token, signal }),
  topUp: (token: string, amount: number, method: Exclude<PayMethod, 'wallet'>) => call<{ balance: number }>('/wallet/topup', { method: 'POST', token, body: { amount, method } }),
  validateCoupon: (token: string, code: string, amount: number, signal?: AbortSignal) =>
    call<CouponResult>('/coupons/validate', { method: 'POST', token, body: { code, amount }, signal }),

  karma: (token: string, signal?: AbortSignal) => call<KarmaInfo>('/karma', { token, signal }),

  plus: (token: string, signal?: AbortSignal) => call<PlusStatus>('/plus', { token, signal }),
  subscribePlus: (token: string, body: { plan: 'monthly' | 'yearly'; method: PayMethod; karmaPoints?: number }) => call<PlusStatus>('/plus', { method: 'POST', token, body }),
  cancelPlus: (token: string) => call<PlusStatus>('/plus', { method: 'DELETE', token }),

  passes: (token: string, signal?: AbortSignal) => call<Pass[]>('/passes', { token, signal }),
  buyPass: (token: string, body: { venueId: number; kind: 'daily' | 'monthly'; date?: string; method: PayMethod; karmaPoints?: number }) => call<Pass>('/passes', { method: 'POST', token, body }),

  giftCards: (token: string, signal?: AbortSignal) => call<GiftCards>('/gift-cards', { token, signal }),
  buyGiftCard: (token: string, body: { amount: number; recipientId?: number | null; message?: string; method: PayMethod }) => call<GiftCard>('/gift-cards', { method: 'POST', token, body }),
  redeemGiftCard: (token: string, code: string) => call<{ amount: number; balance: number }>('/gift-cards/redeem', { method: 'POST', token, body: { code } }),

  referrals: (token: string, signal?: AbortSignal) => call<Referrals>('/referrals', { token, signal }),
  policy: (signal?: AbortSignal) => call<Policy>('/policy', { signal }),
};
