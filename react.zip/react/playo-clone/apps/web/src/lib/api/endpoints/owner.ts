import { call, qs } from '../client';
import type { NewVenue, OwnerDashboard, OwnerVenue, Venue } from '../types';

export const ownerApi = {
  ownerVenues: (token: string, signal?: AbortSignal) => call<OwnerVenue[]>('/owner/venues', { token, signal }),
  claimable: (token: string, city: string, signal?: AbortSignal) => call<Venue[]>(`/owner/claimable?${qs({ city })}`, { token, signal }),
  claimVenue: (token: string, id: number) => call<OwnerVenue>(`/owner/venues/${id}/claim`, { method: 'POST', token }),
  createVenue: (token: string, body: NewVenue) => call<OwnerVenue>('/owner/venues', { method: 'POST', token, body }),
  ownerVenue: (token: string, id: number, date: string, signal?: AbortSignal) => call<OwnerDashboard>(`/owner/venues/${id}?${qs({ date })}`, { token, signal }),
  setPricing: (token: string, id: number, body: { pricePerHour: number; peakExtra: number }) => call<{ pricePerHour: number; peakExtra: number }>(`/owner/venues/${id}/pricing`, { method: 'PUT', token, body }),
  blockHours: (token: string, id: number, body: { date: string; times: string[] }) => call<{ date: string; times: string[] }>(`/owner/venues/${id}/blocks`, { method: 'POST', token, body }),
  unblockHours: (token: string, id: number, body: { date: string; times: string[] }) => call<{ date: string; times: string[] }>(`/owner/venues/${id}/blocks`, { method: 'DELETE', token, body }),
  replyToReview: (token: string, reviewId: number, body: string) => call(`/owner/reviews/${reviewId}/reply`, { method: 'POST', token, body: { body } }),
};
