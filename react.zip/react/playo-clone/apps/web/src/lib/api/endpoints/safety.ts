import { call, qs } from '../client';
import type { AdminReport, Player } from '../types';

export const safetyApi = {
  blocks: (token: string, signal?: AbortSignal) => call<Player[]>('/blocks', { token, signal }),
  blockPlayer: (token: string, userId: number) => call('/blocks', { method: 'POST', token, body: { userId } }),
  unblockPlayer: (token: string, userId: number) => call(`/blocks/${userId}`, { method: 'DELETE', token }),
  reportReasons: (signal?: AbortSignal) => call<string[]>('/report-reasons', { signal }),
  report: (token: string, body: { kind: 'player' | 'message' | 'game' | 'review'; targetId: number; reason: string; details?: string }) => call<{ id: number }>('/reports', { method: 'POST', token, body }),
  adminReports: (token: string, status: string, signal?: AbortSignal) => call<AdminReport[]>(`/admin/reports?${qs({ status })}`, { token, signal }),
  decideReport: (token: string, id: number, decision: 'resolve' | 'dismiss') => call(`/admin/reports/${id}/${decision}`, { method: 'POST', token }),
};
