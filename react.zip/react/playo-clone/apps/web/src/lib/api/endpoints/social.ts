import { call, qs } from '../client';
import type { FollowRequest, FriendsData, NotificationPage, PlayedWith, PlayerProfile, PlayerWithRelationship, Suggestion } from '../types';

export const socialApi = {
  /** `token` is optional: without it the profile has no relationship to the viewer (what the server renders) */
  player: (username: string, token: string | null, signal?: AbortSignal) => call<PlayerProfile>(`/players/${username}`, { token, signal }),
  searchPlayers: (token: string, q: string, signal?: AbortSignal) => call<PlayerWithRelationship[]>(`/players/search?${qs({ q })}`, { token, signal }),
  playedWith: (token: string, signal?: AbortSignal) => call<PlayedWith[]>('/players/me/played-with', { token, signal }),
  suggested: (token: string, signal?: AbortSignal) => call<Suggestion[]>('/players/suggested', { token, signal }),
  ratePlayer: (token: string, playerId: number, body: { gameId: number; rating: number; body: string }) =>
    call(`/players/${playerId}/ratings`, { method: 'POST', token, body }),

  friends: (token: string, signal?: AbortSignal) => call<FriendsData>('/friends', { token, signal }),
  requestFriend: (token: string, userId: number) => call<{ id: number }>('/friends/requests', { method: 'POST', token, body: { userId } }),
  acceptFriend: (token: string, id: number) => call(`/friends/requests/${id}/accept`, { method: 'POST', token }),
  declineFriend: (token: string, id: number) => call(`/friends/requests/${id}/decline`, { method: 'POST', token }),
  cancelFriendRequest: (token: string, id: number) => call(`/friends/requests/${id}`, { method: 'DELETE', token }),
  unfriend: (token: string, userId: number) => call(`/friends/${userId}`, { method: 'DELETE', token }),

  follow: (token: string, userId: number) => call<{ status: 'following' | 'pending' }>('/follows', { method: 'POST', token, body: { userId } }),
  unfollow: (token: string, userId: number) => call(`/follows/${userId}`, { method: 'DELETE', token }),
  followRequests: (token: string, signal?: AbortSignal) => call<FollowRequest[]>('/follows/requests', { token, signal }),
  acceptFollow: (token: string, followerId: number) => call(`/follows/requests/${followerId}/accept`, { method: 'POST', token }),
  declineFollow: (token: string, followerId: number) => call(`/follows/requests/${followerId}/decline`, { method: 'POST', token }),

  notifications: (token: string, page: number, signal?: AbortSignal) => call<NotificationPage>(`/notifications?${qs({ page, limit: 10 })}`, { token, signal }),
  markRead: (token: string, ids?: number[]) => call<{ unread: number }>('/notifications/read', { method: 'POST', token, body: ids ? { ids } : {} }),
  devNotifications: (token: string, count: number) => call('/dev/notifications', { method: 'POST', token, body: { count } }),
};
