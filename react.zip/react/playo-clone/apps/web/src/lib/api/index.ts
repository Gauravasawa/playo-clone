import { authApi } from './endpoints/auth';
import { bookingsApi } from './endpoints/bookings';
import { catalogApi } from './endpoints/catalog';
import { chatsApi } from './endpoints/chats';
import { coachingApi } from './endpoints/coaching';
import { communityApi } from './endpoints/community';
import { eventsApi } from './endpoints/events';
import { gamesApi } from './endpoints/games';
import { helpApi } from './endpoints/help';
import { moneyApi } from './endpoints/money';
import { ownerApi } from './endpoints/owner';
import { safetyApi } from './endpoints/safety';
import { socialApi } from './endpoints/social';

/** The backend, as one object: `api.venues(...)`, `api.book(...)`. One file per area in endpoints/. */
export const api = {
  ...catalogApi, ...authApi, ...socialApi, ...chatsApi, ...bookingsApi, ...gamesApi, ...moneyApi,
  ...communityApi, ...coachingApi, ...eventsApi, ...ownerApi, ...helpApi, ...safetyApi,
};

export { ApiError, setFailureReader, setPaymentFailureReader, setRateLimitHandler } from './client';
export type * from './types';
