export type CurrencyCode = 'INR' | 'AED' | 'QAR' | 'AUD' | 'GBP';
export interface Sport { id: string; name: string; emoji: string }

/* ---------- Venues, slots ---------- */
export interface Equipment { id: string; name: string; priceInr: number }
export interface PassOffer { hours: number; priceInr: number; note: string }
export interface Venue {
  id: number; name: string; city: string; area: string; sports: string[];
  /** Rupees per hour (what is charged) and the extra for the 18:00–21:00 peak */
  pricePerHour: number; peakExtra: number;
  currency: CurrencyCode; pricePerHourLocal: number;
  rating: number; reviews: number; image: string; images: string[];
  amenities: string[]; address: string; description: string;
  lat: number; lng: number; equipment: Equipment[];
  ownerId: number | null; custom: boolean;
  /** Only when the list was asked with a position */
  distanceKm?: number | null;
}
export interface VenueDetail extends Venue { passes: { daily: PassOffer; monthly: PassOffer } }
export interface VenuePage { items: Venue[]; page: number; total: number; nextPage: number | null }
export interface VenueFilter {
  city: string; sport: string; q: string; sort: 'rating' | 'price' | 'distance';
  amenities: string[]; maxPrice: number | null; near: { lat: number; lng: number } | null; maxKm: number | null;
}
export interface Slot { time: string; price: number; available: boolean; reason: 'past' | 'blocked' | 'taken' | null }

/* ---------- People ---------- */
export type SkillLevel = 'Beginner' | 'Intermediate' | 'Advanced';
export interface SportLevel { sport: string; level: SkillLevel }
export interface Plays { days: ('weekday' | 'weekend')[]; times: ('morning' | 'evening')[] }

export interface Player {
  id: number; username: string; name: string; avatarEmoji: string; avatarColor: string; city: string; isPrivate: boolean; online: boolean; plus: boolean;
}
export interface Relationship {
  friend: 'none' | 'pending_out' | 'pending_in' | 'friends';
  friendshipId: number | null;
  follow: 'none' | 'pending' | 'following';
  followsMe: boolean;
  /** Requests are only allowed to players you've shared a finished game with */
  playedWith: boolean;
}
export interface PlusStatus { active: boolean; plan: 'monthly' | 'yearly' | null; renewsAt: number | null; cancelled: boolean; priceMonthly: number; priceYearly: number }
export interface Me {
  id: number; name: string; username: string; phone: string; bio: string; city: string;
  avatarEmoji: string; avatarColor: string; isPrivate: boolean; wallet: number; karma: number; plus: PlusStatus;
  referralCode: string; isAdmin: boolean; plays: Plays; favorites: number[]; sports: SportLevel[];
}
export interface ProfileUpdate {
  name: string; username: string; bio: string; city: string; avatarEmoji: string; avatarColor: string; isPrivate: boolean;
  sports: SportLevel[]; plays: Plays;
}
export interface Badge { id: string; label: string; emoji: string }
export interface PlayerStats { gamesPlayed: number; wins: number; bookings: number; friends: number; followers: number; following: number; reviewsWritten: number }
export interface PlayerRating { id: number; rating: number; body: string; createdAt: number; author: Player | null }
export interface PlayerProfile extends Player {
  bio: string; restricted: boolean; isMe: boolean; sports: SportLevel[]; plays: Plays;
  stats: Partial<PlayerStats> & { followers: number; following: number; friends: number };
  badges: Badge[]; rating: { avg: number; count: number }; ratings: PlayerRating[];
  relationship: Relationship | null; ratable: { id: number; title: string }[]; blockedByMe: boolean;
}
export interface PlayerWithRelationship extends Player { relationship: Relationship }
export interface PlayedWith { player: Player; games: number; lastAt: number; relationship: Relationship }
export interface Suggestion {
  player: Player; matchPercent: number; reasons: string[]; score: number;
  sharedSports: { sport: string; mine: string; theirs: string }[];
  relationship: Relationship; sharedGames: { id: number; title: string }[];
}

export interface FriendRequest { id: number; player: Player; createdAt: number }
export interface FriendsData { friends: Player[]; incoming: FriendRequest[]; outgoing: FriendRequest[] }
export interface FollowRequest { player: Player; createdAt: number }

/* ---------- Notifications ---------- */
export interface NotificationItem {
  id: number; type: string; read: boolean; createdAt: number;
  data: { actor?: Player; requestId?: number; text?: string; title?: string; gameId?: number; chatId?: number; [k: string]: unknown };
}
export interface NotificationPage { items: NotificationItem[]; page: number; total: number; nextPage: number | null; unread: number }
export interface Badges { notifications: number; chats: number }

/* ---------- Chat ---------- */
export interface ChatMessage { id: number; chatId: number; senderId: number; body: string; image: string | null; createdAt: number; /** only on the client, while it's being sent */ pending?: boolean; failed?: boolean }
export interface Chat {
  id: number; kind: 'direct' | 'group' | 'game'; title: string | null; gameId: number | null; createdBy: number;
  members: Player[]; reads: Record<number, number>; lastMessage: ChatMessage | null; unread: number;
}
export interface MessagesPage { items: ChatMessage[]; hasMore: boolean; reads: Record<number, number> }

/* ---------- Money ---------- */
export type PayMethod = 'wallet' | 'upi' | 'card';
export interface BookingExtra { id: string; name: string; hours: number; priceInr: number }
export interface Booking {
  id: number; venueId: number; venueName: string; area: string; city: string; currency: CurrencyCode; sport: string; date: string; slots: string[]; startsAt: number;
  total: number; slotsInr: number; extras: BookingExtra[]; extrasInr: number; discount: number; coupon: string | null;
  passId: number | null; passCovered: number; fee: number; karmaUsed: number; karmaDiscount: number; paid: number; method: PayMethod;
  status: 'confirmed' | 'attended'; createdAt: number;
  /** What cancelling now would give back, and what's allowed */
  refundPercent: number; canCancel: boolean; canReschedule: boolean;
}
export interface BookingRequest { venueId: number; date: string; slots: string[]; sport?: string; extras?: string[]; coupon?: string | null; karmaPoints?: number; passId?: number | null }
export interface NewBooking extends BookingRequest { method: PayMethod }
export interface Quote {
  venueId: number; date: string; startsAt: number; slots: { time: string; price: number }[]; slotsInr: number;
  extras: BookingExtra[]; extrasInr: number; passId: number | null; passCoveredInr: number; passHours: number;
  chargeableInr: number; coupon: string | null; couponDiscountInr: number; karmaPointsUsed: number; karmaDiscountInr: number;
  feeInr: number; payableInr: number; isPlus: boolean; earnKarma: number;
}
export interface WalletTx { id: number; amount: number; kind: string; note: string; createdAt: number }
export interface Wallet { balance: number; transactions: WalletTx[]; coupons: { code: string; label: string }[] }
export interface CouponResult { code: string; label: string; discount: number }
export interface KarmaTx { id: number; points: number; kind: string; note: string; createdAt: number }
export interface KarmaInfo { balance: number; history: KarmaTx[]; multiplier: number }
export interface Pass {
  id: number; venueId: number; venueName: string; city: string; kind: 'daily' | 'monthly'; validDate: string | null;
  hoursTotal: number; hoursLeft: number; validUntil: number; paid: number; active: boolean;
}
export interface GiftCard {
  code: string; amount: number; message: string; createdAt: number; expiresAt: number; buyer: Player | null; recipient: Player | null;
  redeemed: boolean; redeemedAt: number | null; expired: boolean; mine: boolean;
}
export interface GiftCards { bought: GiftCard[]; received: GiftCard[] }
export interface Referrals {
  code: string; newcomerBonus: number; referrerBonus: number; referrerKarma: number; referred: { player: Player | null; rewarded: boolean; joinedAt: number }[];
}
export interface Policy {
  convenienceFee: { percent: number; min: number; max: number };
  refund: { standard: { hoursBefore: number; percent: number }[]; plus: { hoursBefore: number; percent: number }[] };
  rescheduleUntilHoursBefore: number; gameLeaveRefundHoursBefore: number;
  karma: { rupeesPerPoint: number; maxShareOfPayable: number; perRupees: number; review: number; game: number; daily: number; referrer: number };
  plus: { monthly: number; yearly: number; karmaMultiplier: number };
  passes: { dailyHours: number; monthlyHours: number; monthlyDiscount: number };
  giftCard: { min: number; max: number; validMs: number };
  referral: { newcomer: number; referrer: number };
  welcomeBonus: number;
}

/* ---------- Games ---------- */
export interface GamePlayer { id: number; name: string; username: string; won: boolean; attended: boolean | null; paidInr?: number }
export interface JoinRequest { id: number; player: Player | null; level: string; paidInr: number; createdAt: number }
export interface Game {
  id: number; title: string; sport: string; city: string; hostName: string; hostId: number;
  startsAt: string; capacity: number; level: string; status: 'open' | 'ended'; endedAt: number | null; chatId: number | null;
  joinMode: 'open' | 'approval'; visibility: 'public' | 'private'; minLevel: SkillLevel | null; priceInr: number; inviteCode: string | null;
  venue: { id: number; name: string; area: string; currency: CurrencyCode } | null;
  players: GamePlayer[];
  rsvp: { going: number; maybe: number; no: number; mine: 'going' | 'maybe' | 'no' | null };
  requests?: JoinRequest[];
  me: { isHost: boolean; isPlayer: boolean; invited: boolean; request: 'pending' | 'approved' | 'declined' | null };
  viaCode?: boolean;
}
export interface NewGame {
  title: string; sport: string; venueId: number; startsAt: string; capacity: number; level: string;
  joinMode: 'open' | 'approval'; visibility: 'public' | 'private'; minLevel: SkillLevel | null; priceInr: number;
}
export interface JoinResult { joined: boolean; pending: boolean; game: Game }

/* ---------- Community ---------- */
export interface VenueReview { id: number; rating: number; body: string; createdAt: number; author: Player | null; reply: { body: string; createdAt: number } | null }
export interface VenueReviews { avg: number; count: number; canReview: boolean; items: VenueReview[] }
export interface LeaderboardRow { rank: number; player: Player; games: number; wins: number; points: number }
export interface Tournament {
  id: number; name: string; sport: string; city: string; startsAt: string; fee: number; prize: number; capacity: number; format: string;
  registered: boolean; spotsLeft: number;
}

/* ---------- Coaching ---------- */
export interface Coach {
  id: number; name: string; sport: string; city: string; area: string; experienceYears: number; pricePerSession: number; rating: number; bio: string;
  certifications: string[]; specialties: string[]; languages: string[]; reviewCount: number;
}
export interface CoachPage { items: Coach[]; page: number; total: number; nextPage: number | null }
export interface Batch { id: number; programId: number; days: string; time: string; startsOn: string; seats: number; seatsLeft: number; startsAt: number }
export interface Program { id: number; coachId: number; title: string; sport: string; level: string; sessions: number; weeks: number; priceInr: number; description: string; batches: Batch[] }
export interface CoachDetail extends Coach {
  programs: Program[]; canReview: boolean;
  reviews: { id: number; rating: number; body: string; createdAt: number; author: Player | null }[];
}
export interface CoachSlot { time: string; available: boolean; reason: 'past' | 'taken' | null }
export interface Enrolment {
  id: number; status: 'active' | 'cancelled' | 'completed'; paid: number; createdAt: number; startsAt: number; refundPercent: number;
  program: { id: number; title: string; sport: string; sessions: number }; coach: { id: number; name: string; city: string };
  batch: { id: number; days: string; time: string; startsOn: string };
}
export interface CoachSession {
  id: number; status: 'confirmed' | 'attended' | 'cancelled'; date: string; time: string; paid: number; startsAt: number; refundPercent: number;
  coach: { id: number; name: string; city: string; sport: string };
}
export interface Learning { enrolments: Enrolment[]; sessions: CoachSession[] }

/* ---------- Events ---------- */
export type EventType = 'marathon' | 'trek' | 'meetup';
export interface EventCategory { id: string; label: string; feeInr: number }
export interface EventParticipant { id: number; name: string; username: string; avatarEmoji: string; avatarColor: string; bib: number | null; category: string | null; status: string }
export interface SportEvent {
  id: number; type: EventType; title: string; city: string; startsAt: string; place: string; description: string;
  feeInr: number; capacity: number; hostName: string; hostId: number | null;
  categories?: EventCategory[]; difficulty?: 'Easy' | 'Moderate' | 'Hard'; itinerary?: string[]; sport?: string;
  going: number; spotsLeft: number; currency: CurrencyCode; isHost: boolean; past: boolean;
  mine: { status: 'going' | 'maybe'; category: string | null; bib: number | null; paid: number; refundPercent: number } | null;
  participants?: EventParticipant[];
}
export interface NewMeetup { title: string; city: string; startsAt: string; place: string; description: string; feeInr: number; capacity: number; sport?: string }

/* ---------- Venue owners ---------- */
export interface OwnerVenue extends Venue { stats: { bookings: number; upcoming: number; revenueInr: number } }
export interface OwnerDashboard {
  venue: OwnerVenue;
  pricing: { pricePerHour: number; peakExtra: number; currency: CurrencyCode; pricePerHourLocal: number };
  bookings: { id: number; date: string; slots: string[]; paid: number; status: string; method: string; player: Player | null }[];
  blocked: { date: string; times: string[] };
  revenue: { date: string; revenue: number; bookings: number }[];
  reviews: VenueReview[];
}
export interface NewVenue { name: string; city: string; area: string; sports: string[]; pricePerHourLocal: number; amenities: string[]; address: string; description: string }

/* ---------- Help ---------- */
export interface Faq { id: number; category: string; question: string; answer: string }
export interface FaqResponse { items: Faq[]; categories: string[]; total: number }
export interface ArticleSummary { slug: string; title: string; summary: string; tags: string[]; sport: string | null; readMinutes: number; publishedAt: string }
export interface Article extends ArticleSummary { body: string[]; relatedVenues: Venue[] }
export interface ArticleList { items: ArticleSummary[]; tags: string[] }
export interface TicketMessage { id: number; sender: 'user' | 'agent'; body: string; createdAt: number }
export interface Ticket {
  id: number; topic: string; subject: string; bookingId: number | null; status: 'open' | 'answered' | 'closed'; createdAt: number; updatedAt: number;
  lastMessage: { sender: 'user' | 'agent'; body: string; createdAt: number } | null; messages?: TicketMessage[];
}

/* ---------- Safety ---------- */
export interface AdminReport {
  id: number; kind: 'player' | 'message' | 'game' | 'review'; targetId: number; target: string; reason: string; details: string;
  status: 'open' | 'resolved' | 'dismissed'; createdAt: number; reporter: Player | null;
}
