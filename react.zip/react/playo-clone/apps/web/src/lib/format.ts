export const money = (n: number) => `₹${n.toLocaleString('en-IN')}`;

/** The next `n` days as `{ value: 'YYYY-MM-DD', day: 'Today' | 'Mon', date: '21' }` */
export function nextDays(n = 7): { value: string; day: string; date: string }[] {
  return Array.from({ length: n }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return { value, day: i === 0 ? 'Today' : d.toLocaleDateString('en-IN', { weekday: 'short' }), date: String(d.getDate()) };
  });
}

export const formatGameTime = (iso: string) =>
  new Date(iso).toLocaleString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
