'use client';

import { useEffect, useState } from 'react';

/**
 * False on the server and during hydration, true afterwards. Persisted state (city, token...) is
 * read from localStorage in the browser only, so UI that shows it waits for this to avoid a
 * server/client HTML mismatch.
 */
export function useMounted() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted;
}
