/** Shrinks a picture in the browser (longest side `max` px, JPEG) and returns it as a data URL, small enough to send in a message */
export async function shrinkImage(file: File, max = 900, quality = 0.8): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('Pick an image file');
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext('2d')!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return canvas.toDataURL('image/jpeg', quality);
}
