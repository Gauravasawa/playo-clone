/**
 * The booking price as the browser works it out while you pick slots, add rentals and apply a coupon or
 * Karma. It mirrors apps/api/src/services/pricing.ts and policy.ts; the server's own quote is the one
 * that is charged, and the checkout shows a notice if the two ever differ.
 *
 * It is a plain function so that the store's computed values, the checkout and the server-side quote
 * route (which runs the same store on the server) all use the same code.
 */
export const PRICING = {
  fee: { percent: 3, min: 10, max: 100 },
  karma: { rupeesPerPoint: 0.1, maxShare: 0.2, perRupees: 10 },
  plusKarmaMultiplier: 2,
} as const;

export interface QuoteInput {
  slots: { time: string; price: number }[];
  /** Rental items chosen: the price is per hour */
  extras: { id: string; name: string; priceInr: number }[];
  /** A pass pays for the slots */
  passCoversSlots: boolean;
  couponDiscountInr: number;
  karmaBalance: number;
  useKarma: boolean;
  isPlus: boolean;
}

export interface ComputedQuote {
  slotsInr: number; extrasInr: number; passCoveredInr: number; chargeableInr: number; couponDiscountInr: number;
  karmaPointsUsed: number; karmaDiscountInr: number; feeInr: number; payableInr: number; earnKarma: number;
}

export const convenienceFee = (chargeableInr: number, isPlus: boolean) =>
  isPlus || chargeableInr <= 0 ? 0 : Math.min(PRICING.fee.max, Math.max(PRICING.fee.min, Math.round((chargeableInr * PRICING.fee.percent) / 100)));

/** How much Karma takes off an amount: 10 points = ₹1, never more than 20% of it */
export function karmaDiscount(amountInr: number, balance: number, wanted: boolean) {
  if (!wanted) return { pointsUsed: 0, discountInr: 0 };
  const cap = Math.floor(Math.max(0, amountInr) * PRICING.karma.maxShare);
  const discountInr = Math.min(Math.floor(Math.max(0, balance) * PRICING.karma.rupeesPerPoint), cap);
  return { pointsUsed: Math.round(discountInr / PRICING.karma.rupeesPerPoint), discountInr };
}

export function computeQuote(i: QuoteInput): ComputedQuote {
  const slotsInr = i.slots.reduce((s, x) => s + x.price, 0);
  const extrasInr = i.extras.reduce((s, x) => s + x.priceInr * i.slots.length, 0);
  const passCoveredInr = i.passCoversSlots ? slotsInr : 0;
  const chargeableInr = slotsInr - passCoveredInr + extrasInr;
  const afterCoupon = chargeableInr - i.couponDiscountInr;
  const k = karmaDiscount(afterCoupon, i.karmaBalance, i.useKarma);
  const feeInr = convenienceFee(chargeableInr, i.isPlus);
  const payableInr = Math.max(0, afterCoupon - k.discountInr + feeInr);
  return {
    slotsInr, extrasInr, passCoveredInr, chargeableInr, couponDiscountInr: i.couponDiscountInr,
    karmaPointsUsed: k.pointsUsed, karmaDiscountInr: k.discountInr, feeInr, payableInr,
    earnKarma: Math.floor(payableInr / PRICING.karma.perRupees) * (i.isPlus ? PRICING.plusKarmaMultiplier : 1),
  };
}
