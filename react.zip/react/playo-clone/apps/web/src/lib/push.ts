/**
 * Browser notifications (the Notification API) for when the tab is in the background. They need the
 * person's permission, asked for from a button, never on page load.
 */
export const pushSupported = () => typeof window !== 'undefined' && 'Notification' in window;
export const pushPermission = (): NotificationPermission | 'unsupported' => (pushSupported() ? Notification.permission : 'unsupported');

/** Asks the browser for permission; true if it was granted */
export async function askForPush(): Promise<boolean> {
  if (!pushSupported()) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  return (await Notification.requestPermission()) === 'granted';
}

/** Shows a browser notification, but only when this tab can't be seen (otherwise the toast does the job) */
export function showPush(title: string, body: string, tag: string, onClick?: () => void) {
  if (!pushSupported() || Notification.permission !== 'granted' || document.visibilityState === 'visible') return false;
  const n = new Notification(title, { body, tag });
  n.onclick = () => {
    window.focus();
    onClick?.();
    n.close();
  };
  return true;
}
