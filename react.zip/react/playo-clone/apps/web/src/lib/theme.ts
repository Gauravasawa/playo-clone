'use client';

import { useSyncExternalStore } from 'react';

/** What the person chose; 'system' follows the operating system and changes with it */
export type ThemePref = 'light' | 'dark' | 'system';
/** What is actually shown */
export type Resolved = 'light' | 'dark';

export const THEME_PREFS: readonly ThemePref[] = ['light', 'dark', 'system'];
export const isThemePref = (v: unknown): v is ThemePref => v === 'light' || v === 'dark' || v === 'system';

const query = () => (typeof matchMedia === 'function' ? matchMedia('(prefers-color-scheme: dark)') : null);
export const resolveTheme = (pref: ThemePref): Resolved => (pref === 'system' ? (query()?.matches ? 'dark' : 'light') : pref);
export const reducedMotion = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
export const currentTheme = (): Resolved => (document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light');

/** Puts a theme on <html>: every colour in the app hangs off `data-theme`, so this one call re-colours the page */
export function paint(resolved: Resolved, pref: ThemePref) {
  const el = document.documentElement;
  el.dataset.theme = resolved;
  el.dataset.themePref = pref;
  el.style.colorScheme = resolved; // native controls (selects, date pickers, scrollbars) follow
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', resolved === 'dark' ? '#09110e' : '#f5f7f6');
}

type Origin = { x: number; y: number };
const DURATION = 900;

/**
 * Switches the theme with a reveal: the new theme grows out of the toggle as a circle while the old page tilts
 * back in 3D (a View Transition). Falls back to an instant switch when the browser has no View Transitions or the
 * person asked for reduced motion. `apply` must change the page synchronously.
 */
export async function runThemeTransition(apply: () => void, origin?: Origin) {
  const doc = document as Document & { startViewTransition?: (cb: () => void) => { ready: Promise<void>; finished: Promise<void> } };
  if (!doc.startViewTransition || reducedMotion()) {
    apply();
    return;
  }
  const root = document.documentElement;
  const x = origin?.x ?? innerWidth - 40;
  const y = origin?.y ?? 30;
  const radius = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
  root.classList.add('theme-switching');
  root.style.setProperty('--vt-x', `${x}px`);
  root.style.setProperty('--vt-y', `${y}px`);
  try {
    const transition = doc.startViewTransition(apply);
    await transition.ready;
    const ease = 'cubic-bezier(.22,.8,.26,1)';
    // the new theme: a circle growing out of the toggle, with the page swinging in from a slight 3D angle
    root.animate(
      { clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${radius}px at ${x}px ${y}px)`] },
      { duration: DURATION, easing: ease, pseudoElement: '::view-transition-new(root)' }
    );
    root.animate(
      { transform: ['perspective(1600px) rotateY(16deg) scale(1.04)', 'perspective(1600px) rotateY(0deg) scale(1)'] },
      { duration: DURATION, easing: ease, pseudoElement: '::view-transition-new(root)' }
    );
    // the old theme: tilts away and dims as it is covered
    root.animate(
      { transform: ['perspective(1600px) rotateY(0deg) scale(1)', 'perspective(1600px) rotateY(-22deg) scale(.9)'], opacity: [1, 0.35] },
      { duration: DURATION, easing: ease, fill: 'forwards', pseudoElement: '::view-transition-old(root)' }
    );
    await transition.finished;
  } finally {
    root.classList.remove('theme-switching');
    root.style.removeProperty('--vt-x');
    root.style.removeProperty('--vt-y');
  }
}

/** The theme being shown, as it is on <html> (so it is right even before React has loaded the saved choice) */
function subscribe(cb: () => void) {
  const mo = new MutationObserver(cb);
  mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  return () => mo.disconnect();
}
export function useResolvedTheme(): Resolved {
  return useSyncExternalStore(subscribe, currentTheme, () => 'light');
}
