import type { AppProps } from 'next/app';
import '../app/globals.css';
import '../app/theme.css';

// The Pages Router needs its own entry to load the global styles. Only /p/[username] lives here
// (see pages/p/[username].tsx for why); the rest of the app is in app/.
export default function PagesApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />;
}
