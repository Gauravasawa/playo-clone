import { Head, Html, Main, NextScript } from 'next/document';
import { ThemeScript } from '@/components/theme/ThemeScript';

// The Pages Router page (/p/[username]) needs the same pre-paint theme script as the App Router layout, or it would flash white in dark mode.
export default function Document() {
  return (
    <Html lang="en" suppressHydrationWarning>
      <Head>
        <meta name="color-scheme" content="light dark" />
        <ThemeScript />
      </Head>
      <body className="min-h-screen font-sans antialiased">
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
