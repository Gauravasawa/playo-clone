import type { GetServerSideProps } from 'next';
import Head from 'next/head';
import { useState } from 'react';
import { Shell } from '@/components/layout/Shell';
import { PublicProfileView } from '@/features/profile';
import { app } from '@/store';

/**
 * A player's public page, rendered the *other* way createStore supports SSR: no Server Component,
 * no <Root> carrying data. Instead:
 *   server:  getServerSideProps loads the profile into a scope (`createScope`) and returns its snapshot as page props;
 *            the page renders inside <Root scope={...}> made from that snapshot
 *   browser: `hydrate(snapshot)` fills the app's store from the same props
 * (This is how a store is used with the Pages Router or any server that renders React to a string. The library's other way, a
 * data tag written with `scope.toScript()` and read by `hydrate()`, needs `dangerouslySetInnerHTML`; this app does not use it:
 * the page props are already escaped by Next, so nothing is written into the page as raw HTML.)
 */
interface Props {
  username: string;
  /** What the server loaded, as plain JSON (a scope itself can't cross to the page) */
  snapshot: Record<string, unknown>;
}

export const getServerSideProps: GetServerSideProps<Props> = async ({ params }) => {
  const username = String(params?.username);
  const scope = app.createScope();
  await scope.fetchQuery('player', { username, token: null }).catch(() => {});
  return { props: { username, snapshot: JSON.parse(JSON.stringify(scope.snapshot())) } };
};

export default function PlayerPage({ username, snapshot }: Props) {
  // Server: a scope for this request, with what getServerSideProps loaded. Browser: the app's store, filled from the same snapshot.
  // The snapshot travels in the page props (Next writes them into __NEXT_DATA__ with its own escaping), so nothing is written into the
  // page as raw HTML: no data tag, no dangerouslySetInnerHTML.
  const [scope] = useState(() => (typeof window === 'undefined' ? app.createScope(snapshot as never) : app.hydrate(snapshot as never)));

  return (
    <>
      <Head>
        <title>{`@${username} · Playo clone`}</title>
        {/* the App Router adds its own icon; pages here have to say so */}
        <link rel="icon" href="/icon.svg" />
      </Head>
      <app.Root scope={scope}>
        <Shell>
          <PublicProfileView username={username} />
        </Shell>
      </app.Root>
    </>
  );
}
