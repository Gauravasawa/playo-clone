'use client';

import { useEffect } from 'react';
import { app } from '@/store';
import { handleEvent, refreshEverything } from './handlers';
import { connect, disconnect } from './socket';

/** Keeps one WebSocket open while someone is logged in, and lets the handlers write into the stores */
export function RealtimeProvider() {
  const [token] = app.useGlobalState('token');

  useEffect(() => {
    if (!token) {
      disconnect();
      app.setState('socket', 'closed');
      return;
    }
    connect(token, {
      onEvent: handleEvent,
      onStatus: (s) => app.setState('socket', s),
      onReconnect: refreshEverything,
    });
    return () => disconnect();
  }, [token]);

  // Another tab read the notifications: this tab's badge and list follow (the event is broadcast to every tab)
  useEffect(
    () =>
      app.on('notifications-read', () => {
        const t = app.getState('token');
        if (t) app.fetchQuery('badges', t, true).catch(() => {});
        app.invalidate('notifications');
      }),
    []
  );

  return null;
}
