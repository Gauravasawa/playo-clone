import type { ChatMessage, NotificationItem } from '@/lib/api';

/** What the backend pushes over the WebSocket (mirrors apps/api/src/realtime/hub.ts) */
export type ServerEvent =
  | { type: 'hello'; userId: number }
  | { type: 'notification'; notification: NotificationItem }
  | { type: 'message'; message: ChatMessage }
  | { type: 'typing'; chatId: number; userId: number }
  | { type: 'read'; chatId: number; userId: number; upTo: number }
  | { type: 'presence'; userId: number; online: boolean }
  | { type: 'chat'; chatId: number }
  | { type: 'ticket'; ticketId: number }
  | { type: 'refresh'; what: 'friends' | 'followRequests' | 'games' | 'wallet' | 'bookings' | 'player' | 'owner' | 'tickets' | 'learning' | 'events' | 'karma' };

/** What a browser may send */
export type ClientEvent = { type: 'typing'; chatId: number };
