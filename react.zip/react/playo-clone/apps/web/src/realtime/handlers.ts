import type { Chat, ChatMessage } from '@/lib/api';
import { describe } from '@/features/notifications/describe';
import { showPush } from '@/lib/push';
import { app } from '@/store';
import { chatStore } from '@/store/chat';
import type { ServerEvent } from './events';

const token = () => app.getState('token');
const myId = async () => {
  const t = token();
  return t ? ((await app.fetchQuery('me', t)).id as number) : null;
};

/** Is the chat open in a visible tab? Then new messages in it are read at once */
const viewing = (chatId: number) => chatStore.getState('activeChat') === chatId && document.visibilityState === 'visible';

/** Keeps the chat list entry in step with a new message, without reloading the list */
async function touchChatList(message: ChatMessage, mine: boolean) {
  const t = token();
  if (!t) return;
  let known = true;
  app.setQueryData(
    'chats',
    (prev: Chat[] | undefined) => {
      const chat = prev?.find((c) => c.id === message.chatId);
      if (!prev || !chat) {
        known = false;
        return prev;
      }
      const updated = { ...chat, lastMessage: message, unread: mine || viewing(chat.id) ? 0 : chat.unread + 1 };
      return [updated, ...prev.filter((c) => c.id !== chat.id)];
    },
    t
  );
  if (!known) await app.invalidate('chats'); // a chat this device hasn't seen yet
}

async function onMessage(message: ChatMessage) {
  await chatStore.messages.add(message);
  const me = await myId();
  const mine = message.senderId === me;
  await touchChatList(message, mine);
  if (mine) return;

  if (viewing(message.chatId)) {
    chatStore.actions.markSeen(message.chatId);
    return;
  }
  const t = token();
  if (t) app.fetchQuery('badges', t, true).catch(() => {});
  const chats = (t ? await app.fetchQuery('chats', t).catch(() => null) : null) as Chat[] | null;
  const chat = chats?.find((c) => c.id === message.chatId);
  const sender = chat?.members.find((m) => m.id === message.senderId);
  const text = message.body || 'sent a picture';
  app.emit('toast', { kind: 'ok', text: `💬 ${sender?.name ?? 'New message'}: ${text}` });
  if (app.getState('pushEnabled')) showPush(sender?.name ?? 'New message', text, `chat-${message.chatId}`, () => (location.href = `/chat/${message.chatId}`));
}

/** Which cached lists a kind of notification makes stale */
const STALE_BY_TYPE: [prefix: string, names: Parameters<typeof app.invalidate>[0][]][] = [
  ['friend_', ['friends', 'playedWith', 'player', 'suggested']],
  ['follow_', ['followRequests', 'player']],
  ['new_follower', ['followRequests', 'player']],
  ['game_', ['games', 'game', 'gameByCode', 'myGames']],
  ['booking_', ['bookings', 'wallet', 'karma', 'slots']],
  ['gift_card_', ['giftCards', 'wallet']],
  ['plus_', ['plus', 'me', 'wallet']],
  ['pass_', ['passes', 'wallet']],
  ['referral_', ['referrals', 'wallet', 'karma']],
  ['tournament_', ['tournaments', 'wallet']],
  ['program_', ['learning', 'coach', 'wallet']],
  ['session_', ['learning', 'coachSlots', 'wallet']],
  ['event_', ['events', 'event', 'wallet']],
  ['owner_', ['ownerVenues', 'ownerVenue']],
  ['review_', ['venueReviews']],
  ['ticket_', ['tickets', 'ticket']],
  ['report_', ['adminReports']],
];

/** The server pushed something: update what's on screen */
export function handleEvent(e: ServerEvent) {
  const t = token();
  switch (e.type) {
    case 'hello':
      return;

    case 'notification': {
      const d = describe(e.notification);
      app.emit('toast', { kind: 'ok', text: `${d.emoji} ${d.text}` });
      if (app.getState('pushEnabled')) showPush('Playo clone', `${d.emoji} ${d.text}`, `n-${e.notification.id}`, () => (location.href = d.href ?? '/notifications'));
      if (t) app.fetchQuery('badges', t, true).catch(() => {});
      app.invalidate('notifications');
      const type = e.notification.type;
      for (const [prefix, names] of STALE_BY_TYPE) if (type.startsWith(prefix)) names.forEach((n) => app.invalidate(n));
      if (type === 'game_ended') { app.invalidate('leaderboard'); app.invalidate('playedWith'); }
      return;
    }

    case 'message':
      void onMessage(e.message);
      return;

    case 'typing': {
      chatStore.typing.mark(e.chatId, e.userId, Date.now() + 4000);
      setTimeout(() => chatStore.typing.prune(Date.now()), 4200);
      return;
    }

    case 'read':
      chatStore.reads.set(e.chatId, e.userId, e.upTo);
      return;

    case 'presence':
      app.presence.set(e.userId, e.online);
      return;

    case 'chat':
      app.invalidate('chats');
      if (t) app.fetchQuery('badges', t, true).catch(() => {});
      return;

    case 'ticket':
      app.invalidate('tickets');
      app.invalidate('ticket');
      return;

    case 'refresh': {
      const stale: Record<typeof e.what, Parameters<typeof app.invalidate>[0][]> = {
        friends: ['friends', 'playedWith', 'player', 'suggested'],
        followRequests: ['followRequests', 'player'],
        games: ['games', 'game', 'gameByCode', 'myGames'],
        wallet: ['wallet', 'karma', 'me'],
        bookings: ['bookings'],
        player: ['player', 'leaderboard', 'playedWith'],
        owner: ['ownerVenues', 'ownerVenue'],
        tickets: ['tickets', 'ticket'],
        learning: ['learning', 'coach', 'coachSlots'],
        events: ['events', 'event'],
        karma: ['karma', 'me'],
      };
      stale[e.what].forEach((n) => app.invalidate(n));
      return;
    }
  }
}

/** The WebSocket was down for a while: anything may have changed */
export function refreshEverything() {
  const t = token();
  if (!t) return;
  for (const name of ['chats', 'friends', 'followRequests', 'notifications', 'wallet', 'games', 'bookings', 'learning', 'tickets'] as const) app.invalidate(name);
  app.fetchQuery('badges', t, true).catch(() => {});
  const active = chatStore.getState('activeChat');
  if (active) chatStore.actions.loadHistory(active).catch(() => {});
}
