import type { SocketStatus } from '@/store/types';
import type { ClientEvent, ServerEvent } from './events';

const url = (token: string) =>
  `${process.env.NEXT_PUBLIC_WS_URL ?? `ws://${location.hostname}:4000/ws`}?token=${encodeURIComponent(token)}`;

let ws: WebSocket | null = null;
let retryTimer: ReturnType<typeof setTimeout> | undefined;
let attempts = 0;
let wanted = false;

export interface SocketHandlers {
  onEvent: (e: ServerEvent) => void;
  onStatus: (s: SocketStatus) => void;
  /** The connection came back after having dropped: reload what may have changed meanwhile */
  onReconnect: () => void;
}

/** Opens the connection and keeps it open (with growing pauses between retries) until `disconnect()` */
export function connect(token: string, h: SocketHandlers) {
  disconnect();
  wanted = true;
  let everOpened = false;

  const open = () => {
    if (!wanted) return;
    h.onStatus('connecting');
    const socket = new WebSocket(url(token));
    ws = socket;
    socket.onopen = () => {
      attempts = 0;
      h.onStatus('open');
      if (everOpened) h.onReconnect();
      everOpened = true;
    };
    socket.onmessage = (m) => {
      try {
        h.onEvent(JSON.parse(String(m.data)) as ServerEvent);
      } catch (e) {
        console.error('bad websocket message', e);
      }
    };
    socket.onclose = () => {
      if (ws === socket) ws = null;
      h.onStatus('closed');
      if (!wanted) return;
      retryTimer = setTimeout(open, Math.min(10_000, 500 * 2 ** attempts++));
    };
    socket.onerror = () => socket.close();
  };
  open();
}

export function disconnect() {
  wanted = false;
  clearTimeout(retryTimer);
  const socket = ws;
  ws = null;
  if (socket) {
    socket.onclose = null;
    socket.close();
  }
}

export function send(event: ClientEvent) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(event));
}
