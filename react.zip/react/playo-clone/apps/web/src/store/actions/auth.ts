import { api } from '@/lib/api';
import { EMPTY_CHECKOUT, EMPTY_SELECTION } from '../state';
import type { ActionContext } from './types';

/** Log in and out: both touch several keys at once */
export const authActions = (s: ActionContext) => ({
  async login(phone: string, name: string, otp: string) {
    const referral = s.getState('pendingReferral') || undefined;
    const { token } = await api.login({ phone, name, otp, referral });
    s.batch(() => {
      s.token(token);
      s.pendingReferral(''); // used (or it was not valid, and then the login above would have failed)
    });
    // Bring the server's favorites into this device (the server wins after login)
    const me = await s.fetchQuery('me', token, true).catch(() => null);
    if (me) s.favorites(me.favorites);
    s.emit('toast', { kind: 'ok', text: `Welcome${me ? `, ${me.name}` : ''}!` });
  },

  logout() {
    s.batch(() => {
      s.token(null);
      s.favorites([]);
      s.selection(EMPTY_SELECTION);
      s.checkout(EMPTY_CHECKOUT);
    });
    s.emit('toast', { kind: 'ok', text: 'Logged out' });
  },
});
