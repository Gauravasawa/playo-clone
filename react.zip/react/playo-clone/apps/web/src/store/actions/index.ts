import { authActions } from './auth';
import type { ActionContext } from './types';

/** Multi-step operations: one file per area, merged here as `app.actions.<name>()` */
export const actions = (s: ActionContext) => ({
  ...authActions(s),
});
