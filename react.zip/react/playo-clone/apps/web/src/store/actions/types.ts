import type { Me } from '@/lib/api';
import type { Checkout, Selection, Toast } from '../types';

/**
 * What actions may use of the store's `api`: written out here so action files don't depend on the
 * store being defined (the store is built from them).
 */
export interface ActionContext {
  token(value: string | null): Promise<void>;
  favorites(value: number[]): Promise<void>;
  selection(value: Selection): Promise<void>;
  checkout(value: Checkout): Promise<void>;
  pendingReferral(value: string): Promise<void>;
  getState(key: 'pendingReferral'): string;
  batch<T>(fn: () => T): T;
  emit(event: 'toast', payload: Toast): void;
  fetchQuery(name: 'me', params: string, force?: boolean): Promise<Me>;
}
