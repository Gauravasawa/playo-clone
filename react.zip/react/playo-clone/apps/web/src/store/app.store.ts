import { createStore, defineEvents } from '@/lib/store/createStore';
import { setFailureReader, setPaymentFailureReader, setRateLimitHandler } from '@/lib/api';
import { actions } from './actions';
import { bindStore, bridge } from './bridge';
import { computed } from './computed';
import { keyActions } from './key-actions';
import { history, persist, syncTabs } from './persistence';
import { queries } from './queries';
import { state } from './state';
import { ssr } from './ssr';
import { validate } from './validate';
import type { AppEvents } from './types';

const errorText = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong');

/**
 * The app's global store. This file only wires the parts together:
 *   state.ts · queries.ts · computed.ts · key-actions/ · actions/ · persistence.ts · ssr.ts · validate.ts · types.ts
 */
export const app = createStore(
  { ...state, ...queries },
  {
    name: 'playo',
    shared: typeof window !== 'undefined', // one instance across hot reloads (browser only: the library ignores it on the server)
    ssr, // one store per request on the server; see ssr.ts and the README
    persist,
    syncTabs,
    history,
    events: defineEvents<AppEvents>(),
    computed,
    keyActions,
    actions: (s) => actions(s),

    // Keep server data and queue saves while offline: with the network off, pages show what was last
    // loaded, and saves (favourites, messages...) wait and run when the connection is back
    // maxSize: the offline copy of server data is not kept if it grows past 1,000,000 characters
    offline: { maxSize: 1_000_000 },
    // Saved state, the offline copy and other tabs' changes are checked before they're used
    validate,
    // Redux DevTools (if the browser extension is installed), and a console log of every change; both only in development
    devtools: process.env.NODE_ENV !== 'production',
    logger: process.env.NEXT_PUBLIC_STORE_LOGGER === '1',

    // onSaveStart / onSaveSuccess / onSaveError keep a count of saves in flight; the header shows "Saving…" while it is above 0
    onSaveStart: () => void app.setState('pendingSaves', (n) => n + 1),
    onSaveSuccess: (key, action) => {
      void app.setState('pendingSaves', (n) => Math.max(0, n - 1));
      bridge.toast({ kind: 'ok', text: `Saved ${key}.${action}` });
    },
    onSaveError: (key, action, error) => {
      void app.setState('pendingSaves', (n) => Math.max(0, n - 1));
      bridge.toast({ kind: 'err', text: `Couldn't save ${key}.${action}: ${errorText(error)}. Change undone.` });
    },
  }
);

bindStore({
  getToken: () => app.getState('token'),
  toast: (t) => app.emit('toast', t),
  simulateFailure: () => app.getState('simulateFailure'),
  simulatePaymentFailure: () => app.getState('simulatePaymentFailure'),
});
// The Lab's switches are browser state. On the server (Server Actions, Route Handlers) there is no
// request store to read them from, and `app.getState()` there throws, so only the browser registers them.
if (typeof window !== 'undefined') {
  // A 429 from any request becomes one toast that says how long to wait
  setRateLimitHandler((message) => bridge.toast({ kind: 'err', text: message }));
  setFailureReader(() => bridge.simulateFailure());
  setPaymentFailureReader(() => bridge.simulatePaymentFailure());
}
