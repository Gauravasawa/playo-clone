import type { Toast } from './types';

/**
 * Key-action `save` callbacks and the store's error hooks run inside the options of createStore,
 * before the store exists. They reach it through this bridge, which `bindStore` fills in right
 * after the store is created.
 */
interface Bridge {
  getToken: () => string | null;
  toast: (toast: Toast) => void;
  simulateFailure: () => boolean;
  simulatePaymentFailure: () => boolean;
}

export const bridge: Bridge = {
  getToken: () => null,
  toast: () => {},
  simulateFailure: () => false,
  simulatePaymentFailure: () => false,
};

export function bindStore(deps: Bridge) {
  Object.assign(bridge, deps);
}
