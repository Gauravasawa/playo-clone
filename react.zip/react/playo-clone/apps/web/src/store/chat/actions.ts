import { api, type ChatMessage } from '@/lib/api';
import { app } from '../app.store';

/** What chat actions use of their store's api (written out so this file doesn't need the store to exist) */
export interface ChatActionContext {
  getState(key: 'messages'): Record<number, ChatMessage[]>;
  getState(key: 'reads'): Record<number, Record<number, number>>;
  getState(key: 'drafts'): Record<number, string>;
  messages: {
    add(m: ChatMessage): Promise<void>;
    addMany(chatId: number, items: ChatMessage[]): Promise<void>;
    confirm(chatId: number, tempId: number, real: ChatMessage): Promise<void>;
    fail(chatId: number, tempId: number): Promise<void>;
    retrying(chatId: number, tempId: number): Promise<void>;
    discard(chatId: number, tempId: number): Promise<void>;
  };
  drafts: { set(chatId: number, text: string): Promise<void> };
  reads: { set(chatId: number, userId: number, upTo: number): Promise<void>; replace(chatId: number, reads: Record<number, number>): Promise<void> };
  hasMore: { set(chatId: number, more: boolean): Promise<void> };
  /** Runs the task now, or when the connection is back */
  whenOnline(task: () => Promise<unknown> | unknown): Promise<unknown>;
}

const token = () => {
  const t = app.getState('token');
  if (!t) throw new Error('Log in first');
  return t;
};
const myId = async () => (await app.fetchQuery('me', token())).id as number;

export const chatActions = (s: ChatActionContext) => {
  const transmit = async (chatId: number, temp: ChatMessage) => {
    const t = token();
    try {
      // Offline: the message shows as "sending…" and goes out when the connection is back
      const real = (await s.whenOnline(() => api.sendMessage(t, chatId, { body: temp.body, image: temp.image }))) as ChatMessage;
      await s.messages.confirm(chatId, temp.id, real);
    } catch {
      await s.messages.fail(chatId, temp.id);
    }
  };

  return {
    /** Shows the message at once, then sends it; it stays in the list marked "failed" if sending fails */
    async send(chatId: number, body: string, image: string | null) {
      const temp: ChatMessage = { id: -Date.now(), chatId, senderId: await myId(), body, image, createdAt: Date.now(), pending: true };
      await s.messages.add(temp);
      await s.drafts.set(chatId, '');
      await transmit(chatId, temp);
    },

    async retry(chatId: number, tempId: number) {
      const temp = s.getState('messages')[chatId]?.find((m) => m.id === tempId);
      if (!temp) return;
      await s.messages.retrying(chatId, tempId);
      await transmit(chatId, temp);
    },

    /** The newest messages of a chat, merged into what's on the device */
    async loadHistory(chatId: number) {
      const page = await api.messages(token(), chatId, null);
      await s.messages.addMany(chatId, page.items);
      await s.reads.replace(chatId, page.reads);
      await s.hasMore.set(chatId, page.hasMore);
    },

    async loadOlder(chatId: number) {
      const oldest = s.getState('messages')[chatId]?.find((m) => m.id > 0);
      if (!oldest) return;
      const page = await api.messages(token(), chatId, oldest.id);
      await s.messages.addMany(chatId, page.items);
      await s.hasMore.set(chatId, page.hasMore);
    },

    /** Tells the server (and so the other members) that everything in this chat has been read */
    async markSeen(chatId: number) {
      const me = await myId();
      const newest = [...(s.getState('messages')[chatId] ?? [])].reverse().find((m) => m.id > 0);
      if (!newest || (s.getState('reads')[chatId]?.[me] ?? 0) >= newest.id) return;
      await s.reads.set(chatId, me, newest.id);
      await api.markChatRead(token(), chatId, newest.id).catch(() => {});
    },
  };
};
