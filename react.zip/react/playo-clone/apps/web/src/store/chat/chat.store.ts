import { createStore } from '@/lib/store/createStore';
import { chatActions } from './actions';
import { idbStorage } from './idb';
import { draftActions, hasMoreActions, messageActions, readActions, typingActions } from './key-actions';
import { chatState } from './state';

/** Messages, drafts and read receipts: big, per-device data, kept apart from the app store */
export const chatStore = createStore(chatState, {
  name: 'playo-chat',
  shared: typeof window !== 'undefined',
  // Saved in IndexedDB, which is asynchronous: the store starts empty and fills in when it has loaded.
  // `debounce`: typing a message changes `drafts` on every key; it's written once typing pauses.
  persist: { storage: idbStorage, keys: ['messages', 'drafts', 'reads'], version: 1, debounce: 300 },
  // Another tab's half-typed message shows up here too
  syncTabs: { keys: ['drafts'] },
  validate: (key, value) => (key === 'messages' || key === 'drafts' || key === 'reads') && typeof value === 'object' && value !== null && !Array.isArray(value),
  keyActions: {
    messages: messageActions,
    drafts: draftActions,
    reads: readActions,
    typing: typingActions,
    hasMore: hasMoreActions,
  },
  actions: (s) => chatActions(s),
});
