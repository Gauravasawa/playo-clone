import type { StorageAdapter } from '@/lib/store/createStore';

const DB_NAME = 'playo-chat';
const STORE = 'kv';

let opening: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  opening ??= new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return opening;
}

/** Wraps one IndexedDB request in a promise */
const request = <T,>(make: (store: IDBObjectStore) => IDBRequest<T>, mode: IDBTransactionMode): Promise<T> =>
  open().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const req = make(db.transaction(STORE, mode).objectStore(STORE));
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      })
  );

/**
 * A StorageAdapter on IndexedDB, so the chat store's saved state is loaded asynchronously.
 * On the server (no IndexedDB) there's nothing saved, and writes do nothing.
 */
export const idbStorage: StorageAdapter = {
  async getItem(key) {
    if (typeof indexedDB === 'undefined') return null;
    return ((await request((s) => s.get(key), 'readonly')) as string | undefined) ?? null;
  },
  async setItem(key, value) {
    if (typeof indexedDB === 'undefined') return;
    await request((s) => s.put(value, key), 'readwrite');
  },
  async removeItem(key) {
    if (typeof indexedDB === 'undefined') return;
    await request((s) => s.delete(key), 'readwrite');
  },
};
