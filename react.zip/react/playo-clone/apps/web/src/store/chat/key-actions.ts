import type { ChatMessage } from '@/lib/api';

const KEEP = 100; // messages kept per chat

/** Merges messages into a chat's list: no duplicates (by id), oldest first, newest 100 kept */
const merged = (list: ChatMessage[], incoming: ChatMessage[]) => {
  const byId = new Map(list.map((m) => [m.id, m]));
  for (const m of incoming) byId.set(m.id, { ...byId.get(m.id), ...m });
  return [...byId.values()].sort((a, b) => (a.createdAt - b.createdAt) || (a.id - b.id)).slice(-KEEP);
};

export const messageActions = {
  add: (cur: Record<number, ChatMessage[]>, message: ChatMessage) => ({ ...cur, [message.chatId]: merged(cur[message.chatId] ?? [], [message]) }),

  addMany: (cur: Record<number, ChatMessage[]>, chatId: number, items: ChatMessage[]) => ({ ...cur, [chatId]: merged(cur[chatId] ?? [], items) }),

  /** A message that was waiting to be sent (negative temporary id) became a real one */
  confirm: (cur: Record<number, ChatMessage[]>, chatId: number, tempId: number, real: ChatMessage) => ({
    ...cur,
    // the server may have pushed the real message over the WebSocket first: then there is just one
    [chatId]: merged((cur[chatId] ?? []).filter((m) => m.id !== tempId), [real]),
  }),

  fail: (cur: Record<number, ChatMessage[]>, chatId: number, tempId: number) => ({
    ...cur,
    [chatId]: (cur[chatId] ?? []).map((m) => (m.id === tempId ? { ...m, pending: false, failed: true } : m)),
  }),

  retrying: (cur: Record<number, ChatMessage[]>, chatId: number, tempId: number) => ({
    ...cur,
    [chatId]: (cur[chatId] ?? []).map((m) => (m.id === tempId ? { ...m, pending: true, failed: false } : m)),
  }),

  discard: (cur: Record<number, ChatMessage[]>, chatId: number, tempId: number) => ({
    ...cur,
    [chatId]: (cur[chatId] ?? []).filter((m) => m.id !== tempId),
  }),
};

export const draftActions = {
  set: (cur: Record<number, string>, chatId: number, text: string) => {
    if (text === (cur[chatId] ?? '')) return cur;
    const { [chatId]: _old, ...rest } = cur;
    return text ? { ...rest, [chatId]: text } : rest;
  },
};

export const readActions = {
  set: (cur: Record<number, Record<number, number>>, chatId: number, userId: number, upTo: number) => {
    const chat = cur[chatId] ?? {};
    return (chat[userId] ?? 0) >= upTo ? cur : { ...cur, [chatId]: { ...chat, [userId]: upTo } };
  },
  replace: (cur: Record<number, Record<number, number>>, chatId: number, reads: Record<number, number>) => ({ ...cur, [chatId]: reads }),
};

export const typingActions = {
  mark: (cur: Record<number, Record<number, number>>, chatId: number, userId: number, until: number) => ({
    ...cur, [chatId]: { ...(cur[chatId] ?? {}), [userId]: until },
  }),
  /** Forgets people whose "typing" has run out */
  prune: (cur: Record<number, Record<number, number>>, now: number) => {
    let changed = false;
    const next: Record<number, Record<number, number>> = {};
    for (const [chatId, who] of Object.entries(cur)) {
      const alive = Object.fromEntries(Object.entries(who).filter(([, until]) => until > now));
      if (Object.keys(alive).length !== Object.keys(who).length) changed = true;
      if (Object.keys(alive).length) next[Number(chatId)] = alive as Record<number, number>;
    }
    return changed ? next : cur;
  },
};

export const hasMoreActions = {
  set: (cur: Record<number, boolean>, chatId: number, more: boolean) => (cur[chatId] === more ? cur : { ...cur, [chatId]: more }),
};
