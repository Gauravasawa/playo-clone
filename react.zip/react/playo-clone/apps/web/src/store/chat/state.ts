import type { ChatMessage } from '@/lib/api';

/** Keys saved to IndexedDB: see chat.store.ts */
export const chatState = {
  /** The latest messages of each chat, kept on the device so chats open instantly and can be read offline */
  messages: {} as Record<number, ChatMessage[]>,
  /** What was typed in each chat's box and not sent yet */
  drafts: {} as Record<number, string>,
  /** Per chat: the last message id each member has read (read receipts) */
  reads: {} as Record<number, Record<number, number>>,

  // Not saved
  /** Per chat: who is typing, until when (ms timestamp) */
  typing: {} as Record<number, Record<number, number>>,
  /** The chat that's open on screen, if any */
  activeChat: null as number | null,
  /** Per chat: are there older messages to load? */
  hasMore: {} as Record<number, boolean>,
};
