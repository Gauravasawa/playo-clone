import type { StateReader, Values } from '@/lib/store/createStore';
import { computeQuote } from '@/lib/pricing';
import type { queries } from './queries';
import type { state } from './state';

type AppValues = Values<typeof state & typeof queries>;
type Layer<L> = { [K in keyof L]: L[K] extends (...args: never[]) => infer R ? R : never };

/** Values worked out from state, recalculated when what they read changes. */
const layer1 = {
  loggedIn: (get: StateReader<AppValues>) => !!get('token'),
  slotCount: (get: StateReader<AppValues>) => get('selection').slots.length,
  total: (get: StateReader<AppValues>) => get('selection').slots.reduce((sum, s) => sum + s.price, 0),
  favoriteCount: (get: StateReader<AppValues>) => get('favorites').length,
};

/** A later layer can read the earlier ones */
const layer2 = {
  canBook: (get: StateReader<AppValues & Layer<typeof layer1>>) => get('loggedIn') && get('slotCount') > 0,
};

/**
 * The booking price, worked out in the browser from the picked slots and the checkout choices (rentals, pass,
 * coupon, Karma). The server computes its own and is the one that charges; the checkout compares the two.
 */
const layer3 = {
  quote: (get: StateReader<AppValues & Layer<typeof layer1> & Layer<typeof layer2>>) => {
    const checkout = get('checkout');
    const pricing = get('pricing');
    return computeQuote({
      slots: get('selection').slots,
      extras: pricing.equipment.filter((e) => checkout.extras.includes(e.id)),
      passCoversSlots: checkout.passId !== null && pricing.passCoversSlots,
      couponDiscountInr: checkout.coupon?.discountInr ?? 0,
      karmaBalance: pricing.karmaBalance,
      useKarma: checkout.useKarma,
      isPlus: pricing.isPlus,
    });
  },
};

export const computed: [typeof layer1, typeof layer2, typeof layer3] = [layer1, layer2, layer3];
