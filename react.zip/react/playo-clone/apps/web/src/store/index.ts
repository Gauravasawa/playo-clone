// No 'use client': this module is used by Server Components too (`await app.fetchQuery(...)`,
// `<app.Root>`), where the library gives every request its own store.
export { app } from './app.store';
export { prefetch } from './prefetch';
export type { AppEvents, PickedSlot, Selection, Toast } from './types';
