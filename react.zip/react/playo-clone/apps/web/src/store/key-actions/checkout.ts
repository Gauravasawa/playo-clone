import { EMPTY_CHECKOUT, EMPTY_PRICING } from '../state';
import type { Checkout, Pricing } from '../types';

/** What's chosen at checkout besides the slots: `const [, setCheckout] = useGlobalState('checkout'); setCheckout.toggleExtra(id)` */
export const checkoutActions = {
  toggleExtra: (c: Checkout, id: string): Checkout => ({ ...c, extras: c.extras.includes(id) ? c.extras.filter((x) => x !== id) : [...c.extras, id] }),
  setPass: (c: Checkout, passId: number | null): Checkout => (c.passId === passId ? c : { ...c, passId, coupon: passId ? null : c.coupon }),
  setKarma: (c: Checkout, useKarma: boolean): Checkout => (c.useKarma === useKarma ? c : { ...c, useKarma }),
  setCoupon: (c: Checkout, coupon: Checkout['coupon']): Checkout => ({ ...c, coupon }),
  reset: (): Checkout => EMPTY_CHECKOUT,
};

/** What the quote needs to know about the venue and the payer; filled in when the checkout opens */
export const pricingActions = {
  set: (_: Pricing, next: Pricing): Pricing => next,
  reset: (): Pricing => EMPTY_PRICING,
};
