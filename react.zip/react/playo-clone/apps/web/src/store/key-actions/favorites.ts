import { api } from '@/lib/api';
import { bridge } from '../bridge';

/**
 * `const [, setFavorites] = useGlobalState('favorites'); setFavorites.toggle(id)`.
 * The change shows at once; if `save` fails the store puts it back and calls onSaveError.
 */
export const favoritesActions = {
  toggle: {
    run: (current: number[], id: number) => (current.includes(id) ? current.filter((x) => x !== id) : [...current, id]),
    save: (next: number[]) => {
      const token = bridge.getToken();
      return token ? api.saveFavorites(token, next) : undefined;
    },
  },
};
