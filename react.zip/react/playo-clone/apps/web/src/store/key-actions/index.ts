import { checkoutActions, pricingActions } from './checkout';
import { favoritesActions } from './favorites';
import { presenceActions } from './presence';
import { recentSearchActions } from './recent-searches';
import { selectionActions } from './selection';

/** Actions per state key: one file per key */
export const keyActions = {
  favorites: favoritesActions,
  selection: selectionActions,
  recentSearches: recentSearchActions,
  presence: presenceActions,
  checkout: checkoutActions,
  pricing: pricingActions,
};
