/** Who is online, as the WebSocket reports it */
export const presenceActions = {
  set: (current: Record<number, boolean>, userId: number, online: boolean) =>
    current[userId] === online ? current : { ...current, [userId]: online },
  clear: () => ({}) as Record<number, boolean>,
};
