/** Player-search history: newest first, no repeats, at most 8 */
export const recentSearchActions = {
  add: (current: string[], q: string) => [q, ...current.filter((x) => x !== q)].slice(0, 8),
  clear: () => [] as string[],
};
