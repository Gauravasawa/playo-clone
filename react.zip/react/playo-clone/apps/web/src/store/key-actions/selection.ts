import type { PickedSlot, Selection } from '../types';

/** `const [, setSelection] = useGlobalState('selection'); setSelection.toggle(slot)` */
export const selectionActions = {
  /** Start picking for a venue and day; the same venue and day keeps what was picked */
  start: (current: Selection, venueId: number, date: string): Selection =>
    current.venueId === venueId && current.date === date ? current : { venueId, date, slots: [] },

  toggle: (current: Selection, slot: PickedSlot): Selection => ({
    ...current,
    slots: current.slots.some((s) => s.time === slot.time)
      ? current.slots.filter((s) => s.time !== slot.time)
      : [...current.slots, slot].sort((a, b) => a.time.localeCompare(b.time)),
  }),

  clear: (current: Selection): Selection => ({ ...current, slots: [] }),
};
