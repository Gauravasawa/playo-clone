import type { state } from './state';

type Key = keyof typeof state & string;

/**
 * Saved in localStorage. Bump `version` when the saved shape changes and describe the change in
 * `migrate`, so people keep their data instead of losing it.
 *   1: city, sport, sort, token, favorites
 *   2: + recentSearches
 *   3: + pushEnabled, pendingReferral
 *   4: + theme
 */
export const persist = {
  keys: ['city', 'sport', 'sort', 'token', 'favorites', 'recentSearches', 'pushEnabled', 'pendingReferral', 'theme'] as Key[],
  version: 4,
  /** Typing in the search box changes `recentSearches` often: write once after a quiet moment, not per key */
  debounce: 250,
  migrate: (saved: Record<string, unknown>, from: number) => ({
    ...saved,
    ...(from < 2 && { recentSearches: [] }),
    ...(from < 3 && { pushEnabled: false, pendingReferral: '' }),
    ...(from < 4 && { theme: 'system' }),
  }),
};

/** Followed by the app's other open tabs: log in or out in one tab, all tabs follow */
export const syncTabs = {
  keys: ['city', 'sport', 'token', 'favorites', 'recentSearches', 'theme'] as Key[],
};

/** Keys with undo/redo */
export const history = {
  limit: 50,
  keys: ['selection'] as Key[],
};
