/**
 * For Server Components: load data into the request's store before rendering `<app.Root>`.
 * If the backend is down the page still renders; the browser then loads the data itself.
 */
export async function prefetch(...jobs: Promise<unknown>[]) {
  await Promise.allSettled(jobs);
}
