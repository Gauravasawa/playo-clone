import { createStore } from '@/lib/store/createStore';

/**
 * Preferences that only last as long as the tab: saved in sessionStorage (`persist: 'session'`), so a reload keeps them
 * and closing the tab forgets them. A separate store from the app's, which saves to localStorage.
 */
export const prefs = createStore(
  {
    /** Hide wallet and Karma amounts in the header (handy when someone is looking at your screen) */
    privacyMode: false,
    /** Show small cards on the venue list */
    compactCards: false,
  },
  {
    name: 'playo-prefs',
    shared: typeof window !== 'undefined',
    persist: 'session',
    syncTabs: false, // a session belongs to one tab
  }
);
