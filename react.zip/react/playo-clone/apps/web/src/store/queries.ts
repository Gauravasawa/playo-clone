import { query } from '@/lib/store/createStore';
import { api, type CoachPage, type NotificationPage, type VenueFilter, type VenuePage } from '@/lib/api';

type Sport = { sport: string; city: string };
type WithToken = { token: string | null };

/**
 * Server data the store loads, caches and refreshes. Read with `useGlobalState('<name>', params)`.
 * Params are part of the cache key, so each distinct set is its own entry. Things that depend on the signed-in
 * user take the token as their params (a different user is a different entry); public pages pass `token: null`
 * so the server can render them.
 */
export const queries = {
  /* ---------- Catalog ---------- */
  sports: query((_: undefined, signal: AbortSignal) => api.sports(signal), { staleTime: 5 * 60_000 }),

  // paged: each distinct filter is its own cache entry, pages load one by one
  venues: query((page: number, filter: VenueFilter, signal: AbortSignal) => api.venues(page, filter, signal), {
    pages: { first: 1, next: (last: VenuePage) => last.nextPage, refresh: 'loaded' },
  }),
  /** Every venue that matches the filter, for the map */
  mapVenues: query((filter: VenueFilter, signal: AbortSignal) => api.venuesAll(filter, signal), { staleTime: 30_000 }),
  venue: query((id: number, signal: AbortSignal) => api.venue(id, signal), { staleTime: 60_000 }),
  slots: query((p: { venueId: number; date: string }, signal: AbortSignal) => api.slots(p.venueId, p.date, signal), { staleTime: 10_000 }),
  venueReviews: query((p: { venueId: number; token: string | null }, signal: AbortSignal) => api.venueReviews(p.venueId, p.token, signal), {
    staleTime: 15_000,
    refetchAfterMutation: true,
  }),

  /* ---------- Games ---------- */
  games: query((p: Sport & WithToken, signal: AbortSignal) => api.games(p.city, p.sport, p.token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  /** Games you're in (open ones, or finished ones for "My games") */
  myGames: query((p: { token: string; status: 'open' | 'ended' }, signal: AbortSignal) => api.myGames(p.token, p.status, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  game: query((p: { id: number } & WithToken, signal: AbortSignal) => api.game(p.id, p.token, signal), { staleTime: 5_000, refetchAfterMutation: true }),
  /** What an invite link opens */
  gameByCode: query((p: { code: string } & WithToken, signal: AbortSignal) => api.gameByCode(p.code, p.token, signal), { staleTime: 5_000, refetchAfterMutation: true }),

  /* ---------- Community (public) ---------- */
  leaderboard: query((p: Sport, signal: AbortSignal) => api.leaderboard(p.sport, p.city, signal), { staleTime: 20_000 }),
  tournaments: query((p: Sport & WithToken, signal: AbortSignal) => api.tournaments(p.city, p.sport, p.token, signal), { staleTime: 15_000, refetchAfterMutation: true }),
  // paged: "Load more"
  coaches: query((page: number, p: Sport, signal: AbortSignal) => api.coaches(page, p.city, p.sport, signal), {
    pages: { first: 1, next: (last: CoachPage) => last.nextPage },
  }),
  coach: query((p: { id: number } & WithToken, signal: AbortSignal) => api.coach(p.id, p.token, signal), { staleTime: 15_000, refetchAfterMutation: true }),
  coachSlots: query((p: { id: number; date: string }, signal: AbortSignal) => api.coachSlots(p.id, p.date, signal), { staleTime: 5_000, refetchAfterMutation: true }),
  events: query((p: { type: string; city: string; q: string } & WithToken, signal: AbortSignal) => api.events({ type: p.type, city: p.city, q: p.q }, p.token, signal), { staleTime: 15_000, refetchAfterMutation: true }),
  event: query((p: { id: number } & WithToken, signal: AbortSignal) => api.event(p.id, p.token, signal), { staleTime: 10_000, refetchAfterMutation: true }),

  /* ---------- Help (public) ---------- */
  policy: query((_: undefined, signal: AbortSignal) => api.policy(signal), { staleTime: 5 * 60_000 }),
  // The search text is the param: each text is an entry, and the page cancels the old request while typing
  faq: query((q: string, signal: AbortSignal) => api.faq(q, signal), { staleTime: 60_000, gcTime: 30_000, retry: 0 }),
  articles: query((p: { tag: string; q: string }, signal: AbortSignal) => api.articles(p, signal), { staleTime: 60_000 }),
  article: query((p: { slug: string; city: string }, signal: AbortSignal) => api.article(p.slug, p.city, signal), { staleTime: 60_000 }),
  reportReasons: query((_: undefined, signal: AbortSignal) => api.reportReasons(signal), { staleTime: 10 * 60_000 }),

  /* ---------- A player's page (public part is rendered on the server, token = null) ---------- */
  // gcTime: a profile nobody is looking at is dropped after 20 s, so browsing many players doesn't pile up
  player: query((p: { username: string } & WithToken, signal: AbortSignal) => api.player(p.username, p.token, signal), {
    staleTime: 15_000,
    gcTime: 20_000,
  }),
  // typing in the search box: each text is an entry; old ones go after 15 s
  searchPlayers: query((p: { token: string; q: string }, signal: AbortSignal) => api.searchPlayers(p.token, p.q, signal), {
    staleTime: 10_000,
    gcTime: 15_000,
    retry: 0,
  }),

  /* ---------- The signed-in user's data: keyed by token, so a different user is a different entry ---------- */
  me: query((token: string, signal: AbortSignal) => api.me(token, signal), { retry: 0 }),
  badges: query((token: string, signal: AbortSignal) => api.badges(token, signal), { staleTime: 10_000 }),
  // retryDelay as a function: 300 ms, 600 ms, 1.2 s... but never more than 3 s (the default grows without a cap)
  wallet: query((token: string, signal: AbortSignal) => api.wallet(token, signal), { staleTime: 10_000, retry: 4, retryDelay: (attempt: number) => Math.min(300 * 2 ** (attempt - 1), 3000) }),
  karma: query((token: string, signal: AbortSignal) => api.karma(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  plus: query((token: string, signal: AbortSignal) => api.plus(token, signal), { staleTime: 30_000, refetchAfterMutation: true }),
  passes: query((token: string, signal: AbortSignal) => api.passes(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  giftCards: query((token: string, signal: AbortSignal) => api.giftCards(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  referrals: query((token: string, signal: AbortSignal) => api.referrals(token, signal), { staleTime: 30_000 }),
  bookings: query((token: string, signal: AbortSignal) => api.bookings(token, signal), { staleTime: 5_000, refetchAfterMutation: true }),
  learning: query((token: string, signal: AbortSignal) => api.learning(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  friends: query((token: string, signal: AbortSignal) => api.friends(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  followRequests: query((token: string, signal: AbortSignal) => api.followRequests(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  playedWith: query((token: string, signal: AbortSignal) => api.playedWith(token, signal), { staleTime: 15_000 }),
  suggested: query((token: string, signal: AbortSignal) => api.suggested(token, signal), { staleTime: 30_000 }),
  blocks: query((token: string, signal: AbortSignal) => api.blocks(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  chats: query((token: string, signal: AbortSignal) => api.chats(token, signal), { staleTime: 10_000 }),
  tickets: query((token: string, signal: AbortSignal) => api.tickets(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  ticket: query((p: { token: string; id: number }, signal: AbortSignal) => api.ticket(p.token, p.id, signal), { staleTime: 5_000, refetchAfterMutation: true }),

  // paged, and only the newest 3 pages are kept (`max`): load more than that and the oldest drops out
  notifications: query((page: number, token: string, signal: AbortSignal) => api.notifications(token, page, signal), {
    pages: { first: 1, next: (last: NotificationPage) => last.nextPage, max: 3, refresh: 'loaded' }, // a refresh reloads the pages already loaded, so a long list keeps its length
    staleTime: 5_000,
  }),

  /* ---------- Venue owners ---------- */
  ownerVenues: query((token: string, signal: AbortSignal) => api.ownerVenues(token, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  claimable: query((p: { token: string; city: string }, signal: AbortSignal) => api.claimable(p.token, p.city, signal), { staleTime: 10_000, refetchAfterMutation: true }),
  ownerVenue: query((p: { token: string; id: number; date: string }, signal: AbortSignal) => api.ownerVenue(p.token, p.id, p.date, signal), { staleTime: 5_000, refetchAfterMutation: true }),

  /* ---------- Admin ---------- */
  adminReports: query((p: { token: string; status: string }, signal: AbortSignal) => api.adminReports(p.token, p.status, signal), { staleTime: 5_000, refetchAfterMutation: true }),
};
