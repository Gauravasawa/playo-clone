import { app } from './app.store';
import { chatStore } from './chat';

/**
 * Log out and leave nothing of this person behind on the device: the actions clear the login, then
 * `reset()` empties the query cache (including its offline copy in localStorage) and both stores'
 * saved state (the chat store's messages in IndexedDB too).
 */
export function signOut() {
  app.actions.logout();
  app.reset();
  chatStore.reset();
}
