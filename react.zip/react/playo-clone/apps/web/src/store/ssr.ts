import type { queries } from './queries';

type QueryKey = keyof typeof queries & string;

/**
 * What the server sends to the browser: public server data only. Per-visitor state (city, token,
 * favorites...) is not listed on purpose: the browser loads those from localStorage, and a
 * snapshot would overwrite them with the server's initial values.
 */
export const ssr = {
  keys: [
    'sports', 'venues', 'venue', 'games', 'game', 'gameByCode', 'player', 'leaderboard', 'tournaments', 'coaches', 'coach',
    'events', 'event', 'policy', 'faq', 'articles', 'article',
  ] as QueryKey[],
  /** Bump when a key's shape changes, so a page cached by an old deployment is ignored */
  version: 1,
};
