import type { ThemePref } from '@/lib/theme';
import type { VenueFilter } from '@/lib/api';
import { DEFAULT_CITY } from '@/config/constants';
import type { Checkout, Pricing, Selection, SocketStatus } from './types';

export const EMPTY_SELECTION: Selection = { venueId: null, date: '', slots: [] };
export const EMPTY_CHECKOUT: Checkout = { extras: [], passId: null, useKarma: false, coupon: null };
export const EMPTY_PRICING: Pricing = { equipment: [], isPlus: false, karmaBalance: 0, passCoversSlots: false };

/** Plain state keys. Which of them are saved or synced between tabs is decided in persistence.ts. */
export const state = {
  city: DEFAULT_CITY as string,
  sport: 'all',
  search: '',
  sort: 'rating' as VenueFilter['sort'],
  token: null as string | null,
  favorites: [] as number[],
  selection: EMPTY_SELECTION, // has undo/redo (see persistence.ts)
  recentSearches: [] as string[], // player search history (added in persist version 2)
  pushEnabled: false, // browser notifications when the tab is in the background (persist version 3)
  pendingReferral: '', // a referral code from ?ref=CODE, used when this device signs up (persist version 3)

  // Checkout: the pieces the store's `quote` value is worked out from
  checkout: EMPTY_CHECKOUT,
  pricing: EMPTY_PRICING,

  // Where the visitor is, for "near me" (never saved: asked for again each visit)
  location: null as { lat: number; lng: number; source: 'gps' | 'city' } | null,

  // Live
  presence: {} as Record<number, boolean>, // who is online, pushed over the WebSocket
  socket: 'closed' as SocketStatus,

  // UI
  theme: 'system' as ThemePref, // light / dark / system (saved since persist version 4)
  loginOpen: false,
  pendingSaves: 0, // saves started and not finished yet (the header shows "Saving…" while it is above 0)
  simulateFailure: false, // the Lab's switch: every write fails on the server
  simulatePaymentFailure: false, // the Lab's switch: UPI and card payments are declined
};
