import type { Equipment } from '@/lib/api';

export interface PickedSlot {
  time: string;
  price: number;
}

/** The slots being picked on a venue page */
export interface Selection {
  venueId: number | null;
  date: string;
  slots: PickedSlot[];
}

/** What has been chosen at checkout besides the slots (rentals, pass, coupon, Karma) */
export interface Checkout {
  /** Rental ids, e.g. "badminton:Racket" */
  extras: string[];
  passId: number | null;
  useKarma: boolean;
  coupon: { code: string; discountInr: number } | null;
}

/**
 * What the checkout needs to know to price a booking without asking the server: the venue's rentals,
 * who is paying (Plus? how much Karma?), and whether the chosen pass covers the slots.
 * The checkout fills it in when it opens; the store's `quote` computed value reads it.
 */
export interface Pricing {
  equipment: Equipment[];
  isPlus: boolean;
  karmaBalance: number;
  passCoversSlots: boolean;
}

export type SocketStatus = 'closed' | 'connecting' | 'open';

export interface Toast {
  kind: 'ok' | 'err';
  text: string;
}

/** Event names and payloads of the app store: `app.emit('toast', ...)` / `app.on('toast', ...)` */
export interface AppEvents {
  toast: Toast;
  /** Sent to every tab (`{ broadcast: true }`) when notifications are marked read, so all tabs clear their badge */
  'notifications-read': { ids: number[] | 'all' };
}
