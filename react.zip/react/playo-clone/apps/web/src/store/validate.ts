import { CITIES } from '@/config/constants';

type From = 'storage' | 'offline' | 'remote';

/**
 * `validate` option: checks data the store didn't write itself. That's the saved state in
 * localStorage, the offline copy of server data, and changes sent by other tabs. A value that
 * fails is ignored and the key keeps what it had (so a tampered or outdated value can't break the app).
 */
export function validate(key: string, value: unknown, from: From): boolean {
  switch (key) {
    case 'city':
      return typeof value === 'string' && (CITIES as readonly string[]).includes(value);
    case 'sport':
      return typeof value === 'string' && value.length <= 20;
    case 'sort':
      return value === 'rating' || value === 'price' || value === 'distance';
    case 'token':
      return value === null || (typeof value === 'string' && /^[0-9a-f-]{36}$/.test(value));
    case 'favorites':
      return Array.isArray(value) && value.length <= 500 && value.every((x) => Number.isInteger(x));
    case 'recentSearches':
      return Array.isArray(value) && value.length <= 8 && value.every((x) => typeof x === 'string' && x.length <= 40);
    case 'theme':
      return value === 'light' || value === 'dark' || value === 'system';
    case 'pushEnabled':
      return typeof value === 'boolean';
    case 'pendingReferral':
      return typeof value === 'string' && /^[A-Za-z0-9]{0,10}$/.test(value);
    default:
      // anything else only arrives as an offline copy of a query: it must at least be real data
      return from !== 'offline' || (value !== null && value !== undefined && typeof value === 'object');
  }
}
