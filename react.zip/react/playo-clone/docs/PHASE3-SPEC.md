# Phase 3 spec: everything missing from Playo, plus the remaining createStore features

Written from the user's answers (five rounds of questions). **User decisions** are exactly what they chose;
**My rule** marks a small rule the options didn't settle, so it can be changed. Progress is ticked at the bottom.

## User decisions

| Area | Decision |
| --- | --- |
| Karma | Earn per action, redeem as a checkout discount. 1 pt per ₹10 paid on bookings, + finished (attended) game, + review, + daily login. 10 pts = ₹1, capped at 20% of the amount. Karma page (balance + history), "use Karma" switch at checkout. |
| Gift cards | Buy for yourself or a friend (₹500/1000/2000/custom), pay wallet or mock UPI/card, optional message; code `PLAYO-XXXX-XXXX`; recipient notified; redeem by code into the wallet; single use; expires after 1 year. |
| Host controls | Join requests the host approves/declines; private (invite-only) games; RSVP (going/maybe/can't) and attendance marked after the game (counts for stats); minimum skill level per game (server checks profile). |
| Matchmaking | "Players for you" ranked by shared sports, same level, same city and free times; new profile setting "when I usually play" (weekday/weekend × morning/evening); match % and reasons; requests still need a shared game, so a "Join a game together" shortcut is shown. |
| Coaching | Coach profile page (certifications, specialties, ratings, reviews); programs with batches you enrol in and pay for ("My learning"); single trial session booking (pay per session, cancel for refund); **the existing list + enquiry stays too**. |
| Events | Marathons/runs (5K/10K/21K, fee, bib number, participants list), treks/outdoor trips (date, meeting point, difficulty, group size, fee, itinerary), local meet-ups and workshops (free or paid, RSVP, host). Tournaments stay as they are. |
| Venue passes | Daily pass and monthly membership (N hours/month at a lower rate), bought with wallet or mock UPI/card, used at checkout ("book with pass"), hours left shown, unused hours expire at month end. |
| Premium | Playo Plus monthly/yearly, wallet or mock UPI/card: 2x Karma, no convenience fee, free cancellation up to 2 h before, profile badge, priority in "Players for you". Cancel any time, runs to period end. |
| Help | FAQ with search; blog with ~8 seed articles (tags, related venues); support tickets (demo agent replies live); cancellation/refund policy page and the same rules enforced when cancelling. |
| Sports/cities | Padel; Chennai, Kolkata, Ahmedabad, Jaipur; Dubai, Doha, Sydney, London. |
| Currency | Show local currency for venues in foreign cities; wallet stays ₹; fixed demo rates in one config file; checkout shows both, e.g. `AED 80 (₹1,800)`. |
| Location | Venue coordinates, "Near me" sort with distance, map view (Leaflet + OpenStreetMap tiles); browser geolocation with fallback to the city centre. |
| Reach | Share/invite links (games, venues, profiles; invite link joins a private game; works logged out); referral codes (₹100 to newcomer, ₹100 + Karma to referrer after the newcomer's first booking); browser push notifications (Notification API when the tab is hidden). |
| Venue extras | Equipment rental at checkout; reschedule a booking (price difference charged/refunded, follows the policy window); photo gallery; filter by amenities and price. |
| Venue owners | Owner dashboard `/owner`: list or claim a venue, see bookings, block slots, edit hourly and peak price, revenue, reply to reviews, notifications for new bookings. |
| Safety | Block a player; report a player/message/game/review (admin page); rate limiting (429 handled in the UI); message filtering (blocklist → `***`). |
| Split cost | Host sets a price per player; joining charges it; leaving ≥ 3 h before the start refunds, later leaves don't; the host is credited when the game ends. |
| Real services | Keep the demo OTP and mock payments, behind small provider interfaces so a real one is a drop-in. |
| Store features | Tab sync tests + DevTools time travel; owner price preview in a nested `<Root>` with its own scope; server-side price quote through a scope (computed, key actions, history); `onSaveStart` saving indicator + session-only preferences store + `offline.maxSize` + several queued `whenOnline` tasks; concurrency self-tests, `retryDelay`, refresh on focus/online; performance benchmark in the Lab; type-check with TypeScript 7.0.2; run the browser suite in Firefox and WebKit. |

## My rules (small choices the options didn't settle; easy to change)

- All amounts on the server are **rupees**; local currency is a display conversion by city (`data/currency.ts`, mirrored in `web/src/config/cities.ts`).
- **Convenience fee** (so that "no convenience fee" for Plus means something): 3% of what you pay for slots + extras after passes, minimum ₹10, maximum ₹100; not charged for Plus, for game joins, or when nothing is charged.
- **Cancellation policy:** refund 100% if ≥ 24 h before the first slot, 50% if 2–24 h, 0% under 2 h. **Plus:** 100% up to 2 h before. Karma used is refunded in the same share.
- **Reschedule:** allowed until 2 h before the original start, to free slots at the same venue (same rules for Plus). The price difference is charged or refunded to the wallet.
- Past slots of today can't be booked. All times use the server's clock and time zone (demo simplification).
- **Gift cards** can be sent to friends only. Codes expire after 1 year.
- **Approval-mode paid games:** the price is taken when the request is made and refunded if it's declined or cancelled.
- **Attendance:** players the host marks absent don't get the game in their stats, Karma, leaderboard or "played with". Unmarked (older) games count as attended.
- **Skill levels:** Beginner < Intermediate < Advanced; a player with no level for the sport counts as Beginner.
- **Admin:** a seeded admin account (`phone 9000000000`, OTP `1234`) sees `/admin/reports`.
- **Rate limits** (per user, or per IP when logged out): login 10/min, messages 30/min, friend/follow requests 20/min, tickets 5/min. In-memory.
- Blocked players: no search results, no requests, no new direct messages, their direct chats are hidden, their group messages are hidden for the blocker, and their profile answers 404 to the blocked.
- Referral bonus: ₹100 + 50 Karma for the referrer after the referred user's **first booking**; ₹100 for the newcomer at signup, on top of the ₹1000 welcome bonus.
- The seeded demo players keep behaving as before; new bots (one per new city) and an admin are added.

## Phases

- [x] 0 Foundations: schema v4, currency, 13 cities, padel, venue catalog (coords, images, equipment, owners/overrides)
- [x] 1 Money: pricing engine, convenience fee, Plus, Karma, passes, gift cards, referrals, policy, reschedule, equipment, checkout
- [x] 2 Games v2: approval, private/invites/links, skill limit, RSVP/attendance, paid games; matchmaking + availability
- [x] 3 Coaching (profiles, programs, trial sessions, reviews) and events
- [x] 4 Venue owner dashboard
- [x] 5 Help centre: FAQ, blog, tickets, policy page
- [x] 6 Safety: block, report/admin, rate limits, message filter
- [x] 7 Location (map, near me), filters, gallery, share links, push notifications
- [x] 8 createStore features (A: tab sync + DevTools time travel, nested Root preview, server quote scope, saving indicator/session store/maxSize/queued tasks; B: concurrency tests, retryDelay, focus/online, benchmark, TS 7, Firefox + WebKit; Firefox could not be launched on this machine, see findings 07)
- [x] 9 Findings, README, full regression (dev + production)
