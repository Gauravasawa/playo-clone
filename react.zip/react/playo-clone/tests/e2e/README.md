# Browser tests

Playwright scripts that drive the real app (Node, `playwright-core`, Microsoft Edge; WebKit with `ENGINE=webkit`). They need the API on :4000 and the web app running.

```
cd tests/e2e && npm install            # playwright-core (WebKit: npx playwright-core install webkit)
rm ../../apps/api/playo.db*            # a fresh database gives repeatable results; restart the API afterwards
BASE=http://localhost:3000 node --experimental-strip-types g1-money.mts      # and g2 … g7
```

| Script | What it covers |
| --- | --- |
| `g1`…`g7-*.mts` | the feature journeys (money, venues + games, social + safety, coaching + events, owner + help, notifications + policy, chat + regression), ~110 steps |
| `scan.mts` | every route twice, no console errors or 4xx/5xx (`SCHEME=dark` for dark mode) |
| `store-phase3.mts` | createStore features in the browser: server-scope quote, saving indicator, session prefs, tab sync (2 and 4 tabs), DevTools time travel (fake extension), focus/online refresh, `retryDelay`, offline queue. **Dev server** (`BASE=http://localhost:3100`), because DevTools only runs in development |
| `selftests-all.mts` | opens `/lab`, runs the 61 library self-tests, prints each result |
| `theme-e2e.mts` | dark mode: system/saved theme, no flash, the ball and the switch animation, menu, tab sync, reduced motion, hero scene, dark map, Pages Router page |
| `theme-audit.mts` | WCAG contrast of every text element on 31 pages in both themes (`ONLY=/wallet` to narrow) |
| `theme-states.mts` | hover, keyboard focus, inputs, selects, menus, toasts, disabled, pressed, skeletons |
| `modals-audit.mts` | opens 16 dialogs in both themes: contrast, field edges, Escape, focus trap |
| `html-audit.mts` | the small things in the markup, on 31 routes logged in and out: icons without a name or tooltip, cut-off text without its full text on hover, disabled buttons with no reason, badges and dots that carry information, images without alt, fields without labels, duplicate ids, missing title / lang / h1, empty links, nested interactive elements, heading jumps. Exits 1 on any finding |
| `tooltips.mts` | real hover, keyboard focus and touch long-press on ~25 controls in both themes: the text, on screen, `aria-describedby`, gone on leave / Escape / click / scroll, does not block clicks, readable (4.5:1), reduced motion |
| `docs-page.mts` | the documentation page (`C:eactdocs`): the left list follows scrolling, clicks, selected text, links, search and #hash (all 37 sections), sub-headings, phone drawer; tooltips on hover, keyboard focus and touch, contrast in both themes |
| `xss.mts` | hostile text (`<img onerror>`, `</script><script>`, `javascript:` links) in a name, bio, game title, chat message and ticket subject, shown on 10 pages as two users in both themes: nothing may run, become markup or open a dialog, and the server HTML must not contain it as markup |
| `editor-link.mts` | the owner price editor: click a preview row → the matching field on the left is focused and selected; hover and focus highlight each other; keyboard; both themes |
| `mobile-audit.mts`, `mobile-modals.mts` | phone and tablet widths: overflow, clipping, tap targets, contrast, menus |

`glib.mts` has the helpers (sign-up, API calls, steps). Paths in the scripts that start with `/` need `MSYS_NO_PATHCONV=1` in Git Bash.
