// The documentation page: the left list follows the page, and tooltips appear on hover and focus.
//   Run: FILE="file:///C:/react/docs/createStore documentation.html" node --experimental-strip-types docs-page.mts
import { chromium, type Page } from 'playwright-core';

const FILE = process.env.FILE ?? 'file:///C:/react/docs/createStore%20documentation.html';
const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
let passed = 0, failed = 0;
async function step(name: string, fn: () => Promise<string | void>) {
  try { const note = await fn(); passed++; console.log(`PASS ${name}${note ? ` — ${note}` : ''}`); }
  catch (e) { failed++; console.log(`FAIL ${name}: ${(e as Error).message.split('\n').slice(0, 3).join(' | ')}`); }
}
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const errors: string[] = [];

async function open(opts: { width?: number; height?: number; scheme?: 'light' | 'dark'; hash?: string; touch?: boolean } = {}) {
  const ctx = await browser.newContext({ viewport: { width: opts.width ?? 1280, height: opts.height ?? 900 }, colorScheme: opts.scheme ?? 'light', hasTouch: opts.touch, isMobile: false });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errors.push('pageerror ' + e.message.slice(0, 120)));
  p.on('console', (m) => { if (m.type() === 'error' && !/fonts\.|prism|cdnjs|ERR_|Failed to load resource/.test(m.text())) errors.push(m.text().slice(0, 120)); });
  await p.goto(FILE + (opts.hash ?? ''));
  await sleep(1200);
  return { ctx, p };
}
const nav = (p: Page) => p.evaluate(() => ({
  section: document.querySelector('#sidebar a[data-nav][aria-current="true"]')?.getAttribute('data-nav') ?? null,
  sub: document.querySelector('#sidebar a[data-sub][aria-current]')?.getAttribute('data-sub') ?? null,
}));
const inSidebarView = (p: Page, sel: string) => p.evaluate((s) => {
  const el = document.querySelector(s) as HTMLElement | null, sb = document.querySelector('#sidebar') as HTMLElement;
  if (!el) return false; const a = el.getBoundingClientRect(), b = sb.getBoundingClientRect();
  return a.top >= b.top - 1 && a.bottom <= b.bottom + 1;
}, sel);

const { ctx: c0, p: p0 } = await open();
const sectionIds: string[] = await p0.evaluate(() => [...document.querySelectorAll('.doc-section')].map((s) => s.id));
await c0.close();

await step(`deep links: opening #<section> marks that section on the left (all ${sectionIds.length} sections)`, async () => {
  const bad: string[] = [];
  const { ctx, p } = await open();
  for (const id of sectionIds) {
    await p.goto(FILE + '#' + id); await sleep(450);
    const n = await nav(p);
    if (n.section !== id) bad.push(`${id}→${n.section}`);
  }
  await ctx.close();
  assert(!bad.length, `wrong: ${bad.slice(0, 8).join(', ')}${bad.length > 8 ? ` (+${bad.length - 8})` : ''}`);
});

await step('deep links to a sub-heading: the section and the sub-heading are both marked, and visible in the left list', async () => {
  const subs: string[] = ['api-persist', 'api-query', 'api-status', 'api-storage'];
  const { ctx, p } = await open();
  for (const id of subs) {
    await p.goto(FILE + '#' + id); await sleep(500);
    const n = await nav(p);
    assert(n.section === 'api' && n.sub === id, `#${id}: section ${n.section}, sub ${n.sub}`);
    assert(await inSidebarView(p, `#sidebar a[data-sub="${id}"]`), `#${id}: its entry is not inside the visible part of the left list`);
  }
  await ctx.close();
});

await step('clicking inside a section selects it on the left at once, even when the reading line is still in the previous section', async () => {
  const { ctx, p } = await open();
  await p.goto(FILE + '#sync-tabs'); await sleep(500);
  assert((await nav(p)).section === 'sync-tabs', 'start');
  const target = p.locator('#persist p').first();
  const y = await target.evaluate((e) => { e.scrollIntoView({ block: 'end' }); return e.getBoundingClientRect().top; }); void y;
  await sleep(100);
  await target.click({ position: { x: 5, y: 5 } });
  await sleep(150);
  const n = await nav(p);
  assert(n.section === 'persist', `after clicking a paragraph in #persist the left list shows ${n.section}`);
  await ctx.close();
});

await step('selecting text (a field name in a table, a heading) selects its section and sub-heading on the left', async () => {
  const { ctx, p } = await open();
  await p.goto(FILE + '#top'); await sleep(300);
  // a field in the API reference: triple-click selects the whole table cell
  const cell = p.locator('#api-persist ~ .table-wrap').first().locator('td code').first();
  await cell.scrollIntoViewIfNeeded(); await sleep(1200); // let the smooth scroll finish
  await cell.dblclick(); await sleep(400);
  let n = await nav(p);
  assert(n.section === 'api' && n.sub === 'api-persist', `field selected: section ${n.section}, sub ${n.sub}`);
  const h3 = p.locator('#api-status');
  await h3.scrollIntoViewIfNeeded(); await sleep(1200); await h3.click({ clickCount: 3 }); await sleep(400);
  n = await nav(p);
  assert(n.section === 'api' && n.sub === 'api-status', `heading selected: section ${n.section}, sub ${n.sub}`);
  await ctx.close();
});

await step('scrolling by hand follows too (sections and sub-headings), and at the very bottom the last section is marked', async () => {
  const { ctx, p } = await open();
  const want: [string, string][] = [['persist', 'persist'], ['ssr', 'ssr'], ['faq', 'faq']];
  for (const [id] of want) {
    await p.evaluate((i) => { const y = (document.getElementById(i) as HTMLElement).getBoundingClientRect().top + scrollY - 70; scrollTo({ top: y, behavior: 'instant' as ScrollBehavior }); }, id);
    await sleep(450);
    assert((await nav(p)).section === id, `scrolled to #${id}: ${(await nav(p)).section}`);
  }
  await p.evaluate(() => scrollTo({ top: document.documentElement.scrollHeight, behavior: 'instant' as ScrollBehavior })); await sleep(450);
  const last = await p.evaluate(() => [...document.querySelectorAll('.doc-section')].pop()!.id);
  assert((await nav(p)).section === last, `bottom: ${(await nav(p)).section}, expected ${last}`);
  await p.evaluate(() => scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior })); await sleep(450);
  assert((await nav(p)).section === null, `at the very top nothing should be marked, got ${(await nav(p)).section}`);
  await ctx.close();
});

await step('the search dialog and the left list agree: opening a result marks it on the left', async () => {
  const { ctx, p } = await open();
  await p.keyboard.press('/'); await sleep(300);
  await p.locator('#search-input').fill('staleTime'); await sleep(300);
  await p.keyboard.press('Enter'); await sleep(900);
  const hash = await p.evaluate(() => location.hash.slice(1));
  const n = await nav(p);
  assert(hash && (n.section === hash || n.sub === hash || (await p.evaluate((h) => document.getElementById(h)?.closest('.doc-section')?.id, hash)) === n.section), `hash ${hash}, nav ${JSON.stringify(n)}`);
  await ctx.close();
});

await step('clicking an entry on the left marks it, and its sub-headings open under the current section only', async () => {
  const { ctx, p } = await open();
  await p.locator('#sidebar a[data-nav="queries"]').click(); await sleep(1800);
  let n = await nav(p);
  assert(n.section === 'queries', `queries: ${n.section}`);
  const open1 = await p.evaluate(() => [...document.querySelectorAll('#sidebar ul.sub:not([hidden])')].map((u) => u.id));
  assert(open1.length === 1 && open1[0] === 'sub-queries', `open lists: ${open1.join()}`);
  await p.locator('#sidebar a[data-nav="persist"]').click(); await sleep(1800);
  const open2 = await p.evaluate(() => [...document.querySelectorAll('#sidebar ul.sub:not([hidden])')].map((u) => u.id));
  assert(open2.length === 1 && open2[0] === 'sub-persist', `open lists after: ${open2.join()}`);
  await p.locator('#sub-persist a').first().click(); await sleep(1500);
  n = await nav(p);
  assert(n.sub !== null, 'a sub-heading link should be marked');
  await ctx.close();
});

await step('phone: the drawer shows the current entry, and a tap inside a section updates it', async () => {
  const { ctx, p } = await open({ width: 390, height: 800, touch: true, hash: '#api-persist' });
  await sleep(600);
  await p.locator('.menu-btn').tap(); await sleep(500);
  assert(await p.evaluate(() => document.querySelector('#sidebar')!.classList.contains('open')), 'drawer did not open');
  assert(await inSidebarView(p, '#sidebar a[data-sub="api-persist"]'), 'the current entry is not visible in the drawer');
  await ctx.close();
});

const tipText = (p: Page) => p.evaluate(() => { const t = document.getElementById('doc-tip'); return t?.classList.contains('show') ? t.textContent : null; });
for (const scheme of ['light', 'dark'] as const) {
  await step(`[${scheme}] tooltips: icon buttons, copy buttons and the search button explain themselves on hover`, async () => {
    const { ctx, p } = await open({ scheme });
    const cases: [string, RegExp][] = [['.theme-btn', /light and dark/i], ['.search-btn', /Search the docs/], ['.brand', /top/i], ['.copy >> nth=0', /Copy this code/]];
    for (const [sel, re] of cases) {
      await p.locator(sel).first().scrollIntoViewIfNeeded();
      await p.locator(sel).first().hover(); await sleep(450);
      const t = await tipText(p);
      assert(t && re.test(t), `${sel}: tooltip "${t}"`);
      const box = await p.evaluate(() => { const r = document.getElementById('doc-tip')!.getBoundingClientRect(); return { l: r.left, r: r.right, t: r.top, b: r.bottom, w: innerWidth, h: innerHeight }; });
      assert(box.l >= 0 && box.r <= box.w && box.t >= 0 && box.b <= box.h, `${sel}: tooltip off screen ${JSON.stringify(box)}`);
      await p.mouse.move(2, 400); await sleep(200);
      assert((await tipText(p)) === null, `${sel}: tooltip stayed after the pointer left`);
    }
    await ctx.close();
  });

  await step(`[${scheme}] tooltips: API names in running text explain themselves (from the API reference), and have enough contrast`, async () => {
    const { ctx, p } = await open({ scheme });
    const info = await p.evaluate(() => (window as unknown as { __docTips: { glossary: number; terms: number } }).__docTips);
    assert(info.glossary > 40 && info.terms > 50, `glossary ${info.glossary}, terms ${info.terms}`);
    const term = p.locator('#persist p code.has-tip').first();
    await term.scrollIntoViewIfNeeded(); await term.hover(); await sleep(450);
    const t = await tipText(p);
    assert(t && t.length > 12, `no tooltip on a term: "${t}"`);
    const ratio = await p.evaluate(() => {
      const el = document.getElementById('doc-tip')!, cs = getComputedStyle(el);
      const rgb = (c: string) => (c.match(/[\d.]+/g) ?? []).slice(0, 3).map(Number);
      const lum = (c: number[]) => { const f = (v: number) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
      const a = lum(rgb(cs.color)), b = lum(rgb(cs.backgroundColor)); return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
    });
    assert(ratio >= 4.5, `tooltip contrast ${ratio.toFixed(2)}`);
    await p.screenshot({ path: `shots/docs-tip-${scheme}.png` });
    await ctx.close();
    return `${info.glossary} API names known, ${info.terms} in the text; "${t!.slice(0, 70)}…"; contrast ${ratio.toFixed(1)}:1`;
  });
}

await step('tooltips on keyboard focus (Tab to the Copy button), Escape closes them', async () => {
  const { ctx, p } = await open();
  await p.locator('.copy').first().scrollIntoViewIfNeeded();
  await p.locator('.copy').first().focus(); await p.keyboard.press('Shift+Tab'); await p.keyboard.press('Tab'); await sleep(300);
  const t = await tipText(p); assert(t && /Copy/.test(t), `tooltip on focus: "${t}"`);
  await p.keyboard.press('Escape'); await sleep(150);
  assert((await tipText(p)) === null, 'Escape did not close it');
  await ctx.close();
});

await step('touch: a long press on a button and a tap on an API name show the tooltip', async () => {
  const { ctx, p } = await open({ width: 390, height: 800, touch: true });
  const term = p.locator('#persist p code.has-tip').first();
  await term.scrollIntoViewIfNeeded();
  const box = (await term.boundingBox())!;
  await p.touchscreen.tap(box.x + box.width / 2, box.y + box.height / 2); await sleep(500);
  const t = await tipText(p);
  assert(t && t.length > 12, `tap on a term: "${t}"`);
  await ctx.close();
});

await step('markup: table headers have scope, code blocks scroll from the keyboard, no duplicate ids, no title attribute left (they became tooltips)', async () => {
  const { ctx, p } = await open();
  const r = await p.evaluate(() => ({
    thNoScope: document.querySelectorAll('th:not([scope])').length,
    preNoTab: document.querySelectorAll('pre:not([tabindex])').length,
    dupIds: (() => { const ids = [...document.querySelectorAll('[id]')].map((e) => e.id); return ids.filter((x, i) => ids.indexOf(x) !== i).length; })(),
    titles: document.querySelectorAll('[title]').length,
    noName: [...document.querySelectorAll('button')].filter((b) => !(b.textContent ?? '').trim() && !b.getAttribute('aria-label')).length,
  }));
  await ctx.close();
  assert(r.thNoScope === 0 && r.preNoTab === 0 && r.dupIds === 0 && r.titles === 0 && r.noName === 0, JSON.stringify(r));
});

await step('no script errors on load, in either theme, on a phone or while using it', async () => {
  assert(!errors.length, errors.join(' | '));
});

console.log(`\n${passed} passed, ${failed} failed`);
await browser.close();
process.exit(failed ? 1 : 0);
