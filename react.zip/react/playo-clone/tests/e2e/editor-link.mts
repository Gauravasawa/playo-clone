// The owner price editor: the fields on the left and the preview on the right point at each other.
import { chromium } from 'playwright-core';
import { api, apiUser, stamp } from './glib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3100';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const owner = await apiUser(`Editor ${stamp}`, String(3100000000 + (stamp % 99999999)));
const claimable = await api(owner.token, 'GET', '/owner/claimable?city=Bengaluru');
const venueId = ((claimable.items ?? claimable)[0] as { id: number }).id;
await api(owner.token, 'POST', `/owner/venues/${venueId}/claim`);

const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
let passed = 0, failed = 0;
async function step(name: string, fn: () => Promise<string | void>) {
  try { const note = await fn(); passed++; console.log(`PASS ${name}${note ? ` — ${note}` : ''}`); }
  catch (e) { failed++; console.log(`FAIL ${name}: ${(e as Error).message.split('\n').slice(0, 3).join(' | ')}`); }
}
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };

for (const theme of ['light', 'dark'] as const) {
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, colorScheme: theme });
  await ctx.addInitScript(([t, token]) => { localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, token, city: 'Bengaluru' } })); }, [theme, owner.token] as const);
  const p = await ctx.newPage();
  await p.goto(`${BASE}/owner/${venueId}`);
  await p.getByTestId('owner-dashboard').waitFor();
  await p.getByRole('tab', { name: 'Pricing' }).click();
  await p.getByTestId('price-preview').waitFor();
  await sleep(500);
  const active = () => p.evaluate(() => (document.activeElement as HTMLElement | null)?.getAttribute('data-testid'));
  // number inputs have no selectionStart, so check the effect: with the whole value selected, Backspace empties the field
  const selected = async () => {
    const id = await active();
    const before = await p.getByTestId(id!).inputValue();
    await p.keyboard.press('Backspace');
    const emptied = (await p.getByTestId(id!).inputValue()) === '';
    await p.getByTestId(id!).fill(before);
    await p.getByTestId(id!).evaluate((e) => (e as HTMLInputElement).select());
    return emptied && before.length > 0;
  };
  const lit = (id: string) => p.getByTestId(id).getAttribute('data-lit');

  await step(`[${theme}] clicking a normal-hour row in the preview focuses and selects "Price per hour" on the left`, async () => {
    await p.getByTestId('preview-row-17:00').click();
    assert((await active()) === 'price-hourly', `focus is on ${await active()}`);
    assert(await selected(), 'the value in the field is not selected');
    assert((await lit('field-hourly')) === 'true', 'the field row is not highlighted');
  });

  await step(`[${theme}] clicking a peak row focuses "Peak extra"`, async () => {
    await p.getByTestId('preview-row-18:00').click();
    assert((await active()) === 'price-peak', `focus is on ${await active()}`);
    assert(await selected(), 'not selected');
    assert((await lit('field-peak')) === 'true', 'not highlighted');
  });

  await step(`[${theme}] the flash goes away by itself; focusing a field lights the rows it changes (hourly → all rows, peak → peak rows only)`, async () => {
    await p.mouse.move(5, 5);
    await p.getByTestId('price-hourly').focus();
    assert((await lit('preview-row-17:00')) === 'true' && (await lit('preview-row-18:00')) === 'true' && (await lit('preview-row-19:00')) === 'true', 'hourly should light all rows');
    await p.getByTestId('price-peak').focus();
    assert((await lit('preview-row-17:00')) === 'false' && (await lit('preview-row-18:00')) === 'true' && (await lit('preview-row-19:00')) === 'true', 'peak should light only the peak rows');
    await p.getByTestId('price-peak').blur();
    await sleep(1700);
    assert((await lit('field-peak')) === 'false' && (await lit('preview-row-18:00')) === 'false', 'highlight stayed on');
  });

  await step(`[${theme}] hovering a preview row highlights its field; hovering a field highlights the preview rows`, async () => {
    await p.getByTestId('preview-row-19:00').hover();
    assert((await lit('field-peak')) === 'true', 'hover on a peak row should light the peak field');
    await p.mouse.move(5, 5);
    assert((await lit('field-peak')) === 'false', 'hover left, highlight stayed');
    await p.getByTestId('field-hourly').hover();
    assert((await lit('preview-row-17:00')) === 'true', 'hover on the hourly field should light the rows');
    await p.screenshot({ path: `shots/editor-link-${theme}.png`, clip: { x: 100, y: 180, width: 1000, height: 560 } });
    await p.mouse.move(5, 5);
  });

  await step(`[${theme}] keyboard: Tab to a preview row, Enter jumps to the field; rows have a tooltip and an accessible name`, async () => {
    await p.getByTestId('preview-row-17:00').focus();
    assert((await lit('field-hourly')) === 'true', 'focus on the row should light the field');
    await p.keyboard.press('Enter');
    assert((await active()) === 'price-hourly', `focus is on ${await active()}`);
    const title = await p.getByTestId('preview-row-18:00').getAttribute('title');
    const label = await p.getByTestId('preview-row-18:00').getAttribute('aria-label');
    assert(/peak extra/.test(title ?? '') && /Edit the peak extra/.test(label ?? ''), `title "${title}", label "${label}"`);
    const lt = await p.getByTestId('field-hourly').getAttribute('title');
    assert(/one hour/.test(lt ?? ''), `field title "${lt}"`);
  });

  await step(`[${theme}] typing a new price updates the preview and the app store stays untouched`, async () => {
    await p.getByTestId('price-hourly').fill('900');
    assert((await p.getByTestId('preview-slot-17:00').innerText()).includes('900'), 'preview did not follow');
    assert((await p.getByTestId('preview-global-check').getAttribute('data-slots')) === '0', 'the app store changed');
  });
  await ctx.close();
}

console.log(`\n${passed} passed, ${failed} failed`);
await browser.close();
process.exit(failed ? 1 : 0);
