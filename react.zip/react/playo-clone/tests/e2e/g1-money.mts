import { BASE, api, apiUser, launch, signUp, step, summary, use, walletOf, isoDay, sleep, stamp, accept } from './glib.mts';
const browser = await launch();
const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const { page: A, phone: phoneA } = await signUp(ctx, `Money ${stamp}`);
accept(A); use(A);
const tokA = (await apiUser(`Money ${stamp}`, phoneA)).token;
const nums = (s: string | null) => Number((s ?? '').replace(/[^0-9]/g, ''));
const pickDay = async (n: number) => { await A.locator('button[data-testid^=slot-]').first().waitFor({ timeout: 15000 }); await A.locator('section button:has(.font-bold)').nth(n).click(); await A.waitForTimeout(500); };
const firstSlots = async (count: number) => {
  const slots = A.locator('button[data-testid^=slot-]:not([disabled])');
  await slots.first().waitFor({ timeout: 8000 });
  for (let i = 0; i < count; i++) await slots.nth(i).click();
};
let myCode = '';

await step('welcome: wallet ≥ ₹1000 + daily Karma', async () => {
  const w = await walletOf(tokA); if (w < 1000) throw new Error('wallet ' + w);
  const me = await api(tokA, 'GET', '/me'); myCode = me.referralCode;
  // give the account some Karma by a first booking (Karma is earned per ₹10 paid)
  const s = (await api(tokA, 'GET', '/venues/3/slots?date=' + isoDay(2))).filter((x: any) => x.available);
  await api(tokA, 'POST', '/bookings', { venueId: 3, date: isoDay(2), slots: [s[0].time], method: 'wallet' });
  const k = (await api(tokA, 'GET', '/karma')).balance; if (!(k >= 10)) throw new Error('karma ' + k);
});

await step('venue page: gallery + share + passes + slot pick', async () => {
  await A.goto(BASE + '/venues/3'); await A.getByTestId('gallery').waitFor();
  await A.getByTestId('share-button').first().waitFor(); await A.getByTestId('venue-passes').waitFor();
  await pickDay(3); await firstSlots(2);
  const total = nums(await A.getByTestId('total').textContent()); if (!total) throw new Error('no total');
});

let basePayable = 0;
await step('checkout: rental raises price, fee line, client quote == server quote', async () => {
  await A.getByTestId('book-now').click(); await A.getByTestId('breakdown').waitFor();
  const before = nums(await A.getByTestId('payable').textContent());
  const rentals = A.locator('[data-testid^=rental-]'); if (!(await rentals.count())) throw new Error('no rentals offered');
  await rentals.first().check(); await A.waitForTimeout(500);
  const after = nums(await A.getByTestId('payable').textContent());
  if (!(after > before)) throw new Error(`rental did not raise price ${before}->${after}`);
  if (!/₹/.test((await A.getByTestId('fee-line').textContent()) ?? '')) throw new Error('fee line');
  await A.waitForTimeout(1200);
  if (await A.getByTestId('quote-mismatch').count()) throw new Error('client/server quote mismatch');
  basePayable = after;
});

await step('coupon PLAY20 lowers payable', async () => {
  await A.getByPlaceholder(/coupon/i).fill('PLAY20'); await A.getByTestId('apply-coupon').click();
  await A.getByTestId('coupon-ok').waitFor();
  const p = nums(await A.getByTestId('payable').textContent()); if (!(p < basePayable)) throw new Error(`${basePayable}->${p}`);
});

await step('bad coupon shows error', async () => {
  await A.getByPlaceholder(/coupon/i).fill('NOPE'); await A.getByTestId('apply-coupon').click(); await A.getByTestId('coupon-error').waitFor();
});

await step('Karma redeem toggle lowers payable', async () => {
  const k = (await api(tokA, 'GET', '/karma')).balance; if (k < 10) throw new Error('karma<10: ' + k);
  const before = nums(await A.getByTestId('payable').textContent());
  await A.getByTestId('use-karma').check(); await A.waitForTimeout(400);
  const after = nums(await A.getByTestId('payable').textContent()); if (!(after < before)) throw new Error(`${before}->${after}`);
  await A.getByTestId('use-karma').uncheck();
});

const topup = async (n = 10000) => { await api(tokA, 'POST', '/wallet/topup', { amount: n, method: 'upi' }); };
let bookingPaid = 0;
await step('pay with wallet: debit == payable; Karma earned', async () => {
  await topup(); await A.waitForTimeout(500);
  const w0 = await walletOf(tokA); const k0 = (await api(tokA, 'GET', '/karma')).balance;
  const pay = nums(await A.getByTestId('payable').textContent());
  await A.getByTestId('checkout-pay').click();
  await sleep(2500);
  const w1 = await walletOf(tokA); bookingPaid = w0 - w1; if (bookingPaid !== pay) throw new Error(`debited ${bookingPaid}, payable ${pay}`);
  const k1 = (await api(tokA, 'GET', '/karma')).balance; if (!(k1 > k0)) throw new Error(`karma ${k0}->${k1}`);
});

await step('bookings page: reschedule + cancel buttons', async () => {
  await A.goto(BASE + '/bookings'); await A.locator('[data-testid^=booking-]').first().waitFor();
  await A.getByTestId('reschedule').first().waitFor(); await A.getByTestId('cancel-booking').first().waitFor();
});

await step('reschedule to another day', async () => {
  const b0 = (await api(tokA, 'GET', '/bookings'))[0];
  await A.getByTestId('reschedule').first().click();
  await A.locator('[data-testid^=resched-day-]').nth(5).click();
  const slot = A.locator('[data-testid^=resched-slot-]:not([disabled])'); await slot.first().waitFor(); await slot.first().click();
  await A.getByTestId('reschedule-confirm').click(); await sleep(1500);
  const b1 = (await api(tokA, 'GET', '/bookings')).find((x: any) => x.id === b0.id);
  if (!b1 || b1.date === b0.date) throw new Error(`date unchanged ${b0.date} -> ${b1?.date}`);
});

await step('cancel: 100% refund shown and credited', async () => {
  const w0 = await walletOf(tokA);
  await A.getByTestId('cancel-booking').first().click(); await A.getByTestId('cancel-refund').waitFor();
  if (!/100/.test((await A.getByTestId('cancel-refund').textContent()) ?? '')) throw new Error('refund percent not 100');
  await A.getByTestId('confirm-cancel').click(); await sleep(1500);
  const w1 = await walletOf(tokA); if (!(w1 > w0)) throw new Error(`wallet ${w0}->${w1}`);
});

await step('karma tab: balance + history', async () => {
  await A.goto(BASE + '/wallet?tab=karma'); await A.getByTestId('karma-balance').waitFor(); await A.getByTestId('karma-history').waitFor();
});

let giftCode = '';
const B = await apiUser(`Friend ${stamp}`);
await step('gift card: buy ₹500 via UI shows PLAYO code, wallet -500', async () => {
  await A.goto(BASE + '/wallet?tab=gift'); await A.getByTestId('gift-amount-500').click();
  const w0 = await walletOf(tokA);
  await A.getByTestId('buy-gift-card').click(); await A.getByTestId('gift-code').first().waitFor({ timeout: 8000 });
  const txt = ((await A.getByTestId('gift-code').first().textContent()) ?? '');
  const m = txt.match(/PLAYO-[A-Z0-9]{4}-[A-Z0-9]{4}/); if (!m) throw new Error('code ' + txt);
  giftCode = m[0];
  const w1 = await walletOf(tokA); if (w0 - w1 !== 500) throw new Error(`debit ${w0 - w1}`);
});
await step('gift card: redeemed once, second redeem rejected', async () => {
  const w0 = await walletOf(B.token);
  await api(B.token, 'POST', '/gift-cards/redeem', { code: giftCode });
  const w1 = await walletOf(B.token); if (w1 - w0 !== 500) throw new Error(`credit ${w1 - w0}`);
  let failed = false; try { await api(B.token, 'POST', '/gift-cards/redeem', { code: giftCode }); } catch { failed = true; }
  if (!failed) throw new Error('second redeem succeeded');
});
await step('gift card: redeem via UI; custom ₹50 below min blocked', async () => {
  const g = await api(B.token, 'POST', '/gift-cards', { amount: 500, method: 'wallet' });
  await A.goto(BASE + '/wallet?tab=gift'); const w0 = await walletOf(tokA);
  await A.getByTestId('redeem-code').fill(g.code); await A.getByTestId('redeem-gift-card').click(); await sleep(1500);
  const w1 = await walletOf(tokA); if (w1 - w0 !== 500) throw new Error(`credit ${w1 - w0}`);
  await A.getByTestId('gift-amount-custom').click(); await A.getByTestId('gift-custom-amount').fill('50');
  if (!(await A.getByTestId('buy-gift-card').isDisabled())) throw new Error('buy enabled for ₹50');
});
await step('gift card to non-friend rejected by server', async () => {
  let rej = false; try { await api(tokA, 'POST', '/gift-cards', { amount: 500, recipientId: B.me.id, method: 'wallet' }); } catch { rej = true; }
  if (!rej) throw new Error('gift to non-friend allowed');
});

await step('pass: buy daily pass via UI; listed in wallet passes', async () => {
  await topup(); await A.goto(BASE + '/venues/3'); await A.getByTestId('buy-pass-daily').click();
  await A.getByTestId('buy-pass-confirm').click(); await sleep(1500);
  await A.goto(BASE + '/wallet?tab=passes'); await A.getByTestId('my-passes').waitFor(); await A.locator('[data-testid^=pass-]').first().waitFor();
});

await step('pass quote: fee waived, slot covered', async () => {
  const pass = (await api(tokA, 'GET', '/passes')).find((p: any) => p.kind === 'daily');
  const slots = (await api(tokA, 'GET', `/venues/3/slots?date=${pass.validDate}`)).filter((s: any) => s.available);
  if (!slots.length) { console.log('   (no free slot on pass day)'); return; }
  const q = await api(tokA, 'POST', '/bookings/quote', { venueId: 3, date: pass.validDate, slots: [slots[0].time], passId: pass.id });
  if (q.feeInr !== 0 || q.passCoveredInr <= 0) throw new Error(JSON.stringify(q));
});

await step('Plus: subscribe via UI, fee waived in quote, cancel', async () => {
  await topup(); await A.goto(BASE + '/plus'); await A.getByTestId('plus-plans').waitFor();
  await A.getByTestId('subscribe-plus').click(); await A.getByTestId('plus-active').waitFor({ timeout: 8000 });
  const me = await api(tokA, 'GET', '/me'); if (!me.plus.active) throw new Error('plus not active');
  const slots = (await api(tokA, 'GET', `/venues/3/slots?date=${isoDay(6)}`)).filter((s: any) => s.available);
  const q = await api(tokA, 'POST', '/bookings/quote', { venueId: 3, date: isoDay(6), slots: [slots[0].time] });
  if (q.feeInr !== 0 || !q.isPlus) throw new Error('fee not waived ' + JSON.stringify(q));
  await A.getByTestId('cancel-plus').click(); await sleep(1200);
  const me2 = await api(tokA, 'GET', '/me'); if (!me2.plus.cancelled) throw new Error('not cancelled');
});

await step('referral: /?ref= banner, newcomer gets ₹100 extra, referrer +₹100 after first booking', async () => {
  const ctx2 = await browser.newContext({ viewport: { width: 1200, height: 900 } });
  const c = await signUp(ctx2, `Ref ${stamp}`, undefined, myCode);
  use(A, c.page);
  const tokC = (await apiUser(`Ref ${stamp}`, c.phone)).token;
  const w = await walletOf(tokC); if (w < 1100) throw new Error('newcomer wallet ' + w);
  const wA0 = await walletOf(tokA);
  const slots = (await api(tokC, 'GET', `/venues/3/slots?date=${isoDay(4)}`)).filter((s: any) => s.available);
  await api(tokC, 'POST', '/bookings', { venueId: 3, date: isoDay(4), slots: [slots[0].time], method: 'wallet' });
  await sleep(800);
  const wA1 = await walletOf(tokA); if (wA1 - wA0 !== 100) throw new Error(`referrer credit ${wA1 - wA0}`);
  await ctx2.close();
});

await step('Dubai: AED price with ₹ in brackets; checkout breakdown in AED', async () => {
  await A.goto(BASE + '/'); await A.getByLabel('City', { exact: true }).selectOption('Dubai'); await A.waitForTimeout(1200);
  const price = await A.getByTestId('venue-price').first().textContent(); if (!/AED/.test(price ?? '') || !/₹/.test(price ?? '')) throw new Error('price ' + price);
  await A.locator('article a').first().click(); await A.getByTestId('gallery').waitFor(); await pickDay(3); await firstSlots(1);
  await A.getByTestId('book-now').click(); await A.getByTestId('breakdown').waitFor();
  if (!/AED/.test((await A.getByTestId('breakdown').textContent()) ?? '')) throw new Error('no AED in checkout breakdown');
  await A.keyboard.press('Escape');
  await A.getByLabel('City', { exact: true }).selectOption('Bengaluru');
});

await step('rate limit: spamming tickets gives a 429 toast', async () => {
  for (let i = 0; i < 7; i++) await api(tokA, 'POST', '/tickets', { topic: 'Other', subject: 'spam ticket ' + i, message: 'hello there' }).catch(() => {});
  await A.goto(BASE + '/help/tickets'); await A.getByTestId('new-ticket').click();
  await A.getByTestId('ticket-form').waitFor();
  await A.getByPlaceholder('Subject').fill('spam final');
  await A.locator('[data-testid=ticket-form] textarea').fill('hello hello'); await A.getByTestId('ticket-submit').click();
  await A.getByText(/too many|slow down|try again/i).first().waitFor({ timeout: 6000 });
});

const bad = summary('g1-money'); await browser.close(); process.exit(bad ? 1 : 0);
