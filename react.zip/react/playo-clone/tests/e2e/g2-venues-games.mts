import { BASE, api, apiUser, launch, signUp, step, summary, use, walletOf, isoDay, sleep, stamp, accept } from './glib.mts';
const browser = await launch();
const geo = { latitude: 12.9352, longitude: 77.6245 }; // Koramangala, Bengaluru
const ctxH = await browser.newContext({ viewport: { width: 1200, height: 900 }, geolocation: geo, permissions: ['geolocation'] });
const ctxJ = await browser.newContext({ viewport: { width: 1200, height: 900 } });
await ctxH.addInitScript(() => { Object.defineProperty(navigator, 'share', { value: undefined }); });
const H = await signUp(ctxH, `Host ${stamp}`); accept(H.page);
const J = await signUp(ctxJ, `Joiner ${stamp}`); accept(J.page);
const tokH = (await apiUser(`Host ${stamp}`, H.phone)).token;
const J_api = await apiUser(`Joiner ${stamp}`, J.phone); const tokJ = J_api.token;
const H_me = await api(tokH, 'GET', '/me');
use(H.page, J.page);
const pg = H.page;
const startsAt = (d: number, hh = '18:00') => `${isoDay(d)}T${hh}`;
const newGame = (over: Record<string, unknown> = {}) => ({ title: 'E2E game ' + Math.random().toString(36).slice(2, 6), sport: 'football', venueId: 3, startsAt: startsAt(3), capacity: 4, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 0, ...over });

/* ------------------------------ venues ------------------------------ */
await step('venues: list shows 13 cities + padel; Chennai has venues', async () => {
  await pg.goto(BASE + '/'); await pg.locator('article').first().waitFor();
  const cities = await pg.getByLabel('City', { exact: true }).locator('option').allTextContents();
  for (const c of ['Chennai', 'Kolkata', 'Ahmedabad', 'Jaipur', 'Dubai', 'Doha', 'Sydney', 'London']) if (!cities.includes(c)) throw new Error('missing city ' + c);
  const sports = await api(null, 'GET', '/sports'); if (!sports.some((s: any) => s.id === 'padel')) throw new Error('no padel');
  const v = await api(null, 'GET', '/venues?city=Chennai'); if (!(v.total > 0 || v.items?.length)) throw new Error('no Chennai venues');
});
await step('venues: amenity filter narrows list', async () => {
  const n0 = await pg.getByTestId('venue-card').count().catch(() => 0) || await pg.locator('article').count();
  await pg.getByTestId('filter-amenity-floodlights').click(); await pg.waitForTimeout(1200);
  const txt = (await pg.getByTestId('venue-count').textContent()) ?? '';
  const n1 = await pg.locator('article').count();
  if (n1 === 0) throw new Error('no results with floodlights'); if (n1 > n0) throw new Error(`${n0}->${n1}`);
  await pg.getByTestId('filter-amenity-floodlights').click(); await pg.waitForTimeout(500);
});
await step('venues: sort by price ascending', async () => {
  await pg.getByTestId('sort-select').selectOption('price'); await pg.waitForTimeout(1200);
  const prices = (await pg.getByTestId('venue-price').allTextContents()).map((t) => Number(t.replace(/[^0-9]/g, '').slice(0, 5)));
  for (let i = 1; i < prices.length; i++) if (prices[i] < prices[i - 1]) throw new Error('not sorted ' + prices.join(','));
  await pg.getByTestId('sort-select').selectOption('rating');
});
await step('venues: max price filter', async () => {
  await pg.getByTestId('filter-max-price').selectOption({ index: 1 }); await pg.waitForTimeout(1200);
  const prices = (await pg.getByTestId('venue-price').allTextContents()).map((t) => Number(t.replace(/[^0-9]/g, '').slice(0, 5)));
  if (!prices.length) throw new Error('no venues at lowest max price');
  await pg.getByTestId('filter-max-price').selectOption({ index: 0 });
});
await step('venues: Near me shows distances and nearest sort', async () => {
  await pg.getByTestId('near-me').click(); await pg.getByTestId('venue-distance').first().waitFor({ timeout: 8000 });
  const d = (await pg.getByTestId('venue-distance').allTextContents()).map((t) => parseFloat(t.replace(/[^0-9.]/g, '')));
  const src = (await pg.getByTestId('location-source').textContent().catch(() => '')) ?? '';
  console.log('   location-source:', src.trim());
  for (let i = 1; i < d.length; i++) if (d[i] < d[i - 1]) throw new Error('not nearest-first ' + d.join(','));
});
await step('venues: map view renders Leaflet with markers', async () => {
  await pg.getByTestId('view-map').click(); await pg.getByTestId('venue-map').waitFor({ timeout: 10000 });
  await pg.locator('.leaflet-container').waitFor(); await pg.locator('.venue-pin').first().waitFor({ state: 'attached', timeout: 8000 });
  await pg.locator('.leaflet-marker-icon').first().dispatchEvent('click'); await pg.getByTestId('map-popup-link').waitFor();
  await pg.getByTestId('view-list').click();
});
await step('venue page: gallery next/prev + share copies link', async () => {
  await pg.goto(BASE + '/venues/3'); await pg.getByTestId('gallery').waitFor();
  const c0 = await pg.getByTestId('gallery-count').textContent(); await pg.getByTestId('gallery-next').click();
  const c1 = await pg.getByTestId('gallery-count').textContent(); if (c0 === c1) throw new Error('gallery did not move');
  await ctxH.grantPermissions(['clipboard-read', 'clipboard-write']);
  await pg.getByTestId('share-button').first().click(); await pg.waitForTimeout(500);
  const clip = await pg.evaluate(() => navigator.clipboard.readText()); if (!/\/venues\/3/.test(clip)) throw new Error('clipboard ' + clip);
});

/* ------------------------------ games ------------------------------ */
let gApproval = 0, gPrivate = 0, gMin = 0, gOpen = 0, code = '';
await step('host form: create approval+priced+min-level game via UI', async () => {
  await pg.goto(BASE + '/games'); await pg.getByTestId('host-toggle').click(); await pg.getByTestId('host-form').waitFor();
  await pg.getByLabel('Title').fill('UI approval game'); await pg.getByLabel('Sport').selectOption('football');
  await pg.getByLabel('Starts at').fill(startsAt(4));
  await pg.getByTestId('host-joinmode').selectOption('approval'); await pg.getByTestId('host-minlevel').selectOption('Intermediate'); await pg.getByTestId('host-price').fill('100');
  await pg.getByTestId('host-submit').click(); await sleep(1500);
  const mine = (await api(tokH, 'GET', '/games?mine=1&status=open')).find((g: any) => g.title === 'UI approval game');
  if (!mine) throw new Error('game not created'); if (mine.joinMode !== 'approval' || mine.minLevel !== 'Intermediate' || mine.priceInr !== 100) throw new Error(JSON.stringify(mine));
  gMin = mine.id;
});
await step('min level: beginner joiner is refused (toast), wallet untouched', async () => {
  const w0 = await walletOf(tokJ);
  await J.page.goto(BASE + `/games/${gMin}`); await J.page.getByTestId('game-detail').waitFor();
  const btn = J.page.getByTestId(`join-${gMin}`); await btn.waitFor();
  await btn.click(); await J.page.getByTestId('join-pay').click().catch(() => {});
  await J.page.getByText(/level|Intermediate/i).first().waitFor({ timeout: 6000 });
  if ((await walletOf(tokJ)) !== w0) throw new Error('wallet changed');
});
await step('approval game: join requests hold payment; host approves → player', async () => {
  const g = await api(tokH, 'POST', '/games', newGame({ title: 'Approval A', joinMode: 'approval', priceInr: 100 })); gApproval = g.id;
  const w0 = await walletOf(tokJ);
  await J.page.goto(BASE + `/games/${gApproval}`); await J.page.getByTestId(`join-${gApproval}`).click(); await J.page.getByTestId('join-pay').click();
  await J.page.getByTestId(`withdraw-${gApproval}`).waitFor({ timeout: 8000 });
  if (w0 - (await walletOf(tokJ)) !== 100) throw new Error('payment not held');
  await pg.goto(BASE + `/games/${gApproval}`); await pg.getByTestId('requests-panel').waitFor();
  await pg.getByTestId(`approve-${J_api.me.id}`).click(); await pg.getByTestId(`player-${J_api.me.id}`).waitFor({ timeout: 8000 });
});
await step('joiner sees "approved" live (leave button) and gets host-notification wording', async () => {
  await J.page.goto(BASE + `/games/${gApproval}`); await J.page.getByTestId(`leave-${gApproval}`).waitFor();
  const n = await api(tokJ, 'GET', '/notifications'); const t = (n.items ?? n).map((x: any) => x.type); if (!t.includes('game_request_approved')) throw new Error(t.join());
  await J.page.goto(BASE + '/notifications'); await J.page.getByText(/approved your request/i).first().waitFor();
});
await step('approval game: decline refunds payment', async () => {
  const g = await api(tokH, 'POST', '/games', newGame({ title: 'Approval B', joinMode: 'approval', priceInr: 100 }));
  const w0 = await walletOf(tokJ);
  await api(tokJ, 'POST', `/games/${g.id}/join`, { method: 'wallet' });
  await pg.goto(BASE + `/games/${g.id}`); await pg.getByTestId(`decline-${J_api.me.id}`).click();
  await sleep(1200); if ((await walletOf(tokJ)) !== w0) throw new Error(`refund missing ${w0} -> ${await walletOf(tokJ)}`);
  await J.page.goto(BASE + `/games/${g.id}`); await J.page.getByTestId('request-declined').waitFor();
});
await step('leave ≥3h before: refund of price per player; host not credited', async () => {
  const w0 = await walletOf(tokJ);
  await J.page.goto(BASE + `/games/${gApproval}`); await J.page.getByTestId(`leave-${gApproval}`).click(); await sleep(1500);
  if ((await walletOf(tokJ)) - w0 !== 100) throw new Error(`refund ${(await walletOf(tokJ)) - w0}`);
});
await step('private game: invite code /g/CODE works logged out (preview) and joins when logged in', async () => {
  const g = await api(tokH, 'POST', '/games', newGame({ title: 'Secret one', visibility: 'private' })); gPrivate = g.id; code = g.inviteCode;
  if (!code) throw new Error('no invite code');
  // not in public listing for the joiner
  const list = await api(tokJ, 'GET', '/games?city=Bengaluru&sport=all'); if (list.some((x: any) => x.id === gPrivate)) throw new Error('private game visible in list');
  const ctxAnon = await browser.newContext(); const anon = await ctxAnon.newPage(); anon.setDefaultTimeout(9000);
  await anon.goto(BASE + `/g/${code}`); await anon.getByText('Secret one').first().waitFor(); await ctxAnon.close();
  await J.page.goto(BASE + `/g/${code}`); await J.page.getByTestId(`join-${gPrivate}`).click(); await J.page.getByTestId(`leave-${gPrivate}`).waitFor({ timeout: 8000 });
});
await step('RSVP going → counts update', async () => {
  await J.page.goto(BASE + `/games/${gPrivate}`); await J.page.getByTestId('rsvp-going').click(); await J.page.waitForFunction(() => /1 going/.test(document.querySelector('[data-testid=rsvp-counts]')?.textContent ?? ''), null, { timeout: 5000 }).catch(() => {});
  const cnt = (await J.page.getByTestId('rsvp-counts').textContent()) ?? ''; if (!/1 going/.test(cnt)) throw new Error('count: ' + cnt);
});
await step('host invites a played-with/friend player (invite modal)', async () => {
  const g = await api(tokH, 'POST', '/games', newGame({ title: 'Invite me', visibility: 'private' })); gOpen = g.id;
  // make them friends via a finished shared game so they show in the list
  await api(tokJ, 'POST', `/games/${gPrivate}/leave`).catch(() => {});
  await api(tokJ, 'POST', `/games/${gPrivate}/join`, { method: 'wallet', code }).catch(() => {});
  const ended = await api(tokH, 'POST', '/games', newGame({ title: 'Played together' }));
  await api(tokJ, 'POST', `/games/${ended.id}/join`, { method: 'wallet' });
  await api(tokH, 'POST', `/games/${ended.id}/end`, { winnerIds: [], attendedIds: [H_me.id, J_api.me.id] });
  await pg.goto(BASE + `/games/${gOpen}`); await pg.getByTestId('invite-open').click();
  await pg.getByTestId(`invite-${J_api.me.id}`).check(); await pg.getByTestId('invite-send').click(); await sleep(1200);
  const n = await api(tokJ, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'game_invite')) throw new Error('no invite notification');
  await J.page.goto(BASE + '/notifications'); await J.page.getByText(/invited you to/i).first().waitFor();
});
await step('priced open game: join charges; end game w/ attendance credits host only for attendees', async () => {
  const g = await api(tokH, 'POST', '/games', newGame({ title: 'Paid open', priceInr: 200 }));
  const wj0 = await walletOf(tokJ); const wh0 = await walletOf(tokH);
  await J.page.goto(BASE + `/games/${g.id}`); await J.page.getByTestId(`join-${g.id}`).click(); await J.page.getByTestId('join-pay').click(); await J.page.getByTestId(`leave-${g.id}`).waitFor();
  if (wj0 - (await walletOf(tokJ)) !== 200) throw new Error('joiner not charged');
  await pg.goto(BASE + `/games/${g.id}`); await pg.getByTestId('end-open').click();
  await pg.getByTestId(`attended-${J_api.me.id}`).uncheck(); await pg.getByTestId('end-game-confirm').click(); await sleep(1500);
  const gg = await api(tokH, 'GET', `/games/${g.id}`); if (gg.status !== 'ended') throw new Error('not ended');
  const absent = gg.players.find((p: any) => p.id === J_api.me.id); if (absent?.attended !== false) throw new Error('absent not recorded ' + JSON.stringify(absent));
  const hostGain = (await walletOf(tokH)) - wh0; console.log('   host wallet change after end:', hostGain);
  const n = await api(tokJ, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'game_ended')) throw new Error('no game_ended notification');
});
await step('report game button opens modal and files a report', async () => {
  await J.page.goto(BASE + `/games/${gOpen}`).catch(() => {});
  const g = await api(tokH, 'POST', '/games', newGame({ title: 'Reportable' }));
  await J.page.goto(BASE + `/games/${g.id}`); await J.page.getByTestId(`report-game-${g.id}`).click(); await J.page.locator('[role=dialog] select, [role=dialog] input[type=radio]').first().waitFor();
  const sel = J.page.locator('[role=dialog] select'); if (await sel.count()) await sel.first().selectOption({ index: 1 });
  else await J.page.locator('[role=dialog] input[type=radio]').first().check();
  await J.page.getByTestId('report-submit').click(); await J.page.getByText(/report.*(sent|filed|thanks)|thanks/i).first().waitFor();
});

const bad = summary('g2-venues-games'); await browser.close(); process.exit(bad ? 1 : 0);
