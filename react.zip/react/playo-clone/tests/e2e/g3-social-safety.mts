import { BASE, api, apiUser, launch, signUp, step, summary, use, isoDay, sleep, stamp, accept } from './glib.mts';
const browser = await launch();
const ctxA = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const ctxB = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const ctxAdmin = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const A = await signUp(ctxA, `Alice ${stamp}`); accept(A.page);
const B = await signUp(ctxB, `Bobby ${stamp}`); accept(B.page);
const a = await apiUser(`Alice ${stamp}`, A.phone), b = await apiUser(`Bobby ${stamp}`, B.phone);
use(A.page, B.page);
const mk = (o = {}) => ({ title: 'Social game', sport: 'football', venueId: 3, startsAt: isoDay(3) + 'T18:00', capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 0, ...o });

/* make A and B have played together (needed for requests / blocking from profile) */
const shared = await api(a.token, 'POST', '/games', mk());
await api(b.token, 'POST', `/games/${shared.id}/join`, { method: 'wallet' });
await api(a.token, 'POST', `/games/${shared.id}/end`, { winnerIds: [], attendedIds: [a.me.id, b.me.id] });
const unameA = a.me.username, unameB = b.me.username;

await step('profile: set availability (plays) + sports level via UI and save', async () => {
  await A.page.goto(BASE + '/profile'); await A.page.getByTestId('plays-editor').waitFor();
  await A.page.getByTestId('plays-weekend').check(); await A.page.getByTestId('plays-evening').check();
  const foot = A.page.getByLabel(/Football/).first(); if (!(await foot.isChecked())) await foot.check();
  await A.page.getByRole('button', { name: /save/i }).first().click(); await sleep(1500);
  const me = await api(a.token, 'GET', '/me'); if (!me.plays.days.includes('weekend') || !me.plays.times.includes('evening')) throw new Error(JSON.stringify(me.plays));
});
await step('profile: bot-visible Players for you tab lists matches with % and reasons', async () => {
  await api(b.token, 'PUT', '/me/profile', { name: b.me.name, username: b.me.username, bio: '', city: 'Bengaluru', avatarEmoji: '🙂', avatarColor: '#00b259', isPrivate: false, sports: [{ sport: 'football', level: 'Beginner' }], plays: { days: ['weekend'], times: ['evening'] } });
  await A.page.goto(BASE + '/friends'); await A.page.getByRole('tab', { name: 'Players for you' }).click();
  await A.page.getByTestId('suggested-list').waitFor();
  const n = await A.page.locator('[data-testid^=match-]').count(); if (!n) throw new Error('no suggestions');
  const pct = await A.page.locator('[data-testid^=match-]').first().textContent(); if (!/%/.test(pct ?? '')) throw new Error('no % ' + pct);
  // B should rank (shared sport, level, city, times)
  if (!(await A.page.getByTestId(`match-${unameB}`).count())) throw new Error('B not suggested to A');
});
await step('join a game together shortcut → /games?with=', async () => {
  await api(b.token, 'POST', '/games', mk({ title: 'Bob hosts' }));
  await A.page.getByTestId(`join-together-${unameB}`).click(); await A.page.getByTestId('with-banner').waitFor();
  await A.page.getByText('Bob hosts').first().waitFor();
});

await step('friend request via UI profile; B accepts from Requests tab', async () => {
  await A.page.goto(BASE + `/p/${unameB}`); await A.page.getByTestId('public-profile').waitFor();
  await A.page.getByRole('button', { name: /add friend|friend request/i }).first().click(); await sleep(1200);
  await B.page.goto(BASE + '/friends'); await B.page.getByRole('tab', { name: /Requests/ }).click();
  await B.page.getByRole('button', { name: 'Accept' }).first().click(); await sleep(1200);
  const f = await api(a.token, 'GET', '/friends'); if (!f.friends.some((p: any) => p.id === b.me.id)) throw new Error('not friends');
});

/* chat + filter */
await step('chat: message with a blocked word is shown as ***', async () => {
  const dm = await api(a.token, 'POST', '/chats', { kind: 'direct', userId: b.me.id });
  await A.page.goto(BASE + `/chat/${dm.id}`); await A.page.getByLabel('Message').fill('you are an idiot, truly stupid'); await A.page.keyboard.press('Enter');
  await A.page.getByText(/you are an \*+/).first().waitFor();
  const t = await A.page.locator('main').innerText(); if (/idiot|stupid/i.test(t)) throw new Error('word leaked: ' + t.slice(-120));
  await B.page.goto(BASE + `/chat/${dm.id}`); await B.page.getByText(/you are an \*+/).first().waitFor();
});
await step('report a message from the chat bubble', async () => {
  await B.page.locator('[data-testid^=report-message-]').first().click({ force: true }).catch(async () => { await B.page.locator('[data-testid^=msg-]').first().hover(); await B.page.locator('[data-testid^=report-message-]').first().click({ force: true }); });
  const sel = B.page.locator('[role=dialog] select'); if (await sel.count()) await sel.first().selectOption({ index: 1 }); else await B.page.locator('[role=dialog] input[type=radio]').first().check();
  await B.page.getByTestId('report-submit').click(); await B.page.getByText(/report.*(sent|filed)|thanks/i).first().waitFor();
});

/* block */
await step('block B: B vanishes from A search; A profile 404 for B; blocked list + unblock', async () => {
  await A.page.goto(BASE + `/p/${unameB}`); await A.page.getByTestId(`block-${unameB}`).click(); await sleep(1500);
  const s = await api(a.token, 'GET', `/players/search?q=${encodeURIComponent('Bobby')}`); if ((s.items ?? s).some((p: any) => p.id === b.me.id)) throw new Error('blocked player still in search');
  let st = 0; try { await api(b.token, 'GET', `/players/${unameA}`); } catch (e) { st = /404/.test((e as Error).message) ? 404 : 1; }
  if (st !== 404) throw new Error('blocked player can still see profile');
  await B.page.goto(BASE + `/p/${unameA}`); await B.page.getByText(/not found|doesn.t exist|404/i).first().waitFor();
  await A.page.goto(BASE + '/profile'); await A.page.getByTestId('blocked-list').waitFor(); await A.page.getByTestId('blocked-list').getByText(/Bobby/).waitFor();
  await A.page.getByTestId('blocked-list').getByRole('button', { name: /unblock/i }).click(); await sleep(1200);
  const bl = await api(a.token, 'GET', '/blocks'); if ((bl.items ?? bl).length) throw new Error('still blocked');
});
await step('blocked player cannot send new DM / friend request (API)', async () => {
  await api(a.token, 'POST', '/blocks', { userId: b.me.id });
  let rej = false; try { await api(b.token, 'POST', '/friends/requests', { userId: a.me.id }); } catch { rej = true; }
  if (!rej) throw new Error('request allowed');
  await api(a.token, 'DELETE', `/blocks/${b.me.id}`);
});

/* report player + admin */
let reportId = 0;
await step('report player via UI profile', async () => {
  await A.page.goto(BASE + `/p/${unameB}`); await A.page.getByTestId(`report-player-${b.me.id}`).click();
  const sel = A.page.locator('[role=dialog] select'); if (await sel.count()) await sel.first().selectOption({ index: 1 }); else await A.page.locator('[role=dialog] input[type=radio]').first().check();
  await A.page.getByTestId('report-submit').click(); await A.page.getByText(/report.*(sent|filed)|thanks/i).first().waitFor();
  const adm = await apiUser('Admin', '9000000000'); const list = await api(adm.token, 'GET', '/admin/reports?status=open');
  const r = (list.items ?? list).find((x: any) => x.kind === 'player' && x.targetId === b.me.id || x.target?.id === b.me.id); if (!r) throw new Error('report not in admin list: ' + JSON.stringify(list).slice(0, 200));
  reportId = r.id;
});
await step('admin page: non-admin sees not-admin; admin resolves; reporter notified', async () => {
  await A.page.goto(BASE + '/admin/reports'); await A.page.getByTestId('not-admin').waitFor();
  const admin = await signUp(ctxAdmin, 'Admin', '9000000000'); use(A.page, B.page, admin.page); accept(admin.page);
  await admin.page.goto(BASE + '/admin/reports'); await admin.page.getByTestId(`report-${reportId}`).waitFor();
  await admin.page.getByTestId(`resolve-${reportId}`).click(); await sleep(1500);
  const n = await api(a.token, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'report_update')) throw new Error('no report_update notification');
  await A.page.goto(BASE + '/notifications'); await A.page.getByText(/Your report was/i).first().waitFor();
});

/* rate limiting */
await step('rate limit: 21 friend-requests/min → 429 with Retry-After; UI toast on messages', async () => {
  const spammer = await apiUser('Spam ' + stamp); let saw429 = false;
  const targets = [];
  for (let i = 0; i < 22; i++) targets.push(i + 1);
  for (const t of targets) { try { await api(spammer.token, 'POST', '/friends/requests', { userId: 1 + (t % 5) }); } catch (e) { if (/429/.test((e as Error).message)) saw429 = true; } }
  if (!saw429) throw new Error('never rate limited');
});
await step('rate limit UI: sending 35 chat messages fast shows the slow-down toast', async () => {
  const g = await api(a.token, 'POST', '/games', mk({ title: 'Chatty' })); const chatId = g.chatId;
  await A.page.goto(BASE + `/chat/${chatId}`); await A.page.getByLabel('Message').waitFor();
  for (let i = 0; i < 40; i++) api(a.token, 'POST', `/chats/${chatId}/messages`, { body: 'm' + i }).catch(() => {});
  await sleep(1500);
  await A.page.getByLabel('Message').fill('one more'); await A.page.keyboard.press('Enter');
  await A.page.getByText(/too many|slow down|wait/i).first().waitFor({ timeout: 8000 });
});

/* push toggle */
await step('push toggle: enabling asks permission, stored, off again', async () => {
  const ctxP = await browser.newContext({ permissions: ['notifications'] }); const P = await signUp(ctxP, 'Push ' + stamp);
  await P.page.goto(BASE + '/notifications'); const t = P.page.getByTestId('push-toggle'); await t.waitFor();
  await t.locator('input').check().catch(async () => t.click()); await sleep(800);
  const perm = await P.page.evaluate(() => Notification.permission); if (perm !== 'granted') throw new Error('permission ' + perm);
  const saved = await P.page.evaluate(() => Object.values(localStorage).join('').includes('"pushEnabled":true')); if (!saved) throw new Error('pushEnabled not persisted');
  await ctxP.close();
});

const bad = summary('g3-social-safety'); await browser.close(); process.exit(bad ? 1 : 0);
