import { BASE, api, apiUser, launch, signUp, step, summary, use, isoDay, sleep, stamp, accept, walletOf } from './glib.mts';
const browser = await launch();
const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const U = await signUp(ctx, `Learner ${stamp}`); accept(U.page); use(U.page);
const pg = U.page;
const tok = (await apiUser(`Learner ${stamp}`, U.phone)).token;
await api(tok, 'POST', '/wallet/topup', { amount: 10000, method: 'upi' });
const coaches = (await api(null, 'GET', '/coaches?city=Bengaluru&limit=30')); const list = coaches.items ?? coaches;
const coach = list.find((c: any) => c.sport === 'badminton') ?? list[0];
const detail = await api(null, 'GET', `/coaches/${coach.id}`);
const nums = (s: string | null) => Number((s ?? '').replace(/[^0-9]/g, ''));

/* ---------------- coaching ---------------- */
await step('coaches list: cards link to profile; enquiry button still there', async () => {
  await pg.goto(BASE + '/coaches'); await pg.getByTestId('coach-list').waitFor();
  await pg.getByTestId(`coach-link-${coach.id}`).first().waitFor(); await pg.getByTestId(`enquire-${coach.id}`).first().waitFor();
});
await step('coach profile: certifications, specialties, programs, reviews section', async () => {
  await pg.goto(BASE + `/coaches/${coach.id}`); await pg.getByTestId('coach-profile').waitFor();
  await pg.getByTestId('coach-certs').waitFor(); await pg.getByTestId('coach-specialties').waitFor(); await pg.getByTestId('program-list').waitFor(); await pg.getByRole('heading', { name: 'Reviews' }).waitFor();
});
await step('enquiry from profile → success notification', async () => {
  await pg.getByTestId('open-enquiry').click(); await pg.locator('[role=dialog] textarea').fill('Do you coach beginners on weekends?'); await pg.getByTestId('enquiry-send').click();
  await sleep(1200); const n = await api(tok, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'coach_enquiry_sent')) throw new Error('no enquiry notification');
});
let programId = 0, enrolId = 0;
await step('enrol in a program batch via UI: wallet charged, seat taken, My learning lists it', async () => {
  const prog = detail.programs[0]; programId = prog.id; const batch = prog.batches[0];
  const w0 = await walletOf(tok);
  await pg.goto(BASE + `/coaches/${coach.id}`); await pg.getByTestId(`enrol-${prog.id}`).click();
  await pg.getByTestId(`batch-${batch.id}`).check(); await pg.getByTestId('enrol-pay').click(); await sleep(1500);
  if (!((w0 - (await walletOf(tok))) === prog.priceInr)) throw new Error(`charged ${w0 - (await walletOf(tok))} vs ${prog.priceInr}`);
  await pg.goto(BASE + '/learning'); await pg.getByTestId('enrolment-list').waitFor(); await pg.locator('[data-testid^=enrolment-]:not([data-testid=enrolment-list])').first().waitFor();
  const l = await api(tok, 'GET', '/learning'); enrolId = (l.enrolments ?? l.programs ?? [])[0]?.id;
  const after = await api(null, 'GET', `/coaches/${coach.id}`); const b2 = after.programs[0].batches.find((x: any) => x.id === batch.id); if (b2.seatsLeft !== batch.seatsLeft - 1) throw new Error(`seats ${batch.seatsLeft}->${b2.seatsLeft}`);
});
await step('trial session: pick day+slot, pay, appears in My learning, cancel refunds %', async () => {
  const day = isoDay(3); const w0 = await walletOf(tok);
  await pg.goto(BASE + `/coaches/${coach.id}`); await pg.getByTestId('book-session').click();
  await pg.getByTestId(`session-day-${day}`).click(); const slot = pg.locator('[data-testid^=session-slot-]:not([disabled])'); await slot.first().waitFor(); await slot.first().click();
  await pg.getByTestId('session-pay').click(); await sleep(1500);
  const spent = w0 - (await walletOf(tok)); if (spent <= 0) throw new Error('not charged');
  await pg.goto(BASE + '/learning'); await pg.getByTestId('session-list').waitFor(); await pg.locator('[data-testid^=session-]:not([data-testid=session-list]):not([data-testid=session-slots])').first().waitFor();
  const w1 = await walletOf(tok); await pg.locator('[data-testid^=cancel-session-]').first().click(); await sleep(1500);
  if (!((await walletOf(tok)) > w1)) throw new Error('cancel did not refund');
});
await step('coach review only after attending; form shows after dev attend; review earns Karma', async () => {
  const l = await api(tok, 'GET', '/learning'); const e = (l.enrolments ?? l.programs ?? [])[0];
  await api(tok, 'POST', '/dev/attend', { kind: 'enrolment', id: e.id }).catch(async () => api(tok, 'POST', '/dev/attend', { enrolmentId: e.id }));
  const k0 = (await api(tok, 'GET', '/karma')).balance;
  await pg.goto(BASE + `/coaches/${coach.id}`); await pg.getByTestId('coach-review-form').waitFor();
  await pg.getByTestId('coach-review-form').locator('textarea').fill('Great coach, clear drills'); await pg.getByTestId('coach-review-send').click(); await sleep(1500);
  await pg.getByText('Great coach, clear drills').first().waitFor(); const k1 = (await api(tok, 'GET', '/karma')).balance; if (!(k1 > k0)) throw new Error('no karma for review');
});

/* ---------------- events ---------------- */
const events = await api(tok, 'GET', '/events?city=Bengaluru&type=all&q=');
const marathon = events.find((e: any) => e.type === 'marathon'), trek = events.find((e: any) => e.type === 'trek'), meetup = events.find((e: any) => e.type === 'meetup');
await step('events list: marathons, treks, meetups visible; type filter + search work', async () => {
  await pg.goto(BASE + '/events'); await pg.getByTestId('event-list').waitFor();
  if (!marathon || !trek || !meetup) throw new Error(`missing types m=${!!marathon} t=${!!trek} u=${!!meetup}`);
  await pg.getByRole('tab', { name: /Marathons/ }).click(); await sleep(800);
  const t = await pg.getByTestId('event-list').innerText(); if (/trek/i.test(t) && !/marathon|run|K/i.test(t)) throw new Error('filter off');
  await pg.getByRole('tab', { name: /^All/ }).click(); await pg.getByTestId('event-search').fill(trek.title.split(' ')[0]); await sleep(900);
  await pg.getByTestId(`event-${trek.id}`).waitFor();
});
await step('marathon: choose 10K, pay, get bib; refund % on cancel', async () => {
  const w0 = await walletOf(tok);
  await pg.goto(BASE + `/events/${marathon.id}`); await pg.getByTestId('event-detail').waitFor();
  await pg.getByTestId('event-register').click(); await pg.getByTestId('category-10k').check().catch(async () => pg.locator('[data-testid^=category-]').nth(1).check());
  await pg.getByTestId('event-confirm').click(); await pg.getByTestId('event-bib').waitFor({ timeout: 8000 });
  const bib = nums(await pg.getByTestId('event-bib').textContent()); if (!bib) throw new Error('no bib');
  if (!((w0 - (await walletOf(tok))) > 0)) throw new Error('marathon fee not charged');
  await pg.getByTestId('participants').waitFor();
  const n = await api(tok, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'event_registered')) throw new Error('no event_registered notification');
  await pg.getByTestId('event-cancel').click(); await sleep(1500); if (!((await walletOf(tok)) > w0 - 1)) console.log('   (partial refund)');
});
await step('trek: register shows difficulty + itinerary', async () => {
  await pg.goto(BASE + `/events/${trek.id}`); await pg.getByTestId('event-itinerary').waitFor();
  await pg.getByTestId('event-register').click(); const c = pg.locator('[data-testid^=category-]'); if (await c.count()) await c.first().check();
  await pg.getByTestId('event-confirm').click(); await pg.getByTestId('event-status').waitFor();
});
await step('meetup: RSVP going then maybe', async () => {
  await pg.goto(BASE + `/events/${meetup.id}`); await pg.getByTestId('event-going').click();
  if (await pg.getByTestId('event-confirm').count()) await pg.getByTestId('event-confirm').click();
  await pg.getByTestId('event-status').waitFor();
});
await step('host a meetup via UI; second user sees it and RSVPs; host notified', async () => {
  await pg.goto(BASE + '/events'); await pg.getByTestId('host-meetup').click();
  await pg.getByTestId('meetup-title').fill('E2E Sunday pickup'); await pg.getByTestId('meetup-place').fill('Cubbon Park gate 2');
  const d = pg.locator('[role=dialog] input[type=datetime-local]'); if (await d.count()) await d.fill(isoDay(5) + 'T07:00');
  await pg.getByTestId('meetup-create').click(); await sleep(1500);
  const mine = (await api(tok, 'GET', '/events?city=Bengaluru&type=meetup&q=E2E')).find((e: any) => e.title === 'E2E Sunday pickup'); if (!mine) throw new Error('meetup not created');
  const other = await apiUser('Guest ' + stamp);
  await api(other.token, 'POST', `/events/${mine.id}/register`, { answer: 'going', method: 'wallet' });
  const n = await api(tok, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'event_rsvp')) throw new Error('host not notified');
  await pg.goto(BASE + `/events/${mine.id}`); await pg.getByTestId('event-host-note').waitFor(); await pg.getByTestId('participants').waitFor();
});
await step('notification wording: enrolment / session / event types read well', async () => {
  await pg.goto(BASE + '/notifications');
  for (const re of [/enrolled in/i, /Your enquiry was sent|enquiry/i, /You're going to|registered/i]) await pg.getByText(re).first().waitFor({ timeout: 6000 });
});

const bad = summary('g4-learning-events'); await browser.close(); process.exit(bad ? 1 : 0);
