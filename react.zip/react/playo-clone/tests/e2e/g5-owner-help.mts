import { BASE, api, apiUser, launch, signUp, step, summary, use, isoDay, sleep, stamp, accept } from './glib.mts';
const browser = await launch();
const ctxO = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const ctxP = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const O = await signUp(ctxO, `Owner ${stamp}`); accept(O.page);
const P = await signUp(ctxP, `Player ${stamp}`); accept(P.page);
const o = await apiUser(`Owner ${stamp}`, O.phone), p = await apiUser(`Player ${stamp}`, P.phone);
use(O.page, P.page);
const pg = O.page;
let venueId = 0, bookingId = 0, reviewId = 0;
const day = isoDay(3);

await step('owner home: claimable venues listed; claim one via UI', async () => {
  const claimable = await api(o.token, 'GET', '/owner/claimable?city=Bengaluru'); const first = (claimable.items ?? claimable)[0]; if (!first) throw new Error('nothing claimable');
  venueId = first.id;
  await pg.goto(BASE + '/owner'); await pg.getByTestId(`claim-${venueId}`).click(); await pg.getByTestId(`owner-venue-${venueId}`).waitFor({ timeout: 8000 });
  const mine = await api(o.token, 'GET', '/owner/venues'); if (!(mine.items ?? mine).some((v: any) => v.id === venueId)) throw new Error('not in my venues');
  const n = await api(o.token, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'venue_claimed')) throw new Error('no venue_claimed');
});
await step('owner home: list a brand-new venue through the form', async () => {
  await pg.goto(BASE + '/owner'); await pg.getByTestId('new-venue').click();
  await pg.getByLabel('Venue name').fill('E2E Arena ' + stamp); await pg.getByLabel('Area').fill('Indiranagar'); await pg.getByLabel('Address').fill('12 Test Road');
  await pg.getByLabel('Description').fill('Made by the e2e test'); await pg.getByLabel('Price per hour').fill('500');
  await pg.locator('[role=dialog] fieldset').first().locator('button').first().click();
  await pg.getByTestId('venue-submit').click(); await sleep(1500);
  const mine = await api(o.token, 'GET', '/owner/venues'); if (!(mine.items ?? mine).some((v: any) => /E2E Arena/.test(v.name))) throw new Error('new venue missing');
  const v = await api(null, 'GET', '/venues?city=Bengaluru&q=E2E+Arena'); if (!(v.items ?? v).some((x: any) => /E2E Arena/.test(x.name))) throw new Error('not in public catalog');
});
await step('owner gets live notification + dashboard row when a player books', async () => {
  await pg.goto(BASE + `/owner/${venueId}`); await pg.getByTestId('owner-dashboard').waitFor();
  const slots = (await api(p.token, 'GET', `/venues/${venueId}/slots?date=${day}`)).filter((s: any) => s.available);
  const sport = (await api(null, 'GET', `/venues/${venueId}`)).sports[0];
  const b = await api(p.token, 'POST', '/bookings', { venueId, date: day, slots: [slots[0].time, slots[1].time], sport, method: 'wallet' }); bookingId = b.id;
  await pg.getByText(/booked/i).first().waitFor({ timeout: 8000 }); // toast
  await pg.reload(); await pg.getByTestId(`owner-booking-${bookingId}`).waitFor();
  const stat = Number((await pg.getByTestId('stat-bookings').textContent())?.replace(/\D/g, '')); if (!(stat >= 1)) throw new Error('stat ' + stat);
});
await step('pricing tab: edit hourly+peak, preview updates in nested Root without touching the app store', async () => {
  await pg.getByRole('tab', { name: 'Pricing' }).click(); await pg.getByTestId('price-preview').waitFor();
  const before = await pg.getByTestId('preview-payable').textContent();
  const g0 = await pg.getByTestId('preview-global-check').getAttribute('data-slots');
  await pg.getByTestId('price-hourly').fill('900'); await pg.getByTestId('price-peak').fill('150'); await sleep(600);
  const after = await pg.getByTestId('preview-payable').textContent(); if (before === after) throw new Error('preview did not change ' + before);
  const g1 = await pg.getByTestId('preview-global-check').getAttribute('data-slots'); if (g0 !== g1) throw new Error(`global store changed ${g0} -> ${g1}`);
  if (g1 !== '0') throw new Error('global selection not empty: ' + g1);
  const slot18 = await pg.getByTestId('preview-slot-18:00').textContent(); if (!/1,?050/.test(slot18 ?? '')) throw new Error('peak slot ' + slot18);
  await pg.locator('main input[type=checkbox]').filter({ hasNot: pg.locator('x') }).first().check().catch(() => {}); // Plus toggle
  await pg.getByTestId('save-pricing').click(); await sleep(1500);
  const v = await api(null, 'GET', `/venues/${venueId}`); if (v.pricePerHour !== 900) throw new Error('price not saved ' + v.pricePerHour);
  await P.page.goto(BASE + `/venues/${venueId}`); await P.page.getByTestId('venue-hourly').getByText(/900/).waitFor();
});
await step('block slots: owner blocks an hour; player can no longer book it; unblock restores', async () => {
  await pg.getByRole('tab', { name: 'Block slots' }).click(); await pg.getByTestId(`block-day-${isoDay(4)}`).click();
  const slots = (await api(p.token, 'GET', `/venues/${venueId}/slots?date=${isoDay(4)}`)).filter((s: any) => s.available); const t = slots[0].time;
  await pg.getByTestId(`block-${t}`).click(); await pg.getByTestId('block-hours').click(); await sleep(1200);
  const after = (await api(p.token, 'GET', `/venues/${venueId}/slots?date=${isoDay(4)}`)).find((s: any) => s.time === t); if (after.available || after.reason !== 'blocked') throw new Error(JSON.stringify(after));
  let rej = false; try { await api(p.token, 'POST', '/bookings', { venueId, date: isoDay(4), slots: [t], method: 'wallet' }); } catch { rej = true; } if (!rej) throw new Error('blocked slot bookable');
  await pg.getByTestId(`block-${t}`).click(); await pg.getByTestId('unblock-hours').click(); await sleep(1200);
  const re = (await api(p.token, 'GET', `/venues/${venueId}/slots?date=${isoDay(4)}`)).find((s: any) => s.time === t); if (!re.available) throw new Error('not restored');
});
await step('revenue tab shows total', async () => {
  await pg.getByRole('tab', { name: 'Revenue' }).click(); await pg.getByTestId('revenue-total').waitFor();
});
await step('reply to a review: owner replies in UI; player sees reply + notification', async () => {
  await api(p.token, 'POST', `/bookings/${bookingId}/attend`); await api(p.token, 'POST', `/venues/${venueId}/reviews`, { rating: 4, body: 'Nice courts, bit of a wait' });
  await pg.reload(); await pg.getByRole('tab', { name: 'Reviews' }).click(); const item = pg.locator('[data-testid^=owner-review-]').first(); await item.waitFor();
  reviewId = Number((await item.getAttribute('data-testid'))!.replace(/\D/g, ''));
  await item.getByLabel('Reply').fill('Thanks, we added another court!'); await pg.getByTestId(`reply-send-${reviewId}`).click(); await pg.getByTestId(`reply-${reviewId}`).waitFor();
  await P.page.goto(BASE + `/venues/${venueId}`); await P.page.getByTestId('owner-reply').first().waitFor(); await P.page.getByText('Thanks, we added another court!').first().waitFor();
  const n = await api(p.token, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'review_reply')) throw new Error('no review_reply notification');
});
await step('only the owner can open the dashboard (API 403 for others)', async () => {
  let st = 0; try { await api(p.token, 'GET', `/owner/venues/${venueId}`); } catch (e) { st = /403|404/.test((e as Error).message) ? 403 : 1; } if (st !== 403) throw new Error('player could read owner dashboard');
});

/* ---------------- help ---------------- */
await step('help: FAQ search filters, abort count recorded, empty search shows all', async () => {
  const h = O.page; await h.goto(BASE + '/help'); await h.getByTestId('faq-list').waitFor(); const all = await h.locator('[data-testid^=faq-]:not([data-testid=faq-list]):not([data-testid=faq-meta]):not([data-testid^=faq-cat-]):not([data-testid=faq-search])').count();
  await h.getByTestId('faq-search').type('refund', { delay: 60 }); await sleep(1200); const some = await h.locator('details').count();
  if (!(some > 0 && some < all)) throw new Error(`all ${all} refund ${some}`);
  console.log('   faq-meta:', (await h.getByTestId('faq-meta').textContent())?.trim(), 'cancelled=', await h.getByTestId('faq-meta').getAttribute('data-cancelled'));
  await h.getByTestId('faq-search').fill('zzzzqqq'); await sleep(1000); await h.getByText(/no (answers|results|matches)|ask support/i).first().waitFor();
});
await step('tickets: create via UI → live agent reply arrives without reload', async () => {
  await pg.goto(BASE + '/help/tickets'); await pg.getByTestId('new-ticket').click(); await pg.getByPlaceholder('Subject').fill('Refund missing'); await pg.locator('[role=dialog] textarea').fill('My refund for a cancelled booking has not arrived yet');
  await pg.getByTestId('ticket-submit').click(); await pg.getByTestId('ticket-thread').waitFor({ timeout: 8000 });
  await pg.getByTestId('msg-user').first().waitFor(); await pg.getByTestId('msg-agent').first().waitFor({ timeout: 15000 });
  await pg.getByLabel('Reply').fill('Thanks, any update?'); await pg.getByTestId('ticket-reply').click(); await pg.locator('[data-testid=msg-user]').nth(1).waitFor();
  await pg.getByTestId('close-ticket').click(); await sleep(800);
  const n = await api(o.token, 'GET', '/notifications'); if (!(n.items ?? n).some((x: any) => x.type === 'ticket_reply')) throw new Error('no ticket_reply notification');
});
await step('blog: list, tag filter, article page with related venues + share', async () => {
  await pg.goto(BASE + '/blog'); await pg.getByTestId('article-list').waitFor(); const n = await pg.locator('[data-testid^=article-]:not([data-testid=article-list])').count(); if (n < 8) throw new Error('articles ' + n);
  await pg.getByTestId('blog-search').fill('football'); await sleep(800); await pg.locator('[data-testid^=article-]:not([data-testid=article-list])').first().click();
  await pg.getByTestId('article').waitFor(); await pg.getByTestId('related-venues').waitFor(); await pg.getByTestId('share-button').first().waitFor();
});
await step('policy page: refund table matches server policy (100/50/0 and Plus 100)', async () => {
  await pg.goto(BASE + '/policy'); await pg.getByTestId('refund-table').waitFor();
  const std = [await pg.getByTestId('refund-std-0').textContent(), await pg.getByTestId('refund-std-1').textContent(), await pg.getByTestId('refund-std-2').textContent()];
  if (std.join() !== '100%,50%,0%') throw new Error(std.join()); if (!/100%/.test((await pg.getByTestId('refund-plus-1').textContent()) ?? '')) throw new Error('plus row');
});

const bad = summary('g5-owner-help'); await browser.close(); process.exit(bad ? 1 : 0);
