import { BASE, api, apiUser, launch, signUp, step, summary, use, isoDay, sleep, stamp, accept, walletOf } from './glib.mts';
const browser = await launch();
const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const U = await signUp(ctx, `Notif ${stamp}`); accept(U.page); use(U.page);
const pg = U.page;
const u = await apiUser(`Notif ${stamp}`, U.phone); const tok = u.token;
const friend = await apiUser(`Pal ${stamp}`);
await api(tok, 'POST', '/wallet/topup', { amount: 10000, method: 'upi' });
const mk = (o = {}) => ({ title: 'N game', sport: 'football', venueId: 3, startsAt: isoDay(3) + 'T18:00', capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 0, ...o });
const nums = (s: string | null) => Number((s ?? '').replace(/[^0-9]/g, ''));

/* make them friends through a shared ended game */
const g0 = await api(tok, 'POST', '/games', mk()); await api(friend.token, 'POST', `/games/${g0.id}/join`, { method: 'wallet' });
await api(tok, 'POST', `/games/${g0.id}/end`, { winnerIds: [u.me.id], attendedIds: [u.me.id, friend.me.id] });
const fr = await api(tok, 'POST', '/friends/requests', { userId: friend.me.id }); await api(friend.token, 'POST', `/friends/requests/${fr.id ?? fr.requestId}/accept`).catch(() => {});

await step('trigger every money/learning/event notification type', async () => {
  const slots = (await api(tok, 'GET', `/venues/3/slots?date=${isoDay(4)}`)).filter((s: any) => s.available);
  const b = await api(tok, 'POST', '/bookings', { venueId: 3, date: isoDay(4), slots: [slots[0].time], method: 'wallet' });
  const s5 = (await api(tok, 'GET', `/venues/3/slots?date=${isoDay(5)}`)).filter((s: any) => s.available);
  await api(tok, 'POST', `/bookings/${b.id}/reschedule`, { date: isoDay(5), slots: [s5[0].time] });
  const b2 = await api(tok, 'POST', '/bookings', { venueId: 3, date: isoDay(6), slots: [(await api(tok, 'GET', `/venues/3/slots?date=${isoDay(6)}`)).find((s: any) => s.available).time], method: 'wallet' });
  await api(tok, 'DELETE', `/bookings/${b2.id}`);
  await api(tok, 'POST', '/gift-cards', { amount: 500, recipientId: friend.me.id, message: 'Have fun!', method: 'wallet' });
  const gc = await api(friend.token, 'GET', '/gift-cards'); const code = (gc.received ?? [])[0]?.code; if (code) await api(friend.token, 'POST', '/gift-cards/redeem', { code });
  await api(tok, 'POST', '/passes', { venueId: 3, kind: 'monthly', method: 'wallet' });
  await api(tok, 'POST', '/plus', { plan: 'monthly', method: 'wallet' });
  const coach = ((await api(null, 'GET', '/coaches?city=Bengaluru&limit=30')).items)[0]; const d = await api(null, 'GET', `/coaches/${coach.id}`);
  await api(tok, 'POST', `/programs/${d.programs[0].id}/enrol`, { batchId: d.programs[0].batches[0].id, method: 'wallet' });
  await api(tok, 'POST', '/wallet/topup', { amount: 10000, method: 'upi' });
  const cs = (await api(null, 'GET', `/coaches/${coach.id}/slots?date=${isoDay(3)}`)).find((s: any) => s.available);
  await api(tok, 'POST', `/coaches/${coach.id}/sessions`, { date: isoDay(3), time: cs.time, method: 'wallet' });
  const ev = (await api(tok, 'GET', '/events?city=Bengaluru&type=marathon&q=')).find((e: any) => !e.past);
  await api(tok, 'POST', `/events/${ev.id}/register`, { category: ev.categories[0].id, method: 'wallet' });
  const t = (await api(tok, 'GET', '/tournaments?city=Bengaluru&sport=all'))[0]; if (t) await api(tok, 'POST', `/tournaments/${t.id}/register`, { method: 'wallet' }).catch(() => {});
  await sleep(500);
});
await step('notifications page: every new type reads as a sentence (no undefined/NaN/[object])', async () => {
  await pg.goto(BASE + '/notifications'); await pg.getByRole('button', { name: /Load more|More/i }).click().catch(() => {});
  const all = await api(tok, 'GET', '/notifications?limit=50'); const types = (all.items ?? all).map((x: any) => x.type); console.log('   types:', [...new Set(types)].join(','));
  // read the full list through several pages in the UI
  for (let i = 0; i < 4; i++) { const more = pg.getByRole('button', { name: /load more|older|show more/i }); if (await more.count()) await more.first().click().catch(() => {}); await sleep(500); }
  const text = await pg.locator('main').innerText();
  const bad = text.match(/undefined|NaN|\[object|null/); if (bad) throw new Error('bad text: ' + bad[0] + ' near ' + text.slice(Math.max(0, text.indexOf(bad[0]) - 80), text.indexOf(bad[0]) + 40).replace(/\n/g, ' '));
  for (const re of [/Booking confirmed at/, /moved to/, /refunded to your wallet/, /Playo Plus member/, /Monthly membership bought|pass bought/i, /enrolled in/, /Trial session with/]) if (!re.test(text)) console.log('   (not on first pages:', re, ')');
  const f = await api(friend.token, 'GET', '/notifications'); const ft = (f.items ?? f).map((x: any) => x.type); if (!ft.includes('gift_card_received')) throw new Error('friend lacks gift_card_received: ' + ft);
  if (!(await api(tok, 'GET', '/notifications?limit=50')).items.some((x: any) => x.type === 'gift_card_redeemed')) throw new Error('giver lacks gift_card_redeemed');
});
await step('Plus badge shows on own public profile; ✨ in user menu', async () => {
  await pg.goto(BASE + `/p/${u.me.username}`); await pg.getByTestId('plus-badge').waitFor();
  await pg.getByTestId('user-menu').click(); await pg.getByText(/✨ Plus/).first().waitFor();
});
await step('checkout with Plus: convenience fee line is ₹0', async () => {
  await pg.goto(BASE + '/venues/3'); await pg.locator('button[data-testid^=slot-]').first().waitFor();
  await pg.locator('section button:has(.font-bold)').nth(2).click(); await sleep(600);
  await pg.locator('button[data-testid^=slot-]:not([disabled])').first().click(); await pg.getByTestId('book-now').click(); await pg.getByTestId('breakdown').waitFor();
  const fee = await pg.getByTestId('fee-line').textContent(); if (nums(fee) !== 0) throw new Error('fee shown: ' + fee);
  await pg.keyboard.press('Escape');
});
await step('checkout with monthly pass: pass radio offered, payable drops', async () => {
  await pg.goto(BASE + '/venues/3'); await pg.locator('button[data-testid^=slot-]').first().waitFor();
  await pg.locator('section button:has(.font-bold)').nth(2).click(); await sleep(600);
  await pg.locator('button[data-testid^=slot-]:not([disabled])').first().click(); await pg.getByTestId('book-now').click(); await pg.getByTestId('breakdown').waitFor();
  const before = nums(await pg.getByTestId('payable').textContent());
  const radio = pg.locator('[data-testid^=use-pass-]'); if (!(await radio.count())) throw new Error('no pass offered');
  await radio.first().check(); await sleep(500); const after = nums(await pg.getByTestId('payable').textContent()); if (!(after < before)) throw new Error(`${before}->${after}`);
  await pg.getByTestId('checkout-pay').click(); await sleep(1500);
  const bk = (await api(tok, 'GET', '/bookings')).find((x: any) => x.passId); if (!bk) throw new Error('booking without pass'); if (!(bk.passCovered > 0)) throw new Error('pass covered 0');
  const pass = (await api(tok, 'GET', '/passes')).find((p: any) => p.kind === 'monthly'); if (!(pass.hoursLeft < pass.hoursTotal)) throw new Error('hours not used');
});
await step('50% refund window: booking 3–22 h away shows 50% in UI and refunds half via API', async () => {
  await api(tok, 'POST', '/wallet/topup', { amount: 10000, method: 'upi' });
  const now = Date.now(); let found: { day: string; time: string } | null = null;
  for (const d of [0, 1]) {
    const slots = (await api(tok, 'GET', `/venues/3/slots?date=${isoDay(d)}`)).filter((s: any) => s.available);
    for (const s of slots) { const h = (new Date(`${isoDay(d)}T${s.time}:00`).getTime() - now) / 36e5; if (h > 3 && h < 22) { found = { day: isoDay(d), time: s.time }; break; } }
    if (found) break;
  }
  if (!found) { console.log('   (no free slot 3–22h away right now; skipped)'); return; }
  const b = await api(tok, 'POST', '/bookings', { venueId: 3, date: found.day, slots: [found.time], method: 'wallet' });
  const b1 = (await api(tok, 'GET', '/bookings')).find((x: any) => x.id === b.id);
  // Plus members get 100% to 2h, so check with the non-Plus policy by cancelling a fresh user's booking
  const other = await apiUser('Half ' + stamp); const b2 = await api(other.token, 'POST', '/bookings', { venueId: 3, date: found.day, slots: [(await api(other.token, 'GET', `/venues/3/slots?date=${found.day}`)).filter((s: any) => s.available && s.time !== found.time && (new Date(`${found.day}T${s.time}:00`).getTime() - now) / 36e5 > 3)[0]?.time ?? found.time], method: 'wallet' }).catch(() => null);
  if (b1.refundPercent !== 100) throw new Error('Plus should get 100%, got ' + b1.refundPercent);
  if (b2) { const c = (await api(other.token, 'GET', '/bookings')).find((x: any) => x.id === b2.id); if (c.refundPercent !== 50) throw new Error('standard should get 50%, got ' + c.refundPercent); const w0 = await walletOf(other.token); await api(other.token, 'DELETE', `/bookings/${b2.id}`); const w1 = await walletOf(other.token); if (Math.abs((w1 - w0) - Math.round(b2.paid * 0.5)) > 1) throw new Error(`refund ${w1 - w0} of ${b2.paid}`); }
});
await step('login rate limit: 11 quick logins from one client → 429', async () => {
  let saw = false; for (let i = 0; i < 14; i++) { try { await api(null, 'POST', '/auth/login', { phone: '5000000001', name: 'RL', otp: '9999' }); } catch (e) { if (/429/.test((e as Error).message)) saw = true; } }
  if (!saw) throw new Error('no 429');
});

const bad = summary('g6-notifs-policy'); await browser.close(); process.exit(bad ? 1 : 0);
