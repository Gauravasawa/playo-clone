import { BASE, api, apiUser, launch, signUp, step, summary, use, isoDay, sleep, stamp, accept, walletOf } from './glib.mts';
const browser = await launch();
const ctxA = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const ctxB = await browser.newContext({ viewport: { width: 1200, height: 900 } });
const A = await signUp(ctxA, `Ann ${stamp}`); const B = await signUp(ctxB, `Ben ${stamp}`); accept(A.page); accept(B.page); use(A.page, B.page);
const a = await apiUser(`Ann ${stamp}`, A.phone), b = await apiUser(`Ben ${stamp}`, B.phone);
const mk = (o = {}) => ({ title: 'Regress game', sport: 'football', venueId: 3, startsAt: isoDay(3) + 'T18:00', capacity: 4, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 0, ...o });

const g = await api(a.token, 'POST', '/games', mk()); await api(b.token, 'POST', `/games/${g.id}/join`, { method: 'wallet' });
await api(a.token, 'POST', `/games/${g.id}/end`, { winnerIds: [b.me.id], attendedIds: [a.me.id, b.me.id] });
const fr = await api(a.token, 'POST', '/friends/requests', { userId: b.me.id }); await api(b.token, 'POST', `/friends/requests/${fr.id}/accept`);
const dm = await api(a.token, 'POST', '/chats', { kind: 'direct', userId: b.me.id });

await step('payment declined (UPI) shows the bank message; Lab switch off lets it through', async () => {
  const p = A.page; await p.goto(BASE + '/lab'); await p.getByText('Decline UPI and card payments').click();
  await p.getByRole('link', { name: 'Venues' }).first().click(); await p.locator('article a').first().click(); await p.locator('button[data-testid^=slot-]:not([disabled])').first().waitFor();
  await p.locator('section button:has(.font-bold)').nth(2).click(); await sleep(600); await p.locator('button[data-testid^=slot-]:not([disabled])').first().click();
  await p.getByTestId('book-now').click(); await p.getByLabel('UPI (mock)').check(); await p.getByTestId('checkout-pay').click(); await p.getByText(/Payment declined/).first().waitFor({ timeout: 6000 });
  const n = (await api(a.token, 'GET', '/bookings')).length; if (n !== 0) throw new Error('booking created despite decline: ' + n);
  await p.keyboard.press('Escape');
});
await step('1:1 chat: typing indicator → reply → Seen receipt, live', async () => {
  await A.page.goto(BASE + `/chat/${dm.id}`); await B.page.goto(BASE + `/chat/${dm.id}`);
  await A.page.getByLabel('Message').pressSequentially('hel', { delay: 80 }); await B.page.getByTestId('typing').filter({ hasText: /typing/ }).waitFor({ timeout: 5000 });
  await A.page.getByLabel('Message').fill('hello Ben'); await A.page.keyboard.press('Enter'); await B.page.locator('main p', { hasText: 'hello Ben' }).first().waitFor({ timeout: 6000 });
  await B.page.getByLabel('Message').fill('hi Ann'); await B.page.keyboard.press('Enter'); await A.page.locator('main p', { hasText: 'hi Ann' }).first().waitFor({ timeout: 6000 });
  await B.page.getByTestId('receipt').filter({ hasText: /Seen/ }).first().waitFor({ timeout: 6000 }).catch(() => A.page.getByTestId('receipt').filter({ hasText: /Seen/ }).first().waitFor({ timeout: 6000 }));
});
await step('unread badge on the chat icon, cleared on opening', async () => {
  await B.page.goto(BASE + '/notifications'); await api(a.token, 'POST', `/chats/${dm.id}/messages`, { body: 'ping while away' });
  await B.page.getByTestId('chat-badge').waitFor({ timeout: 6000 }); await B.page.goto(BASE + `/chat/${dm.id}`); await B.page.locator('main p', { hasText: 'ping while away' }).first().waitFor();
  await B.page.getByTestId('chat-badge').waitFor({ state: 'detached', timeout: 6000 });
});
await step('presence: online dot over the WebSocket on the friends list', async () => {
  await B.page.goto(BASE + '/friends'); await B.page.getByTestId(`player-${a.me.username}`).waitFor(); await B.page.getByTestId(`player-${a.me.username}`).getByTestId(/online-/).waitFor({ timeout: 8000 });
});
await step('rate a player from a shared game (stars + text) and see it on their profile', async () => {
  await A.page.goto(BASE + `/p/${b.me.username}`); await A.page.getByLabel('Rate this player').waitFor();
  await A.page.getByLabel('4 stars').click(); await A.page.getByPlaceholder('A few words (optional)').fill('Great teammate'); await A.page.getByRole('button', { name: 'Submit rating' }).click();
  await A.page.getByText('Great teammate').first().waitFor({ timeout: 6000 });
});
await step('private profile of a friend shows Sports; stranger sees the lock', async () => {
  await api(b.token, 'PUT', '/me/profile', { name: b.me.name, username: b.me.username, bio: 'hi', city: 'Bengaluru', avatarEmoji: '🙂', avatarColor: '#00b259', isPrivate: true, sports: [{ sport: 'football', level: 'Advanced' }], plays: { days: [], times: [] } });
  await A.page.goto(BASE + `/p/${b.me.username}`); await A.page.getByText('Sports', { exact: true }).waitFor({ timeout: 6000 });
  const s = await apiUser('Stranger ' + stamp); const c = await browser.newContext(); const sp = await c.newPage(); sp.setDefaultTimeout(8000); await sp.goto(BASE + `/p/${b.me.username}`); await sp.getByTestId('restricted').waitFor(); await c.close();
});
await step('persist.migrate: a v1 saved state is upgraded through the chain (now version 4)', async () => {
  const p = A.page; await p.goto(BASE + '/lab'); await sleep(1500);
  await p.getByRole('button', { name: 'Save an old (v1) state' }).click(); await p.waitForLoadState('load'); await p.getByLabel('City', { exact: true }).waitFor(); await sleep(900);
  const saved = JSON.parse((await p.evaluate(() => localStorage.getItem('playo:state'))) ?? '{}');
  if (saved.$version !== 4) throw new Error('saved version ' + saved.$version);
  if (saved.state.city !== 'Pune' || saved.state.sport !== 'tennis' || !Array.isArray(saved.state.recentSearches) || saved.state.pushEnabled !== false || saved.state.pendingReferral !== '') throw new Error('values: ' + JSON.stringify(saved).slice(0, 300));
});

const bad = summary('g7-chat-regression'); await browser.close(); process.exit(bad ? 1 : 0);
