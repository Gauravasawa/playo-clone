import { chromium, type Page, type BrowserContext, type Browser } from 'playwright-core';
export const BASE = process.env.BASE ?? 'http://localhost:3000';
export const API = process.env.API ?? 'http://localhost:4000/api';
const EDGE = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
export const stamp = String(Date.now()).slice(-6);
let counter = 0;
export const phone = () => String(3000000000 + (Number(stamp) * 37 + ++counter * 7919) % 900000000);
export const inr = (s: string) => Number(s.replace(/[^0-9.]/g, '')) ;

export async function launch(): Promise<Browser> { return chromium.launch({ executablePath: EDGE, headless: true }); }

export const results: { name: string; ok: boolean; msg?: string }[] = [];
const watchers = new Map<Page, string[]>();
let current: Page[] = [];
export function use(...pages: Page[]) { current = pages; }
export async function step(name: string, fn: () => Promise<void>) {
  try { await fn(); results.push({ name, ok: true }); console.log(`PASS ${name}`); }
  catch (e) {
    const msg = (e as Error).message.split('\n').filter(Boolean).slice(0, 3).join(' | ');
    results.push({ name, ok: false, msg }); console.log(`FAIL ${name}: ${msg}`);
    let i = 0; for (const pg of current) await pg.screenshot({ path: `gfail-${results.length}-${i++}.png` }).catch(() => {});
  }
}
export function summary(label: string) {
  const bad = results.filter((r) => !r.ok);
  console.log(`\n${label}: ${results.length - bad.length}/${results.length} passed`);
  for (const [pg, errs] of watchers) { const u = [...new Set(errs)]; if (u.length) console.log(`  page ${pg.url().replace(BASE, '')} problems:\n   ` + u.slice(0, 12).join('\n   ')); }
  return bad.length;
}

export function watch(page: Page) {
  const errs: string[] = []; watchers.set(page, errs);
  page.on('console', (m) => {
    const t = m.text();
    if (['error', 'warning'].includes(m.type()) && !/Failed to load resource.*(503|402|409|403|400|401|429|404)/.test(t) && !/React DevTools|Download the React|Notification/.test(t)) errs.push(`[${m.type()}] ${t.slice(0, 200)}`);
  });
  page.on('pageerror', (e) => errs.push(`[pageerror] ${e.message.slice(0, 200)}`));
}

export async function signUp(ctx: BrowserContext, name: string, ph = phone(), ref?: string): Promise<{ page: Page; phone: string; name: string }> {
  const page = await ctx.newPage(); page.setDefaultTimeout(9000); watch(page);
  await page.goto(BASE + (ref ? `/?ref=${ref}` : ''));
  await page.waitForSelector('article');
  await page.getByRole('button', { name: 'Log in', exact: true }).first().click();
  await page.getByPlaceholder('Your name').fill(name);
  await page.getByPlaceholder('Phone (10 digits)').fill(ph);
  await page.getByPlaceholder('OTP').fill('1234');
  await page.locator('form button', { hasText: 'Log in' }).click();
  await page.getByTestId('wallet-chip').waitFor({ timeout: 10000 });
  return { page, phone: ph, name };
}

/* ---- API helpers for setup and assertions ---- */
export async function api<T = any>(token: string | null, method: string, path: string, body?: unknown): Promise<T> {
  const r = await fetch(API + path, { method, headers: { ...(body !== undefined && { 'content-type': 'application/json' }), ...(token && { authorization: `Bearer ${token}` }) }, body: body === undefined ? undefined : JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`${method} ${path} -> ${r.status} ${(j as any).error ?? ''}`);
  return j as T;
}
export async function apiUser(name: string, ph = phone(), referral?: string) {
  const { token } = await api<{ token: string }>(null, 'POST', '/auth/login', { phone: ph, name, otp: '1234', referral });
  const me = await api<any>(token, 'GET', '/me');
  return { token, me, phone: ph };
}
export const walletOf = async (token: string) => (await api<any>(token, 'GET', '/wallet')).balance as number;
export const tokenOf = (page: Page) => page.evaluate(() => { for (const k of Object.keys(localStorage)) { const v = localStorage.getItem(k) ?? ''; const m = v.match(/"token":"([^"]+)"/); if (m) return m[1]; } return null as string | null; });
export function isoDay(plus: number) { const d = new Date(Date.now() + plus * 864e5); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
export async function toast(page: Page, re: RegExp, timeout = 8000) { await page.getByText(re).first().waitFor({ timeout }); }
export async function accept(page: Page) { page.on('dialog', (d) => d.accept().catch(() => {})); }
