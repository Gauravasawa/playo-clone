// HTML audit: the small things that are easy to miss in markup, on every page, logged in and logged out.
//   icons/symbols without a name or tooltip · truncated text without its full text on hover · disabled buttons without a reason ·
//   badges and dots that carry information · images without alt · fields without labels · duplicate ids · missing title/lang/h1 ·
//   empty links · nested interactive elements · positive tabindex · aria-label that hides the visible text · heading jumps · th without scope
// Exit code 1 when anything is found.   Run: BASE=http://localhost:3000 API=http://localhost:4000/api node --experimental-strip-types html-audit.mts
import { chromium, type Page } from 'playwright-core';
import { api, apiUser, isoDay } from './glib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3000';
const only = process.env.ONLY ?? '';
const stamp = Date.now();
const user = await apiUser(`Html ${stamp}`, String(3100000000 + (stamp % 99999999)));
const tok = user.token;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// data so the pages have something on them: a game, a booking, a ticket, a friend via a shared game
const friend = await apiUser(`Html Friend ${stamp}`, String(3200000000 + (stamp % 99999999)));
const game = await api(tok, 'POST', '/games', { title: 'Audit game with a rather long title so that it has to be cut off somewhere', sport: 'football', venueId: 3, startsAt: `${isoDay(3)}T18:00`, capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 100 }).catch(() => null);
if (game) await api(friend.token, 'POST', `/games/${game.id}/join`, { method: 'wallet' }).catch(() => null);
for (let i = 0; i < 6; i++) {
  const ok = await api(tok, 'POST', '/bookings', { venueId: 3, date: isoDay(6 + Math.floor(Math.random() * 20)), slots: [`${String(6 + Math.floor(Math.random() * 16)).padStart(2, '0')}:00`], method: 'wallet' }).catch(() => null);
  if (ok) break;
}
await api(tok, 'POST', '/tickets', { topic: 'booking', subject: 'Audit ticket', body: 'Testing the markup audit' }).catch(() => null);
await api(tok, 'PUT', '/favorites', { favorites: [3, 4] }).catch(() => null);

const ROUTES = [
  '/', '/venues/3', '/games', game ? `/games/${game.id}` : '/games', '/events', '/events/1', '/coaches', '/coaches/1', '/tournaments', '/leaderboard',
  '/friends', '/chat', '/notifications', '/wallet', '/wallet?tab=karma', '/wallet?tab=gift', '/wallet?tab=passes', '/wallet?tab=referrals',
  '/bookings', '/learning', '/plus', '/profile', '/p/aarav_k', '/owner', '/help', '/help/tickets', '/blog', '/blog/badminton-footwork-basics', '/policy', '/lab', '/admin/reports',
].filter((r) => !only || r.includes(only));

type Finding = { kind: string; sel: string; text: string; detail?: string };

/** Runs in the page. Returns problems, plus the truncated elements (the outer script hovers them). */
function audit() {
  const out: Finding[] = [];
  const truncated: { sel: string; text: string; idx: number }[] = [];
  const GLYPH_ONLY = (t: string) => t.trim() !== '' && !/[\p{L}\p{N}]/u.test(t);
  const sel = (el: Element) => {
    const id = el.getAttribute('data-testid');
    const cls = (el.getAttribute('class') ?? '').split(/\s+/).filter(Boolean).slice(0, 3).join('.');
    return `${el.tagName.toLowerCase()}${id ? `[${id}]` : cls ? '.' + cls : ''}`;
  };
  const visibleText = (el: Element) => {
    const c = el.cloneNode(true) as Element;
    c.querySelectorAll('[aria-hidden="true"], script, style, .sr-only').forEach((n) => n.remove());
    return (c.textContent ?? '').replace(/\s+/g, ' ').trim();
  };
  const shown = (el: Element) => {
    const cs = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return cs.display !== 'none' && cs.visibility !== 'hidden' && r.width > 0 && r.height > 0 && !el.closest('[aria-hidden="true"]');
  };
  const labelledBy = (el: Element) => (el.getAttribute('aria-labelledby') ?? '').split(/\s+/).map((id) => document.getElementById(id)?.textContent?.trim() ?? '').join(' ').trim();
  const ariaName = (el: Element) => (el.getAttribute('aria-label') ?? '').trim() || labelledBy(el) || [...el.querySelectorAll('img[alt]')].map((i) => i.getAttribute('alt')).join(' ').trim() || [...el.querySelectorAll('[role=img][aria-label]')].map((i) => i.getAttribute('aria-label')).join(' ').trim();
  const hasTip = (el: Element) => !!(el.closest('[data-tip]') || el.getAttribute('title') || el.closest('[title]'));
  const INTERACTIVE = 'button, a[href], [role=button], [role=menuitemradio], [role=tab], summary, input[type=button], input[type=submit]';

  // 1. icon / symbol only controls
  for (const el of document.querySelectorAll(INTERACTIVE)) {
    if (!shown(el)) continue;
    const text = visibleText(el);
    if (text !== '' && !GLYPH_ONLY(text)) continue;
    const named = !!ariaName(el);
    const hasImg = !!el.querySelector('img[alt]:not([alt=""])');
    if (!named && !hasImg) out.push({ kind: 'icon-no-name', sel: sel(el), text: text || '(empty)' });
    else if (!hasTip(el) && !hasImg && !el.getAttribute('aria-label')) out.push({ kind: 'icon-no-tooltip', sel: sel(el), text: ariaName(el) || text });
  }

  // 2. badges (counts), dots and chips that carry information
  for (const el of document.querySelectorAll('span, div, i')) {
    if (!shown(el) || el.closest(INTERACTIVE + ', [role=dialog]') === null && false) continue;
    if (el.children.length > 0 && !GLYPH_ONLY(visibleText(el))) continue;
    const cs = getComputedStyle(el);
    const text = visibleText(el);
    const round = parseFloat(cs.borderTopLeftRadius) >= Math.min(el.clientWidth, el.clientHeight) / 2 - 1 || /rounded-full/.test(el.getAttribute('class') ?? '');
    const r = el.getBoundingClientRect();
    const filled = cs.backgroundColor !== 'rgba(0, 0, 0, 0)' && cs.backgroundColor !== 'transparent';
    const own = !!(el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('data-tip') || el.getAttribute('role') === 'img');
    const ancestorLabel = !!el.closest('[data-tip], [title], [aria-label]');
    // a dot with no text at all
    if (text === '' && round && filled && r.width <= 16 && r.height <= 16 && !el.querySelector('*')) {
      if (!own && !ancestorLabel) out.push({ kind: 'dot-no-text', sel: sel(el), text: '(dot)' });
      continue;
    }
    // a bare number on a round badge (unread, counts)
    if (round && /^\d+\+?$/.test(text) && !own) out.push({ kind: 'count-badge-no-label', sel: sel(el), text });
  }
  // glyph-only leaves that stand alone (an emoji meaning something, with no words beside it)
  for (const el of document.querySelectorAll('span, p, div, td, li')) {
    if (el.children.length || !shown(el)) continue;
    const text = visibleText(el);
    if (!text || !GLYPH_ONLY(text) || /^[\s·•|/–—-]+$/.test(text)) continue;
    if (!/\p{Extended_Pictographic}/u.test(text) && !/[★☆✓✔✕×♥❤🔒]/u.test(text)) continue;
    if (el.closest(INTERACTIVE)) continue; // buttons are checked above
    if (el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('data-tip') || el.closest('[data-tip],[title],[aria-label],[role=img]')) continue;
    const parentWords = (visibleText(el.parentElement as Element)).replace(text, '').trim();
    if (/[\p{L}\p{N}]/u.test(parentWords) && !/^(★|☆)+$/.test(text)) continue; // an emoji beside words is decoration
    out.push({ kind: 'glyph-no-text', sel: sel(el), text });
  }

  // 3. truncated text: the outer script hovers these
  let n = 0;
  for (const el of document.querySelectorAll('*')) {
    if (!(el instanceof HTMLElement) || !shown(el)) continue;
    if (el.scrollWidth <= el.clientWidth + 1 && el.scrollHeight <= el.clientHeight + 1) continue;
    const cs = getComputedStyle(el);
    const ellipsis = cs.textOverflow === 'ellipsis' && el.scrollWidth > el.clientWidth + 1;
    const clamp = (cs.getPropertyValue('-webkit-line-clamp') || '').trim() !== '' && cs.getPropertyValue('-webkit-line-clamp') !== 'none' && el.scrollHeight > el.clientHeight + 1;
    if (!ellipsis && !clamp) continue;
    const text = visibleText(el);
    if (!text) continue;
    el.setAttribute('data-audit-trunc', String(n));
    truncated.push({ sel: sel(el), text, idx: n++ });
  }

  // 4. disabled controls without a reason
  for (const el of document.querySelectorAll('button:disabled, input:disabled, select:disabled, textarea:disabled, [aria-disabled="true"]')) {
    if (!shown(el)) continue;
    if (el.getAttribute('title') || el.closest('[data-tip]') || el.getAttribute('data-tip') || el.getAttribute('aria-describedby')) continue;
    out.push({ kind: 'disabled-no-reason', sel: sel(el), text: visibleText(el) || el.getAttribute('aria-label') || '' });
  }

  // 5. images
  for (const el of document.querySelectorAll('img')) if (!el.hasAttribute('alt')) out.push({ kind: 'img-no-alt', sel: sel(el), text: (el.getAttribute('src') ?? '').slice(0, 60) });
  // 6. form fields without a label
  for (const el of document.querySelectorAll('input, select, textarea')) {
    const t = (el as HTMLInputElement).type;
    if (['hidden', 'submit', 'button', 'reset', 'image'].includes(t) || !shown(el)) continue;
    const id = el.getAttribute('id');
    const hasLabel = (id && document.querySelector(`label[for="${CSS.escape(id)}"]`)) || el.closest('label') || ariaName(el) || el.getAttribute('title');
    if (!hasLabel) out.push({ kind: 'field-no-label', sel: sel(el), text: el.getAttribute('placeholder') ?? '' });
  }
  // 7. duplicate ids
  const seen = new Map<string, number>();
  for (const el of document.querySelectorAll('[id]')) seen.set(el.id, (seen.get(el.id) ?? 0) + 1);
  for (const [id, c] of seen) if (c > 1) out.push({ kind: 'duplicate-id', sel: `#${id}`, text: `${c}×` });
  // 8. document
  if (!document.title.trim()) out.push({ kind: 'no-title', sel: 'head', text: '' });
  if (!document.documentElement.lang) out.push({ kind: 'no-lang', sel: 'html', text: '' });
  const h1 = [...document.querySelectorAll('h1')].filter(shown);
  if (h1.length !== 1) out.push({ kind: 'h1-count', sel: 'h1', text: `${h1.length} h1` });
  // 9. links and nesting
  for (const el of document.querySelectorAll('a')) {
    if (!shown(el)) continue;
    if (!el.hasAttribute('href')) out.push({ kind: 'link-no-href', sel: sel(el), text: visibleText(el) });
    else if (!visibleText(el) && !ariaName(el) && !el.getAttribute('title')) out.push({ kind: 'link-empty', sel: sel(el), text: el.getAttribute('href') ?? '' });
  }
  for (const el of document.querySelectorAll('a button, a a, button button, button a, a [role=button], button [role=button], a input, button input, a select, button select')) out.push({ kind: 'nested-interactive', sel: sel(el), text: visibleText(el).slice(0, 30) });
  for (const el of document.querySelectorAll('[tabindex]')) if (Number(el.getAttribute('tabindex')) > 0) out.push({ kind: 'tabindex-positive', sel: sel(el), text: el.getAttribute('tabindex') ?? '' });
  // 10. the visible text must be part of the accessible name (WCAG 2.5.3)
  for (const el of document.querySelectorAll('[aria-label]')) {
    if (!shown(el) || !el.matches(INTERACTIVE)) continue;
    const vis = visibleText(el).toLowerCase();
    const label = (el.getAttribute('aria-label') ?? '').toLowerCase();
    if (/[\p{L}\p{N}]/u.test(vis) && !label.includes(vis.replace(/[^\p{L}\p{N}\s]/gu, '').trim().slice(0, 40))) out.push({ kind: 'label-not-in-name', sel: sel(el), text: `"${vis.slice(0, 30)}" vs aria-label "${label.slice(0, 30)}"` });
  }
  // 11. heading order
  let last = 0;
  for (const el of document.querySelectorAll('h1, h2, h3, h4, h5, h6')) {
    if (!shown(el)) continue;
    const lvl = Number(el.tagName[1]);
    if (last && lvl > last + 1) out.push({ kind: 'heading-skip', sel: sel(el), text: `h${last} → h${lvl}: ${visibleText(el).slice(0, 30)}` });
    last = lvl;
  }
  // 12. table headers
  for (const el of document.querySelectorAll('th')) if (!el.getAttribute('scope') && shown(el)) out.push({ kind: 'th-no-scope', sel: sel(el), text: visibleText(el) });

  return { out, truncated };
}

const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const all: (Finding & { route: string; who: string })[] = [];
let tipsChecked = 0;

async function tooltipText(page: Page) {
  return page.evaluate(() => document.querySelector('[role=tooltip]')?.textContent?.trim() ?? null);
}

for (const who of ['logged in', 'logged out'] as const) {
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, colorScheme: 'light' });
  await ctx.addInitScript(([token, on]) => { localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: 'light', token: on ? token : null, city: 'Bengaluru', favorites: on ? [3, 4] : [] } })); }, [tok, who === 'logged in'] as const);
  const page = await ctx.newPage();
  for (const route of ROUTES) {
    try {
      await page.goto(BASE + route, { waitUntil: 'load' });
      await sleep(1700);
      const { out, truncated } = await page.evaluate(audit);
      for (const f of out) all.push({ ...f, route, who });
      // hover a few truncated elements: the full text has to show up
      for (const t of truncated.slice(0, 4)) {
        const h = page.locator(`[data-audit-trunc="${t.idx}"]`).first();
        await h.scrollIntoViewIfNeeded().catch(() => {});
        await h.hover({ timeout: 3000, force: true }).catch(() => {});
        await sleep(550);
        const shownText = await tooltipText(page);
        tipsChecked++;
        const want = t.text.replace(/\s+/g, ' ');
        if (!shownText || !(shownText.includes(want.slice(0, 20)))) all.push({ kind: 'truncated-no-tooltip', sel: t.sel, text: want.slice(0, 50), detail: `tooltip: ${shownText ?? 'none'}`, route, who });
        await page.mouse.move(2, 2); await sleep(80);
      }
    } catch (e) { console.log('skip', route, (e as Error).message.slice(0, 80)); }
  }
  await ctx.close();
}

// ---- dialogs and menus: opened one by one, then the same checks ----
const theirs = await api(friend.token, 'POST', '/games', { title: 'Priced game to join', sport: 'football', venueId: 3, startsAt: `${isoDay(4)}T19:00`, capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 150 }).catch(() => null);
const evs = await api(null, 'GET', '/events?city=Bengaluru&type=all&q=').catch(() => []);
const marathon = (Array.isArray(evs) ? evs : evs.items ?? []).find((e: { type: string }) => e.type === 'marathon');
const click = (p: Page, sel: string) => p.locator(sel).first().click({ timeout: 8000 });
const openers: { name: string; path: string; open: (p: Page) => Promise<void>; out?: boolean }[] = [
  { name: 'checkout', path: '/venues/3', open: async (p) => { await click(p, 'button[data-testid^=slot-]:not([disabled])'); await click(p, '[data-testid=book-now]'); } },
  { name: 'day pass', path: '/venues/3', open: async (p) => { await click(p, '[data-testid=buy-pass-daily]'); } },
  { name: 'cancel booking', path: '/bookings', open: async (p) => { await click(p, '[data-testid=cancel-booking]'); } },
  { name: 'reschedule booking', path: '/bookings', open: async (p) => { await click(p, '[data-testid=reschedule]'); } },
  { name: 'join priced game', path: '/games', open: async (p) => { await p.getByText('Priced game to join').first().waitFor(); await click(p, `[data-testid=join-${theirs?.id}]`); } },
  { name: 'invite', path: `/games/${game?.id}`, open: async (p) => { await click(p, '[data-testid=invite-open]'); } },
  { name: 'end game', path: `/games/${game?.id}`, open: async (p) => { await click(p, '[data-testid=end-open]'); } },
  { name: 'report player', path: '/p/aarav_k', open: async (p) => { await click(p, '[data-testid^=report-player]'); } },
  { name: 'coach session', path: '/coaches/1', open: async (p) => { await click(p, '[data-testid=book-session]'); } },
  { name: 'coach enrol', path: '/coaches/1', open: async (p) => { await click(p, '[data-testid^=enrol-]'); } },
  { name: 'coach enquiry', path: '/coaches/1', open: async (p) => { await click(p, '[data-testid=open-enquiry]'); } },
  { name: 'host meet-up', path: '/events', open: async (p) => { await click(p, '[data-testid=host-meetup]'); } },
  { name: 'marathon registration', path: marathon ? `/events/${marathon.id}` : '/events/1', open: async (p) => { await click(p, '[data-testid=event-register]'); } },
  { name: 'support ticket', path: '/help/tickets', open: async (p) => { await click(p, '[data-testid=new-ticket]'); } },
  { name: 'new chat', path: '/chat', open: async (p) => { await p.getByRole('button', { name: /new/i }).first().click({ timeout: 8000 }); } },
  { name: 'host a game form', path: '/games', open: async (p) => { await click(p, '[data-testid=host-toggle]'); } },
  { name: 'user menu', path: '/', open: async (p) => { await click(p, '[data-testid=user-menu]'); } },
  { name: 'theme menu', path: '/', open: async (p) => { await click(p, '[data-testid=theme-menu-button]'); } },
  { name: 'more menu', path: '/', open: async (p) => { await click(p, '[data-testid=more-menu]'); } },
  { name: 'login', path: '/', out: true, open: async (p) => { await p.getByRole('button', { name: 'Log in', exact: true }).first().click(); } },
];
for (const o of openers.filter((x) => !only || x.name.includes(only))) {
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, colorScheme: 'light' });
  await ctx.addInitScript(([token, on]) => { localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: 'light', token: on ? token : null, city: 'Bengaluru' } })); }, [tok, !o.out] as const);
  const page = await ctx.newPage();
  try {
    await page.goto(BASE + o.path); await sleep(1700);
    await o.open(page); await sleep(900);
    const { out } = await page.evaluate(audit);
    for (const f of out) all.push({ ...f, route: 'dialog: ' + o.name, who: o.out ? 'logged out' : 'logged in' });
  } catch (e) { all.push({ kind: 'could-not-open', sel: o.name, text: (e as Error).message.split('\n')[0].slice(0, 80), route: 'dialog: ' + o.name, who: 'n/a' }); }
  await ctx.close();
}
await browser.close();

const by = new Map<string, typeof all>();
for (const f of all) by.set(f.kind, [...(by.get(f.kind) ?? []), f]);
console.log(`Audited ${ROUTES.length} routes × 2 (logged in / out); hovered ${tipsChecked} truncated elements.\n`);
for (const [kind, list] of [...by].sort((a, b) => b[1].length - a[1].length)) {
  const uniq = new Map<string, (typeof all)[number] & { where: Set<string> }>();
  for (const f of list) { const k = `${f.sel}|${f.text}`; const u = uniq.get(k) ?? { ...f, where: new Set<string>() }; u.where.add(`${f.route} [${f.who}]`); uniq.set(k, u); }
  console.log(`${kind}: ${list.length} (${uniq.size} distinct)`);
  for (const f of [...uniq.values()].slice(0, Number(process.env.TOP ?? 6))) console.log(`    ${[...f.where].slice(0, 4).join(', ')}${f.where.size > 4 ? ` +${f.where.size - 4} more` : ''}: ${f.sel}  "${f.text}"${f.detail ? '  ' + f.detail : ''}`);
}
console.log(`\n${all.length === 0 ? 'CLEAN: no findings' : `${all.length} finding(s) in ${by.size} group(s)`}`);
process.exit(all.length ? 1 : 0);
