// Phone / tablet audit: overflow, clipped content, tap targets, header, contrast, and the open modals/menus, in both themes.
import { chromium, type Page } from 'playwright-core';
import { api, apiUser, isoDay, sleep } from './glib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3208';
const only = process.env.ONLY ?? '';
const VIEWPORTS = (process.env.VIEWPORTS ?? '390x800,360x740,768x1024').split(',').map((v) => v.split('x').map(Number) as [number, number]);
const THEMES = (process.env.THEMES ?? 'light,dark').split(',') as ('light' | 'dark')[];
const stamp = Date.now();

// ---------- data ----------
const me = await apiUser(`Mob ${stamp}`, String(3100000000 + (stamp % 99999999)));
const mate = await apiUser(`Mate ${stamp}`, String(3200000000 + (stamp % 99999999)));
const tok = me.token;
const game = await api(tok, 'POST', '/games', { title: 'Audit five-a-side with a fairly long title to test wrapping', sport: 'football', venueId: 3, startsAt: `${isoDay(3)}T18:00`, capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'private', minLevel: null, priceInr: 100 }).catch(() => null);
if (game) await api(mate.token, 'POST', `/games/${game.id}/join`, { method: 'wallet', code: game.inviteCode }).catch(() => null);
await api(tok, 'POST', '/bookings', { venueId: 3, date: isoDay(2), slots: ['18:00', '19:00'], method: 'wallet' }).catch(() => null);
await api(tok, 'POST', '/tickets', { topic: 'booking', subject: 'A rather long subject line to see how it wraps on a phone', message: 'Testing the layout', bookingId: null }).catch(() => null);
const claimable = await api(tok, 'GET', '/owner/claimable?city=Bengaluru').catch(() => []);
const claimed = Array.isArray(claimable) && claimable[0] ? await api(tok, 'POST', `/owner/venues/${claimable[0].id}/claim`, {}).catch(() => null) : null;
const ownerVenue = claimed?.id ?? claimable?.[0]?.id ?? 1;
const adminTok = (await apiUser('Admin', '9000000000')).token;

const ROUTES: { path: string; auth: boolean }[] = [
  '/', '/venues/3', '/games', game ? `/games/${game.id}` : '/games', game?.inviteCode ? `/g/${game.inviteCode}` : '/games', '/events', '/events/1', '/coaches', '/coaches/1', '/tournaments', '/leaderboard',
  '/friends', '/chat', '/notifications', '/wallet', '/wallet?tab=karma', '/wallet?tab=gift', '/wallet?tab=passes', '/wallet?tab=referrals', '/bookings', '/learning', '/plus',
  '/profile', '/p/aarav_k', '/owner', `/owner/${ownerVenue}`, '/help', '/help/tickets', '/blog', '/blog/badminton-footwork-basics', '/policy', '/lab', '/admin/reports',
].filter((r) => !only || r.includes(only)).flatMap((path) => [{ path, auth: true }, { path, auth: false }]).filter((r) => r.auth || ['/', '/venues/3', '/games', '/events', '/coaches', '/help', '/blog', '/policy', '/p/aarav_k', '/tournaments', '/leaderboard'].includes(r.path) || r.path.startsWith('/g/'));

// ---------- in-page audit ----------
function inPage() {
  const out: { kind: string; detail: string }[] = [];
  const vw = innerWidth;
  const root = document.scrollingElement as HTMLElement;
  if (root.scrollWidth > vw + 1) {
    // find the widest offenders
    const off: string[] = [];
    for (const el of document.querySelectorAll<HTMLElement>('body *')) {
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      if (r.right > vw + 1 && !el.closest('[data-allow-scroll],nav,.overflow-x-auto,.leaflet-container,.hero-scene,[data-testid=hero-scene]')) off.push(`${el.tagName.toLowerCase()}.${(el.getAttribute('class') ?? '').split(' ').slice(0, 4).join('.')} right=${Math.round(r.right)}`);
    }
    out.push({ kind: 'overflow', detail: `scrollWidth ${root.scrollWidth} > ${vw}: ${off.slice(0, 4).join(' | ') || '(only inside scrollers)'}` });
  }
  // clipped: visible elements with text that extend beyond the viewport horizontally and are not in a scroller
  const seenClip = new Set<string>();
  for (const el of document.querySelectorAll<HTMLElement>('button,a,input,select,textarea,h1,h2,h3,p,span,label,td,th,li')) {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') continue;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    if (el.closest('.overflow-x-auto,.leaflet-container,[data-testid=hero-scene],.hero-scene,[aria-hidden=true]')) continue;
    const clippedByParent = (() => { for (let a: HTMLElement | null = el.parentElement; a; a = a.parentElement) { const o = getComputedStyle(a).overflowX; if (o === 'hidden' || o === 'clip' || o === 'auto' || o === 'scroll') { const ar = a.getBoundingClientRect(); return ar.right <= vw + 1 && ar.left >= -1; } } return false; })();
    if (!clippedByParent && (r.left < -1 || r.right > vw + 1) && (el.textContent ?? '').trim()) {
      const key = el.tagName + (el.textContent ?? '').trim().slice(0, 20);
      if (!seenClip.has(key)) { seenClip.add(key); out.push({ kind: 'clipped', detail: `<${el.tagName.toLowerCase()}> "${(el.textContent ?? '').trim().slice(0, 30)}" spans ${Math.round(r.left)}..${Math.round(r.right)} of ${vw}` }); }
    }
    // text cut off by its own box (ellipsis / overflow hidden) without being intended
    if (cs.overflow === 'hidden' && el.scrollWidth > el.clientWidth + 2 && cs.textOverflow !== 'ellipsis' && (el.textContent ?? '').trim() && el.children.length === 0 && !['SELECT', 'INPUT'].includes(el.tagName)) {
      out.push({ kind: 'cut-off', detail: `<${el.tagName.toLowerCase()}> "${(el.textContent ?? '').trim().slice(0, 30)}" scrollWidth ${el.scrollWidth} > ${el.clientWidth}` });
    }
  }
  // tap targets
  const seenTap = new Set<string>();
  for (const el of document.querySelectorAll<HTMLElement>('button,a[href],input:not([type=hidden]),select,textarea,[role=tab],[role=menuitemradio],summary')) {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || (el as HTMLButtonElement).disabled) continue;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    // inline links inside a sentence are exempt (WCAG 2.5.8 inline exception); skip links whose parent is a paragraph with other text
    if (el.tagName === 'A' && getComputedStyle(el).display === 'inline' && ((el.parentElement?.textContent ?? '').trim().length > (el.textContent ?? '').trim().length + 3)) continue; // a link inside a sentence is exempt (WCAG 2.5.8)
    if (el.closest('.leaflet-container,[aria-hidden=true]')) continue;
    if (el.tagName === 'INPUT' && ['checkbox', 'radio'].includes((el as HTMLInputElement).type)) {
      const lab = el.closest('label'); if (lab) { const lr = lab.getBoundingClientRect(); if (lr.width >= 24 && lr.height >= 24) continue; }
    }
    const small = Math.min(r.width, r.height);
    if (small < 28) {
      const key = el.tagName + (el.getAttribute('aria-label') ?? el.textContent ?? '').trim().slice(0, 14) + Math.round(r.width) + 'x' + Math.round(r.height);
      if (seenTap.has(key)) continue; seenTap.add(key);
      out.push({ kind: small < 24 ? 'tap<24' : 'tap<28', detail: `<${el.tagName.toLowerCase()}> "${(el.getAttribute('aria-label') ?? el.textContent ?? '').trim().slice(0, 24)}" ${Math.round(r.width)}x${Math.round(r.height)}` });
    }
  }
  // contrast
  const cv = document.createElement('canvas').getContext('2d', { willReadFrequently: true })!;
  const rgba = (c: string): [number, number, number, number] => {
    const px = (bg: string) => { cv.clearRect(0, 0, 1, 1); cv.fillStyle = bg; cv.fillRect(0, 0, 1, 1); cv.fillStyle = '#000'; cv.fillStyle = c; cv.fillRect(0, 0, 1, 1); return cv.getImageData(0, 0, 1, 1).data; };
    const w = px('#fff'), k = px('#000');
    const a = Math.max(0, Math.min(1, 1 - (w[0] - k[0]) / 255));
    return a < 0.004 ? [0, 0, 0, 0] : [Math.round(Math.min(255, k[0] / a)), Math.round(Math.min(255, k[1] / a)), Math.round(Math.min(255, k[2] / a)), a];
  };
  const over = (t: number[], u: number[]) => [0, 1, 2].map((i) => t[i] * t[3] + u[i] * (1 - t[3]));
  const lum = (c: number[]) => { const f = (v: number) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
  const ratio = (a: number[], b: number[]) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  const backdrop = (el: Element) => {
    const stack: Element[] = [];
    for (let e: Element | null = el; e; e = e.parentElement) stack.push(e);
    let cols: number[][] = [[255, 255, 255]]; let image = false;
    for (const e of stack.reverse()) {
      const cs = getComputedStyle(e); const base = rgba(cs.backgroundColor);
      if (base[3] > 0) cols = cols.map((u) => over(base, u));
      const bi = cs.backgroundImage;
      if (bi && bi !== 'none') {
        if (/gradient/.test(bi)) { const stops = [...bi.matchAll(/(rgba?\([^)]*\)|oklab\([^)]*\)|oklch\([^)]*\)|lab\([^)]*\)|lch\([^)]*\)|color\([^)]*\)|#[0-9a-f]{3,8})/gi)].map((m) => rgba(m[1])).filter((s) => s[3] > 0.05); if (stops.length) cols = stops.flatMap((s) => cols.map((u) => over(s, u))); }
        else if (/url\(/.test(bi)) image = true;
      }
    }
    return { cols, image };
  };
  const seenC = new Set<Element>();
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const text = (n.textContent ?? '').trim(); const el = n.parentElement;
    if (!text || !el || seenC.has(el) || ['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(el.tagName)) continue;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none') continue;
    const r = el.getBoundingClientRect(); if (r.width === 0 || r.height === 0) continue;
    seenC.add(el);
    if ((el.closest('button,input,select,textarea') as HTMLButtonElement | null)?.disabled) continue;
    const hasWord = /[\p{L}\p{N}]/u.test(text);
    if (!hasWord && /\p{Extended_Pictographic}/u.test(text)) continue;
    let opacity = 1; for (let e: Element | null = el; e; e = e.parentElement) opacity *= parseFloat(getComputedStyle(e).opacity);
    const fg = rgba(cs.color); const { cols, image } = backdrop(el); if (image) continue;
    const size = parseFloat(cs.fontSize); const bold = parseInt(cs.fontWeight) >= 700;
    const need = size >= 24 || (size >= 18.66 && bold) || !hasWord ? 3 : 4.5;
    let worst = 99;
    for (const bg of cols) worst = Math.min(worst, ratio(over([fg[0], fg[1], fg[2], fg[3] * opacity], bg), bg));
    if (worst < need) out.push({ kind: 'contrast', detail: `${worst.toFixed(2)}<${need} "${text.slice(0, 28)}" .${(el.getAttribute('class') ?? '').slice(0, 60)}` });
  }
  return out;
}

const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
type Row = { page: string; vp: string; theme: string; kind: string; detail: string };
const rows: Row[] = [];
let pagesChecked = 0;

for (const theme of THEMES) {
  for (const [w, h] of VIEWPORTS) {
    for (const auth of [true, false]) {
      const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: theme, hasTouch: true, deviceScaleFactor: 1 });
      await ctx.addInitScript(([t, token]) => { localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, token, city: 'Bengaluru' } })); }, [theme, auth ? tok : null] as const);
      const page = await ctx.newPage();
      for (const r of ROUTES.filter((x) => x.auth === auth)) {
        try {
          const path = r.path === '/admin/reports' && auth ? r.path : r.path;
          await page.goto(BASE + path, { waitUntil: 'load' });
          await sleep(1500);
          const found = await page.evaluate(inPage);
          pagesChecked++;
          for (const f of found) rows.push({ page: r.path + (auth ? '' : ' (out)'), vp: `${w}x${h}`, theme, ...f });
          if (found.some((f) => ['overflow', 'clipped', 'cut-off'].includes(f.kind)) && process.env.SHOTS === '1') await page.screenshot({ path: `shots/mob-${theme}-${w}-${r.path.replace(/\W+/g, '_')}${auth ? '' : '-out'}.png`, fullPage: true });
        } catch (e) { rows.push({ page: r.path, vp: `${w}x${h}`, theme, kind: 'error', detail: (e as Error).message.slice(0, 100) }); }
      }
      await ctx.close();
    }
  }
}
await browser.close();

// group
const groups = new Map<string, { n: number; r: Row; pages: Set<string>; vps: Set<string> }>();
for (const r of rows) {
  const key = `${r.kind}|${r.detail.replace(/\d+x\d+|\d+\.\.\d+ of \d+|right=\d+|scrollWidth \d+ > \d+/g, '#')}`;
  const g = groups.get(key) ?? { n: 0, r, pages: new Set(), vps: new Set() };
  g.n++; g.pages.add(r.page); g.vps.add(`${r.vp}/${r.theme}`); groups.set(key, g);
}
console.log(`pages×viewports×themes checked: ${pagesChecked}; findings: ${rows.length} in ${groups.size} distinct groups`);
const order = ['error', 'overflow', 'clipped', 'cut-off', 'tap<24', 'contrast', 'tap<28'];
for (const kind of order) {
  const gs = [...groups.values()].filter((g) => g.r.kind === kind).sort((a, b) => b.n - a.n);
  if (!gs.length) continue;
  console.log(`\n=== ${kind} (${gs.length} groups) ===`);
  for (const g of gs.slice(0, Number(process.env.TOP ?? 25))) console.log(`×${g.n} ${g.r.detail}  [${[...g.pages].slice(0, 4).join(' ')} ${[...g.vps].slice(0, 3).join(' ')}]`);
}
