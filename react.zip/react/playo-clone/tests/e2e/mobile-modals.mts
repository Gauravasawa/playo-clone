// Menus and modals at phone width, both themes: nothing off-screen, everything reachable, no overlap with the viewport edges.
import { chromium, type Page } from 'playwright-core';
import { apiUser, isoDay, api, sleep } from './glib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3208';
const stamp = Date.now();
const me = await apiUser(`Modal ${stamp}`, String(3300000000 + (stamp % 99999999)));
const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const issues: string[] = [];
const notes: string[] = [];

async function inView(p: Page, sel: string, label: string, vp: string) {
  const box = await p.locator(sel).first().boundingBox();
  if (!box) { issues.push(`${vp} ${label}: not found (${sel})`); return null; }
  const w = p.viewportSize()!.width, h = p.viewportSize()!.height;
  if (box.x < -1 || box.x + box.width > w + 1) issues.push(`${vp} ${label}: horizontally outside the screen (${Math.round(box.x)}..${Math.round(box.x + box.width)} of ${w})`);
  if (box.y < -1) issues.push(`${vp} ${label}: above the screen`);
  return { box, w, h };
}
const overflowX = (p: Page) => p.evaluate(() => (document.scrollingElement as HTMLElement).scrollWidth - innerWidth);

for (const theme of ['light', 'dark'] as const) {
  for (const [w, h] of [[390, 800], [360, 740], [768, 1024]] as const) {
    const vp = `${w}x${h}/${theme}`;
    for (const auth of [false, true]) {
      const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: theme, hasTouch: true });
      await ctx.addInitScript(([t, token]) => localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, token, city: 'Bengaluru' } })), [theme, auth ? me.token : null] as const);
      const p = await ctx.newPage();
      await p.goto(BASE + '/'); await p.waitForSelector('article'); await sleep(1200);
      const tag = auth ? 'in' : 'out';

      // the scrolling nav on phones holds every link; More is for md+ only
      const moreVisible = await p.getByTestId('more-menu').isVisible();
      const navLinks = await p.locator('header nav a').allInnerTexts();
      if (w < 768) {
        if (moreVisible) issues.push(`${vp}: the More button should be hidden on phones`);
        for (const label of ['Tournaments', 'Leaderboard']) if (!navLinks.includes(label)) issues.push(`${vp}: ${label} missing from the phone nav`);
        // and it can be scrolled to and tapped
        const link = p.locator('header nav a', { hasText: 'Leaderboard' });
        await link.scrollIntoViewIfNeeded();
        await link.click();
        await p.waitForURL('**/leaderboard'); await sleep(500);
        notes.push(`${vp}/${tag}: Leaderboard reachable from the scrolling nav`);
        await p.goto(BASE + '/'); await p.waitForSelector('article'); await sleep(800);
      } else {
        if (!moreVisible) issues.push(`${vp}: the More button should be visible on tablet`);
        await p.getByTestId('more-menu').click();
        for (const label of ['Tournaments', 'Leaderboard']) if (!(await p.locator('details[open] a', { hasText: label }).isVisible())) issues.push(`${vp}: ${label} not in the More menu`);
        await inView(p, 'details[open] > div', 'More menu', vp);
        await p.mouse.click(5, h - 5);
      }

      // header: nothing overlaps (right group vs nav), everything inside the screen
      const hdr = await p.evaluate(() => {
        const items = [...document.querySelectorAll<HTMLElement>('header a, header button, header select, header summary')].filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && !e.closest('nav') && !(e.closest('details:not([open])') && e.tagName !== 'SUMMARY'); });
        const rects = items.map((e) => ({ t: (e.getAttribute('aria-label') ?? e.textContent ?? e.tagName).trim().slice(0, 18), r: e.getBoundingClientRect() }));
        const overlaps: string[] = [];
        for (let i = 0; i < rects.length; i++) for (let j = i + 1; j < rects.length; j++) {
          const a = rects[i].r, b = rects[j].r;
          if (a.left < b.right - 2 && b.left < a.right - 2 && a.top < b.bottom - 2 && b.top < a.bottom - 2 && !rects[i].t.includes(rects[j].t) && !rects[j].t.includes(rects[i].t)) overlaps.push(`${rects[i].t} / ${rects[j].t}`);
        }
        const outside = rects.filter((x) => x.r.right > innerWidth + 1 || x.r.left < -1).map((x) => `${x.t} ${Math.round(x.r.left)}..${Math.round(x.r.right)}`);
        return { overlaps, outside, height: document.querySelector('header')!.getBoundingClientRect().height };
      });
      if (hdr.overlaps.length) issues.push(`${vp}/${tag} header overlap: ${hdr.overlaps.join(', ')}`);
      if (hdr.outside.length) issues.push(`${vp}/${tag} header outside screen: ${hdr.outside.join(', ')}`);
      notes.push(`${vp}/${tag}: header ${Math.round(hdr.height)}px tall`);

      // theme menu
      await p.getByTestId('theme-menu-button').click();
      await inView(p, '[data-testid=theme-menu]', 'theme menu', vp + '/' + tag);
      const items = await p.locator('[data-testid=theme-menu] button').count();
      if (items !== 3) issues.push(`${vp}/${tag}: theme menu has ${items} items`);
      await p.screenshot({ path: `shots/mobile-${theme}-${w}-theme-menu-${tag}.png`, clip: { x: 0, y: 0, width: w, height: 320 } });
      await p.keyboard.press('Escape');

      if (!auth) {
        // login modal
        await p.getByRole('button', { name: 'Log in', exact: true }).first().click();
        await p.getByRole('dialog', { name: 'Log in' }).waitFor();
        const m = await inView(p, '[role=dialog]', 'login modal', vp);
        if (m && m.box.height > m.h) issues.push(`${vp} login modal taller than the screen (${Math.round(m.box.height)} > ${m.h})`);
        // typing in a field with the keyboard open must keep the fields reachable: focus the OTP input and check it is in view
        await p.getByPlaceholder('OTP').focus(); await sleep(200);
        const ob = await p.getByPlaceholder('OTP').boundingBox();
        if (!ob || ob.y + ob.height > h) issues.push(`${vp} OTP field off screen`);
        for (const sel of ['input[placeholder="Your name"]', 'input[placeholder="Phone (10 digits)"]', 'input[placeholder="OTP"]', 'button:has-text("Cancel")']) {
          const b = await p.locator(sel).first().boundingBox(); if (b && (b.height < 32)) issues.push(`${vp} login: ${sel} is ${Math.round(b.height)}px tall`);
        }
        const fs = await p.getByPlaceholder('Phone (10 digits)').evaluate((e) => parseFloat(getComputedStyle(e).fontSize));
        if (fs < 16 && w < 700) issues.push(`${vp} login phone input font ${fs}px: iOS zooms the page when focusing an input under 16px`);
        await p.screenshot({ path: `shots/mobile-${theme}-${w}-login.png` });
        if ((await overflowX(p)) > 1) issues.push(`${vp} login: page scrolls sideways`);
        await p.getByRole('button', { name: 'Cancel' }).click();
      } else {
        // user menu
        await p.getByTestId('user-menu').click();
        await inView(p, 'details[open] > div', 'user menu', vp);
        const um = await p.locator('details[open] > div').first().boundingBox();
        if (um && um.height > h - 70) {
          const scrollable = await p.locator('details[open] > div').first().evaluate((e) => getComputedStyle(e).overflowY);
          if (!/auto|scroll/.test(scrollable)) issues.push(`${vp} user menu is ${Math.round(um.height)}px tall on a ${h}px screen and does not scroll`);
        }
        await p.screenshot({ path: `shots/mobile-${theme}-${w}-user-menu.png` });
        await p.mouse.click(5, h - 5);

        // checkout modal: pick a slot on the venue page, Book now
        await p.goto(BASE + '/venues/3'); await p.getByTestId('venue-passes').waitFor().catch(() => {}); await sleep(1200);
        const day = p.locator(`[data-testid^=day-], button:has-text("Tomorrow")`).first();
        const slot = p.locator('button[data-testid^=slot-]:not([disabled])').first();
        await slot.scrollIntoViewIfNeeded().catch(() => {});
        if (await slot.count()) {
          await slot.click();
          await p.getByTestId('book-now').scrollIntoViewIfNeeded();
          await p.getByTestId('book-now').click();
          await p.getByRole('dialog').waitFor();
          const cm = await inView(p, '[role=dialog]', 'checkout modal', vp);
          if (cm && cm.box.height > cm.h + 1) {
            const scrolls = await p.locator('[role=dialog]').first().evaluate((e) => /auto|scroll/.test(getComputedStyle(e).overflowY));
            if (!scrolls) issues.push(`${vp} checkout modal taller than the screen (${Math.round(cm.box.height)} > ${cm.h}) and not scrollable`);
          }
          if ((await overflowX(p)) > 1) issues.push(`${vp} checkout: page scrolls sideways`);
          // the pay button reachable: scroll the dialog to the bottom and check it is on screen
          await p.getByTestId('checkout-pay').scrollIntoViewIfNeeded();
          const pb = await p.getByTestId('checkout-pay').boundingBox();
          if (!pb || pb.y + pb.height > h + 1 || pb.height < 32) issues.push(`${vp} checkout pay button not comfortably reachable: ${JSON.stringify(pb)}`);
          await p.screenshot({ path: `shots/mobile-${theme}-${w}-checkout.png` });
        } else issues.push(`${vp} could not pick a slot for the checkout check`);
      }
      await ctx.close();
    }
  }
}
await browser.close();
console.log(`${notes.length} notes`);
notes.slice(0, 6).forEach((n) => console.log('  ', n));
console.log(`\n${issues.length} issue(s)`);
issues.forEach((i) => console.log('ISSUE', i));
