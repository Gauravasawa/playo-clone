// Opens every modal / dialog in the app in both themes and checks: text contrast, form field edges, scrim, Escape, focus handling, screenshot.
import { chromium, type Page } from 'playwright-core';
import { api, apiUser, isoDay } from './glib.mts';
import { auditIn, type Finding } from './audit-lib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3100';
const only = process.env.ONLY ?? '';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const stamp = Date.now();
const rnd = () => String(2800000000 + Math.floor(Math.random() * 99999999));

// ---- data: a main user with a booking and games, a second user with a priced game ----
const me = await apiUser(`Modal Me ${stamp}`, rnd());
const other = await apiUser(`Modal Other ${stamp}`, rnd());
await api(me.token, 'POST', '/wallet/topup', { amount: 2000, method: 'upi' }).catch(() => null);
let bookingRes = null;
for (let i = 0; i < 6 && !bookingRes; i++) bookingRes = await api(me.token, 'POST', '/bookings', { venueId: 3, date: isoDay(6 + Math.floor(Math.random() * 20)), slots: [`${String(6 + Math.floor(Math.random() * 16)).padStart(2, '0')}:00`], method: 'wallet' }).catch((e) => { console.log('booking attempt failed:', e.message); return null; });
console.log('booking', bookingRes ? 'ok' : 'FAILED');
const mine = await api(me.token, 'POST', '/games', { title: 'My modal game', sport: 'football', venueId: 3, startsAt: `${isoDay(4)}T18:00`, capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 0 }).catch(() => null);
const theirs = await api(other.token, 'POST', '/games', { title: 'Priced game to join', sport: 'football', venueId: 3, startsAt: `${isoDay(4)}T19:00`, capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 150 }).catch(() => null);
const events = await api(null, 'GET', '/events?city=Bengaluru&type=all&q=').catch(() => []);
const marathon = (Array.isArray(events) ? events : events.items ?? []).find((e: { type: string }) => e.type === 'marathon');

type Opener = { name: string; path: string; open: (p: Page) => Promise<void>; dialog?: string };
const click = (p: Page, sel: string, opts: { timeout?: number } = {}) => p.locator(sel).first().click({ timeout: opts.timeout ?? 8000 });
const openers: Opener[] = [
  { name: 'checkout', path: '/venues/3', open: async (p) => { await click(p, 'button[data-testid^=slot-]:not([disabled])'); await click(p, '[data-testid=book-now]'); } },
  { name: 'buy day pass', path: '/venues/3', open: async (p) => { await click(p, '[data-testid=buy-pass-daily]'); } },
  { name: 'cancel booking', path: '/bookings', open: async (p) => { await click(p, '[data-testid=cancel-booking]'); } },
  { name: 'reschedule booking', path: '/bookings', open: async (p) => { await click(p, '[data-testid=reschedule]'); } },
  { name: 'join a priced game', path: '/games', open: async (p) => { await p.getByText('Priced game to join').first().waitFor(); await click(p, `[data-testid=join-${theirs?.id}]`); } },
  { name: 'invite to game', path: `/games/${mine?.id}`, open: async (p) => { await click(p, '[data-testid=invite-open]'); } },
  { name: 'end game', path: `/games/${mine?.id}`, open: async (p) => { await click(p, '[data-testid=end-open]'); } },
  { name: 'report a player', path: '/p/aarav_k', open: async (p) => { await click(p, '[data-testid^=report-player]'); } },
  { name: 'coach: book trial session', path: '/coaches/1', open: async (p) => { await click(p, '[data-testid=book-session]'); } },
  { name: 'coach: enrol in a program', path: '/coaches/1', open: async (p) => { await click(p, '[data-testid^=enrol-]'); } },
  { name: 'coach: enquiry', path: '/coaches/1', open: async (p) => { await click(p, '[data-testid=open-enquiry]'); } },
  { name: 'host a meet-up', path: '/events', open: async (p) => { await click(p, '[data-testid=host-meetup]'); } },
  { name: 'register for a marathon', path: marathon ? `/events/${marathon.id}` : '/events/1', open: async (p) => { await click(p, '[data-testid=event-register]'); } },
  { name: 'new support ticket', path: '/help/tickets', open: async (p) => { await click(p, '[data-testid=new-ticket]'); } },
  { name: 'new chat', path: '/chat', open: async (p) => { await p.getByRole('button', { name: /new/i }).first().click({ timeout: 8000 }); } },
  { name: 'login', path: '/', open: async () => {} },
].filter((o) => !only || o.name.includes(only));

const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const issues: string[] = [];
const notes: string[] = [];

for (const theme of ['light', 'dark'] as const) {
  for (const o of openers) {
    const logged = o.name !== 'login';
    const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, colorScheme: theme });
    await ctx.addInitScript(([t, token, name]) => { localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, token: name === 'login' ? null : token, city: 'Bengaluru' } })); }, [theme, me.token, o.name] as const);
    const page = await ctx.newPage();
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(e.message.slice(0, 120)));
    const tag = `[${theme}] ${o.name}`;
    try {
      await page.goto(BASE + o.path); await sleep(1800);
      if (o.name === 'login') { await page.getByRole('button', { name: 'Log in', exact: true }).first().click(); }
      else await o.open(page);
      await sleep(900);
      const dlg = page.locator('[role=dialog]').filter({ hasNot: page.locator('[data-nextjs-dialog]') }).first();
      await dlg.waitFor({ timeout: 6000 });
      // 1. text contrast inside the dialog
      const fails: Finding[] = await page.evaluate(auditIn, '[role=dialog]:not([data-nextjs-dialog])');
      const seen = new Set<string>();
      for (const f of fails) { const k = `${f.text}|${f.fg}|${f.bg}`; if (seen.has(k)) continue; seen.add(k); issues.push(`${tag}: "${f.text}" ${f.ratio}<${f.need} (${f.fg} on ${f.bg}) <${f.tag}> .${f.cls.slice(0, 50)}`); }
      // 2. panel vs scrim vs page
      const look = await dlg.evaluate((e) => { const cs = getComputedStyle(e); const sc = getComputedStyle(e.parentElement as Element); const r = e.getBoundingClientRect(); return { panel: cs.backgroundColor, scrim: sc.backgroundColor, w: Math.round(r.width), h: Math.round(r.height), vh: innerHeight, scroll: (e as HTMLElement).scrollHeight > (e as HTMLElement).clientHeight }; });
      notes.push(`${tag}: panel ${look.panel}, scrim ${look.scrim}, ${look.w}x${look.h}${look.scroll ? ' (scrolls)' : ''}`);
      // 3. form fields in the dialog: edge contrast and text colour
      const fields = await dlg.locator('input:not([type=checkbox]):not([type=radio]), select, textarea').evaluateAll((els) => els.map((e) => {
        const cs = getComputedStyle(e); const c = (window as unknown as { __cc?: unknown }).__cc; void c;
        return { tag: e.tagName.toLowerCase(), ph: (e as HTMLInputElement).placeholder || '', border: cs.borderTopColor, bw: cs.borderTopWidth, bg: cs.backgroundColor, color: cs.color };
      }));
      for (const f of fields) {
        if (f.bw === '0px') issues.push(`${tag}: a ${f.tag} "${f.ph}" has no border (edge invisible?)`);
      }
      // 4. keyboard: Tab stays inside? Escape closes?
      await page.keyboard.press('Tab'); await page.keyboard.press('Tab');
      const insideAfterTab = await page.evaluate(() => !!document.activeElement?.closest('[role=dialog]'));
      await page.screenshot({ path: `shots/modal-${theme}-${o.name.replace(/\W+/g, '_')}.png` });
      await page.keyboard.press('Escape'); await sleep(400);
      const closedByEscape = (await page.locator('[role=dialog]:not([data-nextjs-dialog])').count()) === 0;
      if (!closedByEscape) issues.push(`${tag}: Escape does not close the dialog`);
      if (!insideAfterTab) notes.push(`${tag}: after two Tabs focus is outside the dialog (no focus trap)`);
      if (errors.length) issues.push(`${tag}: page errors ${errors.join(' | ')}`);
      void logged;
    } catch (e) {
      issues.push(`${tag}: could not open (${(e as Error).message.split('\n')[0].slice(0, 100)})`);
    }
    await ctx.close();
  }
}
await browser.close();
console.log('--- notes ---'); notes.forEach((n) => console.log(n));
console.log(`\n--- ${issues.length} issue(s) ---`); issues.forEach((i) => console.log('ISSUE', i));
