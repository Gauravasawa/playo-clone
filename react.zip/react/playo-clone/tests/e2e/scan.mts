import { chromium } from 'playwright-core';
const BASE = process.env.BASE ?? 'http://localhost:3000';
const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, colorScheme: (process.env.SCHEME ?? 'light') as 'light' | 'dark' });
const page = await ctx.newPage();
let errs: string[] = [];
page.on('console', (m) => { if (m.type() === 'error' && !/ERR_INTERNET|WebSocket/.test(m.text())) errs.push(`[console.error] ${m.text().slice(0, 160)}`); });
page.on('pageerror', (e) => errs.push(`[pageerror] ${e.message.split('\n')[0].slice(0, 160)}`));
page.on('response', (r) => { if (r.status() >= 400 && !r.url().includes('/favicon')) errs.push(`[http ${r.status()}] ${r.request().method()} ${r.url().replace(BASE, '')}`); });

await page.goto(BASE);
await page.waitForSelector('article');
await page.getByRole('button', { name: 'Log in', exact: true }).first().click();
await page.getByPlaceholder('Your name').fill('Scanner ' + Date.now());
await page.getByPlaceholder('Phone (10 digits)').fill(String(2000000000 + (Date.now() % 99999999)));
await page.getByPlaceholder('OTP').fill('1234');
await page.locator('form button', { hasText: 'Log in' }).click();
await page.getByTestId('wallet-chip').waitFor({ timeout: 10000 });
// a visitor whose saved city and sport differ from the server's defaults
await page.getByLabel('City', { exact: true }).selectOption('Mumbai');
await page.getByRole('button', { name: /Football/ }).click();
await page.waitForTimeout(800);

const routes: [string, string][] = [
  ['/', 'article'], ['/games', '[data-testid^=game-] || No games'], ['/tournaments', '[data-testid^=tournament-] || No tournaments'],
  ['/coaches', '[data-testid=coach-list] || No coaches'], ['/leaderboard', '[data-testid=leaderboard] || No finished'],
  ['/friends', '[role=tablist]'], ['/chat', '[data-testid=chat-list]'], ['/notifications', '[data-testid=notification-list] || Nothing yet'],
  ['/wallet', '[data-testid=wallet-balance]'], ['/profile', 'form[aria-label="Edit profile"]'], ['/bookings', 'h1'], ['/lab', 'h1'],
  ['/p/aarav_k', '[data-testid=public-profile]'], ['/p/kabir_r', '[data-testid=public-profile]'], ['/venues/3', '[data-testid=venue-reviews]'], ['/events', '[data-testid=event-list] || No events'], ['/events/1', '[data-testid=event-detail]'], ['/coaches/1', '[data-testid=coach-profile]'], ['/learning', 'h1'], ['/plus', '[data-testid=plus-plans] || [data-testid=plus-active]'], ['/owner', 'h1'], ['/help', '[data-testid=faq-search]'], ['/help/tickets', 'h1'], ['/blog', '[data-testid=article-list]'], ['/blog/badminton-footwork-basics', 'h1'], ['/policy', '[data-testid=policy]'], ['/admin/reports', '[data-testid=not-admin]'], ['/games/1', '[data-testid=game-detail]'], ['/wallet?tab=karma', '[data-testid=karma-balance]'], ['/wallet?tab=gift', '[data-testid=buy-gift-card]'], ['/wallet?tab=passes', 'h2, h3'], ['/wallet?tab=referrals', '[data-testid=referral-code]'],
];

let bad = 0;
for (const pass of [1, 2]) {
  console.log(`\n--- pass ${pass}${pass === 2 ? ' (caches filled by pass 1)' : ''} ---`);
  for (const [path, probe] of routes) {
    errs = [];
    await page.goto(BASE + path);
    let loaded = true;
    try { const [css, text] = probe.split(' || '); await (text ? page.locator(css).or(page.getByText(text)).first() : page.locator(css).first()).waitFor({ timeout: 8000 }); } catch { loaded = false; }
    await page.waitForTimeout(700);
    const skeletons = await page.locator('main .animate-pulse').count();
    const stuck = skeletons > 0;
    const problems = [...new Set(errs)];
    const fine = loaded && !stuck && problems.length === 0;
    if (!fine) bad++;
    console.log(`${fine ? 'OK  ' : 'BAD '} ${path.padEnd(14)}${!loaded ? ' content missing' : ''}${stuck ? ` ${skeletons} skeleton(s) still showing` : ''}${problems.map((p) => '\n        ' + p).join('')}`);
  }
}
console.log(`\n${bad === 0 ? 'ALL ROUTES CLEAN' : bad + ' route visit(s) with problems'}`);
await browser.close();
