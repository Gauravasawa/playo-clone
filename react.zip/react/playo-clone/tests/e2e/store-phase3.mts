import { chromium, type Browser, type BrowserContext, type Page } from 'playwright-core';

const BASE = process.env.BASE ?? 'http://localhost:3100';
const API = 'http://localhost:4000/api';
const ENGINE = process.env.ENGINE ?? 'edge';
const only = process.argv[2] ?? 'all';

async function launch(): Promise<Browser> {
  if (ENGINE === 'firefox') return (await import('playwright-core')).firefox.launch({ headless: true });
  if (ENGINE === 'webkit') return (await import('playwright-core')).webkit.launch({ headless: true });
  return chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
}
const browser = await launch();
let passed = 0, failed = 0;
async function step(name: string, fn: () => Promise<string | void>) {
  if (only !== 'all' && !name.startsWith(only)) return;
  try { const note = await fn(); passed++; console.log(`PASS ${name}${note ? ` — ${note}` : ''}`); }
  catch (e) { failed++; console.log(`FAIL ${name}: ${(e as Error).message.split('\n').slice(0, 3).join(' | ')}`); }
}
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };

async function login(page: Page, label = 'Store') {
  await page.goto(BASE);
  await page.waitForSelector('article');
  await page.getByRole('button', { name: 'Log in', exact: true }).first().click();
  await page.getByPlaceholder('Your name').fill(`${label} ${Date.now()}`);
  await page.getByPlaceholder('Phone (10 digits)').fill(String(2000000000 + (Date.now() % 99999999)));
  await page.getByPlaceholder('OTP').fill('1234');
  await page.locator('form button', { hasText: 'Log in' }).click();
  await page.getByTestId('wallet-chip').waitFor({ timeout: 15000 });
}
const tokenOf = async (page: Page) => { await sleep(600); return tokenNow(page); };
const tokenNow = (page: Page) => page.evaluate(() => JSON.parse(localStorage.getItem('playo:state') ?? '{}').state?.token as string);
async function freshUser(ctx?: BrowserContext) {
  const c = ctx ?? (await browser.newContext());
  const page = await c.newPage();
  await login(page);
  return { ctx: c, page };
}

// ---------- Lab ----------
await step('lab: all self-tests pass (including the new saving / session / queue / concurrency ones)', async () => {
  const { ctx, page } = await freshUser();
  await page.goto(`${BASE}/lab`);
  await page.getByRole('button', { name: 'Run all' }).click();
  await page.getByTestId('selftest-summary').waitFor({ timeout: 60000 });
  const summary = await page.getByTestId('selftest-summary').innerText();
  const bad = await page.locator('li:has-text("❌")').allInnerTexts();
  await ctx.close();
  assert(/ 0 failed/.test(summary), `${summary}\n${bad.join('\n')}`);
  return summary;
});

await step('lab: benchmark runs and prints a number for every case', async () => {
  const { ctx, page } = await freshUser();
  await page.goto(`${BASE}/lab`);
  await page.getByTestId('bench-run').click();
  await page.waitForFunction(() => document.querySelectorAll('[data-testid=bench-us]').length >= 9, null, { timeout: 120000 });
  const rows = await page.locator('[data-testid=bench-table] tbody tr').allInnerTexts();
  await ctx.close();
  assert(!rows.some((r) => r.includes('failed')), rows.join(' | '));
  console.log(rows.map((r) => '      ' + r.replace(/\t/g, ' · ')).join('\n'));
});

// ---------- Route Handler through a scope ----------
await step('quote route: the server-side scope quote equals the API quote and the browser quote', async () => {
  const { ctx, page } = await freshUser();
  const token = await tokenOf(page);
  const date = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  const karma = (await (await fetch(`${API}/karma`, { headers: { authorization: `Bearer ${token}` } })).json()).balance as number;
  const body = { venueId: 3, date, slots: ['18:00', '19:00'], extras: [], karmaPoints: karma };
  const api = await (await fetch(`${API}/bookings/quote`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` }, body: JSON.stringify(body) })).json();
  const route = await (await fetch(`${BASE}/quote?venueId=3&date=${date}&slots=18:00,19:00&karma=${karma}&useKarma=1&plus=0`)).json();
  await ctx.close();
  assert(!route.error, JSON.stringify(route)); assert(api.payableInr !== undefined, 'API said: ' + JSON.stringify(api));
  assert(route.quote.payableInr === api.payableInr, `route ${route.quote.payableInr} vs api ${api.payableInr}`);
  assert(route.quote.feeInr === api.feeInr && route.quote.karmaDiscountInr === api.karmaDiscountInr, `fee/karma differ: ${JSON.stringify(route.quote)} vs ${JSON.stringify(api)}`);
  assert(route.undoRestoresQuote === true, 'history.undo inside the scope did not restore the quote');
  return `payable ₹${route.quote.payableInr} both ways (karma ${karma})`;
});

await step('quote route: bad input is a 400, unavailable slot a 409', async () => {
  const bad = await fetch(`${BASE}/quote?venueId=abc`);
  assert(bad.status === 400, `status ${bad.status}`);
  const past = await fetch(`${BASE}/quote?venueId=3&date=2020-01-01&slots=18:00`);
  assert(past.status === 409 || past.status === 400, `past day status ${past.status}`);
});

// ---------- Saving indicator ----------
await step('saving: the header shows "Saving…" during a slow save and the count returns to 0', async () => {
  const { ctx, page } = await freshUser();
  await page.route('**/api/favorites**', async (route) => { await sleep(900); await route.continue(); });
  await page.goto(BASE);
  await page.waitForSelector('article');
  await page.getByRole('button', { name: 'Add to favourites' }).first().click();
  await page.getByTestId('saving').waitFor({ timeout: 3000 });
  await page.getByTestId('saving').waitFor({ state: 'detached', timeout: 8000 });
  await ctx.close();
});

// ---------- Session preferences ----------
await step('session prefs: kept on reload in this tab, absent in a new tab, never in localStorage', async () => {
  const { ctx, page } = await freshUser();
  await page.getByTestId('user-menu').click();
  await page.getByTestId('privacy-mode').check();
  assert((await page.getByTestId('wallet-chip').innerText()).includes('••'), 'amount not hidden');
  await page.reload();
  await page.getByTestId('wallet-chip').waitFor();
  assert((await page.getByTestId('wallet-chip').innerText()).includes('••'), 'reload lost the preference');
  const local = await page.evaluate(() => localStorage.getItem('playo-prefs:state'));
  const session = await page.evaluate(() => sessionStorage.getItem('playo-prefs:state'));
  assert(local === null && session?.includes('true'), `local=${local} session=${session}`);
  const other = await ctx.newPage();
  await other.goto(BASE);
  await other.getByTestId('wallet-chip').waitFor();
  const text = await other.getByTestId('wallet-chip').innerText();
  await ctx.close();
  assert(!text.includes('••'), `a new tab should start with amounts visible, saw "${text}"`);
});

// ---------- Tab sync ----------
await step('tab sync: city, favourites and logout follow between two real tabs', async () => {
  const { ctx, page: a } = await freshUser();
  const b = await ctx.newPage();
  await b.goto(BASE);
  await b.getByTestId('wallet-chip').waitFor();
  await a.getByLabel('City', { exact: true }).selectOption('Pune');
  await b.waitForFunction(() => (document.querySelector('select[aria-label=City]') as HTMLSelectElement | null)?.value === 'Pune', null, { timeout: 5000 });
  await a.getByLabel('City', { exact: true }).selectOption('Chennai');
  await b.waitForFunction(() => (document.querySelector('select[aria-label=City]') as HTMLSelectElement | null)?.value === 'Chennai', null, { timeout: 5000 });
  await a.waitForSelector('article');
  await a.getByRole('button', { name: 'Add to favourites' }).first().click();
  await b.waitForFunction(() => /♥ 1/.test(document.body.innerText), null, { timeout: 5000 });
  await a.getByTestId('user-menu').click();
  await a.getByRole('button', { name: 'Log out' }).click();
  await b.getByRole('button', { name: 'Log in', exact: true }).first().waitFor({ timeout: 5000 });
  await ctx.close();
});

await step('tab sync: a bad value from another tab is refused by validate()', async () => {
  const { ctx, page: a } = await freshUser();
  const b = await ctx.newPage();
  await b.goto(BASE);
  await b.getByTestId('wallet-chip').waitFor();
  await a.evaluate(() => {
    const ch = new BroadcastChannel('playo');
    ch.postMessage({ type: 'state', stamp: [99999, 'zzzz'], values: { city: 12345 } });
  });
  await sleep(500);
  const city = await b.evaluate(() => (document.querySelector('select[aria-label=City]') as HTMLSelectElement).value);
  await ctx.close();
  assert(typeof city === 'string' && city !== '12345', `city is ${city}`);
});

await step('tab sync: emit with broadcast reaches the other tab', async () => {
  const { ctx, page: a } = await freshUser();
  const b = await ctx.newPage();
  await b.goto(`${BASE}/lab`);
  await a.goto(`${BASE}/lab`);
  await a.getByRole('button', { name: 'emit to all tabs' }).click();
  await b.getByText('Broadcast from another tab').first().waitFor({ timeout: 5000 });
  await ctx.close();
});

await step('tab sync: 4 real tabs choosing different cities at the same moment always end on one city (15 rounds)', async () => {
  const { ctx, page: a } = await freshUser();
  const pages = [a];
  for (let i = 0; i < 3; i++) { const p = await ctx.newPage(); await p.goto(BASE); await p.getByTestId('wallet-chip').waitFor(); pages.push(p); }
  const cities = ['Mumbai', 'Delhi', 'Pune', 'Hyderabad'];
  const read = (p: Page) => p.evaluate(() => (document.querySelector('select[aria-label=City]') as HTMLSelectElement).value);
  const winners: string[] = [];
  let slowest = 0;
  for (let round = 0; round < 15; round++) {
    const mix = [...cities].sort(() => Math.random() - 0.5);
    await Promise.all(pages.map((p, i) => p.getByLabel('City', { exact: true }).selectOption(mix[i])));
    // the tabs may take a moment to settle (the machine is busy): wait until they agree, up to 3 s, and remember how long it took
    const t0 = Date.now();
    let got = await Promise.all(pages.map(read));
    while (new Set(got).size > 1 && Date.now() - t0 < 3000) { await sleep(100); got = await Promise.all(pages.map(read)); }
    slowest = Math.max(slowest, Date.now() - t0);
    assert(new Set(got).size === 1, `round ${round}: tabs still disagree after 3 s: ${got.join(', ')} (wrote ${mix.join(', ')})`);
    winners.push(got[0]);
  }
  // and the saved value (shared localStorage) is the same one the tabs show (saving is debounced by 250 ms: let it finish)
  await sleep(900);
  const saved = await a.evaluate(() => JSON.parse(localStorage.getItem('playo:state') ?? '{}').state?.city);
  await ctx.close();
  assert(saved === winners[winners.length - 1], `localStorage has "${saved}" but the tabs show "${winners[winners.length - 1]}"`);
  return `agreed every round (slowest ${slowest} ms); winners: ${[...new Set(winners)].join(', ')}`;
});

// ---------- DevTools time travel ----------
await step('devtools: JUMP_TO_STATE from the extension sets the store back', async () => {
  const ctx = await browser.newContext();
  await ctx.addInitScript(() => {
    const w = window as unknown as Record<string, unknown>;
    const log: { type: string; state: Record<string, unknown> }[] = [];
    w.__dtLog = log;
    w.__REDUX_DEVTOOLS_EXTENSION__ = {
      connect: (o: { name: string }) => ({
        init: (s: Record<string, unknown>) => { if (o.name === 'playo') log.push({ type: '@@INIT', state: JSON.parse(JSON.stringify(s)) }); },
        send: (a: { type: string }, s: Record<string, unknown>) => { if (o.name === 'playo') log.push({ type: a.type, state: JSON.parse(JSON.stringify(s)) }); },
        subscribe: (cb: (m: unknown) => void) => { if (o.name === 'playo') w.__dtSend = cb; return () => {}; },
      }),
    };
  });
  const page = await ctx.newPage();
  await login(page);
  const city = () => page.evaluate(() => (document.querySelector('select[aria-label=City]') as HTMLSelectElement).value);
  const start = await city();
  await page.getByLabel('City', { exact: true }).selectOption('Mumbai');
  await page.getByLabel('City', { exact: true }).selectOption('Jaipur');
  await sleep(300);
  const log = await page.evaluate(() => (window as unknown as { __dtLog: { type: string; state: Record<string, unknown> }[] }).__dtLog);
  const cityStates = log.map((l) => l.state.city);
  assert(cityStates.includes('Mumbai') && cityStates.includes('Jaipur'), `DevTools never saw Mumbai and Jaipur: ${JSON.stringify([...new Set(cityStates)])}`);
  const mumbai = log.find((l) => l.state.city === 'Mumbai')!;
  await page.evaluate((state) => (window as unknown as { __dtSend: (m: unknown) => void }).__dtSend({ type: 'DISPATCH', payload: { type: 'JUMP_TO_STATE' }, state: JSON.stringify(state) }), mumbai.state);
  await sleep(300);
  assert((await city()) === 'Mumbai', `after JUMP_TO_STATE the city is ${await city()}`);
  // a malformed message is ignored, not a crash
  await page.evaluate(() => (window as unknown as { __dtSend: (m: unknown) => void }).__dtSend({ type: 'DISPATCH', payload: { type: 'JUMP_TO_STATE' }, state: '{not json' }));
  await sleep(200);
  assert((await city()) === 'Mumbai', 'a malformed message changed the city');
  await ctx.close();
  return `from ${start}: Mumbai → Jaipur → jumped back to Mumbai`;
});

// ---------- Refresh on focus / online ----------
await step('refresh: a focus event re-fetches what is on screen once it is stale; online does too', async () => {
  const { ctx, page } = await freshUser();
  let hits = 0;
  page.on('request', (r) => { if (/\/api\/wallet(\?|$)/.test(r.url())) hits++; });
  await page.goto(`${BASE}/wallet`);
  await page.getByTestId('wallet-balance').waitFor();
  await sleep(11000); // staleTime of wallet is 10 s
  const before = hits;
  await page.evaluate(() => window.dispatchEvent(new Event('focus')));
  await sleep(800);
  const afterFocus = hits;
  await sleep(11000);
  await page.evaluate(() => window.dispatchEvent(new Event('online')));
  await sleep(800);
  const afterOnline = hits;
  await ctx.close();
  assert(afterFocus > before, `focus made no request (${before} → ${afterFocus})`);
  assert(afterOnline > afterFocus, `online made no request (${afterFocus} → ${afterOnline})`);
  return `wallet requests: ${before} → ${afterFocus} (focus) → ${afterOnline} (online)`;
});

await step('refresh: focus while the data is fresh does NOT re-fetch', async () => {
  const { ctx, page } = await freshUser();
  let hits = 0;
  page.on('request', (r) => { if (/\/api\/wallet(\?|$)/.test(r.url())) hits++; });
  await page.goto(`${BASE}/wallet`);
  await page.getByTestId('wallet-balance').waitFor();
  await sleep(500);
  const before = hits;
  await page.evaluate(() => window.dispatchEvent(new Event('focus')));
  await sleep(600);
  await ctx.close();
  return `wallet requests ${before} → ${hits} after a focus right after loading`;
});

// ---------- Custom retryDelay on the wallet query ----------
await step('retryDelay: wallet retries with 300 / 600 / 1200 ms gaps while the API is failing, then recovers', async () => {
  const { ctx, page } = await freshUser();
  await sleep(700); // the saved login is written after a short debounce: wait for it, then drop the offline copy so the next page must ask the API
  await page.evaluate(() => { localStorage.removeItem('playo:inline'); localStorage.removeItem('playo:queries'); });
  const stamps: number[] = [];
  let fail = true;
  await page.route(/\/api\/wallet(\?|$)/, async (route) => {
    stamps.push(Date.now());
    if (fail && stamps.length <= 3) return route.fulfill({ status: 503, body: '{"error":"down"}', contentType: 'application/json' });
    return route.continue();
  });
  await page.goto(`${BASE}/wallet`);
  await page.getByTestId('wallet-balance').waitFor({ timeout: 20000 });
  fail = false;
  await ctx.close();
  const gaps = stamps.slice(1, 4).map((t, i) => t - stamps[i]);
  assert(stamps.length >= 4, `only ${stamps.length} requests`);
  assert(gaps[0] >= 250 && gaps[0] < 600 && gaps[1] >= 550 && gaps[1] < 1100, `gaps were ${gaps.join(', ')} ms`);
  return `gaps ${gaps.join(', ')} ms`;
});

// ---------- Offline queue, several tasks ----------
await step('offline: three saves queue while offline, the header says so, and all three land when back online', async () => {
  const { ctx, page } = await freshUser();
  await page.goto(BASE);
  await page.waitForSelector('article');
  const token = await tokenOf(page);
  await ctx.setOffline(true);
  await page.evaluate(() => window.dispatchEvent(new Event('offline')));
  const hearts = page.getByRole('button', { name: 'Add to favourites' });
  await hearts.nth(0).click();
  await hearts.nth(1).click();
  await hearts.nth(2).click();
  await page.getByTestId('saving').waitFor({ timeout: 3000 });
  const text = await page.getByTestId('saving').innerText();
  const server = async () => (await (await fetch(`${API}/me`, { headers: { authorization: `Bearer ${token}` } })).json()).favorites.length as number;
  assert((await server()) === 0, 'nothing should have reached the server yet');
  await ctx.setOffline(false);
  await page.evaluate(() => window.dispatchEvent(new Event('online')));
  await page.getByTestId('saving').waitFor({ state: 'detached', timeout: 10000 });
  const count = await server();
  await ctx.close();
  assert(count === 3, `server has ${count} favourites, expected 3`);
  return `"${text}" → server favourites: ${count}`;
});

console.log(`\n${passed} passed, ${failed} failed (${ENGINE})`);
await browser.close();
process.exit(failed ? 1 : 0);
