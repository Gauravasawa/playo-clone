// Contrast audit: every text element on every page, light and dark. Computes WCAG contrast (text against the real background it sits on).
import { chromium } from 'playwright-core';
import { api, apiUser, isoDay } from './glib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3100';
const only = process.env.ONLY ?? '';
const stamp = Date.now();
const user = await apiUser(`Audit ${stamp}`, String(2300000000 + (stamp % 99999999)));
const tok = user.token;
// some data so pages have content: a game, a booking, a chat, a ticket
const game = await api(tok, 'POST', '/games', { title: 'Audit game', sport: 'football', venueId: 3, startsAt: `${isoDay(3)}T18:00`, capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 100 }).catch(() => null);
await api(tok, 'POST', '/bookings', { venueId: 3, date: isoDay(2), slots: ['18:00'], method: 'wallet' }).catch(() => null);
await api(tok, 'POST', '/tickets', { topic: 'booking', subject: 'Audit ticket', body: 'Testing the dark theme' }).catch(() => null);

const ROUTES = [
  '/', '/venues/3', '/games', game ? `/games/${game.id}` : '/games', '/events', '/events/1', '/coaches', '/coaches/1', '/tournaments', '/leaderboard',
  '/friends', '/chat', '/notifications', '/wallet', '/wallet?tab=karma', '/wallet?tab=gift', '/wallet?tab=passes', '/wallet?tab=referrals',
  '/bookings', '/learning', '/plus', '/profile', '/p/aarav_k', '/owner', '/help', '/help/tickets', '/blog', '/blog/badminton-footwork-basics', '/policy', '/lab', '/admin/reports',
].filter((r) => !only || r.includes(only));

const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });

type Finding = { route: string; text: string; tag: string; cls: string; fg: string; bg: string; ratio: number; need: number; size: number };

function audit() {
  const cv = document.createElement('canvas').getContext('2d', { willReadFrequently: true })!;
  const rgba = (c: string): [number, number, number, number] => {
    cv.clearRect(0, 0, 1, 1);
    cv.fillStyle = '#000';
    cv.fillStyle = c;
    cv.fillRect(0, 0, 1, 1);
    const d = cv.getImageData(0, 0, 1, 1).data;
    // canvas premultiplies: ask for the straight colour via a second draw over white and black
    cv.clearRect(0, 0, 1, 1); cv.fillStyle = '#fff'; cv.fillRect(0, 0, 1, 1); cv.fillStyle = c; cv.fillRect(0, 0, 1, 1);
    const w = cv.getImageData(0, 0, 1, 1).data;
    cv.clearRect(0, 0, 1, 1); cv.fillStyle = '#000'; cv.fillRect(0, 0, 1, 1); cv.fillStyle = c; cv.fillRect(0, 0, 1, 1);
    const k = cv.getImageData(0, 0, 1, 1).data;
    const a = 1 - (w[0] - k[0]) / 255; // over white minus over black = 255 * (1 - alpha)
    void d;
    const alpha = Math.max(0, Math.min(1, a));
    if (alpha < 0.004) return [0, 0, 0, 0];
    return [k[0] / alpha, k[1] / alpha, k[2] / alpha, alpha].map((v, i) => (i < 3 ? Math.round(Math.min(255, v)) : v)) as [number, number, number, number];
  };
  const over = (top: [number, number, number, number], under: [number, number, number]) =>
    [0, 1, 2].map((i) => top[i] * top[3] + under[i] * (1 - top[3])) as [number, number, number];
  const lum = (c: number[]) => {
    const f = (v: number) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
  };
  const ratio = (a: number[], b: number[]) => { const l1 = lum(a), l2 = lum(b); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); };
  const hex = (c: number[]) => '#' + c.map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');

  /** the backgrounds an element sits on, nearest first; a gradient gives several candidate colours */
  const backdrop = (el: Element): { colours: [number, number, number][]; image: boolean } => {
    const stack: Element[] = [];
    for (let e: Element | null = el; e; e = e.parentElement) stack.push(e);
    let colours: [number, number, number][] = [[255, 255, 255]];
    let image = false;
    // walk from the root down, compositing what each level paints
    for (const e of stack.reverse()) {
      const cs = getComputedStyle(e);
      const bgImage = cs.backgroundImage;
      const base = rgba(cs.backgroundColor);
      if (base[3] > 0) colours = colours.map((u) => over(base, u));
      if (bgImage && bgImage !== 'none') {
        if (/gradient/.test(bgImage)) {
          const stops = [...bgImage.matchAll(/(rgba?\([^)]*\)|oklab\([^)]*\)|oklch\([^)]*\)|lab\([^)]*\)|lch\([^)]*\)|color\([^)]*\)|#[0-9a-f]{3,8})/gi)].map((m) => rgba(m[1]));
          const solid = stops.filter((s) => s[3] > 0.05);
          if (solid.length) colours = solid.flatMap((s) => colours.map((u) => over(s, u)));
        } else if (/url\(/.test(bgImage)) image = true;
      }
    }
    return { colours, image };
  };

  const out: Finding[] = [];
  const seen = new Set<Element>();
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const text = (n.textContent ?? '').trim();
    const el = n.parentElement;
    if (!text || !el || seen.has(el)) continue;
    if (['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(el.tagName)) continue;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none') continue;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    // hidden by overflow or off screen: skip anything clipped to nothing
    seen.add(el);
    const disabled = (el.closest('button,input,select,textarea') as HTMLButtonElement | null)?.disabled;
    // opacity of the element and its ancestors multiplies into the text colour
    let opacity = 1;
    for (let e: Element | null = el; e; e = e.parentElement) opacity *= parseFloat(getComputedStyle(e).opacity);
    const fg = rgba(cs.color);
    const { colours, image } = backdrop(el);
    if (image) continue; // text over a photo: needs eyes, not arithmetic
    const size = parseFloat(cs.fontSize);
    const bold = parseInt(cs.fontWeight) >= 700;
    const large = size >= 24 || (size >= 18.66 && bold);
    // emoji are pictures, and symbols like ★ ♥ × are graphics: those need 3:1, words need 4.5:1
    const hasWord = /[\p{L}\p{N}]/u.test(text);
    if (!hasWord && /\p{Extended_Pictographic}/u.test(text)) continue;
    const need = large || !hasWord ? 3 : 4.5;
    let worst = 99;
    let worstBg: number[] = colours[0];
    for (const bg of colours) {
      const a = fg[3] * opacity;
      const text2 = over([fg[0], fg[1], fg[2], a], bg);
      const rr = ratio(text2, bg);
      if (rr < worst) { worst = rr; worstBg = bg; }
    }
    if (worst < need && !disabled) {
      out.push({ route: '', text: text.slice(0, 40), tag: el.tagName.toLowerCase(), cls: (el.getAttribute('class') ?? '').slice(0, 90), fg: hex(over([fg[0], fg[1], fg[2], fg[3] * opacity], worstBg)), bg: hex(worstBg), ratio: Math.round(worst * 100) / 100, need, size });
    }
  }
  return out;
}

const results: Record<string, Finding[]> = {};
for (const theme of ['light', 'dark'] as const) {
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, colorScheme: theme });
  await ctx.addInitScript(([t, token]) => {
    localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, token, city: 'Bengaluru' } }));
  }, [theme, tok] as const);
  const page = await ctx.newPage();
  const all: Finding[] = [];
  for (const route of ROUTES) {
    try {
      await page.goto(BASE + route, { waitUntil: 'load' });
      await page.waitForTimeout(1800);
      const f = (await page.evaluate(audit)).map((x) => ({ ...x, route }));
      all.push(...f);
    } catch (e) { console.log('skip', route, (e as Error).message.slice(0, 80)); }
  }
  results[theme] = all;
  await ctx.close();
}
await browser.close();

for (const theme of ['light', 'dark'] as const) {
  const groups = new Map<string, { n: number; f: Finding; routes: Set<string> }>();
  for (const f of results[theme]) {
    const k = `${f.tag}|${f.cls}|${f.fg}|${f.bg}`;
    const g = groups.get(k) ?? { n: 0, f, routes: new Set() };
    g.n++; g.routes.add(f.route); groups.set(k, g);
  }
  console.log(`\n===== ${theme.toUpperCase()}: ${results[theme].length} failing text elements in ${groups.size} distinct styles =====`);
  [...groups.values()].sort((a, b) => a.f.ratio - b.f.ratio).slice(0, Number(process.env.TOP ?? 40)).forEach((g) =>
    console.log(`${g.f.ratio.toFixed(2)}<${g.f.need}  ${g.f.fg} on ${g.f.bg}  ×${g.n}  <${g.f.tag}> "${g.f.text}" .${g.f.cls.replace(/\s+/g, ' ')}  [${[...g.routes].slice(0, 3).join(' ')}]`));
}
