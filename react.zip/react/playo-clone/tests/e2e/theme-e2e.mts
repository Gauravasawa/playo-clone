import { chromium, webkit, firefox, type Browser, type BrowserContext, type Page } from 'playwright-core';

const BASE = process.env.BASE ?? 'http://localhost:3100';
const ENGINE = process.env.ENGINE ?? 'edge';
const browser: Browser = ENGINE === 'webkit' ? await webkit.launch({ headless: true }) : ENGINE === 'firefox' ? await firefox.launch({ headless: true }) : await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
let passed = 0, failed = 0;
async function step(name: string, fn: () => Promise<string | void>) {
  try { const note = await fn(); passed++; console.log(`PASS ${name}${note ? ` — ${note}` : ''}`); }
  catch (e) { failed++; console.log(`FAIL ${name}: ${(e as Error).message.split('\n').slice(0, 3).join(' | ')}`); }
}
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const theme = (p: Page) => p.evaluate(() => document.documentElement.dataset.theme);
const saved = (p: Page) => p.evaluate(() => JSON.parse(localStorage.getItem('playo:state') ?? '{}').state?.theme);
const bodyBg = (p: Page) => p.evaluate(() => getComputedStyle(document.body).backgroundColor);
async function open(ctx: BrowserContext, path = '/') {
  const p = await ctx.newPage();
  const errors: string[] = [];
  p.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.text().slice(0, 160)); });
  p.on('pageerror', (e) => errors.push(e.message.slice(0, 160)));
  (p as Page & { errors: string[] }).errors = errors;
  await p.goto(BASE + path);
  await p.getByTestId('theme-toggle').waitFor();
  await sleep(1200);
  return p;
}

await step('system light: opens light; the ball shows the day side', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light' });
  const p = await open(ctx);
  assert((await theme(p)) === 'light', `theme ${await theme(p)}`);
  assert((await p.getByTestId('theme-toggle').getAttribute('data-pref')) === 'system', 'default preference should be system');
  const t = await p.getByTestId('theme-toggle').locator('.theme-ball-body').evaluate((e) => getComputedStyle(e).transform);
  assert(t === 'none' || /matrix3d\(1, 0, 0, 0, 0, 1/.test(t) || /matrix\(1, 0, 0, 1/.test(t), `ball transform ${t}`);
  await ctx.close();
});

await step('system dark: opens dark with no white flash (theme is set before the page is parsed further)', async () => {
  const ctx = await browser.newContext({ colorScheme: 'dark' });
  await ctx.addInitScript(() => document.addEventListener('DOMContentLoaded', () => { (window as unknown as Record<string, unknown>).__first = [document.documentElement.dataset.theme, getComputedStyle(document.body).backgroundColor]; }));
  const p = await open(ctx);
  const first = await p.evaluate(() => (window as unknown as Record<string, unknown>).__first);
  assert(JSON.stringify(first) === JSON.stringify(['dark', 'rgb(9, 17, 14)']), `at DOMContentLoaded: ${JSON.stringify(first)}`);
  await ctx.close();
  return `first paint: ${JSON.stringify(first)}`;
});

await step('click the ball: theme flips with the transition class, then is saved and the class is removed', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light', viewport: { width: 1200, height: 800 } });
  const p = await open(ctx);
  await p.getByTestId('theme-toggle').click();
  await sleep(120);
  const during = await p.evaluate(() => document.documentElement.classList.contains('theme-switching'));
  if (ENGINE === 'edge') assert(during, 'no theme-switching class during the transition');
  await p.screenshot({ path: 'shots/anim-1-120ms.png' });
  await sleep(300);
  await p.screenshot({ path: 'shots/anim-2-420ms.png' });
  await sleep(300);
  await p.screenshot({ path: 'shots/anim-3-720ms.png' });
  await sleep(1000);
  assert((await theme(p)) === 'dark', `theme ${await theme(p)}`);
  assert((await saved(p)) === 'dark', `saved ${await saved(p)}`);
  assert(!(await p.evaluate(() => document.documentElement.classList.contains('theme-switching'))), 'theme-switching class left behind');
  assert((await bodyBg(p)) === 'rgb(9, 17, 14)', `body ${await bodyBg(p)}`);
  const t = await p.getByTestId('theme-toggle').locator('.theme-ball-body').evaluate((e) => getComputedStyle(e).transform);
  assert(/matrix3d\(-1/.test(t) || /matrix3d\(-?0\.9/.test(t) || /-1, 0, /.test(t), `the ball should show its moon side (rotated 180°), transform: ${t}`);
  await p.getByTestId('theme-toggle').click();
  await sleep(1500);
  assert((await theme(p)) === 'light' && (await saved(p)) === 'light', `back to light: ${await theme(p)}/${await saved(p)}`);
  await ctx.close();
});

await step('the choice survives a reload and a new tab; a new tab opens in the saved theme before paint', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light' });
  await ctx.addInitScript(() => document.addEventListener('DOMContentLoaded', () => { (window as unknown as Record<string, unknown>).__first = document.documentElement.dataset.theme; }));
  const p = await open(ctx);
  await p.getByTestId('theme-toggle').click();
  await sleep(1400);
  await p.reload();
  await p.getByTestId('theme-toggle').waitFor();
  assert((await p.evaluate(() => (window as unknown as Record<string, unknown>).__first)) === 'dark', 'reload painted light first');
  const q = await open(ctx);
  assert((await q.evaluate(() => (window as unknown as Record<string, unknown>).__first)) === 'dark', 'second tab painted light first');
  await ctx.close();
});

await step('menu: Light / Dark / System; System follows the operating system live', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light' });
  const p = await open(ctx);
  await p.getByTestId('theme-menu-button').click();
  await p.getByTestId('theme-menu').waitFor();
  assert((await p.getByTestId('theme-system').getAttribute('aria-checked')) === 'true', 'System should be checked at first');
  await p.getByTestId('theme-dark').click();
  await sleep(1300);
  assert((await theme(p)) === 'dark' && (await saved(p)) === 'dark', 'Dark chosen');
  await p.emulateMedia({ colorScheme: 'light' });
  await sleep(300);
  assert((await theme(p)) === 'dark', 'an explicit Dark must ignore the OS');
  await p.getByTestId('theme-menu-button').click();
  await p.getByTestId('theme-system').click();
  await sleep(1300);
  assert((await theme(p)) === 'light', `System with light OS: ${await theme(p)}`);
  await p.emulateMedia({ colorScheme: 'dark' });
  await sleep(500);
  assert((await theme(p)) === 'dark', 'System must follow the OS to dark');
  await p.emulateMedia({ colorScheme: 'light' });
  await sleep(500);
  assert((await theme(p)) === 'light', 'System must follow the OS back to light');
  await p.getByTestId('theme-menu-button').click();
  await p.keyboard.press('Escape');
  assert((await p.getByTestId('theme-menu').count()) === 0, 'Escape should close the menu');
  await p.getByTestId('theme-menu-button').click();
  await p.mouse.click(5, 300);
  assert((await p.getByTestId('theme-menu').count()) === 0, 'clicking outside should close the menu');
  await ctx.close();
});

await step('another tab changes the theme: this tab follows (syncTabs)', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light' });
  const a = await open(ctx);
  const b = await open(ctx);
  await b.getByTestId('theme-toggle').click();
  await sleep(1500);
  const seen = await theme(a);
  assert(seen === 'dark', `tab A shows ${seen}`);
  assert((await a.getByTestId('theme-toggle').getAttribute('data-pref')) === 'dark', 'tab A preference');
  await ctx.close();
});

await step('reduced motion: the theme changes at once, no transition class, no 3D spin', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light', reducedMotion: 'reduce' });
  const p = await open(ctx);
  let seen = false;
  await p.exposeFunction('__seen', () => { seen = true; });
  await p.evaluate(() => new MutationObserver(() => { if (document.documentElement.classList.contains('theme-switching')) (window as unknown as { __seen: () => void }).__seen(); }).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] }));
  await p.getByTestId('theme-toggle').click();
  await sleep(150);
  assert((await theme(p)) === 'dark', 'should be dark right away');
  await sleep(800);
  assert(!seen, 'the transition class appeared although motion is reduced');
  const dur = await p.getByTestId('theme-toggle').locator('.theme-ball-body').evaluate((e) => getComputedStyle(e).transitionDuration);
  assert(/^0s/.test(dur), `ball transition ${dur}`);
  const anim = await p.getByTestId('theme-toggle').evaluate((e) => getComputedStyle(e).animationName);
  assert(anim === 'none', `ball animation ${anim}`);
  await ctx.close();
});

await step('hero scene: tilts with the pointer; night shows moon and stars, day shows the sun', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light', viewport: { width: 1200, height: 800 } });
  const p = await open(ctx);
  const scene = p.getByTestId('hero-scene');
  await scene.waitFor();
  const read = () => scene.evaluate((e) => [(e as HTMLElement).style.getPropertyValue('--px'), (e as HTMLElement).style.getPropertyValue('--py')]);
  const hero = await scene.evaluate((e) => { const r = (e.parentElement as HTMLElement).getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; });
  await p.mouse.move(hero.x + hero.w * 0.9, hero.y + hero.h * 0.2);
  await sleep(300);
  const right = await read();
  await p.mouse.move(hero.x + hero.w * 0.1, hero.y + hero.h * 0.8);
  await sleep(300);
  const left = await read();
  assert(Number(right[0]) > 0.3 && Number(left[0]) < -0.3 && Number(right[1]) < 0 && Number(left[1]) > 0, `pointer values ${right} / ${left}`);
  const sunDay = await p.locator('.hs-sun').evaluate((e) => getComputedStyle(e).opacity);
  await p.getByTestId('theme-toggle').click();
  await sleep(1400);
  const sunNight = await p.locator('.hs-sun').evaluate((e) => getComputedStyle(e).opacity);
  const moonNight = await p.locator('.hs-moon').evaluate((e) => getComputedStyle(e).opacity);
  assert(sunDay === '1' && sunNight === '0' && moonNight === '1', `sun ${sunDay}→${sunNight}, moon ${moonNight}`);
  await p.screenshot({ path: 'shots/hero-night.png', clip: { x: hero.x, y: hero.y, width: hero.w, height: hero.h } });
  await p.mouse.move(5, 5);
  await sleep(300);
  assert((await read()).join() === '0.000,0.000' || (await read()).join() === '0,0', `pointer reset ${await read()}`);
  await ctx.close();
});

await step('venue map: OpenStreetMap tiles are darkened with a filter in dark mode only, and swapped without reloading the map', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light', viewport: { width: 1200, height: 900 } });
  const p = await open(ctx);
  await p.getByTestId('view-map').click();
  await p.getByTestId('venue-map').waitFor();
  await p.waitForSelector('.leaflet-tile-loaded', { timeout: 15000 }).catch(() => {});
  const filter = () => p.evaluate(() => getComputedStyle(document.querySelector('.leaflet-tile-pane') as Element).filter);
  const tileHost = () => p.evaluate(() => new URL((document.querySelector('.leaflet-tile') as HTMLImageElement).src).host);
  assert((await filter()) === 'none', `light tile filter: ${await filter()}`);
  const host = await tileHost();
  assert(/openstreetmap/.test(host), `tiles from ${host}`);
  const mapEl = await p.evaluate(() => { (window as unknown as Record<string, unknown>).__mapNode = document.querySelector('[data-testid=venue-map]'); return true; });
  await p.getByTestId('theme-toggle').click();
  await sleep(1800);
  const dark = await filter();
  assert(dark.includes('invert(1)'), `dark tile filter: ${dark}`);
  assert(await p.evaluate(() => (window as unknown as Record<string, unknown>).__mapNode === document.querySelector('[data-testid=venue-map]')), 'the map was rebuilt');
  assert(await p.locator('.leaflet-marker-icon').count() > 3, 'markers missing');
  const markerFilter = await p.evaluate(() => getComputedStyle(document.querySelector('.leaflet-marker-pane') as Element).filter);
  assert(markerFilter === 'none', `markers must not be inverted: ${markerFilter}`);
  await p.screenshot({ path: 'shots/map-dark.png' });
  await ctx.close();
  return `filter none → ${dark.slice(0, 40)}…; ${mapEl ? 'map kept' : ''}`;
});

await step('Pages Router page /p/aarav_k: dark from the first paint, with the toggle', async () => {
  const ctx = await browser.newContext({ colorScheme: 'dark' });
  await ctx.addInitScript(() => document.addEventListener('DOMContentLoaded', () => { (window as unknown as Record<string, unknown>).__first = [document.documentElement.dataset.theme, getComputedStyle(document.body).backgroundColor]; }));
  const p = await ctx.newPage();
  const errs: string[] = [];
  p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 140)); });
  await p.goto(BASE + '/p/aarav_k');
  await p.getByTestId('theme-toggle').waitFor();
  await sleep(1000);
  const first = await p.evaluate(() => (window as unknown as Record<string, unknown>).__first);
  assert(JSON.stringify(first) === JSON.stringify(['dark', 'rgb(9, 17, 14)']), `first paint ${JSON.stringify(first)}`);
  await p.getByTestId('theme-toggle').click();
  await sleep(1400);
  assert((await theme(p)) === 'light', 'toggle on the Pages Router page');
  assert(!errs.length, errs.join(' | '));
  await ctx.close();
});

await step('no console errors or warnings while switching themes on 6 pages', async () => {
  const ctx = await browser.newContext({ colorScheme: 'light' });
  const p = await open(ctx);
  const errors = (p as Page & { errors: string[] }).errors;
  for (const path of ['/', '/games', '/events', '/help', '/blog', '/policy']) {
    await p.goto(BASE + path);
    await p.getByTestId('theme-toggle').waitFor();
    await sleep(700);
    await p.getByTestId('theme-toggle').click();
    await sleep(1300);
  }
  await ctx.close();
  assert(!errors.filter((e) => !/Download the React DevTools|favicon/.test(e)).length, errors.join(' | '));
});

console.log(`\n${passed} passed, ${failed} failed (${ENGINE})`);
await browser.close();
process.exit(failed ? 1 : 0);
