// Interactive states in both themes: hover, focus, active, disabled, inputs, selects, loading skeletons, menus, modals, toasts.
import { chromium, type Page, type ElementHandle } from 'playwright-core';
import { api, apiUser, isoDay } from './glib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3100';
const stamp = Date.now();
const user = await apiUser(`States ${stamp}`, String(2500000000 + (stamp % 99999999)));
const tok = user.token;
const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Installed in every page: contrast helpers (colours resolved through a canvas so oklab / color-mix / lab all work) */
function install() {
  const cv = document.createElement('canvas').getContext('2d', { willReadFrequently: true })!;
  const rgba = (c: string): [number, number, number, number] => {
    const px = (bg: string) => { cv.clearRect(0, 0, 1, 1); cv.fillStyle = bg; cv.fillRect(0, 0, 1, 1); cv.fillStyle = '#000'; cv.fillStyle = c; cv.fillRect(0, 0, 1, 1); return cv.getImageData(0, 0, 1, 1).data; };
    const w = px('#fff'), k = px('#000');
    const a = Math.max(0, Math.min(1, 1 - (w[0] - k[0]) / 255));
    if (a < 0.004) return [0, 0, 0, 0];
    return [Math.round(Math.min(255, k[0] / a)), Math.round(Math.min(255, k[1] / a)), Math.round(Math.min(255, k[2] / a)), a];
  };
  const over = (t: number[], u: number[]) => [0, 1, 2].map((i) => t[i] * t[3] + u[i] * (1 - t[3]));
  const lum = (c: number[]) => { const f = (v: number) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
  const ratio = (a: number[], b: number[]) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  const hex = (c: number[]) => '#' + c.map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');
  const backdrop = (el: Element, pseudo = false) => {
    const stack: Element[] = [];
    for (let e: Element | null = pseudo ? el.parentElement : el; e; e = e.parentElement) stack.push(e);
    let cols: number[][] = [[255, 255, 255]];
    let image = false;
    for (const e of stack.reverse()) {
      const cs = getComputedStyle(e);
      const base = rgba(cs.backgroundColor);
      if (base[3] > 0) cols = cols.map((u) => over(base, u));
      const bi = cs.backgroundImage;
      if (bi && bi !== 'none') {
        if (/gradient/.test(bi)) {
          const stops = [...bi.matchAll(/(rgba?\([^)]*\)|oklab\([^)]*\)|oklch\([^)]*\)|lab\([^)]*\)|lch\([^)]*\)|color\([^)]*\)|#[0-9a-f]{3,8})/gi)].map((m) => rgba(m[1])).filter((s) => s[3] > 0.05);
          if (stops.length) cols = stops.flatMap((s) => cols.map((u) => over(s, u)));
        } else if (/url\(/.test(bi)) image = true;
      }
    }
    return { cols, image };
  };
  (window as unknown as Record<string, unknown>).__c = {
    /** text colour of an element (or its ::placeholder) against what is behind it */
    text(el: Element, pseudo?: string) {
      const cs = getComputedStyle(el, pseudo ?? null);
      let opacity = 1;
      for (let e: Element | null = el; e; e = e.parentElement) opacity *= parseFloat(getComputedStyle(e).opacity);
      const fg = rgba(cs.color);
      const { cols, image } = backdrop(el);
      if (image) return null;
      let worst = 99, bgw = cols[0];
      for (const bg of cols) { const t = over([fg[0], fg[1], fg[2], fg[3] * opacity], bg); const r = ratio(t, bg); if (r < worst) { worst = r; bgw = bg; } }
      return { ratio: Math.round(worst * 100) / 100, fg: hex(over([fg[0], fg[1], fg[2], fg[3] * opacity], bgw)), bg: hex(bgw), size: parseFloat(cs.fontSize), weight: cs.fontWeight };
    },
    /** how much a shape (border / outline / fill) stands out from what is behind it */
    shape(colour: string, el: Element) {
      const c = rgba(colour);
      const { cols } = backdrop(el, true);
      if (c[3] < 0.05) return { ratio: 1, colour: 'transparent' };
      let worst = 99;
      for (const bg of cols) worst = Math.min(worst, ratio(over(c, bg), bg));
      return { ratio: Math.round(worst * 100) / 100, colour: hex(over(c, cols[0])) };
    },
    backdropOf(el: Element) { return hex(backdrop(el).cols[0]); },
  };
}

type TextRes = { ratio: number; fg: string; bg: string; size: number; weight: string } | null;
const text = (h: ElementHandle, pseudo?: string) => h.evaluate((e, ps) => (window as unknown as { __c: { text: (e: Element, p?: string) => TextRes } }).__c.text(e, ps), pseudo);
const shape = (h: ElementHandle, colour: string) => h.evaluate((e, c) => (window as unknown as { __c: { shape: (c: string, e: Element) => { ratio: number; colour: string } } }).__c.shape(c, e), colour);

const issues: string[] = [];
const notes: string[] = [];
function need(label: string, ratio: number | undefined, min: number, extra = '') {
  if (ratio === undefined) return;
  if (ratio < min) issues.push(`${label}: ${ratio} < ${min} ${extra}`);
}

for (const theme of ['light', 'dark'] as const) {
  console.log(`\n######## ${theme.toUpperCase()} ########`);
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, colorScheme: theme });
  await ctx.addInitScript(install);
  await ctx.addInitScript(([t]) => { if (!localStorage.getItem('playo:state')) localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, city: 'Bengaluru' } })); }, [theme] as const);
  const page = await ctx.newPage();
  const L = (s: string) => `[${theme}] ${s}`;

  /* ---- 1. hover on interactive things (home page, logged out) ---- */
  await page.goto(BASE + '/'); await page.waitForSelector('article'); await sleep(1500);
  const hovers: [string, string][] = [
    ['sport chip', 'button:has-text("Badminton")'], ['near me', 'button:has-text("Near me")'], ['amenity chip', 'button:has-text("Parking")'],
    ['list/map toggle', '[data-testid=view-map]'], ['log in button', 'button:has-text("Log in")'], ['nav link', 'a:has-text("Events")'], ['more menu', '[data-testid=more-menu]'],
    ['heart', 'button[aria-label="Add to favourites"]'], ['venue card title', 'article a >> nth=0'], ['theme ball', '[data-testid=theme-toggle]'], ['theme caret', '[data-testid=theme-menu-button]'],
  ];
  for (const [name, sel] of hovers) {
    const h = await page.locator(sel).first().elementHandle();
    if (!h) { issues.push(L(`hover: ${name} not found`)); continue; }
    const before = await text(h);
    await h.hover(); await sleep(350);
    const after = await text(h);
    const bgBefore = await h.evaluate((e) => getComputedStyle(e).backgroundColor);
    const bgAfter = await h.evaluate((e) => getComputedStyle(e).backgroundColor);
    if (after) need(L(`hover ${name}`), after.ratio, name === 'heart' || name === 'theme ball' ? 3 : 4.5, `${after.fg} on ${after.bg}`);
    notes.push(L(`hover ${name}: ${before?.ratio ?? '-'} → ${after?.ratio ?? '-'}  (bg ${bgBefore} → ${bgAfter})`));
  }
  await page.mouse.move(2, 600);

  /* ---- 2. keyboard focus: every focusable element in the header and the filters shows a visible ring ---- */
  await page.goto(BASE + '/'); await page.waitForSelector('article'); await sleep(1200);
  let noRing = 0, weakRing = 0, checked = 0;
  await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  for (let i = 0; i < 28; i++) {
    await page.keyboard.press('Tab');
    const info = await page.evaluate(() => {
      const el = document.activeElement as HTMLElement | null;
      if (!el || el === document.body) return null;
      const cs = getComputedStyle(el);
      const c = (window as unknown as { __c: { shape: (c: string, e: Element) => { ratio: number } } }).__c;
      const outline = cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0;
      const ring = cs.boxShadow !== 'none';
      return { tag: el.tagName.toLowerCase(), label: (el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.textContent || el.className || '').trim().slice(0, 40), outline, ring, ratio: outline ? c.shape(cs.outlineColor, el).ratio : null };
    });
    if (!info) continue;
    checked++;
    if (!info.outline && !info.ring) { noRing++; issues.push(L(`focus: no visible ring on <${info.tag}> "${info.label}"`)); }
    else if (info.ratio !== null && info.ratio < 3) { weakRing++; issues.push(L(`focus: ring contrast ${info.ratio} on <${info.tag}> "${info.label}"`)); }
  }
  notes.push(L(`keyboard focus: ${checked} elements, ${noRing} without a ring, ${weakRing} with a weak ring`));

  /* ---- 3. inputs, selects, options, checkbox/radio, placeholder ---- */
  const search = page.locator('input[placeholder="Search venues or areas"]');
  const sH = await search.elementHandle();
  if (sH) {
    const ph = await text(sH, '::placeholder'); need(L('search placeholder'), ph?.ratio, 4.5, `${ph?.fg} on ${ph?.bg}`);
    await search.fill('Playzone'); const typed = await text(sH); need(L('typed text in the search box'), typed?.ratio, 4.5, `${typed?.fg} on ${typed?.bg}`);
    await search.focus(); await sleep(200);
    await page.screenshot({ path: `shots/state-${theme}-search-focus.png`, clip: { x: 100, y: 80, width: 1000, height: 220 } });
    await search.fill('');
  }
  for (const [name, sel] of [['city select', 'select[aria-label=City]'], ['price select', 'select >> nth=1'], ['sort select', 'select >> nth=2']] as const) {
    const h = await page.locator(sel).first().elementHandle();
    if (!h) { issues.push(L(`${name} not found`)); continue; }
    const t = await text(h); need(L(`${name} text`), t?.ratio, 4.5, `${t?.fg} on ${t?.bg}`);
    const border = await h.evaluate((e) => getComputedStyle(e).borderColor);
    const sh = await shape(h, border); need(L(`${name} border vs background (non-text 3:1)`), sh.ratio, 3, sh.colour);
    const opts = await h.evaluate((e) => [...(e as HTMLSelectElement).options].slice(0, 3).map((o) => { const cs = getComputedStyle(o); return { color: cs.color, bg: cs.backgroundColor, scheme: cs.colorScheme }; }));
    const scheme = await h.evaluate((e) => getComputedStyle(e).colorScheme);
    notes.push(L(`${name}: colour-scheme ${scheme}; option colours ${JSON.stringify(opts[0])}`));
    if (theme === 'dark') { if (!/dark/.test(scheme)) issues.push(L(`${name}: colour-scheme is "${scheme}", native dropdown will be light`)); }
  }
  // the login form inputs
  await page.getByRole('button', { name: 'Log in', exact: true }).first().click();
  await page.getByPlaceholder('Your name').waitFor();
  for (const [name, sel] of [['name', 'input[placeholder="Your name"]'], ['phone', 'input[placeholder="Phone (10 digits)"]'], ['otp', 'input[placeholder="OTP"]']] as const) {
    const h = await page.locator(sel).elementHandle();
    if (!h) continue;
    const ph = await text(h, '::placeholder'); need(L(`login ${name} placeholder`), ph?.ratio, 4.5, `${ph?.fg} on ${ph?.bg}`);
    await h.fill('1234'); const tt = await text(h); need(L(`login ${name} text`), tt?.ratio, 4.5, `${tt?.fg} on ${tt?.bg}`);
    const border = await h.evaluate((e) => getComputedStyle(e).borderColor);
    const sh = await shape(h, border); need(L(`login ${name} border`), sh.ratio, 3, sh.colour);
    await h.fill('');
  }
  const dlg = page.locator('[role=dialog]');
  const dBg = await dlg.evaluate((e) => getComputedStyle(e).backgroundColor);
  const scrim = await dlg.evaluate((e) => getComputedStyle(e.parentElement as Element).backgroundColor);
  notes.push(L(`login modal: panel ${dBg}, scrim ${scrim}`));
  await page.screenshot({ path: `shots/state-${theme}-login-modal.png` });
  // every text in the modal
  for (const h of await dlg.locator('label, p, h2, button, a, span').elementHandles()) {
    const t = await text(h); const s = await h.evaluate((e) => (e.textContent ?? '').trim().slice(0, 30));
    if (t && s) need(L(`login modal "${s}"`), t.ratio, 4.5, `${t.fg} on ${t.bg}`);
  }
  await page.keyboard.press('Escape'); await page.getByLabel('Close').click().catch(() => {});
  await sleep(300);

  /* ---- 4. logged in: menus, toast, disabled, skeleton, active, checkbox ---- */
  await ctx.addInitScript(([t, token]) => { localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, token, city: 'Bengaluru' } })); }, [theme, tok] as const);
  const p2 = await ctx.newPage();
  await p2.goto(BASE + '/'); await p2.waitForSelector('article'); await p2.getByTestId('wallet-chip').waitFor(); await sleep(1200);
  await p2.getByTestId('user-menu').click(); await sleep(300);
  await p2.screenshot({ path: `shots/state-${theme}-user-menu.png`, clip: { x: 800, y: 0, width: 400, height: 460 } });
  for (const h of await p2.locator('details[open] a, details[open] button, details[open] label, details[open] p').elementHandles()) {
    const t = await text(h); const s = await h.evaluate((e) => (e.textContent ?? '').trim().slice(0, 30));
    if (t && s) need(L(`user menu "${s}"`), t.ratio, 4.5, `${t.fg} on ${t.bg}`);
  }
  await p2.keyboard.press('Escape'); await p2.mouse.click(5, 400);
  await p2.getByTestId('theme-menu-button').click(); await sleep(250);
  await p2.screenshot({ path: `shots/state-${theme}-theme-menu.png`, clip: { x: 800, y: 0, width: 400, height: 200 } });
  for (const h of await p2.locator('[data-testid=theme-menu] button').elementHandles()) { const t = await text(h); const s = await h.evaluate((e) => (e.textContent ?? '').trim()); if (t) need(L(`theme menu "${s}"`), t.ratio, 4.5, `${t.fg} on ${t.bg}`); }
  await p2.mouse.click(5, 400);
  await p2.getByTestId('more-menu').click(); await sleep(250);
  for (const h of await p2.locator('details[open] a').elementHandles()) { const t = await text(h); const s = await h.evaluate((e) => (e.textContent ?? '').trim()); if (t) need(L(`more menu "${s}"`), t.ratio, 4.5, `${t.fg} on ${t.bg}`); }
  await p2.mouse.click(5, 400);

  // toasts (ok and error) from the Lab buttons
  await p2.goto(BASE + '/lab'); await p2.getByRole('button', { name: 'emit toast here' }).waitFor(); await sleep(800);
  await p2.getByRole('button', { name: 'emit toast here' }).click(); await sleep(400);
  const toast = await p2.locator('[role=status]').first().elementHandle();
  if (toast) { const t = await text(toast); need(L('toast (ok)'), t?.ratio, 4.5, `${t?.fg} on ${t?.bg}`); await p2.screenshot({ path: `shots/state-${theme}-toast.png`, clip: { x: 800, y: 700, width: 400, height: 200 } }); } else issues.push(L('no toast appeared'));
  // an error toast: simulate failures and try to save a favourite
  await p2.getByLabel(/fail every write/i).check().catch(() => {});
  await p2.goto(BASE + '/'); await p2.waitForSelector('article'); await sleep(800);
  await p2.getByRole('button', { name: 'Add to favourites' }).first().click().catch(() => {}); await sleep(900);
  const errToast = p2.locator('[role=status]').filter({ hasText: /couldn/i }).first();
  const eh = await errToast.elementHandle().catch(() => null);
  if (eh) { const t = await text(eh); need(L('toast (error)'), t?.ratio, 4.5, `${t?.fg} on ${t?.bg}`); }

  // disabled + skeleton + active (pressed) + checkbox/radio on the wallet page
  await ctx.route('**/api/**', async (r) => { if (!/\/api\/(me|badges)/.test(r.request().url())) await sleep(2500); await r.continue().catch(() => {}); });
  const p3 = await ctx.newPage();
  await p3.goto(BASE + '/bookings', { waitUntil: 'commit' }); await sleep(1300);
  const skel = await p3.$('.animate-pulse');
  if (skel) {
    const c = await skel.evaluate((e) => getComputedStyle(e).backgroundColor);
    const sh = await shape(skel, c);
    notes.push(L(`skeleton: fill ${c}, visible against its surface at ${sh.ratio}:1`));
    need(L('skeleton visible against the page (≥1.15)'), sh.ratio, 1.15, c);
    await p3.screenshot({ path: `shots/state-${theme}-skeleton.png` });
  } else notes.push(L('skeleton: none on screen at that moment'));
  await ctx.unroute('**/api/**');
  await sleep(3500); await p3.goto(BASE + '/wallet'); await p3.waitForSelector('[data-testid=wallet-balance]', { timeout: 15000 }); await sleep(500);
  const pay = p3.getByRole('button', { name: /^Pay/ }).first();
  const radio = await p3.locator('input[type=radio]').first().elementHandle();
  if (radio) { const acc = await radio.evaluate((e) => getComputedStyle(e).accentColor); notes.push(L(`radio accent colour: ${acc}`)); }
  // active (mouse held down) on a brand button
  const payH = await pay.elementHandle();
  if (payH) {
    const before = await text(payH);
    const box = await pay.boundingBox();
    if (box) { await p3.mouse.move(box.x + box.width / 2, box.y + box.height / 2); await p3.mouse.down(); await sleep(250); }
    const active = await text(payH);
    await p3.screenshot({ path: `shots/state-${theme}-active-button.png`, clip: { x: 100, y: Math.max(0, (box?.y ?? 400) - 60), width: 700, height: 160 } });
    await p3.mouse.up();
    need(L('active (pressed) brand button'), active?.ratio, 4.5, `${active?.fg} on ${active?.bg}`);
    notes.push(L(`pay button text contrast: normal ${before?.ratio} / pressed ${active?.ratio}`));
  }
  // a disabled button: visible and distinguishable
  await p3.goto(BASE + '/wallet?tab=gift'); await p3.waitForSelector('[data-testid=buy-gift-card]'); await sleep(800);
  await p3.locator('[data-testid=gift-amount-custom]').click().catch(() => {});
  await p3.locator('[data-testid=gift-custom-amount]').fill('5').catch(() => {});
  const dis = await p3.locator('[data-testid=buy-gift-card]').elementHandle();
  if (dis) {
    const isDis = await dis.evaluate((e) => (e as HTMLButtonElement).disabled);
    const t = await text(dis);
    notes.push(L(`disabled button: disabled=${isDis}, text contrast ${t?.ratio} (exempt from WCAG, but should stay readable ≥ 3: ${t && t.ratio >= 3 ? 'yes' : 'NO'})`));
    if (isDis) need(L('disabled button still readable'), t?.ratio, 3, `${t?.fg} on ${t?.bg}`);
    await p3.screenshot({ path: `shots/state-${theme}-disabled.png` });
  }
  await ctx.close();
}

console.log('\n--- notes ---');
notes.forEach((n) => console.log(n));
console.log(`\n--- ${issues.length} issue(s) ---`);
issues.forEach((i) => console.log('ISSUE', i));
await browser.close();
process.exit(issues.length ? 1 : 0);
