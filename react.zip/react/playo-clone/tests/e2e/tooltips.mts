// Tooltips, for real: mouse hover, keyboard focus, touch long-press and tap, in both themes.
// Checks the text, that the bubble stays on screen, aria-describedby, that it goes away (leave / Escape / timeout), that it does not block clicks,
// and that its text is readable (4.5:1) in light and dark.
//   Run: BASE=http://localhost:3000 API=http://localhost:4000/api node --experimental-strip-types tooltips.mts
import { chromium, type BrowserContext, type Page } from 'playwright-core';
import { api, apiUser, isoDay } from './glib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3000';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
let passed = 0, failed = 0;
const failures: string[] = [];
async function check(name: string, fn: () => Promise<string | void>) {
  try { const note = await fn(); passed++; if (process.env.VERBOSE) console.log(`PASS ${name}${note ? ` — ${note}` : ''}`); }
  catch (e) { failed++; const m = `FAIL ${name}: ${(e as Error).message.split('\n').slice(0, 3).join(' | ')}`; failures.push(m); console.log(m); }
}
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };

const stamp = Date.now();
const me = await apiUser(`Tip ${stamp}`, String(3300000000 + (stamp % 99999999)));
await api(me.token, 'POST', '/games', { title: 'A game with a very long title that cannot possibly fit in the chat list row', sport: 'football', venueId: 3, startsAt: `${isoDay(3)}T18:00`, capacity: 6, level: 'Beginner', joinMode: 'approval', visibility: 'public', minLevel: null, priceInr: 0 }).catch(() => null);

const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });

/** Cases: where, which element, what the tooltip must say. */
type Case = { name: string; path: string; sel: string; text: string | RegExp; login?: boolean; prep?: (p: Page) => Promise<void> };
const cases: Case[] = [
  { name: 'wallet chip', path: '/', sel: '[data-testid=wallet-chip]', text: 'Wallet balance (tap to add money)' },
  { name: 'unread bell badge', path: '/', sel: '[data-testid=bell-badge]', text: /\d+ unread notifications/ },
  { name: 'live-updates dot', path: '/', sel: '[data-testid=socket-status]', text: /Live updates/ },
  { name: 'theme ball (title)', path: '/', sel: '[data-testid=theme-toggle]', text: 'Switch light / dark' },
  { name: 'theme caret (aria-label)', path: '/', sel: '[data-testid=theme-menu-button]', text: /Choose theme/ },
  { name: 'city select', path: '/', sel: 'select[aria-label=City]', text: 'Choose your city' },
  { name: 'account menu', path: '/', sel: '[data-testid=user-menu]', text: 'Your account' },
  { name: 'favourites count (title)', path: '/', sel: 'header span:has-text("♥")', text: 'Favourite venues' },
  { name: 'favourite heart (aria-label)', path: '/', sel: 'button[aria-label="Add to favourites"]', text: 'Add to favourites' },
  { name: 'venue rating badge', path: '/', sel: '[data-tip^="Rated"]', text: /Rated [\d.]+ out of 5/ },
  { name: 'gallery arrow', path: '/venues/3', sel: '[data-testid=gallery-prev]', text: 'Previous photo' },
  { name: 'gallery thumbnail', path: '/venues/3', sel: '[data-testid=gallery-thumb]', text: /Show photo 1/ },
  { name: 'disabled Book now', path: '/venues/3', sel: '[data-testid=book-now]', text: 'Pick at least one hourly slot first' },
  { name: 'disabled Redo', path: '/venues/3', sel: 'button[data-tip="Nothing to redo yet"]', text: 'Nothing to redo yet' },
  { name: 'disabled past slot (title)', path: '/venues/3', sel: 'button[data-testid^=slot-]:disabled', text: /./ },
  { name: 'price chip', path: '/games', sel: '[data-testid^=price-]', text: /Free to join|Price per player/ },
  { name: 'host-approves chip', path: '/games', sel: '[data-tip^="The host approves"]', text: /host approves each request/ },
  { name: 'cut-off chat title', path: '/chat', sel: 'span.truncate', text: /A game with a very long title/ },
  { name: 'unread count', path: '/notifications', sel: '[data-testid=unread-count]', text: /\d+ unread/ },
  { name: 'disabled Redeem', path: '/wallet?tab=gift', sel: '[data-testid=redeem-gift-card]', text: 'Type the gift card code first' },
  { name: 'disabled Join Plus', path: '/plus', sel: '[data-testid=subscribe-plus]', text: /Not enough wallet balance/ },
  { name: 'emoji picker button', path: '/profile', sel: 'button[aria-label^="Emoji"]', text: /Emoji/ },
  { name: 'rating star', path: '/p/aarav_k', sel: 'button[aria-label="3 stars"]', text: '3 stars' },
  { name: 'dialog close ×', path: '/help/tickets', sel: '[role=dialog] button[aria-label=Close]', text: 'Close', prep: async (p) => { await p.locator('[data-testid=new-ticket]').click(); await p.locator('[role=dialog]').waitFor(); } },
  { name: 'disabled login button', path: '/', sel: '[role=dialog] button[data-tip]', text: /10-digit phone/, login: false, prep: async (p) => { await p.getByRole('button', { name: 'Log in', exact: true }).first().click(); await p.locator('[role=dialog]').waitFor(); } },
];

const lum = (c: number[]) => { const f = (v: number) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
const ratio = (a: number[], b: number[]) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
const rgb = (s: string) => (s.match(/[\d.]+/g) ?? []).slice(0, 3).map(Number);

async function ctxFor(theme: 'light' | 'dark', opts: { touch?: boolean; width?: number; height?: number; reduced?: boolean; out?: boolean } = {}) {
  const ctx = await browser.newContext({ viewport: { width: opts.width ?? 1200, height: opts.height ?? 900 }, colorScheme: theme, hasTouch: !!opts.touch, reducedMotion: opts.reduced ? 'reduce' : 'no-preference' });
  await ctx.addInitScript(([t, token]) => { localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, token, city: 'Bengaluru' } })); }, [theme, opts.out ? null : me.token] as const);
  return ctx;
}
const tooltip = (p: Page) => p.locator('[role=tooltip]');
async function tipInfo(p: Page) {
  return p.evaluate(() => {
    const t = document.querySelector('[role=tooltip]') as HTMLElement | null;
    if (!t) return null;
    const r = t.getBoundingClientRect(); const cs = getComputedStyle(t);
    return { text: t.textContent?.trim() ?? '', left: r.left, top: r.top, right: r.right, bottom: r.bottom, color: cs.color, bg: cs.backgroundColor, pe: cs.pointerEvents, vw: innerWidth, vh: innerHeight };
  });
}

// ---------------- mouse hover + keyboard focus, every case, both themes ----------------
for (const theme of ['light', 'dark'] as const) {
  const ctx = await ctxFor(theme);
  const outCtx = await ctxFor(theme, { out: true });
  for (const c of cases) {
    const p = await (c.login === false ? outCtx : ctx).newPage();
    await check(`[${theme}] hover: ${c.name}`, async () => {
      await p.goto(BASE + c.path); await sleep(1800);
      if (c.prep) await c.prep(p);
      const el = p.locator(c.sel).first();
      await el.waitFor({ state: 'attached', timeout: 6000 });
      await el.scrollIntoViewIfNeeded().catch(() => {});
      await sleep(350); // let the scroll event pass: scrolling hides a tooltip, by design
      const box = await el.boundingBox();
      assert(box, 'element has no box');
      await p.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
      await tooltip(p).waitFor({ state: 'visible', timeout: 2500 });
      const t = (await tipInfo(p))!;
      assert(typeof c.text === 'string' ? t.text === c.text : c.text.test(t.text), `tooltip says "${t.text}", expected ${c.text}`);
      assert(t.left >= 0 && t.top >= 0 && t.right <= t.vw && t.bottom <= t.vh, `tooltip outside the viewport: ${Math.round(t.left)},${Math.round(t.top)} → ${Math.round(t.right)},${Math.round(t.bottom)} of ${t.vw}x${t.vh}`);
      const cr = ratio(rgb(t.color), rgb(t.bg));
      assert(cr >= 4.5, `contrast ${cr.toFixed(2)}:1 (${t.color} on ${t.bg})`);
      assert(t.pe === 'none', `pointer-events ${t.pe}`);
      const described = await el.evaluate((e) => e.getAttribute('aria-describedby'));
      assert(described === 'app-tooltip', `aria-describedby is ${described}`);
      await p.mouse.move(2, 2);
      await tooltip(p).waitFor({ state: 'detached', timeout: 1500 });
      const after = await el.evaluate((e) => ({ d: e.getAttribute('aria-describedby'), t: e.hasAttribute('title') }));
      assert(after.d !== 'app-tooltip', 'aria-describedby left behind');
    });
    await p.close();
  }
  await ctx.close();
  await outCtx.close();
}

// ---------------- keyboard: Tab to a control, the tooltip shows; Escape closes it ----------------
for (const theme of ['light', 'dark'] as const) {
  const ctx = await ctxFor(theme);
  const p = await ctx.newPage();
  await check(`[${theme}] keyboard: focus shows the tooltip, Escape closes it`, async () => {
    await p.goto(BASE + '/'); await sleep(1800);
    await p.keyboard.press('Tab'); // keyboard modality: from now on programmatic focus counts as :focus-visible
    await p.locator('[data-testid=theme-menu-button]').focus();
    await tooltip(p).waitFor({ state: 'visible', timeout: 2500 });
    assert(/Choose theme/.test((await tipInfo(p))!.text), 'wrong text on focus');
    await p.keyboard.press('Escape');
    await tooltip(p).waitFor({ state: 'detached', timeout: 1000 });
    await p.locator('[data-testid=wallet-chip]').focus();
    await tooltip(p).waitFor({ state: 'visible', timeout: 2500 });
    await p.keyboard.press('Tab');
    await tooltip(p).waitFor({ state: 'detached', timeout: 1500 });
  });
  await check(`[${theme}] a mouse click focuses a control but does not pop a tooltip (only keyboard focus does)`, async () => {
    await p.goto(BASE + '/'); await sleep(1500);
    await p.locator('[data-testid=theme-menu-button]').click();
    await sleep(700);
    // the pointer is still over it, so the hover tooltip may show; move away, click again elsewhere and make sure focus alone does nothing
    await p.mouse.move(2, 400); await sleep(400);
    assert((await tooltip(p).count()) === 0, 'a tooltip stayed after the pointer left');
  });
  await check(`[${theme}] the tooltip does not block the click it is above`, async () => {
    await p.goto(BASE + '/'); await sleep(1500);
    const el = p.locator('[data-testid=theme-menu-button]');
    const box = (await el.boundingBox())!;
    await p.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await tooltip(p).waitFor({ state: 'visible', timeout: 2500 });
    await p.mouse.down(); await p.mouse.up();
    await p.locator('[data-testid=theme-menu]').waitFor({ state: 'visible', timeout: 2000 });
  });
  await p.close();
  await ctx.close();
}

// ---------------- phone: the bubble stays on screen at the right edge; touch long-press and tap ----------------
for (const theme of ['light', 'dark'] as const) {
  const ctx = await ctxFor(theme, { touch: true, width: 390, height: 800 });
  const p = await ctx.newPage();
  const cdp = await (ctx as BrowserContext & { newCDPSession: (p: Page) => Promise<{ send: (m: string, a: object) => Promise<unknown> }> }).newCDPSession(p);
  const touch = async (type: string, x: number, y: number) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: type === 'touchEnd' ? [] : [{ x, y }] });
  await check(`[${theme}] phone: long-press on the bell shows "N unread" inside the screen, then it fades`, async () => {
    await p.goto(BASE + '/'); await sleep(1800);
    const box = (await p.locator('[data-testid=bell-badge]').boundingBox())!;
    const x = box.x + box.width / 2, y = box.y + box.height / 2;
    await touch('touchStart', x, y);
    await sleep(700);
    await tooltip(p).waitFor({ state: 'visible', timeout: 1500 });
    const t = (await tipInfo(p))!;
    assert(/unread notifications/.test(t.text), t.text);
    assert(t.left >= 0 && t.right <= t.vw, `outside the screen: ${t.left}..${t.right} of ${t.vw}`);
    await touch('touchEnd', x, y);
    await tooltip(p).waitFor({ state: 'detached', timeout: 5000 });
  });
  await check(`[${theme}] phone: a quick tap still follows the link (no tooltip, no blocked click)`, async () => {
    await p.goto(BASE + '/'); await sleep(1800);
    await p.locator('a[aria-label^="Notifications"]').tap();
    await p.waitForURL('**/notifications', { timeout: 5000 });
    assert((await tooltip(p).count()) === 0, 'tooltip showing after a tap on a link');
  });
  await check(`[${theme}] phone: moving the finger cancels the long press`, async () => {
    await p.goto(BASE + '/'); await sleep(1800);
    const box = (await p.locator('[data-testid=wallet-chip]').boundingBox())!;
    const x = box.x + box.width / 2, y = box.y + box.height / 2;
    await touch('touchStart', x, y); await sleep(150);
    await touch('touchMove', x + 40, y + 40); await sleep(600);
    assert((await tooltip(p).count()) === 0, 'tooltip appeared although the finger moved away');
    await touch('touchEnd', x + 40, y + 40);
  });
  await p.close();
  await ctx.close();
}
{
  const ctx = await ctxFor('light', { touch: true });
  const p = await ctx.newPage();
  await check('touch: a tap on a count badge (not clickable) shows its tooltip for a moment', async () => {
    await p.goto(BASE + '/notifications'); await sleep(2200);
    await p.locator('[data-testid=unread-count]').tap();
    await tooltip(p).waitFor({ state: 'visible', timeout: 1500 });
    { const tx = (await tipInfo(p))!.text; assert(/\d+ unread/.test(tx), `wrong text: ${tx}`); }
    await tooltip(p).waitFor({ state: 'detached', timeout: 5000 });
  });
  await ctx.close();
}

// ---------------- reduced motion: no animation, still works ----------------
{
  const ctx = await ctxFor('dark', { reduced: true });
  const p = await ctx.newPage();
  await check('reduced motion: the tooltip appears without an animation', async () => {
    await p.goto(BASE + '/'); await sleep(1500);
    const box = (await p.locator('[data-testid=wallet-chip]').boundingBox())!;
    await p.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await tooltip(p).waitFor({ state: 'visible', timeout: 2500 });
    const anim = await tooltip(p).evaluate((e) => getComputedStyle(e).animationName);
    assert(anim === 'none', `animation ${anim}`);
  });
  await ctx.close();
}

// ---------------- the pointer leaving the window, scrolling and clicking hide it ----------------
{
  const ctx = await ctxFor('light');
  const p = await ctx.newPage();
  await check('mouse: a click, a scroll or leaving the page hides the tooltip', async () => {
    await p.goto(BASE + '/venues/3'); await sleep(1800);
    const box = (await p.locator('[data-testid=book-now]').boundingBox())!;
    await p.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await tooltip(p).waitFor({ state: 'visible', timeout: 2500 });
    await p.mouse.wheel(0, 300);
    await tooltip(p).waitFor({ state: 'detached', timeout: 1500 });
  });
  await ctx.close();
}

await browser.close();
console.log(`\ntooltips: ${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
