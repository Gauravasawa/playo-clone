// Hostile text everywhere a user can type it: names, bios, game titles, chat messages, ticket subjects. None of it may run as script or become markup.
import { chromium, type Page } from 'playwright-core';
import { api, apiUser, isoDay, stamp } from './glib.mts';

const BASE = process.env.BASE ?? 'http://localhost:3100';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const rnd = () => String(3300000000 + Math.floor(Math.random() * 99999999));

const PAYLOADS = {
  name: '<img src=x onerror=window.__xss=1>',
  bio: '</script><script>window.__xss=2</script><svg onload=window.__xss=3>',
  title: '"><script>window.__xss=4</script>',
  message: '<img src=x onerror=window.__xss=5> <a href="javascript:window.__xss=6">click</a> &lt;b&gt;',
  subject: '</title><script>window.__xss=7</script>',
};

const hostile = await apiUser(PAYLOADS.name, rnd());
const victim = await apiUser(`Victim ${stamp}`, rnd());
const me = await api(hostile.token, 'GET', '/me');
const username = `xss_${stamp % 1000000}`;
const profile = { name: PAYLOADS.name, username, bio: PAYLOADS.bio, city: 'Bengaluru', avatarEmoji: me.avatarEmoji, avatarColor: me.avatarColor, isPrivate: false, sports: me.sports, plays: me.plays };
await api(hostile.token, 'PUT', '/me/profile', profile).catch((e) => console.log('profile update refused:', e.message));
const stored = await api(hostile.token, 'GET', '/me');
console.log('stored name/bio contain the payload:', stored.name === PAYLOADS.name, stored.bio === PAYLOADS.bio);
const game = await api(hostile.token, 'POST', '/games', { title: PAYLOADS.title, sport: 'football', venueId: 3, startsAt: `${isoDay(4)}T18:00`, capacity: 6, level: 'Beginner', joinMode: 'open', visibility: 'public', minLevel: null, priceInr: 0 }).catch((e) => { console.log('game refused:', e.message); return null; });
if (game) {
  await api(victim.token, 'POST', `/games/${game.id}/join`, { method: 'wallet' }).catch(() => null);
  const chatId = game.chatId ?? (await api(victim.token, 'GET', `/games/${game.id}`)).chatId;
  if (chatId) {
    await api(hostile.token, 'POST', `/chats/${chatId}/messages`, { body: PAYLOADS.message }).catch((e) => console.log('message refused:', e.message));
    await api(victim.token, 'POST', `/chats/${chatId}/messages`, { body: PAYLOADS.message }).catch(() => null);
  }
}
await api(hostile.token, 'POST', '/tickets', { topic: 'booking', subject: PAYLOADS.subject, body: PAYLOADS.bio }).catch(() => null);

const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
let passed = 0, failed = 0;
const failures: string[] = [];

async function visit(who: 'victim' | 'hostile', theme: 'light' | 'dark', path: string) {
  const token = who === 'victim' ? victim.token : hostile.token;
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, colorScheme: theme });
  await ctx.addInitScript(([t, tk]) => { localStorage.setItem('playo:state', JSON.stringify({ $version: 4, state: { theme: t, token: tk, city: 'Bengaluru' } })); }, [theme, token] as const);
  const page: Page = await ctx.newPage();
  let dialogs = 0;
  page.on('dialog', async (d) => { dialogs++; await d.dismiss(); });
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message.slice(0, 100)));
  const tag = `[${who}/${theme}] ${path}`;
  try {
    const res = await page.goto(BASE + path);
    await sleep(1800);
    const raw = res ? await res.text() : '';
    const probe = await page.evaluate(() => ({
      xss: (window as unknown as Record<string, unknown>).__xss ?? null,
      imgs: document.querySelectorAll('img[src="x"]').length,
      handlers: document.querySelectorAll('[onerror],[onload],[onclick]').length,
      // Next's own data scripts (__NEXT_DATA__, self.__next_f) legitimately carry the text as an escaped JSON string; what must never appear is a raw <script> or </script inside a script
      injected: [...document.scripts].filter((s) => /<\/?script/i.test(s.textContent ?? '')).length,
      jsLinks: [...document.querySelectorAll('a')].filter((a) => /^\s*javascript:/i.test(a.getAttribute('href') ?? '')).length,
      shown: /<img|<script|onerror/.test(document.body.innerText),
    }));
    const problems: string[] = [];
    if (dialogs) problems.push(`${dialogs} dialog(s) opened`);
    if (probe.xss !== null) problems.push(`window.__xss = ${probe.xss}`);
    if (probe.imgs) problems.push(`${probe.imgs} injected <img src=x>`);
    if (probe.handlers) problems.push(`${probe.handlers} element(s) with an inline handler`);
    if (probe.injected) problems.push('an injected <script>');
    if (probe.jsLinks) problems.push(`${probe.jsLinks} javascript: link(s)`);
    // the raw server HTML must not contain the payloads as markup (only the Pages Router and server-rendered pages have any)
    if (/<script>window\.__xss/.test(raw) || /<img src=x onerror/.test(raw) || /<svg onload/.test(raw)) problems.push('payload present as markup in the server HTML');
    if (errors.length) problems.push(`page error: ${errors[0]}`);
    if (problems.length) { failed++; failures.push(`${tag}: ${problems.join('; ')}`); } else passed++;
    return probe.shown;
  } catch (e) { failed++; failures.push(`${tag}: ${(e as Error).message.split('\n')[0]}`); return false; }
  finally { await ctx.close(); }
}

const paths = ['/', `/p/${username}`, '/games', game ? `/games/${game.id}` : '/games', '/leaderboard', '/friends', '/chat', '/notifications', '/help/tickets', '/profile'];
let shownSomewhere = false;
for (const theme of ['light', 'dark'] as const) {
  for (const who of ['victim', 'hostile'] as const) for (const p of paths) shownSomewhere = (await visit(who, theme, p)) || shownSomewhere;
}
// the same text is shown as plain text: it appears on screen as characters, which proves it was escaped rather than dropped
console.log(shownSomewhere ? 'the payloads are visible as plain text on at least one page (escaped, not executed)' : 'note: no page showed the payload text (the server may have rejected or stripped it)');
if (game) {
  const probeRaw = await (await fetch(`${BASE}/p/${username}`)).text();
  console.log('server HTML of the profile page contains "</script><script>window.__xss": ', /<\/script><script>window\.__xss/.test(probeRaw));
}
console.log(`\nxss: ${passed} page visits clean, ${failed} with problems`);
failures.forEach((f) => console.log('FAIL', f));
await browser.close();
process.exit(failed ? 1 : 0);
